/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */
#include <set>
#include <sstream>
#include "path_planning/predict_map.hpp"

namespace senseAD {
namespace pp {

PredictMap::PredictMap() {}

PredictMap::~PredictMap() {}

adStatus_t PredictMap::Init() {
    auto conf = g_pp_conf["rrt_setting"];
    auto dqq_setting = g_pp_conf["dqq_setting"];
    debug_print_ = dqq_setting["debug_print"];
    this->predmap_as_free_ = conf["predmap_as_free"];
    this->predmap_using_ellipse_ = conf["predmap_using_ellipse"];
    slice_size_ = num_d_grid_ * num_s_front_grid_;
    cell_size_ = num_time_layers_ * num_d_grid_ * num_s_front_grid_;
    cells_3d_.Init(cell_size_);
    return AD_SUCCESS;
}

adStatus_t PredictMap::Update(
    ObjectTrajectory* object_trajectory,
    PredictionResult* prediction_result,
    const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
    const bool lane_change_activated) {
    AD_LINFO(PATH_PLANNING) << "predcitmap updating";
    frenet_system_ = frenet_system;
    this->object_trajectory_ = *object_trajectory;
    this->prediction_result_ = *prediction_result;
    lane_change_activated_ = lane_change_activated;
    obs_screen.Update(frenet_system, lane_change_activated,
      g_vehicle_state);
    return AD_SUCCESS;
}

adStatus_t PredictMap::Update(
    const PredictionObjectArray& poa,
    const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
    const bool lane_change_activated) {
    AD_LINFO(PATH_PLANNING) << "predcitmap updating";
    frenet_system_ = frenet_system;
    poa_ = poa;
    lane_change_activated_ = lane_change_activated;
    obs_screen.Update(frenet_system, lane_change_activated,
      g_vehicle_state);
    return AD_SUCCESS;
}

adStatus_t PredictMap::SetParam(float pedestrain_extrasafe_dist,
                                float vehicle_extrasafe_dist) {
    return AD_SUCCESS;
}

adStatus_t PredictMap::Refresh() {
    // 1. init map
    id_to_index_.clear();
    cells_3d_.Refresh();
    AD_LINFO(PATH_PLANNING) << "poa size "
                            << poa_.prediction_object_array.size();
    // 2. fill cells with each predict trajectory
    for (uint32_t k = 0; k < poa_.prediction_object_array.size(); ++k) {
        auto& p_obj = poa_.prediction_object_array.at(k);
        auto& ta = p_obj.trajectory_array;
        if (ta.size() == 0) {
            AD_LINFO(PATH_PLANNING) << "skipped a empty prediction object";
            continue;
        }

        // only use trajectory with maximum probability
        std::sort(ta.begin(), ta.end(), [](const PredictionTrajectory& a,
                                           const PredictionTrajectory& b) {
            return a.probability > b.probability;
        });
        auto ta_max_prob = ta.front();
        float predict_interval =
            static_cast<double>(ta.front().point_interval_time / 1e9);
        auto& predict_traj = ta.front().trajectory_point_array;

        // if (IsIgnore(predict_traj) == true) {
        //     AD_LINFO(PredictMap) << "id " << p_obj.id << " ignored";
        //     continue;
        // }
        // 0. encode obstacle id
        if (id_to_index_.find(p_obj.id) == id_to_index_.end()) {
            id_to_index_[p_obj.id] = k;
        }
        bool such_is_steady = IsStatic(predict_traj);
        obs_screen.SetObstacleState(p_obj);
        for (uint32_t i = 0; i < ta_max_prob.trajectory_point_array.size();
             i++) {
            ScreenType ignore_type = obs_screen.IsIgnore(
                ta_max_prob.trajectory_point_array.at(i));
            if(ignore_type == ScreenType::IGNORE_OBS) {
                break;
            }
            else if (ignore_type == ScreenType::IGNORE_TRAJ_POINT)
            {
                continue;
            }
            // 1. fill each timepoint with first polygon for static object
            if (true == such_is_steady) {
                std::vector<cv::Point2f> polygon_sd;
                std::set<std::pair<uint32_t, uint32_t>> sd_indice;
                auto first_tjp = ta_max_prob.trajectory_point_array.at(i);
                if (first_tjp.polygon_contour.size() < 3) {
                    AD_LINFO(PREDICT_MAP) << "No." << p_obj.id
                                          << " polygon size is less than 3";
                    break;
                }
                CalculateFrenet(first_tjp.polygon_contour, first_tjp.position,
                                &polygon_sd);
                FindSDRegion(polygon_sd, &sd_indice);
                for (uint32_t t_index = 0; t_index < num_time_layers_;
                     ++t_index)
                    for (auto& sd_index : sd_indice) {
                        cells_3d_.SetCell(TripleToOne(t_index, sd_index.first,
                                                      sd_index.second),
                                          p_obj.id);
                    }
                break;
            }
            // 2. interpolation for dynamic object
            if (0 == i) {
                // 2.1. fill on first timepoint(t = 0) without interpolation
                std::vector<cv::Point2f> polygon_sd;
                std::set<std::pair<uint32_t, uint32_t>> sd_indice;
                auto first_tjp = ta_max_prob.trajectory_point_array.at(i);
                if (first_tjp.polygon_contour.size() < 3) {
                    AD_LINFO(PREDICT_MAP) << "No." << p_obj.id
                                          << " polygon size less than 3";
                    break;
                }
                CalculateFrenet(first_tjp.polygon_contour, first_tjp.position,
                                &polygon_sd);
                FindSDRegion(polygon_sd, &sd_indice);
                uint32_t t_index = 0;
                for (auto& sd_index : sd_indice) {
                    cells_3d_.SetCell(
                        TripleToOne(t_index, sd_index.first, sd_index.second),
                        p_obj.id);
                }
            } else {
                // 2.2. fill on timepoints in ((i - 1) * predict_interval, i
                // * predict_invterval] with interpolation
                uint32_t t_index_begin =
                    static_cast<uint32_t>(std::ceil(predict_interval * (i - 1) /
                                                    (time_layer_width_)) +
                                          1.0);
                uint32_t t_index_end = static_cast<uint32_t>(
                    std::ceil(predict_interval * i / (time_layer_width_)));
                auto tjp_pre = predict_traj.at(i - 1);
                auto tjp = predict_traj.at(i);
                for (uint32_t t_index = t_index_begin; t_index <= t_index_end;
                     ++t_index) {
                    float t_curr =
                        static_cast<float>(t_index * time_layer_width_);
                    float ratio = (t_curr - predict_interval * (i - 1)) /
                                  predict_interval;
                    cv::Point2f move_vec = predict_traj.at(i).position -
                                           predict_traj.at(i - 1).position;
                    float rotate_angle =
                        std::atan2(predict_traj.at(i).direction.y,
                                   predict_traj.at(i).direction.x) -
                        std::atan2(predict_traj.at(i - 1).direction.y,
                                   predict_traj.at(i - 1).direction.x);
                    std::vector<cv::Point2f> polygon_new, polygon_sd;
                    std::set<std::pair<uint32_t, uint32_t>> sd_indice;
                    MovePolygon(predict_traj.at(i - 1).polygon_contour,
                                move_vec * ratio, rotate_angle * ratio,
                                &polygon_new);
                    CalculateFrenet(
                        polygon_new,
                        predict_traj.at(i - 1).position + ratio * move_vec,
                        &polygon_sd);

                    FindSDRegion(polygon_sd, &sd_indice);
                    for (auto& sd_index : sd_indice) {
                        cells_3d_.SetCell(TripleToOne(t_index, sd_index.first,
                                                      sd_index.second),
                                          p_obj.id);
                    }
                }
            }
        }
    }
    // 3. print for debug
    if (debug_print_ == 1) {
        std::string data_path =
            "/tmp/today-logs/" + utils::GetTimestampString() + "predictmap.txt";
        std::stringstream ss;
        for (uint32_t t_index = 0; t_index < num_time_layers_; ++t_index) {
            ss << t_index * time_layer_width_ << std::endl;
            for (uint32_t s_index = 0; s_index < num_s_front_grid_; ++s_index) {
                for (uint32_t d_index = 0; d_index < num_d_grid_; ++d_index) {
                    ss << cells_3d_.GetCell(
                              TripleToOne(t_index, s_index, d_index))
                       << ", ";
                }
                ss << std::endl;
            }
        }
        std::ofstream outfile;
        outfile.open(data_path, std::ofstream::trunc);
        outfile << ss.str();
        outfile.close();
    }
    // 4. print id to obj_id
    cells_3d_.PrintDecodeInfo();
    return AD_SUCCESS;
}

adStatus_t PredictMap::BuildMapFromVector(
    const std::vector<std::vector<int>>& vectors) {
    return AD_SUCCESS;
}

bool PredictMap::IsStatic(
    const std::vector<PredictionTrajectoryPoint>& tjp_array) {
    // determin the steadiness by max wiggle room and velocity
    double max_x = -std::numeric_limits<double>::max();
    double min_x = std::numeric_limits<double>::max();
    double max_y = -std::numeric_limits<double>::max();
    double min_y = std::numeric_limits<double>::max();
    double max_velocity = std::numeric_limits<double>::min();
    for (auto pi : tjp_array) {
        max_x = std::max(max_x, static_cast<double>(pi.position.x));
        min_x = std::min(min_x, static_cast<double>(pi.position.x));
        max_y = std::max(max_y, static_cast<double>(pi.position.y));
        min_y = std::min(min_y, static_cast<double>(pi.position.y));
        max_velocity = std::max(max_velocity, std::fabs(cv::norm(pi.speed)));
    }
    bool such_is_steady = false;
    if (max_y - min_y < 1.0 && max_x - min_x < 1.0 && max_velocity < 1.0) {
        such_is_steady = true;
    }
    return such_is_steady;
}

adStatus_t PredictMap::FindSDRegion(
    const std::vector<cv::Point2f>& polygon_sd,
    std::set<std::pair<uint32_t, uint32_t>>* sd_indice) {
    // assume mathematic computation of frenet coordinate system is the same as
    // cartesin coordinate system at local scale
    if (nullptr == sd_indice) {
        AD_LERROR(PREDICT_MAP) << "sd_indice is nullptr";
        return AD_NULL_PTR;
    }
    sd_indice->clear();
    // 1. find max and min sd of polygon
    float min_s = 100000.0;
    float max_s = -100000.0;
    float min_d = 1000.0;
    float max_d = -1000.0;
    for (const cv::Point2f& pi : polygon_sd) {
        min_s = std::min(pi.x, min_s);
        max_s = std::max(pi.x, max_s);
        min_d = std::min(pi.y, min_d);
        max_d = std::max(pi.y, max_d);
    }
    if (max_s < 0.0) {
        return AD_SUCCESS;
    }
    int min_s_index = std::floor(min_s / s_per_front_grid_);
    int max_s_index = std::ceil(max_s / s_per_front_grid_);
    int min_d_index = std::floor(min_d / d_per_grid_ + (num_d_grid_ * 0.5f));
    int max_d_index = std::ceil(max_d / d_per_grid_ + (num_d_grid_ * 0.5));

    auto round = [](int& x, const int upper_bound) {
        x = std::max(0, std::min(upper_bound, x));
    };
    round(min_s_index, num_s_front_grid_ - 1);
    round(max_s_index, num_s_front_grid_ - 1);
    round(min_d_index, num_d_grid_ - 1);
    round(max_d_index, num_d_grid_ - 1);
    for (int s_index = min_s_index; s_index <= max_s_index; ++s_index) {
        for (int d_index = min_d_index; d_index <= max_d_index; ++d_index) {
            cv::Point2f p_candidate(
                s_index * s_per_front_grid_,
                (d_index - static_cast<int>(num_d_grid_ * 0.5f)) * d_per_grid_);
            // 2. take grids lying on edge of polygon into account
            bool is_near = false;
            for (uint32_t i = 0; i < polygon_sd.size(); ++i) {
                if (std::fabs(polygon_sd.at(i).x - p_candidate.x) <
                        0.5 * s_per_front_grid_ &&
                    std::fabs(polygon_sd.at(i).y - p_candidate.y) <
                        0.5 * d_per_grid_) {
                    is_near = true;
                    break;
                }
            }
            if (true == is_near) {
                sd_indice->emplace(std::make_pair(s_index, d_index));
                continue;
            }
            for (uint32_t i = 1; i < polygon_sd.size(); ++i) {
                std::vector<cv::Point2f> line;
                line.emplace_back(polygon_sd.at(i - 1));
                line.emplace_back(polygon_sd.at(i));
                cv::Point2f foot(0.0, 0.0);
                utils::CalcPerpendicularFoot(p_candidate, line, &foot);
                // if perpendicular foot located inside two endpoints
                bool is_foot_inside = false;
                if (foot.x >= std::min(line.at(0).x, line.at(1).x) &&
                    foot.y <= std::max(line.at(0).x, line.at(1).y)) {
                    is_foot_inside = true;
                }
                if (is_foot_inside == true &&
                    std::fabs(foot.x - p_candidate.x) <
                        0.5 * s_per_front_grid_ &&
                    std::fabs(foot.y - p_candidate.y) < 0.5 * d_per_grid_) {
                    is_near = true;
                    break;
                }
            }
            if (true == is_near) {
                sd_indice->emplace(std::make_pair(s_index, d_index));
                continue;
            }
            // 3. determine if point (s, d) within polygon with cross dot
            bool is_within = true;
            for (uint32_t i = 1; i < polygon_sd.size(); ++i) {
                cv::Point2f vec1 = polygon_sd.at(i) - polygon_sd.at(i - 1);
                cv::Point2f vec2 = p_candidate - polygon_sd.at(i - 1);
                if (vec1.cross(vec2) < 0) {
                    is_within = false;
                    break;
                }
            }
            if (true == is_within) {
                sd_indice->emplace(std::make_pair(s_index, d_index));
            }
        }
    }
    return AD_SUCCESS;
}

uint32_t PredictMap::TripleToOne(const uint32_t time_index,
                                 const uint32_t s_index,
                                 const uint32_t d_index) const {
    uint32_t index = time_index * slice_size_ + s_index * num_d_grid_ + d_index;
    return index;
}

bool PredictMap::OneToTriple(const uint32_t index,
                             uint32_t* time_index,
                             uint32_t* s_index,
                             uint32_t* d_index) const {
    *time_index = index / slice_size_;
    *s_index = (index - (*time_index * slice_size_)) / num_d_grid_;
    *d_index = index - (*time_index * slice_size_) - *s_index * num_d_grid_;
    if (*time_index < num_time_layers_ && *time_index >= 0 &&
        *s_index < num_s_front_grid_ && *s_index >= 0 && *d_index >= 0 &&
        *d_index < num_d_grid_)
        return true;
    else
        return false;
}

bool PredictMap::MovePolygon(const std::vector<cv::Point2f>& polygon,
                             const cv::Point2f& move_vec,
                             const float rotate_angle,
                             std::vector<cv::Point2f>* polygon_new) {
    if (polygon.empty() || polygon_new == nullptr) {
        AD_LINFO(PATH_PLANNING) << "polygon is empty or polygon_new is null";
        return false;
    }
    polygon_new->clear();
    polygon_new->reserve(polygon.size());
    cv::Point2f center_point(0.0, 0.0);
    for (auto& pi : polygon) {
        center_point = center_point + pi;
        polygon_new->emplace_back(pi + move_vec);
    }
    center_point =
        center_point * (1.0 / static_cast<float>(polygon.size())) + move_vec;
    std::for_each(
        polygon_new->begin(), polygon_new->end(),
        [center_point, rotate_angle](cv::Point2f& p) {
            cv::Point2f p_relative = p - center_point;
            p.x = center_point.x + p_relative.x * std::cos(rotate_angle) -
                  p_relative.y * std::sin(rotate_angle);
            p.y = center_point.y + p_relative.x * std::sin(rotate_angle) +
                  p_relative.y * std::cos(rotate_angle);
        });
    return true;
}

bool PredictMap::CalculateFrenet(const std::vector<cv::Point2f>& polygon,
                                 const cv::Point2f& center,
                                 std::vector<cv::Point2f>* polygon_new) {
    if (polygon.empty() || nullptr == polygon_new) {
        AD_LINFO(PATH_PLANNING) << "polygon is empty or polygon_new is nullptr";
        return false;
    }
    // 1. get frenet coords of center poin
    auto frenet_point = frenet_system_->Cartesian2Frenet(center);
    float s = frenet_point.x, d = frenet_point.y;
    // 2. calculate frenet coords of polygon point
    polygon_new->clear();
    polygon_new->reserve(polygon.size());
    float heading_center = frenet_system_->GetHeadingAtS(s);
    for (const cv::Point2f& pi : polygon) {
        cv::Point2f pi_relative = pi - center;
        cv::Point2f p_new(-10000.0, -10000.0);
        p_new.x = s + pi_relative.x * std::cos(heading_center) +
                  pi_relative.y * std::sin(heading_center);
        p_new.y = d - pi_relative.x * std::sin(heading_center) +
                  pi_relative.y * std::cos(heading_center);
        polygon_new->emplace_back(p_new);
    }
    return true;
}

bool PredictMap::IsIgnore(
    const std::vector<PredictionTrajectoryPoint>& tjp_array) const {
    if (tjp_array.empty()) {
        return true;
    }
    // 1. ignore obstalce right behind ego car
    auto& obstacel_position = tjp_array.front().position;
    auto frenet_point = frenet_system_->Cartesian2Frenet(obstacel_position);
    float s = frenet_point.x, d = frenet_point.y;
    if (s < g_vehicle_param.length / 2.0 && std::fabs(d) < 1.5) {
        return true;
    }

    // 2. ignore the obstacles as picture below in lane keeping scanario
    /* genius painter
     *      ----
     *      |   |
     *    / |ego|\
     *   /  |car| \
     *  /   |   |  \
     * /    ----    \
     *      ignore
     *
    */

    constexpr float ignore_angle_threshold = 0.25 * M_PI;
    if (lane_change_activated_ == false && s < 0.0f &&
        std::fabs(d) < (std::fabs(s) * std::tan(ignore_angle_threshold))) {
        return true;
    }
    return false;
}

}  // namespace pp
}  // namespace senseAD
