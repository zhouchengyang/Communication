/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Dengke Wan <wandengke@sensetime.com>
 */
#include "path_planning/obstacle_screen.hpp"

namespace senseAD {
namespace pp {

ObstacleScreen::ObstacleScreen() {

}

void ObstacleScreen::Update(const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
  const bool lane_change_activated, const VehicleState & ego_state) {
    frenet_system_ = frenet_system;
    lane_change_activated_ = lane_change_activated;
    ego_car_state_ = ego_state;
}

void  ObstacleScreen::SetObstacleState(const PredictionObject &obs_predition) {
    obs_initial_speed_ = sqrt(obs_predition.speed.x * obs_predition.speed.x +
      obs_predition.speed.y * obs_predition.speed.y);
    obs_length_ = obs_predition.length;
    obs_width_ = obs_predition.width;
    obs_id_ = obs_predition.id;
}

void ObstacleScreen::limit_theta(double &theta) const{
    if (theta > M_PI) {
        theta -= 2.0 * M_PI;
    } else if (theta < -M_PI) {
        theta += 2.0 * M_PI;
    }    
}

ScreenType ObstacleScreen::IsIgnore(const PredictionTrajectoryPoint &obs_traj) const{
    double x_error = ego_car_state_.x - obs_traj.position.x;
    double y_error = ego_car_state_.y - obs_traj.position.y;
    double obs_to_ego_distance = sqrt(x_error * x_error + y_error * y_error);
    //TODO(wdk) get lane_width_ from map sdk
    const bool debug_print = false;

    // 1.ignore obstacle  which is far away(consider perception ability)
    if(obs_to_ego_distance > consider_range_) {
        if(debug_print) {
            AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_<< " ignore obstacle which is far away "
            <<obs_to_ego_distance;
        }
        return ScreenType::IGNORE_OBS;
    }

    auto obs_frenet_point = frenet_system_->Cartesian2Frenet(obs_traj.position);
    // 2.ignore obstacle which lateral_dis is far away
    //TODO(wdk) set diff d_consdie_range_ in intersection
    if(fabs(obs_frenet_point.y) > d_consdie_range_) {
        if(debug_print) {
            AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
            << " ignore obstacle which lateral_dis is far away "
            <<obs_frenet_point.y;
        }        
        return ScreenType::IGNORE_OBS;
    }
    
    cv::Point2f ego_point(ego_car_state_.x, ego_car_state_.y);
    auto ego_frenet_point = frenet_system_->Cartesian2Frenet(ego_point);
    //3.ignore obstacle is on curent road and is in the back of ego car
    //TODO(wdk) special consider when lane change 
    if((obs_frenet_point.x < (ego_frenet_point.x + g_vehicle_param.length / 2.0)) &&
      (obs_frenet_point.y < (lane_width_ / 2.0)) && (obs_frenet_point.y > (-lane_width_ / 2.0))) {
        if(debug_print) {
            AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
            << " ignore obstacle is on curent road and is in the back of ego car "
            <<" obs_s: "<<obs_frenet_point.x<<" obs_r: "
            <<obs_frenet_point.y;
        }   
        return ScreenType::IGNORE_OBS;
    }

    double vehicle_heading_refline =
        frenet_system_->GetHeadingAtS(ego_frenet_point.x);
    double vehicle_theta_error = ego_car_state_.heading - vehicle_heading_refline;
    ObstacleScreen::limit_theta(vehicle_theta_error);

    double obs_heading_refline =
        frenet_system_->GetHeadingAtS(obs_frenet_point.x);
    double obs_theta_error = atan2(obs_traj.direction.y, obs_traj.direction.x) - obs_heading_refline;
    ObstacleScreen::limit_theta(obs_theta_error);

    //4.ignore obstacle is in the back of ego_car by checking angle between obs and ego_car
    double relative_angle = atan2(y_error, x_error) - ego_car_state_.heading;
    ObstacleScreen::limit_theta(relative_angle);

    double ego_start_s = ego_frenet_point.x - g_vehicle_param.length * cos(vehicle_theta_error) / 2.0;
    double ego_end_s = ego_frenet_point.x + g_vehicle_param.length * cos(vehicle_theta_error)/ 2.0;
    double obs_end_s = obs_frenet_point.x + obs_length_ * cos(obs_theta_error) / 2.0;
    if(obs_initial_speed_ > ego_car_state_.velocity - 5.0 / 3.6) {
        if((lane_change_activated_ == false && fabs(relative_angle) < angle_check_default_) ||
          (lane_change_activated_ == true && fabs(relative_angle) < angle_check_lane_change_)) {
              if(debug_print) {
                  AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
                  << " ignore obstacle is in the back of ego_car by checking angle between obs and ego_car "
                  <<" relative_angle: "<<relative_angle<<" lane_change_activated_: "
                  <<lane_change_activated_<<" obs_initial_speed_: "<<obs_initial_speed_<<
                  " ego_speed: "<<ego_car_state_.velocity;
              }  
              return ScreenType::IGNORE_OBS;
        }
    } else
    {
        if((lane_change_activated_ == false && fabs(relative_angle) < angle_check_default_ &&
          obs_end_s < ego_start_s) ||
          (lane_change_activated_ == true && fabs(relative_angle) < angle_check_lane_change_ &&
          obs_end_s < ego_start_s)) {
              if(debug_print) {
                  AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
                  << " ignore obstacle is in the back of ego_car by checking angle between obs and ego_car "
                  <<" relative_angle: "<<relative_angle<<" lane_change_activated_: "
                  <<lane_change_activated_<<" obs_initial_speed_: "<<obs_initial_speed_<<
                  " ego_speed: "<<ego_car_state_.velocity<<" obs_end_s: "<< obs_end_s<<
                  " ego_start_s: "<<ego_start_s;
              }  
              return ScreenType::IGNORE_OBS;
        }
    }

    //5.ignore current obs point when obs is not in range (ego_front_s, s_range)
    if(obs_end_s < ego_end_s || obs_end_s > vehicle_max_consider_s_) {
        if(debug_print) {
            AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
            << " ignore current obs point when obs is not in range (ego_front_s, s_range) "
            <<" obs_end_s: "<<obs_end_s<<" ego_end_s: "<<ego_end_s;
        }   
        return ScreenType::IGNORE_TRAJ_POINT;
    }

    //6.ignore current obs point when obs is not in range (d_start, d_end)
    double obs_max_d = obs_frenet_point.y;
    double obs_min_d = obs_frenet_point.y;
    double obs_diagonal_length = sqrt(obs_length_ * obs_length_ + obs_width_ * obs_width_);
    double obs_upper_right_corner_theta = atan2(obs_traj.direction.y, obs_traj.direction.x) +
      obs_heading_refline;
    double obs_upper_left_corner_theta = atan2(obs_traj.direction.y, obs_traj.direction.x) -
      obs_heading_refline;
    obs_max_d = std::max(obs_max_d, 0.5 * obs_diagonal_length * sin(obs_upper_right_corner_theta) +
      obs_frenet_point.y);
    obs_max_d = std::max(obs_max_d, 0.5 * obs_diagonal_length * sin(obs_upper_left_corner_theta) +
      obs_frenet_point.y);
    obs_max_d = std::max(obs_max_d, -0.5 * obs_diagonal_length * sin(obs_upper_right_corner_theta) +
      obs_frenet_point.y);
    obs_max_d = std::max(obs_max_d, -0.5 * obs_diagonal_length * sin(obs_upper_left_corner_theta) +
      obs_frenet_point.y);
    obs_min_d = std::min(obs_min_d, 0.5 * obs_diagonal_length * sin(obs_upper_right_corner_theta) +
      obs_frenet_point.y);
    obs_min_d = std::min(obs_min_d, 0.5 * obs_diagonal_length * sin(obs_upper_left_corner_theta) +
      obs_frenet_point.y);
    obs_min_d = std::min(obs_min_d, -0.5 * obs_diagonal_length * sin(obs_upper_right_corner_theta) +
      obs_frenet_point.y);
    obs_min_d = std::min(obs_min_d, -0.5 * obs_diagonal_length * sin(obs_upper_left_corner_theta) +
      obs_frenet_point.y);
    //TODO(wdk) special consider when lane change
    if((obs_max_d < (-lane_width_ / 2.0)) || (obs_min_d > (lane_width_ / 2.0))) {
        if(debug_print) {
            AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
            << " ignore current obs point when obs is not in range (d_start, d_end) "
            <<" obs_max_d: "<<obs_max_d<<" obs_min_d: "<<obs_min_d;
        }   
        return ScreenType::IGNORE_TRAJ_POINT;
    }
    if(debug_print) {
        AD_LERROR(ObstacleScreen) <<"obs_id_:"<<obs_id_
        << " don't ignore  ";
    } 
    return ScreenType::NOT_IGNORE;
}

}  // namespace pp
}  // namespace senseAD
