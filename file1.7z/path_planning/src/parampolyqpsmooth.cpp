/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include <glog/logging.h>
#include <math.h>
#include <cmath>
#include <string>
#include <functional>
#include <vector>
#include <utility>
#include "path_planning/parampolyqpsmooth.hpp"
#include "eigen3/Eigen/Core"
#include "path_planning/util.hpp"

namespace senseAD {
namespace pp {

ParamPolyQPSmoother::ParamPolyQPSmoother(int order) {
    this->order_ = order;
    is_result_available_ = false;
}

void ParamPolyQPSmoother::SetData(const std::vector<TrajectoryPoint> &tps) {
    this->data = tps;
}

ParamPolyCurve ParamPolyQPSmoother::GetFinalResult() { return curve; }

void ParamPolyQPSmoother::Fit() {
    // why we smooth if there is only one point?
    if (this->data.size() < 2) return;
    // 1. build Q matrix and R vector for QP problem
    // The start point and goal point will be add as constrast
    // Therefore, the Q matrix contains only the middle points and minimize them
    double *Q_f = nullptr;
    double *R_f = nullptr;
    std::vector<float> arr_t;
    for (uint32_t i = 0; i < this->data.size(); i++) {
        float t;
        if (i == 0) {
            t = 0.0f;
        } else {
            t = arr_t[arr_t.size() - 1] +
                utils::cvnorm(this->data[i].position -
                              this->data[i - 1].position);
        }
        arr_t.push_back(t);
    }
    max_dist_estimate_ = arr_t[arr_t.size() - 1];
    for (uint32_t i = 0; i < arr_t.size() && arr_t[arr_t.size() - 1] > 1e-4;
         i++) {
        arr_t[i] /= arr_t[arr_t.size() - 1];
        arr_t[i] *= this->scale_;
    }
    if (this->data.size() > 2) {
        int row_A = (this->data.size() - 2) * 2;
        int col_A = (this->order_ + 1) * 2;
        Eigen::MatrixXd A(row_A, col_A);
        Eigen::MatrixXd y(row_A, 1);
        for (uint32_t i = 1; i < this->data.size() - 1; i++) {
            float t = 1.0f;
            for (int j = 0; j < (this->order_ + 1) * 2; j++) {
                if (j < this->order_ + 1) {
                    A(2 * i - 2, j) = t;
                    A(2 * i - 1, j) = 0;
                    t = t * arr_t[i];
                } else {
                    if (j == this->order_ + 1) t = 1.0f;
                    A(2 * i - 2, j) = 0;
                    A(2 * i - 1, j) = t;
                    t = t * arr_t[i];
                }
                y(2 * i - 2, 0) = this->data[i].position.x;
                y(2 * i - 1, 0) = this->data[i].position.y;
            }
        }
        auto Q = A.transpose() * A;
        auto R = -(y.transpose() * A).transpose();
        Q_f = new double[(this->order_ + 1) * 2 * (this->order_ + 1) * 2];
        R_f = new double[(this->order_ + 1) * 2];
        for (int i = 0; i < this->order_ + 1 * 2; i++) {
            for (int j = 0; j < this->order_ + 1 * 2; j++) {
                Q_f[(this->order_ + 1) * 2 * i + j] = Q(i, j);
            }
            R_f[i] = R(i, 0);
        }
    } else {
        Q_f = new double[(this->order_ + 1) * 2 * (this->order_ + 1) * 2];
        R_f = new double[(this->order_ + 1) * 2];
        std::fill(Q_f, Q_f + (this->order_ + 1) * (this->order_ + 1) * 4, 0);
        std::fill(R_f, R_f + (this->order_ + 1) * 2, 0);
    }
    double *lqy = new double[(this->order_ + 1) * 2];
    double *uqy = new double[(this->order_ + 1) * 2];
    std::fill(lqy, lqy + (this->order_ + 1) * 2, -1);
    std::fill(uqy, uqy + (this->order_ + 1) * 2, 1);
    lqy[1] = lqy[1 + this->order_ + 1] = -1;
    uqy[1] = uqy[1 + this->order_ + 1] = 1;
    // 2. set constraints
    // Generally, we have six constraints + x'(t) >= 0 sampling
    // + -max_acc <= x''(t) <= max_acc + -max_acc <= y''(t) <= max_acc
    // (+ -max_jerk <= x'''(t) <= max_jerk + -max_jerk <= y'''(t) <= max_jerk)
    // (not implement yet)
    const int num_x_t_sampling = 50;
    // TODO(some): pass cpplint
    double *constraints =
        new double[(this->order_ + 1) * 2 * (6 + num_x_t_sampling * 3)];
    double *leqy = new double[6 + num_x_t_sampling * 3];
    double *ueqy = new double[6 + num_x_t_sampling * 3];
    std::fill(constraints,
              constraints + (this->order_ + 1) * 2 * (6 + num_x_t_sampling * 3),
              0);
    // 1) the start and goal point (4 contraints, because x and y are seperated)
    double a_tt = 1.0;
    for (int i = 0; i < this->order_ + 1; i++) {
        // goal point
        constraints[i] = constraints[(this->order_ + 1) * 3 + i] = a_tt;
        a_tt = a_tt * this->scale_;
    }
    // start point
    constraints[(this->order_ + 1) * 4] = 1;
    constraints[(this->order_ + 1) * 7] = 1;
    leqy[0] = ueqy[0] = this->data[this->data.size() - 1].position.x;
    leqy[1] = ueqy[1] = this->data[this->data.size() - 1].position.y;
    leqy[2] = ueqy[2] = this->data[0].position.x;
    leqy[3] = ueqy[3] = this->data[0].position.y;
    // 2) the start direction and goal direction (2 constraints)
    double gx = this->data[this->data.size() - 1].direction.x;
    double gy = this->data[this->data.size() - 1].direction.y;
    double sx = this->data[0].direction.x;
    double sy = this->data[0].direction.y;
    a_tt = 1.0;
    for (int i = 0; i < this->order_ + 1; i++) {
        constraints[(this->order_ + 1) * 8 + i] = gy * i * a_tt;
        constraints[(this->order_ + 1) * 9 + i] = -gx * i * a_tt;
        a_tt = a_tt * this->scale_;
    }
    constraints[(this->order_ + 1) * 10 + 1] = sy;
    constraints[(this->order_ + 1) * 11 + 1] = -sx;
    leqy[4] = ueqy[4] = 0;
    leqy[5] = ueqy[5] = 0;
    double ct = 0;
    double rt = this->scale_ * 1.0 / num_x_t_sampling;
    for (int i = 0; i < num_x_t_sampling; i++) {
        double bt = 1.0;
        for (int j = 1; j < order_ + 1; j++) {
            constraints[(this->order_ + 1) * (2 * i + 12) + j] = bt * j;
            bt = bt * ct;
        }
        ct += rt;
        leqy[6 + i] = 0;
        ueqy[6 + i] = 100000;
    }
    // acc constraints
    ct = 0;
    rt = this->scale_ * 1.0 / num_x_t_sampling;
    for (int i = 0; i < num_x_t_sampling; i++) {
        double bt = 1.0;
        for (int j = 2; j < order_ + 1; j++) {
            int constraints_x_index =
                (this->order_ + 1) * 2 * (6 + num_x_t_sampling + i) + j;
            int constraints_y_index =
                (this->order_ + 1) * 2 * (6 + num_x_t_sampling * 2 + i) +
                this->order_ + 1 + j;
            constraints[constraints_x_index] = bt * j * (j - 1);
            constraints[constraints_y_index] = bt * j * (j - 1);
            bt = bt * ct;
        }
        ct += rt;
        leqy[6 + num_x_t_sampling + i] = -2;
        ueqy[6 + num_x_t_sampling + i] = 2;
        leqy[6 + num_x_t_sampling * 2 + i] = -2;
        ueqy[6 + num_x_t_sampling * 2 + i] = 2;
    }
    // 3. Init QP Problem and solve
    qpOASES::HessianType hessian_type;
    qpOASES::Options my_options;
    my_options.enableRegularisation = ::qpOASES::BT_TRUE;
    // TODO(eteced) move to gflags
    my_options.epsNum = -1e-3;
    my_options.epsDen = 1e-3;
    my_options.epsIterRef = 1e-3;
    my_options.terminationTolerance = 1e-3;
    int max_iter = 4000;
    if (this->data.size() > 2) {
        hessian_type = qpOASES::HST_SEMIDEF;
    } else {
        hessian_type = qpOASES::HST_ZERO;
    }
    qpOASES::QProblem qp_problem((this->order_ + 1) * 2,
                                 (6 + num_x_t_sampling * 3), hessian_type);
    qp_problem.setOptions(my_options);
    qp_problem.setPrintLevel(qpOASES::PL_NONE);
    auto ret =
        qp_problem.init(Q_f, R_f, constraints, lqy, uqy, leqy, ueqy, max_iter);
    if (ret != qpOASES::SUCCESSFUL_RETURN) {
        if (ret == qpOASES::RET_MAX_NWSR_REACHED) {
            AD_LERROR(PATH_PLANNING) << "qpOASES solver failed"
                                     << " due to reached max iteration";
        } else {
            AD_LERROR(PATH_PLANNING) << "qpOASES solver failed"
                                     << " due to infeasibility"
                                     << " or other internal reasons";
        }
    }
    // 4. copy result to ParamPolyCurve and set flag
    double *result = new double[(this->order_ + 1) * 2];
    curve.xt_param.clear();
    curve.yt_param.clear();
    curve.order = this->order_;
    qp_problem.getPrimalSolution(result);
    for (int i = 0; i < this->order_ + 1; i++) {
        curve.xt_param.push_back(result[i]);
        curve.yt_param.push_back(result[i + this->order_ + 1]);
    }
    is_result_available_ = (qp_problem.isSolved() == qpOASES::BT_TRUE);
    // 5. free memory
    delete[] Q_f;
    delete[] R_f;
    delete[] constraints;
    delete[] leqy;
    delete[] ueqy;
    delete[] lqy;
    delete[] uqy;
    delete[] result;
}

std::vector<TrajectoryPoint> ParamPolyQPSmoother::SamplePoints(
    float insert_distance) {
    std::vector<TrajectoryPoint> tp;
    if (!this->is_result_available_) {
        return tp;
    }
    float dt = this->scale_ * insert_distance / this->max_dist_estimate_;
    if (dt < 0.005) {
        dt = 0.005;
    }
    for (float t = 0; t < this->scale_; t += dt) {
        cv::Point2f pos, pos_d, pos_dd;
        // float a, b, c, rt;
        // TODO(some): abc not used
        float rt;
        rt = 1.0;
        for (int i = 0; i < this->order_ + 1; i++) {
            pos.x += rt * curve.xt_param[i];
            pos.y += rt * curve.yt_param[i];
            if (i < this->order_) {
                pos_d.x += rt * curve.xt_param[i + 1] * (i + 1);
                pos_d.y += rt * curve.yt_param[i + 1] * (i + 1);
            }
            if (i < this->order_ - 1) {
                pos_dd.x += rt * curve.xt_param[i + 2] * (i + 1) * (i + 2);
                pos_dd.y += rt * curve.yt_param[i + 2] * (i + 1) * (i + 2);
            }
            rt = rt * t;
        }
        float theta = 0;
        if (pos_d.x == 0) {
            if (pos_d.y > 0) {
                theta = M_PI / 2;
            } else if (pos_d.y < 0) {
                theta = -M_PI / 2;
            } else {
                theta = 0;
            }
        } else {
            theta = atan(pos_d.y / pos_d.x);
        }
        float curvature = (pos_d.x * pos_dd.y - pos_dd.x * pos_d.y) /
                          pow(pos_d.x * pos_d.x + pos_d.y * pos_d.y, 3.0 / 2.0);
        auto direction = pos_d;

        direction = direction * (1.0 / cv::norm(direction));

        TrajectoryPoint new_traj_point = TrajectoryPoint();

        new_traj_point.position = pos;
        new_traj_point.direction = direction;
        new_traj_point.velocity = 0.0;
        new_traj_point.theta = theta;
        new_traj_point.curvature = curvature;
        VLOG(4) << "[DEBUG] "
                << "ParamPolyQPSmoother Smooth adding "
                << new_traj_point.position << " " << new_traj_point.direction;
        tp.push_back(new_traj_point);
    }
    return tp;
}

}  // namespace pp
}  // namespace senseAD
