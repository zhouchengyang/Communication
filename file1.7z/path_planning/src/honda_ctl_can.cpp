/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#include "path_planning/honda_ctl_can_sender.hpp"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

// struct sockaddr_in can_addr;

namespace senseAD {
namespace pp {

union CanPacket {
    struct {
        int yaw_rate;        // * DECIMAL_GAIN
        int steering_angle;  // * DECIMAL_GAIN
        int brake;
        int speed;  // * DECIMAL_GAIN
    } msg_buf;
    char content[sizeof(int) * 4];
};

adStatus_t HondaCtlCanSender::set_ip_addr(const std::string ip_addr) {
    can_sock = socket(AF_INET, SOCK_DGRAM, 0);
    can_addr.sin_addr.s_addr = inet_addr(ip_addr.c_str());
    can_addr.sin_port = htons(can_PORT);
    can_addr.sin_family = AF_INET;
    if (can_sock <= 0) {
        AD_LINFO(PATH_PLANNING) << "fail to create can socket";
    }
    return AD_SUCCESS;
}

HondaCtlCanSender::~HondaCtlCanSender() {}
HondaCtlCanSender::HondaCtlCanSender() {}

adStatus_t HondaCtlCanSender::SetVehicleInfo(const VehicleInfo& vi) {
    this->vi_ = vi;
    return AD_SUCCESS;
}

adStatus_t HondaCtlCanSender::SendHCIPacket() {
    CanPacket can_packet;
    errno = 0;

    // msg.v_ref * DECIMAL_GAIN;
    can_packet.msg_buf.yaw_rate =
        static_cast<int>(vi_.angular_yaw_rate * DECIMAL_GAIN);
    // msg.v_ref * DECIMAL_GAIN;
    can_packet.msg_buf.steering_angle =
        static_cast<int>(vi_.steering_angle * DECIMAL_GAIN);
    can_packet.msg_buf.brake =
        vi_.brake > 15.0 ? static_cast<int>(1) : static_cast<int>(0);
    // msg.v_ref * DECIMAL_GAIN;
    can_packet.msg_buf.speed =
        static_cast<int>(vi_.vehicle_speed * DECIMAL_GAIN);
    sendto(can_sock, can_packet.content, sizeof(can_packet), 0,
           (struct sockaddr*)&can_addr, sizeof(can_addr));
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
