/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#include "path_planning/honda_ctl_sig_sender.hpp"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

namespace senseAD {
namespace pp {

union SigPacket {
    struct {
        int speed;          // m/s * DECIMAL_GAIN
        int stop;           // 0:Go, 1:Stop
        int stop_distance;  // m * DECIMAL_GAIN
        int go_ok;
    } msg_buf;
    char content[sizeof(int) * 4];
};

HondaCtlSigSender::HondaCtlSigSender() {}

adStatus_t HondaCtlSigSender::set_ip_addr(const std::string ip_addr) {
    sig_sock = socket(AF_INET, SOCK_DGRAM, 0);
    sig_addr.sin_addr.s_addr = inet_addr(ip_addr.c_str());
    sig_addr.sin_port = htons(sig_PORT);

    sig_addr.sin_family = AF_INET;
    return AD_SUCCESS;
}

HondaCtlSigSender::~HondaCtlSigSender() {}

adStatus_t HondaCtlSigSender::SetHCI(const HondaCtlInput& hci) {
    this->hci_ = hci;
    return AD_SUCCESS;
}

adStatus_t HondaCtlSigSender::SendHCIPacket() {
    SigPacket sig_packet;
    // msg.v_ref * DECIMAL_GAIN;
    sig_packet.msg_buf.speed = static_cast<int>(hci_.tgt_speed * DECIMAL_GAIN);
    // (bool)msg.stop;
    sig_packet.msg_buf.stop = static_cast<int>(hci_.stop_detected);
    //  msg.stop_dist * DECIMAL_GAIN;
    sig_packet.msg_buf.stop_distance =
        static_cast<int>(hci_.stop_distance * DECIMAL_GAIN);
    sig_packet.msg_buf.go_ok = static_cast<int>(1);
    sendto(sig_sock, sig_packet.content, sizeof(sig_packet), 0,
           (struct sockaddr*)&sig_addr, sizeof(sig_addr));
    errno = 0;
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
