/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Zhu Yuzhang <zhuyuzhang@sensetime.com>
 * zhuhaibo <zhuhaibo@sensetime.com>
 */
#include <mutex>
#include <vector>
#include <string>
#include <limits>
#include <fstream>
#include <limits>
#include <sstream>
#include "json11.hpp"
#include "path_planning/pp_evaluation.hpp"
#include "common/utils/path_util.hpp"
#include "common/common_tools.hpp"

namespace senseAD {
namespace pp {

adStatus_t PPEvaluation::Init(const std::string &estimator_config_file,
                              const std::string &results_save_directory,
                              const std::string &results_save_pattern_name,
                              const std::string &testcase_id) {
    if (false ==
        senseAD::common::utils::FileSystem::MakeDirs(results_save_directory)) {
        AD_LERROR(PP_EVALUATION) << "Cannot create results save directory: "
                                 << results_save_directory;
    }

    std::string results_save_file_name =
        testcase_id + "-" + results_save_pattern_name;
    output_file_path_ =
        JOIN_PATH(results_save_directory, results_save_file_name);
    output_file_path_ = JOIN_PATH(
        senseAD::common::utils::FileSystem::ProjectDir(), output_file_path_);

    json11::Json json_obj;
    {
        std::filebuf in;
        if (!in.open(estimator_config_file, std::ios::in)) {
            AD_LERROR(PP_EVALUATION) << "Cannot open json file: "
                                     << estimator_config_file;
            return AD_INTERNAL_ERROR;
        }
        std::istream iss(&in);
        std::istreambuf_iterator<char> eos;
        std::string config_json(std::istreambuf_iterator<char>(iss), eos);
        in.close();
        std::string error;
        json_obj = json11::Json::parse(config_json, error);
    }
    bool is_property_valid = true;
    kCarWeight = (json_obj["CarWeight"].is_null()
                      ? (is_property_valid = false, -1)
                      : json_obj["CarWeight"].number_value());
    kMaxPower =
        (json_obj["MaxPower"].is_null() ? (is_property_valid = false, -1)
                                        : json_obj["MaxPower"].number_value());
    kLincolnLength = (json_obj["LincolnLenght"].is_null()
                          ? (is_property_valid = false, -1)
                          : json_obj["LincolnLenght"].number_value());
    kLincolnWidth = (json_obj["LincolnWidth"].is_null()
                         ? (is_property_valid = false, -1)
                         : json_obj["LincolnWidth"].number_value());
    kBrakeDistance = (json_obj["BrakeDistance"].is_null()
                          ? (is_property_valid = false, -1)
                          : json_obj["BrakeDistance"].number_value());
    kMinRadius = (json_obj["MinRadius"].is_null()
                      ? (is_property_valid = false, -1)
                      : json_obj["MinRadius"].number_value());
    t_c1_ = (json_obj["t_c1"].is_null() ? (is_property_valid = false, -1)
                                        : json_obj["t_c1"].number_value());
    t_c2_ = (json_obj["t_c2"].is_null() ? (is_property_valid = false, -1)
                                        : json_obj["t_c2"].number_value());
    t_c3_ = (json_obj["t_c3"].is_null() ? (is_property_valid = false, -1)
                                        : json_obj["t_c3"].number_value());
    kUsefulSize = (json_obj["UsefulSize"].is_null()
                       ? (is_property_valid = false, -1)
                       : json_obj["UsefulSize"].number_value());
    kAngleThreshold = std::atan(1.0 * kLincolnWidth / kLincolnLength);
    if (kMinRadius < 10e-5) {
        AD_LERROR(PP_EVALUATION)
            << "kMinRadius is wrong. use default value 6.0";
    } else {
        t_f1_ = 1.0 / kMinRadius;
    }
    if (kBrakeDistance < 10e-5) {
        AD_LERROR(PP_EVALUATION)
            << "kBrakeDistance is wrong. use default value 38.0";
    } else {
        t_f3_ = 1.0 * 100 * 100 / (2 * kBrakeDistance * 3.6 * 3.6);
    }
    AD_LINFO(PP_EVALUATION) << "Weight: " << kCarWeight;
    AD_LINFO(PP_EVALUATION) << "Max power: " << kMaxPower;
    AD_LINFO(PP_EVALUATION) << "Lincoln: length: " << kLincolnLength;
    AD_LINFO(PP_EVALUATION) << "Lincoln: width: " << kLincolnWidth;
    AD_LINFO(PP_EVALUATION) << "Lincoln: BrakeDistance: " << kBrakeDistance;
    AD_LINFO(PP_EVALUATION) << "Lincoln: MinRadius: " << kMinRadius;
    AD_LINFO(PP_EVALUATION) << "Lincoln: angle threshold: " << kAngleThreshold;
    AD_LINFO(PP_EVALUATION) << "UsefulSize: " << kUsefulSize;
    if (!is_property_valid) {
        AD_LERROR(PP_EVALUATION) << "Miss some property, please check.";
        return AD_INTERNAL_ERROR;
    }

    return AD_SUCCESS;
}

adStatus_t PPEvaluation::Process(
    const std::vector<senseAD::TrajectoryPoint> &trajectory,
    const senseAD::SingleFrameObjRecovery &sr_result,
    const float64_t &stamp) {
    static float64_t pre_time = 0.0F;
    float32_t time_cost = stamp - pre_time;
    pre_time = stamp;

    float32_t min_dist_veh_lon = std::numeric_limits<float32_t>::max();
    float32_t min_dist_veh_lat = std::numeric_limits<float32_t>::max();
    float32_t min_dist_ped = std::numeric_limits<float32_t>::max();
    float32_t mean_centripetal_acce = 0.0;
    bool F1 = true;
    bool F2 = true;
    bool F3 = true;
    bool C1 = true;
    bool C2 = true;
    bool C3 = true;

    for (size_t i = 0;
         i < trajectory.size() && static_cast<int32_t>(i) < kUsefulSize; i++) {
        senseAD::TrajectoryPoint traj = trajectory[i];
        mean_centripetal_acce += std::pow(traj.velocity, 2) * traj.curvature;
        // concatenate current frame and history frames
        auto vehicle_recovery = sr_result.vehicle_recovery;
        for (const auto vehicle : vehicle_recovery) {
            const auto &veh_center = vehicle.depth_info.position;
            if (fabs(veh_center.x) < 10e-5) {
                if (fabs(veh_center.y) < min_dist_veh_lat) {
                    min_dist_veh_lat = fabs(veh_center.y);
                }
            } else if (fabs(atan(veh_center.y / veh_center.x)) >
                       kAngleThreshold) {  // lat
                if (cv::norm(veh_center) < min_dist_veh_lat) {
                    min_dist_veh_lat = cv::norm(veh_center);
                }
            } else {  // lon
                if (cv::norm(veh_center) < min_dist_veh_lon) {
                    min_dist_veh_lon = cv::norm(veh_center);
                }
            }
        }
        // concatenate current frame and history frames
        auto pedestrian_recovery = sr_result.pedestrian_recovery;
        for (const auto &pedestrian : pedestrian_recovery) {
            const auto &pedestrian_position = pedestrian.depth_info.position;
            const auto normalized_position = cv::norm(pedestrian_position);
            min_dist_ped =
                (normalized_position < min_dist_ped ? normalized_position
                                                    : min_dist_ped);
        }
        //// TODO(zyz): calculate the jerk and acceleration,
        //// check the physical contraint
        //// once there exits one point that does not satisfy the constraint,
        //// the corresponding index will not be changed
        if (F1) {
            F1 = (std::fabs(traj.curvature) <= t_f1_);
        }
        // calculate the longitude acceleration
        // angle |/
        if (F2) {
            if (std::fabs(traj.velocity) < 10e-5) {
                F2 = true;
            } else {
                F2 = (traj.acceleration <=
                      (kMaxPower / (kCarWeight * traj.velocity)));
            }
        }
        if (F3) {
            F3 = (std::fabs(traj.acceleration) <= t_f3_);
        }
        if (C1) {
            C1 = (std::fabs(traj.acceleration) <= t_c1_);
        }
        if (C2) {
            if (i != 0) {
                float32_t jerk = 0.0;
                if (std::fabs(traj.velocity - trajectory[i - 1].velocity) <
                    10e-5) {
                    if (std::fabs(traj.acceleration -
                                  trajectory[i - 1].acceleration) < 10e-5) {
                        C2 = true;
                    } else {
                        C2 = false;
                    }
                } else if (std::fabs(traj.acceleration * traj.acceleration -
                                     trajectory[i - 1].acceleration *
                                         trajectory[i - 1].acceleration)) {
                    if (std::fabs(traj.velocity - trajectory[i - 1].velocity) <
                        10e-5) {
                        C2 = true;
                    } else {
                        C2 = false;
                    }
                } else {
                    jerk = 1.0 * (traj.acceleration * traj.acceleration -
                                  trajectory[i - 1].acceleration *
                                      trajectory[i - 1].acceleration) /
                           (2.0 * (traj.velocity - trajectory[i - 1].velocity));
                    C2 = (std::fabs(jerk) <= t_c2_);
                }
            }
        }
        if (C3) {
            C3 = (std::fabs(traj.yaw_rate) <= t_c3_);
        }
    }
    if (trajectory.size() != 0) {
        mean_centripetal_acce /= trajectory.size();
    }
    static bool is_first_frame = true;
    if (is_first_frame) {
        is_first_frame = false;
    } else {
        max_time_cost_ = std::max(max_time_cost_, time_cost);
        min_time_cost_ = std::min(min_time_cost_, time_cost);
    }
    max_centripetal_acc_ =
        std::max(max_centripetal_acc_, mean_centripetal_acce);
    min_min_dist_ped_ = std::min(min_min_dist_ped_, min_dist_ped);
    min_min_dist_veh_lon_ = std::min(min_min_dist_veh_lon_, min_dist_veh_lon);
    min_min_dist_veh_lat_ = std::min(min_min_dist_veh_lat_, min_dist_veh_lat);

    total_frames_++;
    total_F1_ += (F1 ? 0 : 1);
    total_F2_ += (F2 ? 0 : 1);
    total_F3_ += (F3 ? 0 : 1);
    total_C1_ += (C1 ? 0 : 1);
    total_C2_ += (C2 ? 0 : 1);
    total_C3_ += (C3 ? 0 : 1);

    // write output_file
    std::ofstream output_file_;
    output_file_.open(output_file_path_, std::ios::trunc | std::ios::out);
    if (!output_file_.is_open()) {
        AD_LERROR(PP_EVALUATION) << "Can not open the result file: "
                                 << output_file_path_;
        return AD_INTERNAL_ERROR;
    }
    output_file_ << "# PP Evaluation Report\n"
                 << "|Index|Value|\n"
                 << "|-----|-----|\n"
                 << "|Number of Frames|" << total_frames_ << "|\n"
                 << "|Max Time Cost|" << max_time_cost_ << "|\n"
                 << "|Min Time Cost|" << min_time_cost_ << "|\n"
                 << "|Max Centripetal Acceleration|" << max_centripetal_acc_
                 << "|\n"
                 << "|Min Distance to Pedstrians|" << min_min_dist_ped_ << "|\n"
                 << "|Min Longitude Distance to Vehicles|"
                 << min_min_dist_veh_lon_ << "|\n"
                 << "|Min Lateral Distance to Vehicles|"
                 << min_min_dist_veh_lat_ << "|\n"
                 << "|Fail to meet F1 Cases|" << total_F1_ << "|\n"
                 << "|Fail to meet F2 Cases|" << total_F2_ << "|\n"
                 << "|Fail to meet F3 Cases|" << total_F3_ << "|\n"
                 << "|Fail to meet C1 Cases|" << total_C1_ << "|\n"
                 << "|Fail to meet C2 Cases|" << total_C2_ << "|\n"
                 << "|Fail to meet C3 Cases|" << total_C3_ << "|\n";

    if (!(F1 && F2 && F3 && C1 && C2 && C3)) {
#if 0
        std::string trajectory_save_dir =
            JOIN_PATH(results_save_directory_, "trajectory");
        std::string sr_result_save_dir =
            JOIN_PATH(results_save_directory_, "sr");
        std::string road_block_save_dir =
            JOIN_PATH(results_save_directory_, "rb");
        senseAD::common::utils::FileSystem::MakeDirs(trajectory_save_dir);
        senseAD::common::utils::FileSystem::MakeDirs(sr_result_save_dir);
        senseAD::common::utils::FileSystem::MakeDirs(road_block_save_dir);
        std::string result2name;
        result2name = "_" + std::to_string(F1) + "-" + std::to_string(F2) +
                      "-" + std::to_string(F3) + "-" + std::to_string(C1) +
                      "-" + std::to_string(C2) + "-" + std::to_string(C3);
        {
            std::ofstream ofs_trajectory(trajectory_save_dir + "/trajectory_" +
                                         std::to_string(total_frames_) +
                                         result2name + ".json");
            cereal::JSONOutputArchive ar_trajectory(ofs_trajectory);
            ar_trajectory(trajectory);
        }

        {
            std::ofstream ofs_sr_result(sr_result_save_dir + "/sr_" +
                                        std::to_string(total_frames_) +
                                        result2name + ".json");
            cereal::JSONOutputArchive ar_sr_result(ofs_sr_result);
            ar_sr_result(sr_result);
            // ofs_sr_result.close();
        }
#endif
    }
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
