/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */
#include <math.h>
#include <random>
#include <cmath>
#include <chrono>  // NOLINT
#include <string>
#include <functional>
#include <memory>
#include "path_planning/planner.hpp"
#include "path_planning/rrt_core.hpp"
#include "path_planning/lattice_core.hpp"
#include "common/log.hpp"
#include "path_planning/util.hpp"
#include "path_planning/nn_tool.hpp"
#include "path_planning/ppconfig.hpp"
#include "common/data_type/control_command.hpp"

namespace senseAD {
namespace pp {

Planner::Planner() {}

Planner::~Planner() {}

adStatus_t Planner::Init(const std::string& config) {
    auto core_conf = g_pp_conf["pp_core"];
    std::string pp_type = core_conf["pp_core"];

    // TODO(origin): gridmap init predmap init
    scene_parser_.Init();
    planner_core_ = senseAD::pp::PlannerCore::CreatePlanner(pp_type);
    if (planner_core_ == nullptr) {
        AD_LERROR(DECISON_PLANNING) << "Create planner core failed";
        return AD_NULL_PTR;
    }

    auto func_is_free = std::bind(&SceneParser::is_free, &scene_parser_,
                                  std::placeholders::_1, std::placeholders::_2);
    planner_core_->RegisterCheckCollisionPlug(func_is_free);
    auto func_its_risk =
        std::bind(&SceneParser::its_risk, &scene_parser_, std::placeholders::_1,
                  std::placeholders::_2);
    planner_core_->RegisterCheckSceneRiskPlug(func_its_risk);

    auto func_warp_point =
        std::bind(static_cast<adStatus_t (PoseWarp::*)(cv::Point2f*)>(
                      &PoseWarp::WarpPoint),
                  &pose_warp_, std::placeholders::_1);

    planner_core_->RegisterWarpPointPlug(func_warp_point);
    cache_point_.RegisterWarpPointPlug(func_warp_point);

    // RRTCore Special Bind
    if (pp_type == "RRTCore") {
        auto rrt_core_ = std::dynamic_pointer_cast<RRTCore>(planner_core_);
        auto func_frenet_collision = std::bind(
            &SceneParser::sdt_is_free, &scene_parser_, std::placeholders::_1,
            std::placeholders::_2, std::placeholders::_3, std::placeholders::_4,
            std::placeholders::_5, std::placeholders::_6,
            std::placeholders::_7);
        rrt_core_->RegisterFrenetCollisionPlug(func_frenet_collision);

        auto func_frenet_risk = std::bind(
            &SceneParser::sdt_its_risk, &scene_parser_, std::placeholders::_1,
            std::placeholders::_2, std::placeholders::_3, std::placeholders::_4,
            std::placeholders::_5, std::placeholders::_6,
            std::placeholders::_7);
        rrt_core_->RegisterFrenetRiskPlug(func_frenet_risk);
    } else if (pp_type == "LatticeCore") {
        auto lattice_core_ =
            std::dynamic_pointer_cast<LatticeCore>(planner_core_);
        auto func_frenet_collision = std::bind(
            &SceneParser::sdt_is_free, &scene_parser_, std::placeholders::_1,
            std::placeholders::_2, std::placeholders::_3, std::placeholders::_4,
            std::placeholders::_5, std::placeholders::_6,
            std::placeholders::_7);
        lattice_core_->RegisterFrenetCollisionPlug(func_frenet_collision);

        auto func_frenet_risk = std::bind(
            &SceneParser::sdt_its_risk, &scene_parser_, std::placeholders::_1,
            std::placeholders::_2, std::placeholders::_3, std::placeholders::_4,
            std::placeholders::_5, std::placeholders::_6,
            std::placeholders::_7);
        lattice_core_->RegisterFrenetRiskPlug(func_frenet_risk);
    }

    replan_timer_ = -1;
    planner_core_->Init();

    single_start_.position.x = single_start_.position.y = 0;
    single_start_.direction.x = 1.0f;
    single_start_.direction.y = 0;

    // Extra Config Flags for Planner
    auto conf = g_pp_conf["rrt_setting"];
    traj_smoothing_ = conf["traj_smoothing"];
    node_frequency_ = conf["node_frequency"];
    replan_per_second_ = conf["replan_per_second"];
    recycle_mode_on_laneline_ = conf["recycle_mode_on_laneline"];
    recycle_mode_on_ = conf["recycle_mode_on"];

    off_track_tolerance_ = conf["off_track_tolerance"];
    length_discrepance_tolerance_ = conf["length_discrepance_tolerance"];
    max_tjp_diff_tolerance_ = conf["max_tjp_diff_tolerance"];
    avg_tjp_diff_tolerance_ = conf["avg_tjp_diff_tolerance"];

    bpp_improved_ = conf["bpp_improved"];
    insert_distance_ = conf["insert_distance"];

    use_ref_line_ = conf["use_ref_line"];
    test_old_can_data = conf["test_old_can_data"];
    switch_steering_input_direction_ = conf["switch_steering_input_direction"];
    min_path_length_ = conf["min_path_length"];
    use_routing_refline_ = conf["use_routing_refline"];

    cached_path_offset_threshold_ = conf["cached_path_offset_threshold"];
    recycle_at_terminal_ = conf["recycle_at_terminal"];
    cached_path_check_index_ = conf["cached_path_check_index"];

    correct_path_ = conf["correct_path"];
    replan_track_time_threshold_ = conf["replan_track_time_threshold"];
    replan_track_time_threshold_stop_ =
        conf["replan_track_time_threshold_stop"];
    replan_position_threshold_ = conf["replan_position_threshold"];
    target_point_replan_threshold_ = conf["target_point_replan_threshold"];

    auto veh_conf = g_pp_conf["vehicle_setting"];

    g_vehicle_param.width = veh_conf["car_width"];
    g_vehicle_param.length = veh_conf["car_length"];
    g_vehicle_param.curb_weight = veh_conf["car_weight"];
    g_vehicle_param.min_turning_radius = veh_conf["min_turn_radius"];

    return AD_SUCCESS;
}

adStatus_t Planner::Plan(std::vector<TrajectoryPoint>* out_path) {
    // ---------Excution Time Stats------------
    titles = {
        "Plan         ",  // 0
        "Internal     ",  // 1
        "UpdateScene  ",  // 2
        "CheckRecycle ",  // 3
    };
    function_called_nums = std::vector<int>(4, 0);
    durations =
        std::vector<std::chrono::nanoseconds>(4, std::chrono::nanoseconds());
    auto pp_start = std::chrono::high_resolution_clock::now();

    out_path->clear();
    UpdateSceneAndTracker();
    AD_LINFO(PATH_PLANNING) << "finished SP update";
    ReplanFlag replan_flag = ShouldRecycle();
    AD_LINFO(PATH_PLANNING) << "REPLAN FLAG " << replan_flag;
    if (replan_flag != ReplanFlag::RECYCLE) {
        // TODO(Better Place to put those timing snippet)
        auto pc_plan_start = std::chrono::high_resolution_clock::now();
        planner_core_->Update(base_path_, single_start_, single_goal_,
                              vp_purpose_, velocity_plan_distance_,
                              cached_path_, replan_flag);
        planner_core_->Plan(out_path);
        planner_core_->GetPLanningLog(&planning_log_);

        auto pc_plan_end = std::chrono::high_resolution_clock::now();
        durations[1] += (pc_plan_end - pc_plan_start);
        function_called_nums[1] += 1;

        CheckPathRecyclability(*out_path);
        cached_path_ = *out_path;
        cached_base_path_ = base_path_;
        AD_LINFO(PATH_PLANNING) << "cached base path size "
                                << cached_base_path_.size();
        replan_timer_ = static_cast<int>(node_frequency_ / replan_per_second_);

        last_dm_target_ = dm_target_;
        // save coordinate of last target point in world coordinate
        if (dm_target_.target_point_index >= 0 &&
            BasePathPlanner::base_path_.forward.size() > 0 &&
            dm_target_.target_point_index <
                static_cast<int32_t>(
                    BasePathPlanner::base_path_.forward.size())) {
            last_target_point_ =
                cv::Point2f(BasePathPlanner::base_path_.forward
                                .at(dm_target_.target_point_index)
                                .x,
                            BasePathPlanner::base_path_.forward
                                .at(dm_target_.target_point_index)
                                .y);
        }
        // save coordinate of last velocity target point in world coordinate
        if (dm_target_.dm_velocity_index >= 0 &&
            BasePathPlanner::base_path_.forward.size() > 0 &&
            dm_target_.dm_velocity_index <
                static_cast<int32_t>(
                    BasePathPlanner::base_path_.forward.size())) {
            last_velocity_target_point_ =
                cv::Point2f(BasePathPlanner::base_path_.forward
                                .at(dm_target_.dm_velocity_index)
                                .x,
                            BasePathPlanner::base_path_.forward
                                .at(dm_target_.dm_velocity_index)
                                .y);
        }
    } else {
        *out_path = cached_path_;
    }
    replan_timer_ -= 1;

    utils::EstimatePathTime(out_path);
    auto SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
    switch (dm_target_.signal_blub) {
        case 0:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
            break;
        case 1:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_RIGHT;
            break;
        case 2:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_LEFT;
            break;
        default:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
            break;
    }

    for (size_t i = 0; i < out_path->size(); i++) {
        out_path->at(i).turn_signal = SignalToFill;
    }

    // Log
    AD_LINFO(PATH_PLANNING) << "vehicle position and heading is "
                            << g_vehicle_state.x << ", " << g_vehicle_state.y
                            << ", " << g_vehicle_state.heading;
    AD_LINFO(PATH_PLANNING) << "position direction velocity theta curvature "
                               "sumdistance timediffence yaw rate acceleration";
    AD_LINFO(PATH_PLANNING) << "PP Final Result\n";
    for (uint32_t i = 0; i < static_cast<uint32_t>(out_path->size()) && i < 100;
         i += 1) {
        auto trajpt = out_path->at(i);
        if (i % 5 == 0) {
            AD_LINFO(PATH_PLANNING)
                << i << " " << trajpt.position << " " << trajpt.direction << " "
                << trajpt.velocity << " " << trajpt.theta << " "
                << trajpt.curvature << " " << trajpt.sum_distance << " "
                << trajpt.time_difference << " " << trajpt.yaw_rate << " "
                << trajpt.acceleration << " " << trajpt.timestamp;
        } else {
            AD_LDEBUG(PATH_PLANNING)
                << "PP Final Result " << i << " " << trajpt.position << " "
                << trajpt.direction << " " << trajpt.velocity << " "
                << trajpt.theta << " " << trajpt.curvature << " "
                << trajpt.sum_distance << " " << trajpt.time_difference << " "
                << trajpt.yaw_rate << " " << trajpt.acceleration << " "
                << trajpt.timestamp;
        }
    }

    AD_LINFO(PATH_PLANNING) << "PP replan timer: " << replan_timer_;

    // ----For Honda output----
    if (interface_to_autobox_) {
        // Note: we remove all specific logics that for JOSO demo
        // Here we only ensure this remaining logics compilable
        // And not GUARANTEE they have the desired behavior
        // as JOSO demo version.
        // In fact, they would be removed in future when we design
        // our own autobox interface.
        HondaCtlInput hci;
        honda_converter_.ToHondaCtl(0.0, insert_distance_, *out_path, &hci);

        hci.road_id = 0;

        honda_can_sender_.SetVehicleInfo(vehicle_info_);
        honda_sig_sender_.SetHCI(hci);
        honda_tgt_sender_.SetHCI(hci);

        honda_can_sender_.SendHCIPacket();
        honda_sig_sender_.SendHCIPacket();
        honda_tgt_sender_.SendHCIPacket();
    }
    // ------------------------

    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[0] += (pp_end - pp_start);
    function_called_nums[0] += 1;

    std::stringstream ss_info;
    ss_info << "PP_time ";
    for (uint32_t i = 0; i < titles.size(); i++) {
        ss_info << titles[i] << "\t" << function_called_nums[i] << "\t"
                << std::chrono::duration<float>(durations[i]).count() << "\t";
    }
    AD_LINFO(PATH_PLANNING) << ss_info.str();
    scene_parser_.LogOutTime();

    if (vehicle_status_.AutoCtrlStat == 1) {
        last_autodriving_status_on_ = true;
    } else {
        last_autodriving_status_on_ = false;
    }

    return AD_SUCCESS;
}

adStatus_t Planner::UpdateSceneAndTracker() {
    auto pp_start = std::chrono::high_resolution_clock::now();

    auto cached_goal = single_goal_;

    scene_parser_.SetCachedGoal(cached_goal);

    cv::Point2f entering_direction(1.0, 0);
    float tanv = tan(vehicle_info_.steering_angle / 16.0) / 2.0;
    AD_LINFO(PATH_PLANNING) << "steering_angle : "
                            << vehicle_info_.steering_angle;
    float v_heading = g_vehicle_state.heading + std::atan(tanv);

    AD_LINFO(PATH_PLANNING) << "tanv: " << tanv << " atan " << std::atan(tanv);
    AD_LINFO(PATH_PLANNING) << "v_heading: " << v_heading;

    entering_direction.y = sin(v_heading);
    entering_direction.x = cos(v_heading);

    single_start_.position = cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    single_start_.direction = entering_direction;

    AD_LINFO(PATH_PLANNING) << "entering : " << entering_direction;

    if (last_autodriving_status_on_ == false &&
        vehicle_status_.AutoCtrlStat == 1) {
        scene_parser_.SetStartPoint(cached_path_, true, &single_start_,
                                    &closest_point_);
    } else {
        scene_parser_.SetStartPoint(cached_path_, false, &single_start_,
                                    &closest_point_);
    }
    UpdateCachedBasePath();
    scene_parser_.SetCachedBasePath(cached_base_path_);
    single_start_.theta =
        std::atan2(entering_direction.y, entering_direction.x);
    single_start_.yaw_rate = g_vehicle_state.yaw_rate;
    AD_LINFO(PATH_PLANNING) << "single start direction "
                            << single_start_.position << " "
                            << single_start_.theta;

    TmpUpdateCachedPath();
    std::vector<TrajectoryPoint> routing_refline;
    AD_LINFO(PATH_PLANNING) << "egocar base path size "
                            << BasePathPlanner::base_path_.forward.size();
    for (auto point : BasePathPlanner::base_path_.forward) {
        TrajectoryPoint n_pt;
        n_pt.position.x = point.x;
        n_pt.position.y = point.y;
        n_pt.direction.x = 0.0f;
        n_pt.direction.y = 0.0f;
        n_pt.velocity = 0.0f;
        n_pt.theta = 0.0f;
        n_pt.curvature = 0.0f;
        n_pt.sum_distance = 0.0;
        n_pt.time_difference = 0.0;
        n_pt.yaw_rate = 0.0;
        n_pt.acceleration = 0.0;
        n_pt.timestamp = 0;
        n_pt.gear = senseAD::ControlCommand::GEAR::GEAR_NONE;
        n_pt.turn_signal =
            senseAD::ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;

        routing_refline.push_back(n_pt);
    }
    velocity_plan_distance_ = 0.0;
    for (int32_t i = 1;
         i < static_cast<int32_t>(BasePathPlanner::base_path_.forward.size()) &&
         i < dm_target_.dm_velocity_index;
         i++) {
        auto pti = cv::Point2f(BasePathPlanner::base_path_.forward[i].x,
                               BasePathPlanner::base_path_.forward[i].y);
        auto ptii = cv::Point2f(BasePathPlanner::base_path_.forward[i - 1].x,
                                BasePathPlanner::base_path_.forward[i - 1].y);
        velocity_plan_distance_ += cv::norm(pti - ptii);
    }

    scene_parser_.SetVPEnd(velocity_plan_distance_);

    scene_parser_.SetRoutingRefline(routing_refline);

    scene_parser_.Parse();

    scene_parser_.GetTrajPointGoal(&single_goal_);

    vp_purpose_ = VPPurpose::KEEP_UP_NON_ZERO_VELOCITY;
    scene_parser_.GetVPPurpose(&vp_purpose_);

    // TODO(congq): Put them in Sceneparser
    scene_parser_.GetBasePath(&base_path_);
    scene_parser_.GetReferenceLine(&ref_line_);

    bool should_override_vp_s = false;
    scene_parser_.ShouldOverrideVPS(&should_override_vp_s);
    if (should_override_vp_s) {
        velocity_plan_distance_ =
            insert_distance_ *
            std::max(0.0, static_cast<double>(cv::norm(single_goal_.position) /
                                              insert_distance_));
    }

    if (use_ref_line_) {
        base_path_ = ref_line_;
    }
    // -----them to be exact--------------

    utils::EstimatePathTime(&base_path_);
    utils::EstimatePathTime(&cached_path_);

    curr_dm_target_ = dm_target_;

    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[2] += (pp_end - pp_start);
    function_called_nums[2] += 1;
    return AD_SUCCESS;
}

ReplanFlag Planner::ShouldRecycle() {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();

    ReplanFlag replan_flag = ReplanFlag::PATH_SPEED_REPLAN;
    if (last_autodriving_status_on_ == false &&
        vehicle_status_.AutoCtrlStat == 1) {
        AD_LINFO(PATH_PLANNING)
            << "replan caused by entering auto driving state ";
        return replan_flag;
    }
    if (recycle_mode_on_ != 1) {
        reclying_flag_ = 0;
        return replan_flag;
    }
    bool is_collied = scene_parser_.notCollided(cached_path_);
    if (reclying_flag_ == 1 &&
        (replan_timer_ >= 0 && (cached_path_.size() > 0)) &&
        ((cached_path_.size() > 0 &&
          cached_path_.back().sum_distance -
                  cached_path_.front().sum_distance >=
              min_path_length_) ||
         (recycle_at_terminal_ == 1 &&
          base_path_.size() * insert_distance_ < (0.99 * min_path_length_))) &&
        scene_parser_.notCollided(cached_path_) &&
        curr_dm_target_.type != DMTarget::Type::STOPPED &&
        curr_dm_target_.intention == last_dm_target_.intention &&
        curr_dm_target_.deviation_direction ==
            last_dm_target_.deviation_direction) {
        if (ShouldPathRecycle() == false) {
            // if path need to be replanned, speed also need to be replanned
            AD_LINFO(PATH_PLANNING) << "replan path";
            reclying_flag_ = 0;
            return replan_flag;
        }
        if (ShouldSpeedRecycle() == false) {
            AD_LINFO(PATH_PLANNING) << "replan speed";
            replan_flag = ReplanFlag::SPEED_REPLAN;
            reclying_flag_ = 0;
            return replan_flag;
        }
        replan_flag = ReplanFlag::RECYCLE;
    } else {
        AD_LINFO(PATH_PLANNING) << "replan_timer_ >= 0 "
                                << (replan_timer_ >= 0);
        AD_LINFO(PATH_PLANNING) << "reclying_flag_ == 1 "
                                << (reclying_flag_ == 1);
        AD_LINFO(PATH_PLANNING)
            << "cached_path_.size()*insert_distance_ >= min_path_length_ "
            << (cached_path_.size() == 0 ||
                (cached_path_.size() > 0 &&
                 cached_path_.back().sum_distance >= min_path_length_));
        AD_LINFO(PATH_PLANNING)
            << "curr_dm_target_.type != DMTarget::Type::STOPPED"
            << (curr_dm_target_.type != DMTarget::Type::STOPPED);
        AD_LINFO(PATH_PLANNING) << "not collided " << is_collied;
        AD_LINFO(PATH_PLANNING)
            << "intention changed "
            << (curr_dm_target_.intention == last_dm_target_.intention);
        AD_LINFO(PATH_PLANNING) << "devaition direction changed "
                                << (curr_dm_target_.deviation_direction ==
                                    last_dm_target_.deviation_direction);
    }

    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations[3] += (pc_plan_end - pc_plan_start);
    function_called_nums[3] += 1;

    return replan_flag;
}

bool Planner::ShouldPathRecycle() {
    // 1. lateral track error
    if (cv::norm(cv::Point2f(g_vehicle_state.x, g_vehicle_state.y) -
                 cached_path_.front().position) > off_track_tolerance_) {
        AD_LINFO(PATH_PLANNING) << "replan caused by lateral track error";
        return false;
    }
    // 2. dm target point, ignore stop scenario
    if (BasePathPlanner::base_path_.forward.empty() == true ||
        curr_dm_target_.target_point_index < 0 ||
        curr_dm_target_.target_point_index >=
            static_cast<int32_t>(BasePathPlanner::base_path_.forward.size())) {
        AD_LERROR(PATH_PLANNING)
            << "base path is empty or dm target index invalid";
        return false;
    }
    // if curr target point index is far away from ego car, the move of target
    // point index won't trigger replan
    if (curr_dm_target_.target_point_index * insert_distance_ <
        target_point_replan_threshold_) {
        if (cv::norm(
                last_target_point_ -
                cv::Point2f(BasePathPlanner::base_path_
                                .forward[curr_dm_target_.target_point_index]
                                .x,
                            BasePathPlanner::base_path_
                                .forward[curr_dm_target_.target_point_index]
                                .y)) > target_point_replan_threshold_) {
            AD_LINFO(PATH_PLANNING)
                << "replan caused by dm target point change";
            return false;
        }
    }
    return true;
}

bool Planner::ShouldSpeedRecycle() const {
    // 1. dm target velocity
    if (std::abs(last_dm_target_.dm_velocity - curr_dm_target_.dm_velocity) >
        0.5) {
        AD_LINFO(PATH_PLANNING) << "replan caused by dm velocity changed.";
        return false;
    }
    // 2. dm velocity target point, considering stop scenario
    float target_point_replan_threshold =
        g_vehicle_state.velocity / static_cast<float>(node_frequency_);
    const double k_dm_zero_velocity = 0.2;
    if (curr_dm_target_.dm_velocity > k_dm_zero_velocity) {
        target_point_replan_threshold = std::max(
            target_point_replan_threshold, target_point_replan_threshold_);
    }
    if (BasePathPlanner::base_path_.forward.empty() == true ||
        curr_dm_target_.dm_velocity_index < 0 ||
        curr_dm_target_.dm_velocity_index >=
            static_cast<int32_t>(BasePathPlanner::base_path_.forward.size())) {
        AD_LERROR(PATH_PLANNING)
            << "base path is empty or dm velocity target index invalid";
        return false;
    }
    if (cv::norm(last_velocity_target_point_ -
                 cv::Point2f(BasePathPlanner::base_path_
                                 .forward[curr_dm_target_.dm_velocity_index]
                                 .x,
                             BasePathPlanner::base_path_
                                 .forward[curr_dm_target_.dm_velocity_index]
                                 .y)) > target_point_replan_threshold) {
        AD_LINFO(PATH_PLANNING) << "replan caused by dm velocity point change";
        return false;
    }
    // 3. track time i.e. longitudinal track error
    MicroClock t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    uint64_t t_now_stamp =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 1000);
    // calculate positon error
    if (cached_path_.size() < 2) {
        return false;
    }
    uint32_t i = 0;
    while (i < cached_path_.size() &&
           cached_path_.at(i).timestamp <= t_now_stamp) {
        ++i;
    }
    TrajectoryPoint point_pre, point_next;
    if (i >= cached_path_.size()) {
        point_pre = cached_path_.at(i - 2);
        point_next = cached_path_.at(i - 1);
    } else if (i == 0) {
        point_pre = cached_path_.at(0);
        point_next = cached_path_.at(1);
    } else {
        point_pre = cached_path_.at(i - 1);
        point_next = cached_path_.at(i);
    }
    float ratio =
        static_cast<float>(t_now_stamp - point_pre.timestamp) /
        static_cast<float>(point_next.timestamp - point_pre.timestamp);
    cv::Point2f ideal_position =
        point_pre.position + ratio * (point_next.position - point_pre.position);
    float position_error = cv::norm(
        ideal_position - cv::Point2f(g_vehicle_state.x, g_vehicle_state.y));
    AD_LINFO(PATH_PLANNING) << "position error " << position_error;

    // calculate track time
    uint64_t track_time = (t_now_stamp > closest_point_.timestamp)
                              ? (t_now_stamp - closest_point_.timestamp)
                              : (closest_point_.timestamp - t_now_stamp);
    AD_LINFO(PATH_PLANNING) << "track time " << track_time / 1e9;

    if (dm_target_.dm_velocity < 0.01) {
        if (track_time > (replan_track_time_threshold_stop_ * 1e9)) {
            AD_LINFO(PATH_PLANNING)
                << "replan caused by longitudinal track time";
            return false;
        }
    } else {
        if (track_time > (replan_track_time_threshold_ * 1e9) &&
            position_error > replan_position_threshold_) {
            AD_LINFO(PATH_PLANNING)
                << "replan caused by longitudinal track time";
            return false;
        }
    }
    return true;
}

void Planner::CheckPathRecyclability(
    const std::vector<TrajectoryPoint>& tjp_path) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    bool should_replan_ = false;

    // TODO(congq) cached path size

    if (cached_path_.size() == 0 || tjp_path.size() == 0 ||
        static_cast<float>(cached_path_.size()) /
                static_cast<float>(tjp_path.size()) >
            length_discrepance_tolerance_ ||
        static_cast<float>(tjp_path.size()) /
                static_cast<float>(cached_path_.size()) >
            length_discrepance_tolerance_) {
        AD_LINFO(PATH_PLANNING) << "recycle size " << cached_path_.size() << " "
                                << tjp_path.size();

        should_replan_ = true;
    }
    reclying_flag_ = should_replan_ ? 0 : 1;
    AD_LINFO(PATH_PLANNING) << "recycle flag after length check"
                            << reclying_flag_;
    float sum_trajpt_error_ = 0;
    float max_trajpt_error_ = 0;
    // float avg_trajpt_error_ = 0;

    if (tjp_path.size() < cached_path_.size()) {
        // truncatte cached trajectory
        cached_path_.resize(tjp_path.size());
    }
    for (uint32_t i = 0; i < cached_path_.size(); i++) {
        TrajectoryPoint cached_point = cached_path_[i];
        TrajectoryPoint new_point = tjp_path[i];

        if (!should_replan_) {
            float trajpt_error_ =
                sqrtf(cv::norm(cached_point.position - new_point.position));
            sum_trajpt_error_ += trajpt_error_;
            max_trajpt_error_ = std::max(max_trajpt_error_, trajpt_error_);
            if (max_trajpt_error_ > max_tjp_diff_tolerance_) {
                should_replan_ = true;
            }
        }
    }
    reclying_flag_ = should_replan_ ? 0 : 1;
    AD_LINFO(PATH_PLANNING) << "recycle flag after errcheck" << reclying_flag_;

    if (sum_trajpt_error_ / static_cast<float>(cached_path_.size()) >
        avg_tjp_diff_tolerance_) {
        should_replan_ = true;
    }
    reclying_flag_ = should_replan_ ? 0 : 1;
    AD_LINFO(PATH_PLANNING) << "recycle flag" << reclying_flag_;
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations[3] += (pc_plan_end - pc_plan_start);
    function_called_nums[3] += 1;
}

adStatus_t Planner::TmpUpdateCachedPath() {
    if (cached_path_.empty()) {
        return AD_SUCCESS;
    }
    double range = g_vehicle_state.velocity * 1.0 /
                   static_cast<float>(node_frequency_) * 30;
    auto curr_position = cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    int closest_index = static_cast<int>(
        utils::MatchClosestPoint(cached_path_, 0, curr_position, range));

    AD_LINFO(PATH_PLANNING) << "closest_index: " << closest_index;

    MicroClock t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    uint64_t t_now_stamp =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 1000);
    while (closest_index >= 0 &&
           closest_index < static_cast<int32_t>(cached_path_.size()) &&
           cached_path_.at(closest_index).timestamp > t_now_stamp) {
        closest_index = closest_index - 1;
    }
    closest_index = std::max(0, closest_index);

    if (closest_index < static_cast<int32_t>(cached_path_.size())) {
        // TODO(congq): not begin(), should be the search index
        cached_path_ = Trajectory(cached_path_.begin() + closest_index,
                                  cached_path_.end());
        utils::UpdateSumDistance(&cached_path_, curr_position);
    }
    return AD_SUCCESS;
}

adStatus_t Planner::UpdateCachedBasePath() {
    AD_LINFO(PATH_PLANNING) << "cached base path size "
                            << cached_base_path_.size();
    // 1. find closest point in cached base path
    double range = g_vehicle_state.velocity * 1.0 /
                   static_cast<float>(node_frequency_) * 50;
    auto curr_position = cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    auto closest_index =
        utils::MatchClosestPoint(cached_base_path_, 0, curr_position, range);
    AD_LINFO(PATH_PLANNING) << "closest_index: " << closest_index;
    if (closest_index < static_cast<int32_t>(cached_base_path_.size())) {
        float closest_dist = cv::norm(
            curr_position - cached_base_path_.at(closest_index).position);
        AD_LINFO(PATH_PLANNING) << "closest_dist: " << closest_dist;
        if (closest_dist > insert_distance_ * 5.0) {
            AD_LERROR(PATH_PLANNING) << "failed to update cached basepath "
                                        "caused by cannot find closest point";
            cached_base_path_.clear();
            return AD_INVALID_PARAM;
        }
        cached_base_path_ = Trajectory(
            cached_base_path_.begin() + closest_index, cached_base_path_.end());
        return AD_SUCCESS;
    } else {
        AD_LERROR(PATH_PLANNING) << "failed to update cached basepath.";
        cached_base_path_.clear();
        return AD_INVALID_PARAM;
    }
}

}  // namespace pp
}  // namespace senseAD
