/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * ZhuYuzhang <zhuyuzhang@sensetime.com>
 */

#include <cmath>
#include <chrono>  // NOLINT
#include <string>
#include <functional>
#include "path_planning/lattice_core.hpp"
#include "common/log.hpp"
#include "ini.h"  // NOLINT
#include "path_planning/util.hpp"

namespace senseAD {
namespace pp {

adStatus_t CalculateCurvature(const cv::Point2f& pt1,
                              const cv::Point2f& pt2,
                              const cv::Point2f& pt3,
                              float32_t* curvature) {
    float32_t A1, A2, B1, B2, C1, C2, temp;
    A1 = pt1.x - pt2.x;
    B1 = pt1.y - pt2.y;
    C1 = (pow(pt1.x, 2) - pow(pt2.x, 2) + pow(pt1.y, 2) - pow(pt2.y, 2)) / 2;
    A2 = pt3.x - pt2.x;
    B2 = pt3.y - pt2.y;
    C2 = (pow(pt3.x, 2) - pow(pt2.x, 2) + pow(pt3.y, 2) - pow(pt2.y, 2)) / 2;
    temp = A1 * B2 - A2 * B1;
    cv::Point2f center;
    if (fabs(temp) < 10e-5) {
        center.x = pt1.x;
        center.y = pt1.y;
    } else {
        center.x = (C1 * B2 - C2 * B1) / temp;
        center.y = (A1 * C2 - A2 * C1) / temp;
    }

    *curvature = sqrtf((center.x - pt1.x) * (center.x - pt1.x) +
                       (center.y - pt1.y) * (center.y - pt1.y));
    if (*curvature > 10e-5) *curvature = 1.0 / (*curvature);
    return AD_SUCCESS;
}

void SolveQuinticPoly(float32_t cur_position,
                      float32_t cur_velocity,
                      float32_t cur_acceleration,
                      float32_t target_position,
                      float32_t target_velocity,
                      float32_t target_acceleration,
                      float32_t T,
                      float32_t* a0,
                      float32_t* a1,
                      float32_t* a2,
                      float32_t* a3,
                      float32_t* a4,
                      float32_t* a5) {
    *a0 = cur_position;
    *a1 = cur_velocity;
    *a2 = cur_acceleration / 2.0;
    // solve the equation Ax=b
    float32_t equation[3][3] = {
        {static_cast<float32_t>(std::pow(T, 3)),
         static_cast<float32_t>(std::pow(T, 4)),
         static_cast<float32_t>(std::pow(T, 5))},
        {static_cast<float32_t>(3.0 * std::pow(T, 2)),
         static_cast<float32_t>(4.0 * std::pow(T, 3)),
         static_cast<float32_t>(5.0 * std::pow(T, 4))},
        {static_cast<float32_t>(6.0 * T),
         static_cast<float32_t>(12.0 * std::pow(T, 2)),
         static_cast<float32_t>(20.0 * std::pow(T, 3))}};

    CvMat* equation_mat = cvCreateMat(3, 3, CV_32FC1);
    cvSetData(equation_mat, equation, CV_AUTOSTEP);
    float32_t solved[3][1] = {
        {static_cast<float32_t>(target_position - cur_position -
                                cur_velocity * T -
                                cur_acceleration / 2.0 * std::pow(T, 2))},
        {static_cast<float32_t>(target_velocity - cur_velocity -
                                2.0 * cur_acceleration / 2.0 * T)},
        {static_cast<float32_t>(target_acceleration -
                                2.0 * cur_acceleration / 2.0)}};
    CvMat* solved_mat = cvCreateMat(3, 1, CV_32FC1);
    cvSetData(solved_mat, solved, CV_AUTOSTEP);

    CvMat* param_mat = cvCreateMat(3, 1, CV_32FC1);
    cvSolve(equation_mat, solved_mat, param_mat, CV_LU);
    *a3 = param_mat->data.fl[0];
    *a4 = param_mat->data.fl[1];
    *a5 = param_mat->data.fl[2];

    cvReleaseMat(&equation_mat);
    cvReleaseMat(&solved_mat);
    cvReleaseMat(&param_mat);
    return;
}

void SolveQuarticPoly(float32_t cur_position,
                      float32_t cur_velocity,
                      float32_t cur_acceleration,
                      float32_t target_velocity,
                      float32_t target_acceleration,
                      float32_t T,
                      float32_t* a0,
                      float32_t* a1,
                      float32_t* a2,
                      float32_t* a3,
                      float32_t* a4) {
    *a0 = cur_position;
    *a1 = cur_velocity;
    *a2 = cur_acceleration / 2.0;

    float32_t equation[2][2] = {
        {static_cast<float32_t>(3.0 * std::pow(T, 2)),
         static_cast<float32_t>(4.0 * std::pow(T, 3))},
        {static_cast<float32_t>(6.0 * T),
         static_cast<float32_t>(12.0 * std::pow(T, 2))}};
    CvMat* equation_mat = cvCreateMat(2, 2, CV_32FC1);
    cvSetData(equation_mat, equation, CV_AUTOSTEP);
    float32_t solved[2][1] = {
        {static_cast<float32_t>(target_velocity - cur_velocity -
                                2.0 * cur_acceleration / 2.0 * T)},
        {static_cast<float32_t>(target_acceleration -
                                2.0 * cur_acceleration / 2.0)}};
    CvMat* solved_mat = cvCreateMat(2, 1, CV_32FC1);
    cvSetData(solved_mat, solved, CV_AUTOSTEP);
    CvMat* param_mat = cvCreateMat(2, 1, CV_32FC1);
    cvSolve(equation_mat, solved_mat, param_mat, CV_LU);
    *a3 = param_mat->data.fl[0];
    *a4 = param_mat->data.fl[1];

    cvReleaseMat(&equation_mat);
    cvReleaseMat(&solved_mat);
    cvReleaseMat(&param_mat);
    return;
}

LatticeCore::LatticeCore() {}

LatticeCore::~LatticeCore() {}

adStatus_t LatticeCore::Init() {
    auto lattice_conf = g_pp_conf["lattice_setting"];
    longitude_acc_on_ = lattice_conf["longitude_acc_on"];
    lateral_acc_on_ = lattice_conf["lateral_acc_on"];
    lateral_velocity_on_ = lattice_conf["lateral_velocity_on"];
    search_velocity_ = lattice_conf["search_velocity"];
    use_prediction_ = lattice_conf["use_prediction"];
    warp_time_ = lattice_conf["warp_time"];
    SAMPLE_DISTANCE = lattice_conf["sample_distance"];
    extend_len_ = lattice_conf["extend_len"];

    PLAN_T_INTERVAL_ = lattice_conf["plan_time_interval"];
    SAMPLE_T_INTERVAL_ = lattice_conf["sample_time_interval"];
    MAX_TIME_ = lattice_conf["max_plan_time"];
    MIN_TIME_ = lattice_conf["min_plan_time"];
    SAMPLE_ROAD_INTERVAL_ = lattice_conf["sample_width_interval"];
    MAX_ROAD_WIDTH_ = lattice_conf["max_road_width"];
    // cost weights
    K_OFFSET = lattice_conf["lateral_offset_cost"];
    K_LAT_JERK = lattice_conf["lateral_jerk_cost"];
    K_LON_JERK = lattice_conf["longitude_jerk_cost"];
    K_ACCE = lattice_conf["centripetal_acce_cost"];
    K_TARGET = lattice_conf["goal_cost"];
    K_DISTANCE = lattice_conf["risk_distance_cost"];
    K_SPEED = lattice_conf["target_speed_cost"];

    k_lat = lattice_conf["k_lat"];
    k_lon = lattice_conf["k_lon"];
    k_j_lat = lattice_conf["k_j_lat"];
    k_j_lon = lattice_conf["k_j_lon"];
    k_T_lat = lattice_conf["k_T_lat"];
    k_T_lon = lattice_conf["k_T_lon"];
    k_d2_lat = lattice_conf["k_d2_lat"];
    k_s2_lon = lattice_conf["k_s2_lon"];
    k_s_prime_lon = lattice_conf["k_s_prime_lon"];
    unleashed_ = lattice_conf["unleashed"];
    tamed_ = lattice_conf["tamed"];

    auto vehicle_conf = g_pp_conf["vehicle_setting"];
    MIN_STEERING_RADIUS_ = vehicle_conf["min_turn_radius"];
    CarWeight_ = vehicle_conf["car_weight"];
    MaxPower_ = vehicle_conf["max_power"];

    auto rrt_conf = g_pp_conf["rrt_setting"];
    predmap_as_free_ = rrt_conf["predmap_as_free"];
    ref_line_interval_ = rrt_conf["ref_line_interval"];
    insert_distance_ = rrt_conf["insert_distance"];

    output_by_time_ = 0;

    return AD_SUCCESS;
}

adStatus_t LatticeCore::MatchPoint(cv::Point2f pt, int32_t* curr_index) {
    *curr_index = 0;
    float32_t min_dis = std::numeric_limits<float32_t>::max();
    for (uint32_t i = 0; i < base_path_.size(); i++) {
        if (cv::norm(base_path_[i].position - pt) > min_dis) {
            break;
        } else {
            min_dis = cv::norm(base_path_[i].position - pt);
            *curr_index = i;
        }
    }
    return AD_SUCCESS;
}

adStatus_t LatticeCore::MatchCurrentFrenetStatus() {
    // get vehicle status in frenet frame
    float32_t curr_speed = active_vehicle_state_.velocity;
    float32_t current_acceleration = active_vehicle_state_.acceleration;
    MatchPoint(cv::Point2f(active_vehicle_state_.x, active_vehicle_state_.y),
               &curr_index_);

    // calculate the current state
    float tangent = std::tan(active_vehicle_state_.front_wheel_angle) / 2.0;
    auto v_tangent = cv::Point2f(1.0, tangent);
    v_tangent = v_tangent * (1.0 / cv::norm(v_tangent));

    float32_t cos_theta, sin_theta, base_heading = 0.0;
    auto base_direction = base_path_[curr_index_].direction;
    base_direction = base_direction * (1.0 / cv::norm(base_direction));

    base_heading = std::atan2(base_direction.y, base_direction.x);
    // the angle between the v or a and the direction of refline
    float32_t theta =
        // active_vehicle_state_.heading + vec_direct_in_veh_frame -
        // base_heading;
        active_vehicle_state_.heading - base_heading;
    cos_theta = std::cos(theta);
    sin_theta = std::sin(theta);

    curr_lon_speed = curr_speed * cos_theta;
    curr_lat_speed = curr_speed * sin_theta;
    curr_lat_acce = current_acceleration * sin_theta;
    curr_lon_acce = current_acceleration * cos_theta;

    // TODO(congq): validate the start
    cv::Point2f curr_pos =
        cv::Point2f(active_vehicle_state_.x, active_vehicle_state_.y);
    auto v_base_to_curr_pos = curr_pos - base_path_[curr_index_].position;
    auto v_base_direction = base_path_[curr_index_].direction;

    AD_LINFO(LATTICE) << "Current pos " << v_base_to_curr_pos << " "
                      << v_base_direction;

    // cosine * norm(v_base to currpose)
    curr_lon_position = (v_base_to_curr_pos.x * v_base_direction.x +
                         v_base_to_curr_pos.y * v_base_direction.y) /
                            cv::norm(v_base_direction) +
                        curr_index_ * ref_line_interval_;

    curr_lat_position = (v_base_to_curr_pos.y * v_base_direction.x -
                         v_base_to_curr_pos.x * v_base_direction.y) /
                        cv::norm(v_base_direction);

    // begin to plan
    if (longitude_acc_on_ == 0) {
        curr_lon_acce = 0.0;
    }
    if (lateral_acc_on_ == 0) {
        curr_lat_acce = 0.0;
    }
    if (lateral_velocity_on_ == 0) {
        curr_lat_speed = 0.0;
    }

    if (agent_mode_ == 1) {
        TrajectoryPoint curr_tjp;
        curr_tjp.position = curr_pos;
        float ds, dds, dd, ddd;
        CartesianToFrenet(curr_tjp, base_path_, &curr_lon_position, &ds, &dds,
                          &curr_lat_position, &dd, &ddd);
    }

    AD_LINFO(LATTICE) << "curr_index: " << curr_index_ << " "
                      << "curr pos: " << curr_pos << " "
                      << "theta: " << theta << " "
                      << "base pos: " << base_path_[curr_index_].position << " "
                      << "base direciton : "
                      << base_path_[curr_index_].direction << " "
                      << "curr_lon_position: " << curr_lon_position << " "
                      << "curr_lon_speed: " << curr_lon_speed << " "
                      << "curr_lon_acce: " << curr_lon_acce << " "
                      << "curr_lat_position: " << curr_lat_position << " "
                      << "curr_lat_speed: " << curr_lat_speed << " "
                      << "curr_lat_acce: " << curr_lat_acce;
    return AD_SUCCESS;
}

adStatus_t LatticeCore::Plan(std::vector<TrajectoryPoint>* out_path) {
    auto pp_start = std::chrono::high_resolution_clock::now();
    if (base_path_.size() == 0) {
        out_path->clear();
        out_path->push_back(start_);
        out_path->push_back(goal_);
        AD_LERROR(LATTICE) << "BasePath's size is zero.";
        return AD_INVALID_PARAM;
    }
    nn_tool_.UpdateData(base_path_);
    if (agent_mode_ == 0) {
        active_vehicle_state_ = g_vehicle_state;
    }

    auto match_status_start = std::chrono::high_resolution_clock::now();
    out_path->clear();
    // Match starting status
    MatchCurrentFrenetStatus();
    // Match goal status
    if (agent_mode_ == 0) {
        utils::CartesianToFrenet(goal_, base_path_, &goal_s, &goal_ds,
                                 &goal_dds, &goal_d, &goal_dd, &goal_ddd);
    } else {
        CartesianToFrenet(goal_, base_path_, &goal_s, &goal_ds, &goal_dds,
                          &goal_d, &goal_dd, &goal_ddd);
    }
    AD_LINFO(LATTICE) << "Goal " << goal_.position;
    AD_LINFO(LATTICE) << "Goal s & d " << goal_s << " " << goal_d;
    AD_LINFO(LATTICE) << "Match Status";

    auto after_status_match = std::chrono::high_resolution_clock::now();
    auto match_cost = (after_status_match - match_status_start);
    AD_LINFO(LATTICE) << "====MatchInitStatus=====: "
                      << std::chrono::duration<float32_t>(match_cost).count();
    // Generate Lon and lat path
    ConfigureMode();
    CalculateFrenetPaths(curr_lon_speed, curr_lat_position, curr_lat_speed,
                         curr_lat_acce, curr_lon_position, curr_lon_acce);

    AD_LINFO(LATTICE) << "Calculate Trajectory Path Number:"
                      << frenet_paths_.size();
    auto after_frenet = std::chrono::high_resolution_clock::now();
    auto frenet_cost = (after_frenet - after_status_match);
    AD_LINFO(LATTICE) << "=====CalculateFrenetPaths=====: "
                      << std::chrono::duration<float32_t>(frenet_cost).count();
    // filter path with collision check
    CheckPath();
    auto after_check_point = std::chrono::high_resolution_clock::now();
    auto check_cost = (after_check_point - after_frenet);
    AD_LINFO(LATTICE) << "=====CheckPath=====: "
                      << std::chrono::duration<float32_t>(check_cost).count();
    // Select path with min cost
    if (frenet_paths_.size() > 0) {
        SampleByTime();
    } else {
        SampleByTime();
    }

    if (agent_mode_ == 0 && output_by_time_ != 1) {
        SampleByDistance();
    }

    // to ensure the path's end is 0
    if (curr_behavior == Behavior::STOP && out_path_.size() > 0) {
        out_path_.back().velocity = 0.0;
    }

    *out_path = out_path_;

    auto pp_end = std::chrono::high_resolution_clock::now();
    auto duration = (pp_end - pp_start);
    AD_LINFO(LATTICE) << "out_path->size(): " << out_path->size();
    AD_LINFO(LATTICE) << "=====TotalTime=====: "
                      << std::chrono::duration<float32_t>(duration).count();

    return AD_SUCCESS;
}

adStatus_t LatticeCore::ConfigureMode() {
    if (tamed_ == 1) {
        if (unleashed_ == 1) {
            goal_.velocity = goal_.velocity + 2.0;
        } else {
            // to nothing
        }
    } else {
        if (unleashed_ == 1) {
            goal_.velocity = 15;
        } else {
            goal_.velocity = AnticipateVelocity(base_path_);
            goal_d = 0;
            MAX_ROAD_WIDTH_ = 4;
        }
    }

    auto my_vp_s = std::fabs(goal_.velocity * goal_.velocity -
                             active_vehicle_state_.velocity *
                                 active_vehicle_state_.velocity) /
                   2.0 / 1.0;
    auto my_vp_s_min = std::fabs(goal_.velocity * goal_.velocity -
                                 active_vehicle_state_.velocity *
                                     active_vehicle_state_.velocity) /
                       2.0 / 3.0;

    if (vp_s_ > my_vp_s * 2.0) {
        vp_s_ = my_vp_s;
    }
    if (vp_s_ < my_vp_s_min / 2.0) {
        vp_s_ = my_vp_s_min;
    }

    t_search_range_low_ = MIN_TIME_;
    t_search_range_up_ = MAX_TIME_;
    t_search_range_step_ = SAMPLE_T_INTERVAL_;

    width_search_range_low_ = -MAX_ROAD_WIDTH_;
    width_search_range_up_ = MAX_ROAD_WIDTH_;
    width_search_range_step_ = SAMPLE_ROAD_INTERVAL_;
    AD_LINFO(LATTICE) << width_search_range_step_;
    v_search_range_low_ = 0.0;
    // TODO(should update later)
    v_search_range_up_ = goal_.velocity;
    v_search_range_step_ = 1.0;

    // unused for now
    s_search_range_low_ = 0.0;
    s_search_range_up_ = 0.0;
    s_search_range_step_ = 1.0;

    // lon case
    if (active_vehicle_state_.velocity < low_speed_threshold_ ||
        goal_.velocity < low_speed_threshold_) {
        curr_lon_case = LonCase::LOWSPEED;
    } else {
        curr_lon_case = LonCase::CRUISE;
    }

    // TODO(congq): more behavior
    // Behavior
    if (goal_.velocity < 0.001) {
        curr_behavior = Behavior::STOP;
    } else {
        curr_behavior = Behavior::KEEP_SPEED;
    }

    // start go straight at first
    if (active_vehicle_state_.velocity < 2 || goal_.velocity < 2.0) {
        width_search_range_low_ = -0.01;
        width_search_range_up_ = 0.01;
    }

    // time range should be reasonable, search from 0 when need to stop, bound
    // to max_acc otherwise
    float32_t max_acc = 2.0;
    if (goal_.velocity < active_vehicle_state_.velocity) {
        max_acc = 4.0;
    }
    t_search_range_low_ = std::min(
        std::abs(active_vehicle_state_.velocity - goal_.velocity) / max_acc,
        static_cast<double>(MIN_TIME_));
    if (active_vehicle_state_.velocity < 3.0 && goal_.velocity < 0.01) {
        t_search_range_low_ = 0.1;
    }
    // need more time then max time
    float32_t t_search_range_up_ =
        std::max(static_cast<double>(MAX_TIME_),
                 static_cast<double>(t_search_range_low_ + 3.0));

    if (std::fabs(goal_d) > MAX_ROAD_WIDTH_) {
        goal_d = goal_d / std::abs(goal_d) * 3.5;
        width_search_range_up_ = 0.1;
        width_search_range_low_ = -0.1;
    }

    AD_LINFO(LATTICE) << "current setting";

    AD_LINFO(LATTICE) << "current behavior " << curr_behavior;
    AD_LINFO(LATTICE) << "current loncase " << curr_lon_case;

    AD_LINFO(LATTICE) << "time " << t_search_range_low_ << " "
                      << t_search_range_up_ << " " << t_search_range_step_;
    AD_LINFO(LATTICE) << "velocity " << v_search_range_low_ << " "
                      << v_search_range_up_ << " " << v_search_range_step_;
    AD_LINFO(LATTICE) << "width " << width_search_range_low_ << " "
                      << width_search_range_up_ << " "
                      << width_search_range_step_;
    AD_LINFO(LATTICE) << "s " << s_search_range_low_ << " "
                      << s_search_range_up_ << " " << s_search_range_step_;
    AD_LINFO(LATTICE) << "goal s d " << goal_s << " " << goal_d;

    return AD_SUCCESS;
}

adStatus_t LatticeCore::CalculateFrenetPaths(float32_t curr_speed,
                                             float32_t curr_lat_position,
                                             float32_t curr_lat_speed,
                                             float32_t curr_lat_acce,
                                             float32_t curr_course_position,
                                             float32_t curr_course_acce) {
    lat_paths.clear();
    lon_paths.clear();
    lat_j_cost.clear();
    lon_j_cost.clear();
    lat_T_cost.clear();
    lon_T_cost.clear();
    lat_d_cost.clear();
    lon_s_cost.clear();
    lon_s_prime_cost.clear();
    frenet_paths_.clear();

    if (curr_lon_case == LonCase::LOWSPEED) {
        if (curr_behavior == Behavior::STOP) {
            for (float32_t Ti = t_search_range_low_; Ti <= t_search_range_up_;
                 Ti += t_search_range_step_) {
                AD_LINFO(LATTICE) << "vp_s_ " << vp_s_;
                float32_t la0, la1, la2, la3, la4, la5;
                // TODO(congq): search for s
                for (float32_t si =
                         std::max(1.0, static_cast<double>(vp_s_ - 5));
                     si <= vp_s_ + 1.0; si += 0.5) {
                    SolveQuinticPoly(curr_course_position, curr_speed,
                                     curr_course_acce, si, 0.0, 0.0, Ti, &la0,
                                     &la1, &la2, &la3, &la4, &la5);

                    polynomial<double> lon_qp = {la0, la1, la2, la3, la4, la5};
                    lon_paths.push_back(lon_qp);
                    auto jt =
                        lon_qp.differential().differential().differential();
                    jt = jt * jt;
                    jt = jt.integral(0);
                    auto integral_jerk = jt(Ti) - jt(0.0);
                    lon_j_cost.push_back(integral_jerk);
                    lon_T_cost.push_back(Ti);
                    lon_s_prime_cost.push_back(si * si);

                    for (float32_t di = width_search_range_low_;
                         di <= width_search_range_up_;
                         di += width_search_range_step_) {
                        float32_t a0, a1, a2, a3, a4, a5;
                        SolveQuinticPoly(curr_lat_position, 0, 0, di + goal_d,
                                         0.0, 0.0, si, &a0, &a1, &a2, &a3, &a4,
                                         &a5);
                        polynomial<double> lat_qp2 = {a0, a1, a2, a3, a4, a5};

                        lat_paths.push_back(lat_qp2);

                        auto jt_lat = lat_qp2.differential()
                                          .differential()
                                          .differential();

                        jt_lat = jt_lat * jt_lat;
                        jt_lat = jt_lat.integral(0);
                        auto integral_jerk = jt_lat(si) - jt_lat(0.0);
                        // TODO(congq): to implement low speed jerk cost;
                        lat_j_cost.push_back(integral_jerk);
                        lat_T_cost.push_back(si);
                        lat_d_cost.push_back(di * di);
                        // AD_LINFO(LATTICE) << Ti << " " << di;

                        FrenetPath fp;
                        fp.lat_id = lat_paths.size() - 1;
                        fp.lon_id = lon_paths.size() - 1;
                        // AD_LINFO(LATTICE) << "T lat lon " <<
                        // lat_T_cost.back()
                        //                   << " " << lon_T_cost.back();
                        fp.cost =
                            k_lat * (k_j_lat * lat_j_cost.back() +
                                     k_T_lat * lat_T_cost.back() +
                                     k_d2_lat * lat_d_cost.back()) +
                            k_lon * (k_j_lon * lon_j_cost.back() +
                                     k_T_lon * lon_T_cost.back() +
                                     k_s_prime_lon * lon_s_prime_cost.back());
                        frenet_paths_.push_back(fp);
                    }
                }
            }
        } else {
            // TODO(congq): to handle more case
            for (float32_t Ti = t_search_range_low_; Ti <= t_search_range_up_;
                 Ti += t_search_range_step_) {
                // TODO(congq): configurable
                for (float32_t tv = v_search_range_low_;
                     tv <= v_search_range_up_;
                     tv += (v_search_range_up_ + 2.0 - tv) / 3.0) {
                    float32_t la0, la1, la2, la3, la4;
                    SolveQuarticPoly(curr_course_position, curr_speed,
                                     curr_course_acce, tv, 0.0, Ti, &la0, &la1,
                                     &la2, &la3, &la4);

                    polynomial<double> lon_qp = {la0, la1, la2, la3, la4};
                    lon_paths.push_back(lon_qp);
                    auto jt =
                        lon_qp.differential().differential().differential();
                    jt = jt * jt;
                    jt = jt.integral(0);
                    auto integral_jerk = jt(Ti) - jt(0.0);
                    lon_j_cost.push_back(integral_jerk);
                    lon_T_cost.push_back(Ti);
                    lon_s_prime_cost.push_back((tv - goal_.velocity) *
                                               (tv - goal_.velocity));
                    AD_LDEBUG(LATTICE) << Ti << " " << tv;

                    for (float32_t di = width_search_range_low_;
                         di <= width_search_range_up_;
                         di += width_search_range_step_) {
                        float32_t a0, a1, a2, a3, a4, a5;
                        SolveQuinticPoly(curr_lat_position, 0, 0, di + goal_d,
                                         0.0, 0.0, lon_qp(Ti), &a0, &a1, &a2,
                                         &a3, &a4, &a5);
                        polynomial<double> lat_qp2 = {a0, a1, a2, a3, a4, a5};

                        lat_paths.push_back(lat_qp2);

                        auto jt = lat_qp2.differential()
                                      .differential()
                                      .differential();

                        jt = jt * jt;
                        jt = jt.integral(0);
                        auto integral_jerk = jt(Ti) - jt(0.0);
                        lat_j_cost.push_back(integral_jerk);
                        lat_T_cost.push_back(Ti);
                        lat_d_cost.push_back(di * di);

                        AD_LDEBUG(LATTICE) << width_search_range_step_;
                        AD_LDEBUG(LATTICE) << Ti << " " << di;

                        FrenetPath fp;
                        fp.lat_id = lat_paths.size() - 1;
                        fp.lon_id = lon_paths.size() - 1;
                        AD_LDEBUG(LATTICE) << "T lat lon " << lat_T_cost.back()
                                           << " " << lon_T_cost.back();
                        fp.cost =
                            k_lat * (k_j_lat * lat_j_cost.back() +
                                     k_T_lat * lat_T_cost.back() +
                                     k_d2_lat * lat_d_cost.back()) +
                            k_lon * (k_j_lon * lon_j_cost.back() +
                                     k_T_lon * lon_T_cost.back() +
                                     k_s_prime_lon * lon_s_prime_cost.back());
                        frenet_paths_.push_back(fp);
                    }
                }
                /*
                for (auto i = lon_begin_id; i < lon_paths.size(); i++) {
                    for (auto j = lat_begin_id; j < lat_paths.size(); j++) {
                        FrenetPath fp;
                        fp.lat_id = j;
                        fp.lon_id = i;
                        AD_LDEBUG(LATTICE) << "T lat lon " << lat_T_cost[j]
                                           << " " << lon_T_cost[i];
                        fp.cost = k_lat * (k_j_lat * lat_j_cost[j] +
                                           k_T_lat * lat_T_cost[j] +
                                           k_d2_lat * lat_d_cost[j]) +
                                  k_lon * (k_j_lon * lon_j_cost[i] +
                                           k_T_lon * lon_T_cost[i] +
                                           k_s_prime_lon * lon_s_prime_cost[i]);
                        frenet_paths_.push_back(fp);
                    }
                }*/
            }
        }
    } else {
        if (curr_behavior == Behavior::STOP) {
            for (float32_t Ti = t_search_range_low_; Ti <= t_search_range_up_;
                 Ti += t_search_range_step_) {
                int lat_begin_id = lat_paths.size();
                int lon_begin_id = lon_paths.size();
                for (float32_t di = width_search_range_low_;
                     di <= width_search_range_up_;
                     di += width_search_range_step_) {
                    float32_t a0, a1, a2, a3, a4, a5;
                    SolveQuinticPoly(curr_lat_position, curr_lat_speed,
                                     curr_lat_acce, di + goal_d, 0.0, 0.0, Ti,
                                     &a0, &a1, &a2, &a3, &a4, &a5);
                    polynomial<double> lat_qp2 = {a0, a1, a2, a3, a4, a5};

                    lat_paths.push_back(lat_qp2);

                    auto jt =
                        lat_qp2.differential().differential().differential();

                    jt = jt * jt;
                    jt = jt.integral(0);
                    auto integral_jerk = jt(Ti) - jt(0.0);
                    lat_j_cost.push_back(integral_jerk);
                    lat_T_cost.push_back(Ti);
                    lat_d_cost.push_back(di * di);
                    AD_LINFO(LATTICE) << Ti << " " << di;
                }

                AD_LINFO(LATTICE) << "vp_s_ " << vp_s_;
                float32_t la0, la1, la2, la3, la4, la5;
                // TODO(congq): search for s
                for (float32_t si =
                         std::max(1.0, static_cast<double>(vp_s_ - 5));
                     si <= vp_s_ + 5; si += 0.5) {
                    SolveQuinticPoly(curr_course_position, curr_speed,
                                     curr_course_acce, si, 0.0, 0.0, Ti, &la0,
                                     &la1, &la2, &la3, &la4, &la5);

                    polynomial<double> lon_qp = {la0, la1, la2, la3, la4, la5};
                    lon_paths.push_back(lon_qp);
                    auto jt =
                        lon_qp.differential().differential().differential();
                    jt = jt * jt;
                    jt = jt.integral(0);
                    auto integral_jerk = jt(Ti) - jt(0.0);
                    lon_j_cost.push_back(integral_jerk);
                    lon_T_cost.push_back(Ti);
                    lon_s_prime_cost.push_back(si * si);
                }

                for (size_t i = lon_begin_id; i < lon_paths.size(); i++) {
                    for (size_t j = lat_begin_id; j < lat_paths.size(); j++) {
                        FrenetPath fp;
                        fp.lat_id = j;
                        fp.lon_id = i;
                        AD_LINFO(LATTICE) << "T lat lon " << lat_T_cost[j]
                                          << " " << lon_T_cost[i];
                        fp.cost = k_lat * (k_j_lat * lat_j_cost[j] +
                                           k_T_lat * lat_T_cost[j] +
                                           k_d2_lat * lat_d_cost[j]) +
                                  k_lon * (k_j_lon * lon_j_cost[i] +
                                           k_T_lon * lon_T_cost[i] +
                                           k_s_prime_lon * lon_s_prime_cost[i]);
                        frenet_paths_.push_back(fp);
                    }
                }
            }
        } else {
            // TODO(congq): to handle more case
            for (float32_t Ti = t_search_range_low_; Ti <= t_search_range_up_;
                 Ti += t_search_range_step_) {
                int lat_begin_id = lat_paths.size();
                int lon_begin_id = lon_paths.size();
                for (float32_t di = width_search_range_low_;
                     di <= width_search_range_up_;
                     di += width_search_range_step_) {
                    float32_t a0, a1, a2, a3, a4, a5;
                    SolveQuinticPoly(curr_lat_position, curr_lat_speed,
                                     curr_lat_acce, di + goal_d, 0.0, 0.0, Ti,
                                     &a0, &a1, &a2, &a3, &a4, &a5);
                    polynomial<double> lat_qp2 = {a0, a1, a2, a3, a4, a5};

                    lat_paths.push_back(lat_qp2);

                    auto jt =
                        lat_qp2.differential().differential().differential();

                    jt = jt * jt;
                    jt = jt.integral(0);
                    auto integral_jerk = jt(Ti) - jt(0.0);
                    lat_j_cost.push_back(integral_jerk);
                    lat_T_cost.push_back(Ti);
                    lat_d_cost.push_back(di * di);

                    // AD_LINFO(LATTICE) << width_search_range_step_;
                    // AD_LINFO(LATTICE) << Ti << " " << di;
                }
                // TODO(congq): configurable
                for (float32_t tv = v_search_range_low_;
                     tv <= v_search_range_up_;
                     tv += (v_search_range_up_ + 2.0 - tv) / 3.0) {
                    float32_t la0, la1, la2, la3, la4;
                    SolveQuarticPoly(curr_course_position, curr_speed,
                                     curr_course_acce, tv, 0.0, Ti, &la0, &la1,
                                     &la2, &la3, &la4);

                    polynomial<double> lon_qp = {la0, la1, la2, la3, la4};
                    lon_paths.push_back(lon_qp);
                    auto jt =
                        lon_qp.differential().differential().differential();
                    jt = jt * jt;
                    jt = jt.integral(0);
                    auto integral_jerk = jt(Ti) - jt(0.0);
                    lon_j_cost.push_back(integral_jerk);
                    lon_T_cost.push_back(Ti);
                    lon_s_prime_cost.push_back((tv - goal_.velocity) *
                                               (tv - goal_.velocity));
                    // AD_LINFO(LATTICE) << Ti << " " << tv;
                }
                for (size_t i = lon_begin_id; i < lon_paths.size(); i++) {
                    for (size_t j = lat_begin_id; j < lat_paths.size(); j++) {
                        FrenetPath fp;
                        fp.lat_id = j;
                        fp.lon_id = i;
                        AD_LDEBUG(LATTICE) << "T lat lon " << lat_T_cost[j]
                                           << " " << lon_T_cost[i];
                        fp.cost = k_lat * (k_j_lat * lat_j_cost[j] +
                                           k_T_lat * lat_T_cost[j] +
                                           k_d2_lat * lat_d_cost[j]) +
                                  k_lon * (k_j_lon * lon_j_cost[i] +
                                           k_T_lon * lon_T_cost[i] +
                                           k_s_prime_lon * lon_s_prime_cost[i]);
                        frenet_paths_.push_back(fp);
                    }
                }
            }
        }
    }
    AD_LINFO(PATH_PLANNING) << "Candidate number: " << frenet_paths_.size();
    std::sort(frenet_paths_.begin(), frenet_paths_.end(),
              [](const FrenetPath& a, const FrenetPath& b) -> bool {
                  return a.cost < b.cost;
              });
    return AD_SUCCESS;
}

adStatus_t LatticeCore::CheckPath() {
    int first_non_collided_id = -1;
    for (size_t i = 0; i < frenet_paths_.size(); i++) {
        bool is_free = true;
        auto fp = frenet_paths_[i];
        auto fp_lat = lat_paths[fp.lat_id];
        auto fp_lon = lon_paths[fp.lon_id];

        for (float ts = 0.0; ts < 3.0; ts = ts + 0.3) {
            int risk = 0;
            if (curr_lon_case == LonCase::CRUISE) {
                func_int_frenet_risk(fp_lon(ts), fp_lat(ts), 0.0, ts, 0.0, 0.0,
                                     &risk);
            } else {
                auto s_ts = fp_lon(ts);
                func_int_frenet_risk(s_ts, fp_lat(s_ts), 0.0, ts, 0.0, 0.0,
                                     &risk);
            }
            // AD_LINFO(LATTICE) << fp_lon(ts) << " " << fp_lat(ts) << " "
            // <<
            // ts<< " " << risk;

            if (risk > 9) {
                is_free = false;
                break;
            }
            TrajectoryPoint tp;
            if (curr_lon_case == LonCase::CRUISE) {
                if (agent_mode_ == 0) {
                    utils::FrenetToCartesian(fp_lon(ts), 0, 0, fp_lat(ts), 0, 0,
                                             base_path_, &tp);
                } else {
                    FrenetToCartesian(fp_lon(ts), 0, 0, fp_lat(ts), 0, 0,
                                      base_path_, &tp);
                }

            } else {
                auto s_ts = fp_lon(ts);
                if (agent_mode_ == 0) {
                    utils::FrenetToCartesian(s_ts, 0, 0, fp_lat(s_ts), 0, 0,
                                             base_path_, &tp);
                } else {
                    FrenetToCartesian(s_ts, 0, 0, fp_lat(s_ts), 0, 0,
                                      base_path_, &tp);
                }
            }
            IsFree_(tp.position, &is_free);
            if (!is_free) {
                break;
            }
        }
        if (is_free) {
            first_non_collided_id = i;
            break;
        }
    }

    if (first_non_collided_id != -1) {
        auto fp = frenet_paths_[first_non_collided_id];
        frenet_paths_.clear();
        frenet_paths_.push_back(fp);
        AD_LINFO(LATTICE) << "found non collided path "
                          << first_non_collided_id;
        AD_LINFO(LATTICE) << "lon path " << lon_paths[fp.lon_id];
        AD_LINFO(LATTICE) << "lat path " << lat_paths[fp.lat_id];

    } else {
        frenet_paths_.clear();
        AD_LINFO(LATTICE) << "non collided path not found"
                          << first_non_collided_id;
    }

    return AD_SUCCESS;
}

adStatus_t LatticeCore::SampleByTime() {
    if (frenet_paths_.size() > 0) {
        auto fp = frenet_paths_.front();
        auto lat_id = fp.lat_id;
        auto lon_id = fp.lon_id;
        auto Ti = lon_T_cost[lon_id];

        auto lon_path = lon_paths[lon_id];
        auto lat_path = lat_paths[lat_id];

        auto lon_deri = lon_path.differential();
        auto lat_deri = lat_path.differential();

        auto lon_deri_deri = lon_deri.differential();
        auto lat_deri_deri = lat_deri.differential();

        Trajectory traj;

        AD_LINFO(LATTICE) << "Ti in the sample " << Ti;
        float32_t ti_inc = 0.1;
        if (agent_mode_ == 1) {
            ti_inc = 0.033;
        }
        for (float32_t ti = 0.0; ti <= Ti; ti += ti_inc) {
            TrajectoryPoint tp;
            auto lon_i = lon_path(ti);
            float32_t lat_i = 0.0;
            if (curr_lon_case == LonCase::CRUISE) {
                lat_i = lat_path(ti);
            } else {
                lat_i = lat_path(lon_i);
            }
            AD_LINFO(LATTICE) << "s d are " << lon_i << " " << lat_i;
            if (agent_mode_ == 0) {
                utils::FrenetToCartesian(lon_i, 0, 0, lat_i, 0, 0, base_path_,
                                         &tp);
            } else {
                FrenetToCartesian(lon_i, 0, 0, lat_i, 0, 0, base_path_, &tp);
            }
            tp.velocity = lon_deri(ti);
            /*
            tp.velocity = std::sqrt(lon_deri(ti) * lon_deri(ti) +
                                    lat_deri(ti) * lat_deri(ti));
            */
            tp.acceleration = lon_deri_deri(ti);

            traj.push_back(tp);
        }
        if (traj.size() < 1) {
            AD_LINFO(LATTICE) << "No path output";
        } else if (traj.size() < 2) {
            AD_LINFO(LATTICE) << "single path point output";
            auto curr_direction =
                cv::Point2f(cos(active_vehicle_state_.heading),
                            sin(active_vehicle_state_.heading));
            traj[0].direction = curr_direction;
            traj[0].theta = active_vehicle_state_.heading;
        } else {
            auto normalize_vec = [](cv::Point2f& v_to_norm) -> bool {
                auto norm_of_vec = cv::norm(v_to_norm);
                if (norm_of_vec > 0.0001) {
                    v_to_norm = v_to_norm * (1.0 / norm_of_vec);
                    return true;
                } else {
                    return false;
                }
            };

            auto first_direction = traj[1].position - traj[0].position;
            if (normalize_vec(first_direction)) {
                traj[0].direction = first_direction;
                traj[0].theta =
                    std::atan2(first_direction.y, first_direction.x);
            } else {
                // TODO(congq): throw exception or some thing?
                //
            }

            auto last_direction =
                traj[traj.size() - 1].position - traj[traj.size() - 2].position;
            if (normalize_vec(last_direction)) {
                traj[traj.size() - 1].direction = last_direction;
                traj[traj.size() - 1].theta =
                    std::atan2(last_direction.y, last_direction.x);
            } else {
                // TODO(congq): throw exception or some thing?
                //
            }

            for (int32_t i = 1; i < static_cast<int32_t>(traj.size()) - 1;
                 i++) {
                auto last_direction =
                    traj[i + 1].position - traj[i - 1].position;
                if (normalize_vec(last_direction)) {
                    traj[i].direction = last_direction;
                    traj[i].theta =
                        std::atan2(last_direction.y, last_direction.x);
                } else {
                    AD_LINFO(LATTICE) << "direction error";
                    // TODO(congq): throw exception or some thing?
                    //
                    traj[i].direction =
                        cv::Point2f(std::sin(g_vehicle_state.heading),
                                    std::cos(g_vehicle_state.heading));
                    traj[i].theta =
                        std::atan2(std::sin(g_vehicle_state.heading),
                                   std::cos(g_vehicle_state.heading));
                }
            }

            if (goal_.velocity < 0.01 && traj.back().velocity < 0.1) {
                AD_LINFO(LATTICE) << "lattice faking stop";
                traj.push_back(traj.back());
                traj.back().position =
                    traj.back().position + traj.back().direction * 0.01;
                traj.back().velocity = 0.0;
                traj.back().acceleration = -1.5;
            }
        }
        core_planning_log_.time_interval = ti_inc;
        out_path_ = traj;
    } else {
        AD_LINFO(PATH_PLANNING) << "frenet paths 's size 0,faking a result";
        out_path_.clear();
        out_path_.push_back(start_);
        out_path_.back().velocity = goal_.velocity;
        out_path_.back().acceleration = 0;
        core_planning_log_.time_interval = -1.0;
        AD_LINFO(LATTICE) << "theta " << out_path_.back().theta;
    }

    core_planning_log_.s.clear();
    core_planning_log_.v.clear();
    core_planning_log_.a.clear();
    core_planning_log_.jerk.clear();
    core_planning_log_.num = static_cast<int>(out_path_.size());
    int i = 0;
    for (auto& tra : out_path_) {
        core_planning_log_.s.push_back(tra.sum_distance);
        core_planning_log_.v.push_back(tra.velocity);
        core_planning_log_.a.push_back(tra.acceleration);
        if (i == 0) {
            core_planning_log_.jerk.push_back(0.0);
        } else {
            core_planning_log_.jerk.push_back(
                (out_path_.at(i).acceleration -
                 out_path_.at(i - 1).acceleration) /
                core_planning_log_.time_interval);
        }
        ++i;
    }
    // fill in the theta
    for (uint32_t i = 0; i < out_path_.size() && i < 100; i += 1) {
        auto trajpt = out_path_[i];
        AD_LINFO(LATTICE) << i << " " << trajpt.position << " "
                          << trajpt.direction << " " << trajpt.velocity << " "
                          << trajpt.theta << " " << trajpt.curvature << " "
                          << trajpt.sum_distance << " "
                          << trajpt.time_difference << " " << trajpt.yaw_rate
                          << " " << trajpt.acceleration;
    }

    return AD_SUCCESS;
}

adStatus_t LatticeCore::SampleByDistance() {
    Trajectory traj;
    utils::SegmentTrajectory(out_path_, insert_distance_, &traj);
    out_path_ = traj;
    if (out_path_.size() == 0) {
        AD_LINFO(LATTICE) << "path size() == 0, elon from begin";
    }
    utils::PathElongation(&out_path_, base_path_, insert_distance_);

    utils::UpdateSumDistance(&out_path_, cv::Point2f(active_vehicle_state_.x,
                                                     active_vehicle_state_.y));

    // TODO(congq): implement ss path
    if (goal_.velocity < 0.01 && traj.back().velocity < 0.1 && vp_s_ < 1.0) {
        AD_LINFO(LATTICE) << "faking velocity after vps";
        for (auto& tjp : out_path_) {
            if (tjp.sum_distance > vp_s_) {
                tjp.velocity = 0.0;
                tjp.acceleration = -1.5;
            }
        }
    }
    FillTimeStamp(&out_path_);
    return AD_SUCCESS;
}

adStatus_t LatticeCore::FillTimeStamp(Trajectory* out_path) {
    auto t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    out_path->front().timestamp =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 10000);
    for (uint32_t i = 1; i < out_path->size(); ++i) {
        float delta_t =
            2.0 * insert_distance_ /
            (out_path->at(i - 1).velocity + out_path->at(i).velocity + 0.0001);
        out_path->at(i).timestamp = out_path->at(i - 1).timestamp +
                                    static_cast<uint64_t>(delta_t * 10e9);
    }
    return AD_SUCCESS;
}

float32_t LatticeCore::AnticipateVelocity(Trajectory& path) {
    if (path.size() < 5 * 30) return 0;
    auto dira = path[124].direction;
    auto dirb = path[99].direction;

    auto curv = std::asin(std::sin(2 * M_PI + std::atan2(dira.y, dira.x) -
                                   std::atan2(dirb.y, dirb.x))) /
                cv::norm(dira - dirb);

    float32_t result = std::sqrt(2.0 / (std::abs(curv) + 0.0001));
    return result;
}

adStatus_t LatticeCore::FrenetToCartesian(
    const float& s,
    const float& ds,
    const float& dds,
    const float& d,
    const float& dd,
    const float& ddd,
    const std::vector<TrajectoryPoint>& ref_path,
    TrajectoryPoint* result_pt) {
    // s / accumulated dist ~= indeiix
    int match_id = std::min(static_cast<int>(s / (ref_path[1].sum_distance -
                                                  ref_path[0].sum_distance)),
                            static_cast<int>(ref_path.size() - 1));

    auto matched_ref_pt = ref_path[match_id];
    AD_LTRACE(PATH_PLANNING)
        << "s d input"
        << " " << s << " " << d << "\nmatched " << matched_ref_pt.position
        << " " << matched_ref_pt.direction << " " << matched_ref_pt.theta;
    auto base_position = matched_ref_pt.position;

    AD_LDEBUG(PATH_PLANNING)
        << "FRENET2CART base_point before " << base_position;
    if (match_id < static_cast<int32_t>(ref_path.size()) - 2) {
        base_position = base_position +
                        (ref_path[match_id + 1].position - base_position) *
                            (s - ref_path[match_id].sum_distance);
    }

    AD_LDEBUG(PATH_PLANNING)
        << "FRENET2CART base_point after " << base_position;

    result_pt->position.x = base_position.x - d * sin(matched_ref_pt.theta);
    result_pt->position.y = base_position.y + d * cos(matched_ref_pt.theta);
    return AD_SUCCESS;
}

adStatus_t LatticeCore::CartesianToFrenet(
    const TrajectoryPoint& pt,
    const std::vector<TrajectoryPoint>& ref_path,
    float* s,
    float* ds,
    float* dds,
    float* d,
    float* dd,
    float* ddd) {
    // TODO(congq): Assertion?
    if (ref_path.size() < 1) return AD_SUCCESS;
    // TODO(congq): to make sure the ref_path is the same of the ref_path used
    int32_t min_index = nn_tool_.NearestNeighbor(pt);
    if (min_index >= static_cast<int32_t>(ref_path.size())) {
        min_index = ref_path.size() - 1;
        AD_LDEBUG(PATH_PLANNING) << "CART2FRENET ecced ";
    }

    AD_LDEBUG(PATH_PLANNING) << "CART2FRENET to convert " << pt.position;
    float cos_A = -1;
    float l_v_c = 0;
    float l_v_b = 0;
    float ref_line_interval =
        ref_path[1].sum_distance - ref_path[0].sum_distance;
    cv::Point2f vec_b(1, 0), vec_c(1, 0);

    AD_LDEBUG(PATH_PLANNING)
        << "CART2FRENET matched " << ref_path[min_index].position;
    vec_b = ref_path[min_index].direction;
    vec_c = pt.position - ref_path[min_index].position;
    l_v_b = cv::norm(vec_b);
    l_v_c = cv::norm(vec_c);

    if ((l_v_c) < 0.0001) {
        *s = static_cast<float>(min_index) * ref_line_interval;
        cos_A = 1;
    } else {
        cos_A = (vec_b.x * vec_c.x + vec_b.y * vec_c.y) / (l_v_b * l_v_c);
    }

    AD_LDEBUG(PATH_PLANNING)
        << "CART2FRENET vec_b vec_c l_v_b l_v_c cos_A" << vec_b << " " << vec_c
        << " " << l_v_b << " " << l_v_c << " " << cos_A;
    while (min_index > 0 && cos_A < 0) {
        min_index--;
        AD_LDEBUG(PATH_PLANNING)
            << "CART2FRENET matched changed " << ref_path[min_index].position;
        vec_b = ref_path[min_index].direction;
        vec_c = pt.position - ref_path[min_index].position;
        l_v_b = cv::norm(vec_b);
        l_v_c = cv::norm(vec_c);
        if ((l_v_c) < 0.0001) {
            *s = static_cast<float>(min_index) * ref_line_interval;
            cos_A = 1;
            AD_LDEBUG(PATH_PLANNING) << "CART2FRENET s " << *s;
        } else {
            cos_A = (vec_b.x * vec_c.x + vec_b.y * vec_c.y) / (l_v_b * l_v_c);
        }
        AD_LDEBUG(PATH_PLANNING)
            << "CART2FRENET vec_b vec_c l_v_b l_v_c cos_A" << vec_b << " "
            << vec_c << " " << l_v_b << " " << l_v_c << " " << cos_A;
    }
    *s = l_v_c * cos_A + static_cast<float>(min_index) * ref_line_interval;
    AD_LDEBUG(PATH_PLANNING)
        << "CART2FRENET s " << *s << " min_index" << min_index;
    float sin_A = 0;
    float mid_val = 1 - cos_A * cos_A;
    if (mid_val > 0) {
        sin_A = std::sqrt(1 - cos_A * cos_A);
    }

    // auto abs_d = sqrt(l_v_c * l_v_c + l_v_b * l_v_b);
    auto abs_d = std::abs(l_v_c * sin_A);
    auto cross_b_c = vec_b.x * vec_c.y - vec_b.y * vec_c.x;
    if (cross_b_c > 1e-4) {
        *d = abs_d;
    } else {
        *d = -abs_d;
    }
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
