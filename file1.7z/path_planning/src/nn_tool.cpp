/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#include <algorithm>
#include "path_planning/nn_tool.hpp"
#include "path_planning/ppconfig.hpp"
#include "common/log.hpp"
#include "common/timing_logger.hpp"

namespace senseAD {
namespace pp {

NNTool::NNTool() {}
NNTool::~NNTool() {
    if (kd_tree_ != NULL) {
        delete_tree_(kd_tree_);
    }
}

adStatus_t NNTool::Init() {
    auto conf = g_pp_conf["nn_tool"];
    nn_tool_mode_ = conf["nn_tool_mode"];
    nn_down_sample_rate_ = conf["nn_down_sample_rate"];
    return AD_SUCCESS;
}

adStatus_t NNTool::UpdateData(const std::vector<TrajectoryPoint>& tj_pts) {
    ids_.clear();
    pts_.clear();
    for (uint32_t i = 0; i < tj_pts.size(); i += nn_down_sample_rate_) {
        ids_.push_back(i / nn_down_sample_rate_);
        pts_.push_back(tj_pts[i].position);
    }

    if (kd_tree_ != NULL) {
        delete_tree_(kd_tree_);
    }
    this->kd_tree_ = build_tree_(&ids_, 0, ids_.size(), 0);
    AD_LINFO(PATH_PLANNING) << "NNTool pts.size " << pts_.size();

    return AD_SUCCESS;
}

int NNTool::NearestNeighbor(const TrajectoryPoint& tjp) const {
    if (pts_.size() == 0) {
        AD_LINFO(PATH_PLANNING)
            << "NNTool no dataset, return random trajectory point";
        return -1;
    }
    // Using brutal
    if (nn_tool_mode_ == 0) {
        float min_dist = std::numeric_limits<float>::max();
        int min_index = -1;
        for (uint32_t i = 0; i < pts_.size(); i++) {
            auto ref_pt = pts_[i];
            if (cv::norm(ref_pt - tjp.position) < min_dist) {
                min_index = i;
                min_dist = cv::norm(ref_pt - tjp.position);
            }
        }
        return min_index * nn_down_sample_rate_;
    }

    if (nn_tool_mode_ == 1) {
        auto result = nn(kd_tree_, tjp.position, 0);
        AD_LDEBUG(PATH_PLANNING) << "NNTool nn " << tjp.position << " "
                                 << result * nn_down_sample_rate_;
        return result * nn_down_sample_rate_;
    }
    return -1;
}

KDTreeNode* NNTool::build_tree_(std::vector<int>* pt_ids,
                                uint32_t begin,
                                uint32_t end,
                                uint32_t depth) {
    if (begin == end) return NULL;
    // TODO(congq): is static faster?
    if (depth % 2 == 1) {
        std::sort(pt_ids->begin() + begin, pt_ids->begin() + end,
                  [this](int& a, int& b) -> bool {
                      return this->pts_[a].x < this->pts_[b].x;
                  });
    } else {
        std::sort(pt_ids->begin() + begin, pt_ids->begin() + end,
                  [this](int& a, int& b) -> bool {
                      return this->pts_[a].y < this->pts_[b].y;
                  });
    }
    KDTreeNode* root = new KDTreeNode();

    uint32_t mid = (begin + end) / 2;
    root->data = pt_ids->at(mid);
    root->left_child_ = build_tree_(pt_ids, begin, mid, depth + 1);
    root->right_child_ = build_tree_(pt_ids, mid + 1, end, depth + 1);
    return root;
}

int NNTool::nn(KDTreeNode* root, cv::Point2f point, int depth) const {
    KDTreeNode *next_branch, *opp_branch;
    if ((depth % 2 == 1 && point.x < pts_[root->data].x) ||
        (depth % 2 != 1 && point.y < pts_[root->data].y)) {
        next_branch = root->left_child_;
        opp_branch = root->right_child_;

    } else {
        next_branch = root->right_child_;
        opp_branch = root->left_child_;
    }

    int tmp_result = root->data;
    if (next_branch != NULL) {
        int nn_next = nn(next_branch, point, depth + 1);
        tmp_result = closer_one(point, nn_next, root->data);
    }
    if (opp_branch != NULL &&
        cv::norm(point - pts_[tmp_result]) >
            std::abs(depth % 2 == 1 ? point.x - pts_[root->data].x
                                    : point.y - pts_[root->data].y)) {
        int nn_opt = nn(opp_branch, point, depth + 1);
        tmp_result = closer_one(point, nn_opt, tmp_result);
    }
    return tmp_result;
}

// TODO(congq): Return bool for effiency
int NNTool::closer_one(const cv::Point2f& point,
                       const int& a,
                       const int& b) const {
    auto d_a = cv::norm(point - pts_[a]);
    auto d_b = cv::norm(point - pts_[b]);
    if (d_a < d_b) {
        return a;
    } else {
        return b;
    }
}

void NNTool::delete_tree_(KDTreeNode* root) {
    if (root->left_child_ != NULL) {
        delete_tree_(root->left_child_);
    }

    if (root->right_child_ != NULL) {
        delete_tree_(root->right_child_);
    }
    delete root;
}

}  // namespace pp
}  // namespace senseAD
