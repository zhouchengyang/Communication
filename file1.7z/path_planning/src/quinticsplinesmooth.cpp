/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include <glog/logging.h>
#include <math.h>
#include <cmath>
#include <string>
#include <functional>
#include <vector>
#include <utility>
#include "path_planning/quinticsplinesmooth.hpp"
#include "eigen3/Eigen/Core"
#include "path_planning/util.hpp"

namespace senseAD {
namespace pp {

LearnableQuintSpline::LearnableQuintSpline() {}

void LearnableQuintSpline::SetInput(const std::vector<float> t_for_points,
                                    const std::vector<float> t_for_curvature) {
    this->t_cur = t_for_curvature;
    this->t_pts = t_for_points;
}

void LearnableQuintSpline::SetOutput(
    std::vector<LearnablePoints> *points,
    std::vector<LearnableVariable> *curvature) {
    if (points == nullptr || curvature == nullptr) return;
    this->ptr_outcur = curvature;
    this->ptr_outpts = points;
}

void LearnableQuintSpline::Initialize(
    const std::vector<LearnablePoints> in_param,
    const std::vector<int> numofeachsegs) {
    this->param = in_param;
    this->numofeachsegs = numofeachsegs;
    this->ss = numofeachsegs.size();
    this->init_adam_params();
}

void LearnableQuintSpline::init_adam_params() {
    this->adam_eps = 1e-6;
    this->adam_b1 = 0.9;
    this->adam_b2 = 0.999;
    this->b1_c = 1.0f;
    this->b2_c = 1.0f;
    this->step = 0;
    if (this->param.size() > 0) {
        this->mm_g.resize(this->param.size());
        for (uint32_t i = 0; i < this->mm_g.size(); i++) {
            this->mm_g[i].v.x = this->mm_g[i].v.y = 0;
            this->mm_g[i].d.x = this->mm_g[i].d.y = 0;
        }
    }
}

void LearnableQuintSpline::Forward() {
    int st_t = 0, et_t = -1;
    for (int32_t k_seg = 0; k_seg < this->ss; k_seg++) {
        cv::Point2f P[6];
        int ii_cuv = k_seg * 3;
        P[0] = this->param[ii_cuv].v;
        P[1] = 0.2 * this->param[ii_cuv + 1].v + P[0];
        P[2] = 0.05 * this->param[ii_cuv + 2].v + 2 * P[1] - P[0];
        P[5] = this->param[ii_cuv + 3].v;
        P[4] = P[5] - 0.2 * this->param[ii_cuv + 4].v;
        P[3] = 0.05 * this->param[ii_cuv + 5].v + 2 * P[4] - P[5];
        et_t = st_t + this->numofeachsegs[k_seg];
        for (int32_t ii = st_t; ii < et_t; ii++) {
            float omt[6], t[6];
            t[1] = this->t_pts[ii];
            t[0] = 1.0f;
            omt[1] = 1 - this->t_pts[ii];
            omt[0] = 1.0f;
            for (int32_t i = 2; i <= 5; i++) {
                t[i] = t[i - 1] * t[1];
                omt[i] = omt[i - 1] * omt[1];
            }
            cv::Point2f PP;
            PP.x = PP.y = 0;
            for (int32_t i = 0; i <= 5; i++) {
                PP = PP + omt[5 - i] * t[i] * this->fac[i] * P[i];
            }
            this->ptr_outpts->at(ii).v = PP;
        }
        st_t = et_t;
        cv::Point2f PV[6];
        for (int32_t ii_r = 0; ii_r <= 5; ii_r++) {
            PV[ii_r].x = 0;
            PV[ii_r].y = 0;
            for (int32_t ii_c = 0; ii_c <= 5; ii_c++) {
                PV[ii_r] = PV[ii_r] + this->dmatrix[ii_r][ii_c] * P[ii_c];
            }
        }
        // for curvature
        for (uint32_t ii = 0; ii < this->t_cur.size(); ii++) {
            float t[5];
            t[0] = 1.0f;
            for (int32_t i = 1; i <= 4; i++) {
                t[i] = t[i - 1] * t_cur[ii];
            }
            // first/second order derivation
            cv::Point2f d, dd;
            d.x = d.y = dd.x = dd.y = 0;
            for (int32_t i = 4; i >= 0; i--) {
                d = d + (i + 1) * t[i] * PV[4 - i];
                if (i <= 3) {
                    dd = dd + (i + 1) * (i + 2) * t[i] * PV[3 - i];
                }
            }
            float curvature = (d.x * dd.y - dd.x * d.y) /
                              pow(d.x * d.x + d.y * d.y, 3.0 / 2.0);
            this->ptr_outcur->at(k_seg * this->t_cur.size() + ii).v = curvature;
        }
    }
}

void LearnableQuintSpline::Backward() {
    for (uint32_t i = 0; i < this->param.size(); i++) {
        param[i].d.x = param[i].d.y = 0;
    }
    // int st_t = 0, et_t = -1, ii_pts = 0, ii_cur = 0;
    // TODO(some): ii_pts ii_cur unused
    int st_t = 0, et_t = -1;
    for (int32_t k_seg = 0; k_seg < this->ss; k_seg++) {
        et_t = st_t + this->numofeachsegs[k_seg];
        cv::Point2f P[6];
        int ii_cuv = k_seg * 3;
        P[0] = this->param[ii_cuv].v;
        P[1] = 0.2 * this->param[ii_cuv + 1].v + P[0];
        P[2] = 0.05 * this->param[ii_cuv + 2].v + 2 * P[1] - P[0];
        P[5] = this->param[ii_cuv + 3].v;
        P[4] = P[5] - 0.2 * this->param[ii_cuv + 4].v;
        P[3] = 0.05 * this->param[ii_cuv + 5].v + 2 * P[4] - P[5];
        // For points
        for (int32_t ii = st_t; ii < et_t; ii++) {
            cv::Point2f dL_dFP = this->ptr_outpts->at(ii).d;
            cv::Point2f dFP_dP[6];
            float omt[6], t[6];
            t[1] = this->t_pts[ii];
            t[0] = 1.0f;
            omt[1] = 1 - this->t_pts[ii];
            omt[0] = 1.0f;
            for (int32_t i = 2; i <= 5; i++) {
                t[i] = t[i - 1] * t[1];
                omt[i] = omt[i - 1] * omt[1];
            }
            for (int32_t i = 0; i <= 5; i++) {
                dFP_dP[i].x = dFP_dP[i].y = omt[5 - i] * t[i] * this->fac[i];
            }
            cv::Point2f de;
            // P0
            de = utils::ep(dL_dFP, dFP_dP[0]);
            // P1 -> P0
            de = de + utils::ep(dL_dFP, dFP_dP[1]);
            // P2 -> P0
            de = de - utils::ep(dL_dFP, dFP_dP[2]);
            // P2 -> P1 -> P0
            de = de + 2 * utils::ep(dL_dFP, dFP_dP[2]);
            this->param[ii_cuv + 0].d = this->param[ii_cuv + 0].d + de;
            // P1 -> t_s
            de = 0.2 * utils::ep(dL_dFP, dFP_dP[1]);
            // P2 -> P1 -> t_s
            de = de + 0.2 * 2 * utils::ep(dL_dFP, dFP_dP[2]);
            this->param[ii_cuv + 1].d = this->param[ii_cuv + 1].d + de;
            // P2 -> a_s
            de = 1.0f / 20 * dFP_dP[2];
            de = utils::ep(de, dL_dFP);
            this->param[ii_cuv + 2].d = this->param[ii_cuv + 2].d + de;
            // P3 -> P5
            de = -utils::ep(dL_dFP, dFP_dP[3]);
            // P4 -> P5
            de = de + utils::ep(dL_dFP, dFP_dP[4]);
            // P5
            de = de + utils::ep(dL_dFP, dFP_dP[5]);
            // P3 -> P4 -> P5
            de = de + 2 * utils::ep(dL_dFP, dFP_dP[3]);
            this->param[ii_cuv + 3].d = this->param[ii_cuv + 3].d + de;
            // P4 -> t_e
            de = -0.2 * utils::ep(dL_dFP, dFP_dP[4]);
            // P3 -> P4 -> t_e
            de = de + 2 * (-0.2) * utils::ep(dL_dFP, dFP_dP[3]);
            this->param[ii_cuv + 4].d = this->param[ii_cuv + 4].d + de;
            // P3 -> a_e
            de = 1.0f / 20 * utils::ep(dL_dFP, dFP_dP[3]);
            this->param[ii_cuv + 5].d = this->param[ii_cuv + 5].d + de;
        }
        st_t = et_t;
        cv::Point2f PV[6];
        for (int32_t ii_r = 0; ii_r <= 5; ii_r++) {
            PV[ii_r].x = 0;
            PV[ii_r].y = 0;
            for (int32_t ii_c = 0; ii_c <= 5; ii_c++) {
                PV[ii_r] = PV[ii_r] + this->dmatrix[ii_r][ii_c] * P[ii_c];
            }
        }
        // For Curvature
        for (uint32_t ii = 0; ii < this->t_cur.size(); ii++) {
            float t[5];
            t[0] = 1.0f;
            for (int32_t i = 1; i <= 4; i++) {
                t[i] = t[i - 1] * t_cur[ii];
            }
            // first/second order derivation
            cv::Point2f d, dd;
            d.x = d.y = dd.x = dd.y = 0;
            for (int32_t i = 4; i >= 0; i--) {
                d = d + (i + 1) * t[i] * PV[4 - i];
                if (i <= 3) {
                    dd = dd + (i + 1) * (i + 2) * t[i] * PV[3 - i];
                }
            }
            // We have to seperate X and Y
            // A is the first order derivation
            // B is the second derivation
            // Now is X!!
            float dL_dC = this->ptr_outcur->at(ii + t_cur.size() * k_seg).d;
            float dC_dA, dC_dB, dA_dPV[6], dB_dPV[6], dC_dPV[6];
            float dC_dP[6];
            dC_dA = -3 * d.x * (d.x * dd.y - d.y * dd.x) /
                    powf(d.x * d.x + d.y * d.y, 5 / 2);
            dC_dA = dC_dA + dd.y / powf(d.x * d.x + d.y * d.y, 3 / 2);
            dC_dB = -d.y / powf(d.x * d.x + d.y * d.y, 3 / 2);
            dC_dA = dC_dA * dL_dC;
            dC_dB = dC_dB * dL_dC;
            for (int32_t i = 0; i <= 4; i++) {
                dA_dPV[i] = (5 - i) * t[4 - i];
            }
            dA_dPV[5] = 0;
            for (int32_t i = 0; i <= 3; i++) {
                dB_dPV[i] = (5 - i) * (4 - i) * t[3 - i];
            }
            dB_dPV[4] = dB_dPV[5] = 0;
            for (int32_t i = 0; i < 6; i++) {
                dC_dPV[i] = dC_dA * dA_dPV[i] + dC_dB * dB_dPV[i];
            }
            for (int32_t i = 0; i < 6; i++) {
                dC_dP[i] = 0;
                for (int32_t j = 0; j < 6; j++) {
                    dC_dP[i] = dC_dP[i] + dC_dPV[j] * dmatrix[j][i];
                }
            }
            float de;
            // P0
            de = dC_dP[0];
            // P1 -> P0
            de = de + dC_dP[1];
            // P2 -> P0
            de = de - dC_dP[2];
            // P2 -> P1 -> P0
            de = de + 2 * dC_dP[2];
            this->param[ii_cuv + 0].d.x = this->param[ii_cuv + 0].d.x + de;
            // P1 -> t_s
            de = 0.2 * dC_dP[1];
            // P2 -> P1 -> t_s
            de = de + 0.2 * 2 * dC_dP[2];
            this->param[ii_cuv + 1].d.x = this->param[ii_cuv + 1].d.x + de;
            // P2 -> a_s
            de = 1.0f / 20 * dC_dP[2];
            this->param[ii_cuv + 2].d.x = this->param[ii_cuv + 2].d.x + de;
            // P3 -> P5
            de = -dC_dP[3];
            // P4 -> P5
            de = de + dC_dP[4];
            // P5
            de = de + dC_dP[5];
            // P3 -> P4 -> P5
            de = de + 2 * dC_dP[3];
            this->param[ii_cuv + 3].d.x = this->param[ii_cuv + 3].d.x + de;
            // P4 -> t_e
            de = -0.2 * dC_dP[4];
            // P3 -> P4 -> t_e
            de = de + 2 * (-0.2) * dC_dP[3];
            this->param[ii_cuv + 4].d.x = this->param[ii_cuv + 4].d.x + de;
            // P3 -> a_e
            de = 1.0f / 20 * dC_dP[3];
            this->param[ii_cuv + 5].d.x = this->param[ii_cuv + 5].d.x + de;

            // Now is Y!!
            dC_dA = -3 * d.y * (d.x * dd.y - d.y * dd.x) /
                    powf(d.x * d.x + d.y * d.y, 5 / 2);
            dC_dA = dC_dA - dd.x / powf(d.x * d.x + d.y * d.y, 3 / 2);
            dC_dB = d.x / powf(d.x * d.x + d.y * d.y, 3 / 2);
            dC_dA = dC_dA * dL_dC;
            dC_dB = dC_dB * dL_dC;
            for (int32_t i = 0; i <= 4; i++) {
                dA_dPV[i] = (5 - i) * t[4 - i];
            }
            dA_dPV[5] = 0;
            for (int32_t i = 0; i <= 3; i++) {
                dB_dPV[i] = (5 - i) * (4 - i) * t[3 - i];
            }
            dB_dPV[4] = dB_dPV[5] = 0;
            for (int32_t i = 0; i < 6; i++) {
                dC_dPV[i] = dC_dA * dA_dPV[i] + dC_dB * dB_dPV[i];
            }
            for (int32_t i = 0; i < 6; i++) {
                dC_dP[i] = 0;
                for (int32_t j = 0; j < 6; j++) {
                    dC_dP[i] = dC_dP[i] + dC_dPV[j] * dmatrix[j][i];
                }
            }
            // P0
            de = dC_dP[0];
            // P1 -> P0
            de = de + dC_dP[1];
            // P2 -> P0
            de = de - dC_dP[2];
            // P2 -> P1 -> P0
            de = de + 2 * dC_dP[2];
            this->param[ii_cuv + 0].d.y = this->param[ii_cuv + 0].d.y + de;
            // P1 -> t_s
            de = 0.2 * dC_dP[1];
            // P2 -> P1 -> t_s
            de = de + 0.2 * 2 * dC_dP[2];
            this->param[ii_cuv + 1].d.y = this->param[ii_cuv + 1].d.y + de;
            // P2 -> a_s
            de = 1.0f / 20 * dC_dP[2];
            this->param[ii_cuv + 2].d.y = this->param[ii_cuv + 2].d.y + de;
            // P3 -> P5
            de = -dC_dP[3];
            // P4 -> P5
            de = de + dC_dP[4];
            // P5
            de = de + dC_dP[5];
            // P3 -> P4 -> P5
            de = de + 2 * dC_dP[3];
            this->param[ii_cuv + 3].d.y = this->param[ii_cuv + 3].d.y + de;
            // P4 -> t_e
            de = -0.2 * dC_dP[4];
            // P3 -> P4 -> t_e
            de = de + 2 * (-0.2) * dC_dP[3];
            this->param[ii_cuv + 4].d.y = this->param[ii_cuv + 4].d.y + de;
            // P3 -> a_e
            de = 1.0f / 20 * dC_dP[3];
            this->param[ii_cuv + 5].d.y = this->param[ii_cuv + 5].d.y + de;
        }
    }
}

void LearnableQuintSpline::Step() {
    // SGD Update
    for (uint32_t i = 0; i < this->param.size(); i++) {
        if (this->param[i].require_grad) {
            if (this->param[i].grad_fixed_direction == false) {
                this->param[i].v =
                    this->param[i].v - this->lr * this->param[i].d;
            } else {
                cv::Point2f d = this->lr * this->param[i].d;
                this->grad_direction_warp(this->param[i].v, &d);
                this->param[i].v = this->param[i].v - d;
            }
        }
    }
}

void LearnableQuintSpline::ADAM_Step() {
    // ADAM Update
    step = step + 1;
    this->b1_c = this->b1_c * this->adam_b1;
    this->b2_c = this->b2_c * this->adam_b2;
    for (uint32_t i = 0; i < this->param.size(); i++) {
        this->mm_g[i].v =
            this->adam_b1 * mm_g[i].v + (1 - this->adam_b1) * this->param[i].d;
        this->mm_g[i].d =
            this->adam_b2 * mm_g[i].d +
            (1 - this->adam_b2) * utils::ep(this->param[i].d, this->param[i].d);
    }
    float bias_correction1 = 1.0f - this->b1_c;
    float bias_correction2 = 1.0f - this->b2_c;
    float step_size = this->lr * sqrtf(bias_correction2) / bias_correction1;
    for (uint32_t i = 0; i < this->param.size(); i++) {
        if (this->param[i].require_grad) {
            cv::Point2f vl = this->mm_g[i].d;
            vl.x = sqrtf(vl.x) + this->adam_eps;
            vl.y = sqrtf(vl.y) + this->adam_eps;
            cv::Point2f upd = this->mm_g[i].v;
            upd.x = upd.x / vl.x;
            upd.y = upd.y / vl.y;
            if (this->param[i].grad_fixed_direction == false) {
                this->param[i].v = this->param[i].v - step_size * upd;
            } else {
                cv::Point2f d = step_size * upd;
                this->grad_direction_warp(this->param[i].v, &d);
                this->param[i].v = this->param[i].v - d;
            }
        }
    }
}

void LearnableQuintSpline::grad_direction_warp(const cv::Point2f &src,
                                               cv::Point2f *grad) {
    cv::Point2f g = *(grad);
    float cosine = 0;
    float norm = 0;
    utils::CalcNorm(g, &norm);
    utils::Cosine2Dvect(src, g, &cosine);
    norm = norm * cosine;
    g = src;
    utils::Normalize2Dvect(&g);
    g = g * norm;
    *(grad) = g;
}

std::vector<LearnablePoints> LearnableQuintSpline::ExportResult() {
    return param;
}

PTSLOSS::PTSLOSS() {}

void PTSLOSS::SetInput(const std::vector<TrajectoryPoint> target_points,
                       std::vector<LearnablePoints> *points) {
    if (points == nullptr) return;
    this->in_points = points;
    this->target_points = target_points;
}

void PTSLOSS::SetOutput(LearnableVariable *loss) {
    if (loss == nullptr) return;
    this->out_loss = loss;
}

void PTSLOSS::Forward() {
    this->out_loss->v = 0;
    this->out_loss->d = 0;
    if (this->target_points.size() == 0 ||
        (this->target_points.size() != this->in_points->size()))
        return;
    float aa = 1.0f / this->target_points.size() * pts_weight;
    for (uint32_t i = 0; i < this->target_points.size(); i++) {
        cv::Point2f minus =
            this->target_points[i].position - this->in_points->at(i).v;
        float tt = (minus.x * minus.x + minus.y * minus.y);
        this->out_loss->v += aa * tt;
        if (tt > this->penalty_distance) {
            this->out_loss->v += penalty_weight * tt;
        }
    }
}

void PTSLOSS::Backward() {
    if (this->target_points.size() == 0 ||
        (this->target_points.size() != this->in_points->size())) {
        AD_LERROR(PATH_PLANNING)
            << "mismatch: target_points.size() != in_points.size()";
        return;
    }
    float aa = 1.0f / this->target_points.size() * pts_weight;
    for (uint32_t i = 0; i < this->in_points->size(); i++) {
        cv::Point2f minus =
            this->in_points->at(i).v - this->target_points[i].position;
        float tt = (minus.x * minus.x + minus.y * minus.y);
        this->in_points->at(i).d = 2 * aa * minus;
        if (tt > this->penalty_distance) {
            this->in_points->at(i).d = 2 * penalty_weight * minus;
        }
    }
}

CurvatureLoss::CurvatureLoss() {}
void CurvatureLoss::SetInput(std::vector<LearnableVariable> *in_curs) {
    if (in_curs == nullptr) return;
    this->in_curs = in_curs;
}

void CurvatureLoss::SetOutput(LearnableVariable *loss) {
    if (loss == nullptr) return;
    this->out_loss = loss;
}

void CurvatureLoss::Forward() {
    float max_cur = -1;
    this->out_loss->v = 0;
    this->out_loss->d = 0;
    if (this->in_curs->size() == 0) return;
    float aa = 1.0f / this->in_curs->size();
    for (int32_t i = 0; i < static_cast<int32_t>(this->in_curs->size()); i++) {
        if (this->in_curs->at(i).v > 0)
            this->out_loss->v = this->out_loss->v + aa * this->in_curs->at(i).v;
        else
            this->out_loss->v = this->out_loss->v - aa * this->in_curs->at(i).v;
        if (fabs(this->in_curs->at(i).v) > max_cur) {
            max_cur = fabs(this->in_curs->at(i).v);
            max_cur_idx = i;
        }
        if (i > 0) {
            float aa = this->in_curs->at(i).v - this->in_curs->at(i - 1).v;
            aa = aa * aa;
            this->out_loss->v += this->cur_change * aa;
        }
        if (i < static_cast<int>(this->in_curs->size()) - 1) {
            float bb = this->in_curs->at(i).v - this->in_curs->at(i + 1).v;
            bb = bb * bb;
            this->out_loss->v += this->cur_change * bb;
        }
    }
    this->out_loss->v = this->out_loss->v * wholescale;
    this->out_loss->v += 10 * max_cur;
}

void CurvatureLoss::Backward() {
    float aa = 1.0f / this->in_curs->size();
    for (int32_t i = 0; i < static_cast<int32_t>(this->in_curs->size()); i++) {
        if (this->in_curs->at(i).v > 0) {
            this->in_curs->at(i).d = aa * wholescale;
        } else {
            this->in_curs->at(i).d = -aa * wholescale;
        }
        if (i > 0) {
            this->in_curs->at(i).d +=
                2 * aa * (this->in_curs->at(i).v - this->in_curs->at(i - 1).v);
        }
        if (i < static_cast<int32_t>(this->in_curs->size()) - 1) {
            this->in_curs->at(i).d +=
                2 * this->cur_change * wholescale * aa *
                (this->in_curs->at(i).v - this->in_curs->at(i + 1).v);
        }
    }
    if (this->in_curs->at(max_cur_idx).v > 0) {
        this->in_curs->at(max_cur_idx).d += 10;
    } else {
        this->in_curs->at(max_cur_idx).d += -10;
    }
}

QuintSplineSGDSmoother::QuintSplineSGDSmoother() {}
void QuintSplineSGDSmoother::SetParam(float rdp_threshold,
                                      int cur_sample,
                                      float weight_cur_change,
                                      float weight_cur,
                                      float lr,
                                      int iters,
                                      int special_init_for_one,
                                      float pts_weight,
                                      float penalty_weight,
                                      float penalty_distance) {
    this->rdp_threshold = rdp_threshold;
    this->cur_sample = cur_sample;
    this->weight_cur_change = weight_cur_change;
    this->weight_cur = weight_cur;
    this->lr = lr;
    this->times = iters;
    this->special_init_for_one = special_init_for_one;
    this->pts_weight = pts_weight;
    this->penalty_weight = penalty_weight;
    this->penalty_distance = penalty_distance;
}

void QuintSplineSGDSmoother::Init() {
    auto conf = g_pp_conf["rrt_setting"];
    this->rdp_threshold = conf["qss_rdp_threshold"];
    this->cur_sample = conf["qss_cur_sample"];
    this->weight_cur_change = conf["qss_weight_cur_change"];
    this->weight_cur = conf["qss_weight_cur"];
    this->lr = conf["qss_lr"];
    this->times = conf["qss_iters"];
    this->special_init_for_one = conf["qss_special_init_for_one"];
    this->pts_weight = conf["qss_weight_dist"];
    this->penalty_weight = conf["qss_penalty_dist"];
    this->penalty_distance = conf["qss_weight_penalty_dist"];
    this->second_mid_point = conf["qss_secondmidpoint_method"];
}

void QuintSplineSGDSmoother::Fit() {
    if (this->trp.size() <= 1) return;
    // 1. RDP
    this->simplesegment();
    // 2. init_path
    this->initpath();
    LogCurrentResult("Init");
    // 3. build t
    this->buildt();
    std::vector<LearnablePoints> points;
    std::vector<LearnableVariable> curvature;
    points.resize(this->seg_t.size());
    curvature.resize(this->cur_t.size() * num_segments);
    // 4. Build network and optimize
    this->m_lqs.Initialize(this->param, this->numofeachsegs);
    this->m_lqs.SetInput(this->seg_t, this->cur_t);
    this->m_lqs.SetOutput(&points, &curvature);
    this->m_lqs.lr = this->lr;
    this->m_curloss.SetInput(&curvature);
    this->m_curloss.SetOutput(&cur_loss);
    this->m_curloss.cur_change = this->weight_cur_change;
    this->m_curloss.wholescale = this->weight_cur;
    this->m_ptsloss.SetInput(this->trp, &points);
    this->m_ptsloss.SetOutput(&pts_loss);
    this->m_ptsloss.pts_weight = this->pts_weight;
    this->m_ptsloss.penalty_weight = this->penalty_weight;
    this->m_ptsloss.penalty_distance = this->penalty_distance;
    // 5. Forward Backward
    int iter = 0;
    std::stringstream ss_info;
    while (iter++ < this->times) {
        this->m_lqs.Forward();
        this->m_curloss.Forward();
        this->m_ptsloss.Forward();
        if (iter % 20 == 0) {
            ss_info << "[" << iter << "] "
                    << "PTS Loss: " << this->pts_loss.v
                    << " CUR Loss: " << this->cur_loss.v << " ";
        } else {
            AD_LDEBUG(PATH_PLANNING) << "[" << iter << "] "
                                     << "PTS Loss: " << this->pts_loss.v
                                     << " CUR Loss: " << this->cur_loss.v;
        }
        this->m_ptsloss.Backward();
        this->m_curloss.Backward();
        this->m_lqs.Backward();
        this->m_lqs.ADAM_Step();
    }
    AD_LINFO(PATH_PLANNING) << ss_info.str();
    this->param = this->m_lqs.ExportResult();
    LogCurrentResult("Final");
}

void QuintSplineSGDSmoother::simplesegment() {
    float ma, mb, mc;
    int ss = 0;
    std::vector<cv::Point2f> pts;
    pts.resize(2);
    this->segindexs.clear();
    this->segindexs.push_back(0);
    while (ss < static_cast<int>(this->trp.size()) - 1) {
        int tt = this->trp.size() - 1;
        if (tt - ss == 1) {
            this->segindexs.push_back(tt);
            ss = tt;
        } else {
            while (tt - ss > 1) {
                pts[0] = this->trp[ss].position;
                pts[1] = this->trp[tt].position;
                utils::PointsToLine(pts, &ma, &mb, &mc);
                int max_inner_idx = -1;
                // TODO(congq): max_value not initialized
                float max_value = std::numeric_limits<float>::min(), tmpvalue;
                float div_value = sqrtf(ma * ma + mb * mb);
                for (int32_t i = ss + 1; i < tt; i++) {
                    cv::Point2f p = this->trp[i].position;
                    tmpvalue = (p.x * ma + p.y * mb + mc) / div_value;
                    if (tmpvalue < 0) tmpvalue = -tmpvalue;
                    if (max_inner_idx == -1 || tmpvalue > max_value) {
                        max_value = tmpvalue;
                        max_inner_idx = i;
                    }
                }
                if (max_value < rdp_threshold) break;
                tt = max_inner_idx;
            }
            this->segindexs.push_back(tt);
            ss = tt;
        }
    }
    if (this->segindexs[this->segindexs.size() - 1] !=
        static_cast<int>(this->trp.size()) - 1) {
        this->segindexs.push_back(this->trp.size() - 1);
    }
    this->num_segments = this->segindexs.size() - 1;
}

void QuintSplineSGDSmoother::initpath() {
    param.clear();
    std::vector<float> seg_length;
    int minlength_seg = -1;
    // TODO(some): not initialized before
    float min_length = std::numeric_limits<float>::max(),
          max_length = std::numeric_limits<float>::min();
    max_length = -1;
    for (int32_t i = 0; i < static_cast<int32_t>(this->segindexs.size()) - 1;
         i++) {
        TrajectoryPoint stp, edp;
        cv::Point2f la;
        float ss;
        stp = this->trp[this->segindexs[i]];
        if (i + 1 >= static_cast<int32_t>(this->segindexs.size())) {
            edp = this->trp[this->trp.size() - 1];
        } else {
            edp = this->trp[this->segindexs[i + 1]];
        }
        la = edp.position - stp.position;
        utils::CalcNorm(la, &ss);
        seg_length.push_back(ss);
        if (minlength_seg == -1 || min_length > ss) {
            min_length = ss;
            minlength_seg = seg_length.size() - 1;
        }
        if (max_length < ss) {
            max_length = ss;
        }
    }
    float aa_a = min_length / max_length * 5;
    float bb_b = 5.0f;
    if (this->special_init_for_one == 1 && this->segindexs.size() - 1 == 1) {
        aa_a = min_length / max_length;
        bb_b = 1.0f;
    }
    for (int32_t i = 0; i < static_cast<int32_t>(this->segindexs.size()) - 1;
         i++) {
        TrajectoryPoint stp, edp;
        stp = this->trp[this->segindexs[i]];
        if (i + 1 >= static_cast<int32_t>(this->segindexs.size())) {
            edp = this->trp[this->trp.size() - 1];
        } else {
            edp = this->trp[this->segindexs[i + 1]];
        }
        float scale;
        cv::Point2f P0, P5, t_s, t_e, a_s, a_e, t_c, cand_a, cand_b, P7;
        int ti;
        P0 = stp.position;
        t_s = stp.direction;
        if (second_mid_point == 1) {
            if (i == 0) {
                scale = seg_length[i] * bb_b / 3;
            } else {
                scale = seg_length[i - 1] * bb_b / 3;
                if (scale > seg_length[i] * bb_b / 3) {
                    scale = seg_length[i] * bb_b / 3;
                }
            }
        } else {
            scale = seg_length[i] * aa_a * 1.0f / 3;
        }
        utils::Normalize2Dvect(&t_s);
        t_s = t_s * scale;
        if (i + 1 < static_cast<int32_t>(seg_length.size())) {
            if (second_mid_point == 1) {
                scale = seg_length[i] * bb_b / 3;
                if (scale > seg_length[i + 1] * bb_b / 3) {
                    scale = seg_length[i + 1] * bb_b / 3;
                }
            } else {
                scale = seg_length[i + 1] * aa_a * 1.0f / 3;
            }
        }
        P5 = edp.position;
        t_e = edp.direction;
        utils::Normalize2Dvect(&t_e);
        t_e = t_e * scale;
        // TODO(eteced) the second order of start point and end point currently
        // use zero
        // but it can be determine once we have the curvature of start and end
        // point.
        if (i == 0) {
            a_s.x = 0;
            a_s.y = 0;
        }
        if (i + 1 >= static_cast<int32_t>(this->segindexs.size()) - 1) {
            a_e.x = 0;
            a_e.y = 0;
        } else {
            ti = this->segindexs[i + 2];
            t_c = this->trp[ti].direction;
            P7 = this->trp[ti].position;
            utils::Normalize2Dvect(&t_c);
            // if (second_mid_point == 1) {
            //     scale = seg_length[i + 1] * 1.0f / 3;
            //     if (i + 2 < static_cast<int32_t>(seg_length.size()) &&
            //         scale > seg_length[i + 2] * 1.0f / 3) {
            //         scale = seg_length[i + 2] * 1.0f / 3;
            //     }
            // } else {
            //     if (i + 2 < static_cast<int32_t>(seg_length.size())) {
            //         scale = seg_length[i + 2] * aa_a * 1.0f / 3;
            //     } else {
            //         scale = seg_length[i + 1] * aa_a * 1.0f / 3;
            //     }
            // }
            cand_a = 6 * P0 + 2 * t_s + 4 * t_e - 6 * P5;
            cand_b = -6 * P5 - 4 * t_e - 2 * t_c + 6 * P7;
            float alpha, beta, cc;
            cc = seg_length[i] + seg_length[i + 1];
            alpha = seg_length[i + 1] * 1.0f / cc;
            beta = seg_length[i] * 1.0f / cc;
            a_e = alpha * cand_a;
            a_e = a_e + beta * cand_b;
        }
        if (i == 0) {
            LearnablePoints lP0;
            lP0.v = P0;
            param.push_back(lP0);
            LearnablePoints lt_s;
            lt_s.v = t_s;
            param.push_back(lt_s);
            LearnablePoints la_s;
            la_s.v = a_s;
            param.push_back(la_s);
        }
        LearnablePoints lP5;
        lP5.v = P5;
        param.push_back(lP5);
        LearnablePoints lt_e;
        lt_e.v = t_e;
        param.push_back(lt_e);
        LearnablePoints la_e;
        la_e.v = a_e;
        param.push_back(la_e);
    }
    // Set unadjustable, start/end point and direction is not adjustable
    param[0].require_grad = false;
    param[1].require_grad = true;
    param[1].grad_fixed_direction = true;
    param[param.size() - 3].require_grad = false;
    param[param.size() - 2].require_grad = true;
    param[param.size() - 2].grad_fixed_direction = true;
}

void QuintSplineSGDSmoother::LogCurrentResult(std::string prefix) {
    AD_LDEBUG(PATH_PLANNING) << "[" << prefix << "]"
                             << "segments: " << this->num_segments;
    for (int32_t i = 0; i < this->num_segments; i++) {
        int ii_cuv = i * 3;
        cv::Point2f P[6];
        P[0] = this->param[ii_cuv].v;
        P[1] = 0.2 * this->param[ii_cuv + 1].v + P[0];
        P[2] = 0.05 * this->param[ii_cuv + 2].v + 2 * P[1] - P[0];
        P[5] = this->param[ii_cuv + 3].v;
        P[4] = P[5] - 0.2 * this->param[ii_cuv + 4].v;
        P[3] = 0.05 * this->param[ii_cuv + 5].v + 2 * P[4] - P[5];
        AD_LDEBUG(PATH_PLANNING)
            << "[" << prefix << "]"
            << "Line: " << i << "Params: " << this->param[ii_cuv].v << " "
            << this->param[ii_cuv + 1].v << " " << this->param[ii_cuv + 2].v
            << " " << this->param[ii_cuv + 3].v << " "
            << this->param[ii_cuv + 4].v << " " << this->param[ii_cuv + 5].v
            << " Points: " << P[0] << " " << P[1] << " " << P[2] << " " << P[3]
            << " " << P[4] << " " << P[5];
    }
}

void QuintSplineSGDSmoother::buildt() {
    this->seg_t.clear();
    this->cur_t.clear();
    this->s_seg.clear();
    this->numofeachsegs.clear();
    for (int32_t ii = 0; ii < static_cast<int32_t>(this->segindexs.size()) - 1;
         ii++) {
        int ss = this->segindexs[ii];
        int tt = this->segindexs[ii + 1];
        float total_length;
        total_length = 0;
        for (int32_t i = ss + 1; i <= tt; i++) {
            float vl;
            cv::Point2f aa;
            aa = this->trp[i].position - this->trp[i - 1].position;
            utils::CalcNorm(aa, &vl);
            total_length += vl;
        }
        this->s_seg.push_back(total_length);
        float t;
        for (int32_t i = ss; i < tt; i++) {
            if (i == ss) {
                t = 0;
            } else {
                float vl;
                cv::Point2f aa;
                aa = this->trp[i].position - this->trp[i - 1].position;
                utils::CalcNorm(aa, &vl);
                t += vl / total_length;
            }
            this->seg_t.push_back(t);
        }
        if (ii == static_cast<int32_t>(this->segindexs.size()) - 2) {
            this->seg_t.push_back(1.0f);
            this->numofeachsegs.push_back(tt - ss + 1);
        } else {
            this->numofeachsegs.push_back(tt - ss);
        }
    }
    float dt = 1.0f / this->cur_sample;
    float t = 0;
    while (t < 1.0f) {
        this->cur_t.push_back(t);
        t += dt;
    }
}

std::vector<TrajectoryPoint> QuintSplineSGDSmoother::SamplePoints(
    float insert_distance) {
    std::vector<float> ss;
    std::vector<TrajectoryPoint> tp;
    for (int32_t i = 0; i < static_cast<int32_t>(this->s_seg.size()); i++) {
        if (i != 0)
            ss.push_back(ss[i - 1] + s_seg[i]);
        else
            ss.push_back(s_seg[i]);
    }
    float s, tt;
    s = 0;
    while (s < ss[ss.size() - 1]) {
        int ci = 0;
        while (ci < static_cast<int>(ss.size()) - 1 && ss[ci] < s) ci++;
        if (ci > 0)
            tt = s - ss[ci - 1];
        else
            tt = s;
        tt = tt / this->s_seg[ci];

        int ii_cuv = ci * 3;
        cv::Point2f P[6];
        P[0] = this->param[ii_cuv].v;
        P[1] = 0.2 * this->param[ii_cuv + 1].v + P[0];
        P[2] = 0.05 * this->param[ii_cuv + 2].v + 2 * P[1] - P[0];
        P[5] = this->param[ii_cuv + 3].v;
        P[4] = P[5] - 0.2 * this->param[ii_cuv + 4].v;
        P[3] = 0.05 * this->param[ii_cuv + 5].v + 2 * P[4] - P[5];
        float omt[6], t[6];
        t[1] = tt;
        t[0] = 1.0f;
        omt[1] = 1 - tt;
        omt[0] = 1.0f;
        for (int32_t i = 2; i <= 5; i++) {
            t[i] = t[i - 1] * t[1];
            omt[i] = omt[i - 1] * omt[1];
        }
        cv::Point2f PP;
        PP.x = PP.y = 0;
        for (int32_t i = 0; i <= 5; i++) {
            PP = PP + omt[5 - i] * t[i] * this->fac[i] * P[i];
        }
        // first/second order derivation
        cv::Point2f d, dd;
        d.x = d.y = dd.x = dd.y = 0;
        cv::Point2f PV[6];
        for (int32_t ii_r = 0; ii_r <= 5; ii_r++) {
            PV[ii_r].x = 0;
            PV[ii_r].y = 0;
            for (int32_t ii_c = 0; ii_c <= 5; ii_c++) {
                PV[ii_r] = PV[ii_r] + this->dmatrix[ii_r][ii_c] * P[ii_c];
            }
        }
        for (int32_t i = 4; i >= 0; i--) {
            d = d + (i + 1) * t[i] * PV[4 - i];
            if (i <= 3) {
                dd = dd + (i + 1) * (i + 2) * t[i] * PV[3 - i];
            }
        }
        float curvature =
            (d.x * dd.y - dd.x * d.y) / pow(d.x * d.x + d.y * d.y, 3.0 / 2.0);
        float theta = 0;
        if (d.x == 0) {
            if (d.y > 0) {
                theta = M_PI / 2;
            } else if (d.y < 0) {
                theta = -M_PI / 2;
            } else {
                theta = 0;
            }
        } else {
            theta = atan(d.y / d.x);
        }
        auto direction = d;
        direction = direction * (1.0 / utils::cvnorm(direction));
        TrajectoryPoint new_traj_point = TrajectoryPoint();

        new_traj_point.position = PP;
        new_traj_point.direction = direction;
        new_traj_point.velocity = 0.0;
        new_traj_point.theta = theta;
        new_traj_point.curvature = curvature;
        VLOG(4) << "[DEBUG] "
                << "QuinticSpline Smooth adding " << new_traj_point.position
                << " " << new_traj_point.direction << " "
                << new_traj_point.theta << " " << new_traj_point.curvature;
        tp.push_back(new_traj_point);
        s = s + insert_distance;
    }
    return tp;
}

void QuintSplineSGDSmoother::SetData(const std::vector<TrajectoryPoint> &tps) {
    this->trp = tps;
}

}  // namespace pp
}  // namespace senseAD
