/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include "path_planning/baseplanner.hpp"
#include "path_planning/planner.hpp"
#include "path_planning/longi_lat_planner/longi_lat_planner.hpp"
#include "path_planning/nn_tool.hpp"
#include "ini.h"  // NOLINT
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "common/log.hpp"

namespace senseAD {
namespace pp {

VehicleState g_vehicle_state;

NNTool g_nn_tool;

BasePathPlanner::BasePathPlanner() {}

BasePathPlanner::~BasePathPlanner() {}

adStatus_t BasePathPlanner::CreatePlanner(
    const std::string& config_path, std::shared_ptr<BasePathPlanner>* bpp_ptr) {
    if (bpp_ptr == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }

    AD_LINFO(PATH_PLANNING) << "Creating PathPlanner";
    adStatus_t res = g_pp_conf.Init(config_path);
    if (res != AD_SUCCESS) {
        return AD_INVALID_PARAM;
    }
    auto conf = g_pp_conf["pp_init"];
    std::string pp_type = conf["pp"];

    AD_LINFO(PATH_PLANNING) << "PP type: " << pp_type;
    if (pp_type == "pp") {
        bpp_ptr->reset(new Planner());
        return (*bpp_ptr)->Init(config_path);
    } else if (pp_type == "dqq") {
        bpp_ptr->reset(new LongiLatPlanner());
        return (*bpp_ptr)->Init(config_path);
    } else {
        AD_LERROR(PATH_PLANNING) << " No valid pp type is specified.";
        return AD_INVALID_PARAM;
    }
    AD_LINFO(PATH_PLANNING) << "FAILED TO CREATE ANY PATHPLANNER";
    return AD_SUCCESS;
}

adStatus_t BasePathPlanner::Update(
    senseAD::roadStructure::RoadStructure<cv::Point2f>* rs,
    ObjectTrajectory* object_trajectory,
    PredictionResult* prediction_result,
    DMTarget* dm_target,
    std::shared_ptr<Car_Trajectory> car_trajectory,
    VehicleInfo* vehicle_info,
    routing::BasePath* base_path,
    VehicleStat* vehicle_status) {
    if (car_trajectory == nullptr || rs == nullptr ||
        object_trajectory == nullptr || prediction_result == nullptr ||
        dm_target == nullptr || vehicle_info == nullptr ||
        vehicle_status == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR)
    }
    AD_LINFO(PATH_PLANNING) << "BasePlanner Updating";
    this->car_trajectory_ = car_trajectory;
    this->vehicle_info_ = *vehicle_info;
    this->pose_warp_.SetVehicleInfo(*vehicle_info);
    this->rs_ = *rs;
    this->dm_target_ = *dm_target;
    this->object_trajectory_ = *object_trajectory;
    this->prediction_result_ = *prediction_result;
    this->base_path_ = *base_path;
    this->vehicle_status_ = *vehicle_status;

    if (BuildFrenetCoordSystem() != AD_SUCCESS) {
        AD_LERROR(PATH_PLANNING)
            << "failed to build frenent coordinate system.";
        return AD_INVALID_PARAM;
    }

    this->scene_parser_.Update(rs, object_trajectory, prediction_result,
                               frenet_system_, dm_target);

    AD_LINFO(PATH_PLANNING) << "BasePlanner Updated Input";
    return AD_SUCCESS;
}

adStatus_t BasePathPlanner::Update(
    senseAD::roadStructure::RoadStructure<cv::Point2f>* rs,
    const PredictionObjectArray& poa,
    DMTarget* dm_target,
    std::shared_ptr<Car_Trajectory> car_trajectory,
    VehicleInfo* vehicle_info,
    routing::BasePath* base_path,
    VehicleStat* vehicle_status) {
    if (car_trajectory == nullptr || rs == nullptr || dm_target == nullptr ||
        vehicle_info == nullptr || vehicle_status == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR)
    }
    AD_LINFO(PATH_PLANNING) << "BasePlanner Updating";
    this->car_trajectory_ = car_trajectory;
    this->vehicle_info_ = *vehicle_info;
    this->pose_warp_.SetVehicleInfo(*vehicle_info);
    this->rs_ = *rs;
    this->dm_target_ = *dm_target;
    this->base_path_ = *base_path;
    this->vehicle_status_ = *vehicle_status;
    this->poa_ = poa;
    if (vehicle_status_.AutoCtrlStat == 1) {
        AD_LINFO(PATH_PLANNING) << "auto driving state on";
    } else {
        AD_LINFO(PATH_PLANNING) << "auto driving state off";
    }
    if (BuildFrenetCoordSystem() != AD_SUCCESS) {
        AD_LERROR(PATH_PLANNING)
            << "failed to build frenent coordinate system.";
        return AD_INVALID_PARAM;
    }

    this->scene_parser_.Update(rs, poa, frenet_system_, &dm_target_);

    AD_LINFO(PATH_PLANNING) << "BasePlanner Updated Input";
    return AD_SUCCESS;
}

adStatus_t BasePathPlanner::GetPlanningLog(PlannningLog* planning_log) const {
    *planning_log = planning_log_;
    return AD_SUCCESS;
}

adStatus_t BasePathPlanner::SetHondaConverter(const bool flag,
                                              const std::string ip_addr) {
    interface_to_autobox_ = flag;
    autobox_ip_addr_ = ip_addr;
    // set autobox sender
    honda_can_sender_.set_ip_addr(autobox_ip_addr_);
    honda_sig_sender_.set_ip_addr(autobox_ip_addr_);
    honda_tgt_sender_.set_ip_addr(autobox_ip_addr_);
    return AD_SUCCESS;
}

adStatus_t BasePathPlanner::BuildFrenetCoordSystem() {
    constexpr uint32_t min_base_path_forword_size = 10;
    if (base_path_.forward.size() < min_base_path_forword_size) {
        AD_LERROR(PATH_PLANNING) << "base_path is so short";
        return AD_INVALID_PARAM;
    }
    // 1. update moving vector of frenet origin point
    cv::Point2f frenet_origin_point = std::move(cv::Point2f(
        base_path_.forward.front().x, base_path_.forward.front().y));
    if (frenet_system_->IsValid() == true) {
        frenet_origin_move_vec_ =
            frenet_system_->Cartesian2Frenet(frenet_origin_point);
    } else {
        frenet_origin_move_vec_ = std::move(cv::Point2f(0.0f, 0.0f));
    }
    AD_LINFO(LongiLatPlanner) << "frenet origin move vec "
                              << frenet_origin_move_vec_;

    // 2. build up frenet coordinate system started behind of ego car
    std::vector<TrajectoryPoint> tmp_refline;
    tmp_refline.reserve(base_path_.backward.size() + base_path_.forward.size());
    for (auto iter = base_path_.backward.crbegin();
         iter != base_path_.backward.crend(); ++iter) {
        TrajectoryPoint n_pt;
        n_pt.position.x = iter->x;
        n_pt.position.y = iter->y;
        tmp_refline.emplace_back(n_pt);
    }
    for (auto iter = base_path_.forward.cbegin();
         iter != base_path_.forward.cend(); ++iter) {
        TrajectoryPoint n_pt;
        n_pt.position.x = iter->x;
        n_pt.position.y = iter->y;
        tmp_refline.emplace_back(n_pt);
    }
    frenet_system_->Update(tmp_refline, frenet_origin_point);
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
