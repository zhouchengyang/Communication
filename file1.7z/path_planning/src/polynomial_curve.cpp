/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */
#include "path_planning/polynomial_curve.hpp"
#include <iostream>
#include <cmath>

// TODO(conqq): Need orgnization Util or pp namespace;
// TODO(congq): Time this process
PolynomialCurve::PolynomialCurve(int n) {
    std::vector<std::vector<std::vector<std::vector<float>>>> dp;
    for (int i = 0; i < n + 1; i++) {
        std::vector<std::vector<std::vector<float>>> ith_degree_curves;
        // All i degree curve is a combination of i-1 degree
        for (int j = 0; j < n + 1 - i; j++) {
            // compute the jth i degree curve
            std::vector<std::vector<float>> id_jth_curve;
            if (i == 0) {
                id_jth_curve.push_back(std::vector<float>(1, 1.0));
            } else {
                // combining these two corresponding curves
                auto i1jcurve = dp[i - 1][j];
                auto i1j1curve = dp[i - 1][j + 1];
                // list of polynomials
                // for all poylnomials in idjcurve multi 1-t to them
                // for all polynomials in idjdcurve multiply by t
                std::vector<std::vector<float>> new_i1jcurve;
                std::vector<std::vector<float>> new_i1j1curve;
                for (auto poly : i1jcurve) {
                    // poly is list of coef
                    std::vector<float> new_poly(poly.size() + 1, 0);
                    for (uint32_t ii = 0; ii < poly.size(); ii++) {
                        new_poly[ii] += poly[ii];
                        new_poly[ii + 1] -= poly[ii];
                    }
                    new_i1jcurve.push_back(new_poly);
                }
                for (auto poly : i1j1curve) {
                    std::vector<float> new_poly(poly.size() + 1, 0);
                    for (uint32_t ii = 0; ii < poly.size(); ii++) {
                        new_poly[ii + 1] += poly[ii];
                    }
                    new_i1j1curve.push_back(new_poly);
                }
                // merge the two curve
                // new i1jcurve + newi1j1curve
                id_jth_curve.push_back(new_i1jcurve[0]);
                for (uint32_t ii = 0; ii < new_i1jcurve.size() - 1; ii++) {
                    std::vector<float> new_poly;
                    for (uint32_t jj = 0; jj < new_i1jcurve[ii].size(); jj++) {
                        new_poly.push_back(new_i1jcurve[ii + 1][jj] +
                                           new_i1j1curve[ii][jj]);
                    }
                    id_jth_curve.push_back(new_poly);
                }
                id_jth_curve.push_back(new_i1j1curve.back());
            }
            ith_degree_curves.push_back(id_jth_curve);
        }
        dp.push_back(ith_degree_curves);
    }
    polynomials_ = dp[n][0];
}

void PolynomialCurve::SetReferenceValue(std::vector<float> ref_v) {
    this->reference_value_ = ref_v;
}
// TODO(congq): complete this function
void PolynomialCurve::Display() {}

std::string PolynomialCurve::to_str() {
    std::string result;
    for (auto poly : polynomials_) {
        for (auto coef : poly) {
            result += std::to_string(coef);
            result += " ";
        }
        result += "\n";
    }
    for (uint32_t i = 0; i < reference_value_.size(); i++) {
        if (i != 0) {
            result += " ";
        }
        result += std::to_string(reference_value_[i]);
    }
    return result;
}

// TODO(congq): Fully test this class
float PolynomialCurve::Value(float t) {
    float result = 0;
    for (uint32_t i = 0; i < reference_value_.size(); i++) {
        float ithpower = 1.0;
        float ith_result = 0.0;
        for (uint32_t j = 0; j < polynomials_[i].size(); j++) {
            ith_result += polynomials_[i][j] * ithpower;
            ithpower *= t;
        }
        result += reference_value_[i] * ith_result;
    }
    return result;
}

float PolynomialCurve::SpecialFindtForMonotonic(
    float begin, float allrange, float range, float target, float min_error) {
    if (this->Value(begin + range) < target || this->Value(begin) > target ||
        begin > 1.0f) {
        return -1;
    }
    if (fabs(this->Value(begin + range / 2) - target) < min_error) {
        return begin + range / 2;
    }
    if (this->Value(begin + range / 2) > target) {
        range = range / 2;
        allrange = 1 - begin;
        return SpecialFindtForMonotonic(begin, allrange, range, target,
                                        min_error);
    } else {
        begin = begin + range / 2;
        range = range / 2;
        allrange = 1 - begin;
        return SpecialFindtForMonotonic(begin, allrange, range, target,
                                        min_error);
    }
}

float PolynomialCurve::Findt(float value) {
    return SpecialFindtForMonotonic(0, 1, 1, value, min_error);
}

PolynomialCurve PolynomialCurve::Differential() {
    auto result = *this;
    for (uint32_t i = 0; i < result.polynomials_.size(); i++) {
        for (uint32_t j = 0; j < result.polynomials_[i].size() - 1; j++) {
            result.polynomials_[i][j] = result.polynomials_[i][j + 1] * (j + 1);
        }
        result.polynomials_[i].pop_back();
    }
    return result;
}
