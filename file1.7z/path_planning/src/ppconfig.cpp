/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include "path_planning/ppconfig.hpp"

namespace senseAD {
namespace pp {

#define CONFIG_SECTION(sectionname)                     \
    config_read_state = 0;                              \
    for (PPConfig sec_config = configs[#sectionname];   \
         (inisection = parser.top()(#sectionname)),     \
                  CONFIG_SECTION_ERRORLOG(sectionname), \
                  config_read_state == 0;               \
         config_read_state = 1, configs[#sectionname] = sec_config)

#define CONFIG_SECTION_ERRORLOG(sectionname)                            \
    [&]() {                                                             \
        if (inisection.depth == 0) {                                    \
            AD_LERROR(PATH_PLANNING) << "SectionName: " << #sectionname \
                                     << "Not exist at config!";         \
            config_read_state = -1;                                     \
        }                                                               \
    }

#define READ_PARAM(type, paramname)                             \
    type paramname##_read;                                      \
    if (!inisection[#paramname].empty()) {                      \
        std::stringstream ss;                                   \
        ss << inisection[#paramname];                           \
        ss >> paramname##_read;                                 \
    } else {                                                    \
        AD_LERROR(PATH_PLANNING) << "No " << #paramname << "."; \
        return AD_INVALID_PARAM;                                \
    }

#define ADD_PARAM_WITH_CHECKGE(type, paramname, a) \
    do {                                           \
        READ_PARAM(type, paramname)                \
        if (!(paramname##_read >= a)) {            \
            PARAM_CHECK_ERRORLOG(paramname, a, _)  \
            return AD_INVALID_PARAM;               \
        }                                          \
        VALIDADD(type, paramname)                  \
    } while (0)

#define ADD_PARAM_WITH_CHECKLE(type, paramname, a) \
    do {                                           \
        READ_PARAM(type, paramname)                \
        if (!(paramname##_read <= a)) {            \
            PARAM_CHECK_ERRORLOG(paramname, _, a)  \
            return AD_INVALID_PARAM;               \
        }                                          \
        VALIDADD(type, paramname)                  \
    } while (0)

#define ADD_PARAM_WITH_CHECKAE(type, paramname, a, b)            \
    do {                                                         \
        READ_PARAM(type, paramname)                              \
        if (!(paramname##_read <= b && paramname##_read >= a)) { \
            PARAM_CHECK_ERRORLOG(paramname, a, b)                \
            return AD_INVALID_PARAM;                             \
        }                                                        \
        VALIDADD(type, paramname)                                \
    } while (0)

#define ADD_PARAM(type, paramname)  \
    do {                            \
        READ_PARAM(type, paramname) \
        VALIDADD(type, paramname)   \
    } while (0)

#define PARAM_CHECK_ERRORLOG(paramname, a, b)                    \
    AD_LERROR(PATH_PLANNING) << #paramname << " should lied in " \
                             << "[ " << #a << " , " << #b " ]";

#define VALIDADD(type, paramname) \
    { sec_config.type##_configs[#paramname] = paramname##_read; }

PPConfigSection g_pp_conf;
adStatus_t PPConfigSection::Init(std::string file_path) {
    AD_LINFO(PATH_PLANNING) << "Load config from: " << file_path;
    try {
        INI::Parser parser(file_path.c_str());

        // AT HERE ADD ALL PARAMETERS (WITH CONSTRAINTS)
        // Init Setting
        CONFIG_SECTION(pp_init) {
            // which planner we want to use
            ADD_PARAM(ppstring, pp);
        }

        CONFIG_SECTION(pp_core) {
            // which PlannerCore
            ADD_PARAM(ppstring, pp_core);
        }

        // Vehicle Setting
        CONFIG_SECTION(vehicle_setting) {
            // car width
            ADD_PARAM_WITH_CHECKGE(double, car_width, 0.0001);
            // car length
            ADD_PARAM_WITH_CHECKGE(double, car_length, 0.0001);
            // the minimal turning radius this car can achive
            ADD_PARAM_WITH_CHECKGE(double, min_turn_radius, 0.0001);
            //
            ADD_PARAM_WITH_CHECKGE(double, car_weight, 0.0001);
            //
            ADD_PARAM_WITH_CHECKGE(double, max_power, 0.0001);
        }
        // lattice Setting
        CONFIG_SECTION(lattice_setting) {
            //
            ADD_PARAM_WITH_CHECKGE(float, sample_distance, 0.0001f);
            //
            ADD_PARAM(float, extend_len);
            //
            ADD_PARAM(int, longitude_acc_on);
            //
            ADD_PARAM(int, lateral_acc_on);
            //
            ADD_PARAM(int, lateral_velocity_on);
            //
            ADD_PARAM(int, search_velocity);
            //
            ADD_PARAM(int, use_prediction);
            //
            ADD_PARAM(int, warp_time);
            //
            ADD_PARAM_WITH_CHECKGE(float, plan_time_interval, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, sample_time_interval, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, max_plan_time, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, min_plan_time, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, sample_width_interval, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, max_road_width, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, lateral_offset_cost, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, lateral_jerk_cost, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, longitude_jerk_cost, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, centripetal_acce_cost, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, goal_cost, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, risk_distance_cost, 0.0001f);
            //
            ADD_PARAM_WITH_CHECKGE(float, target_speed_cost, 0.0001f);
            ADD_PARAM(float, k_lat);
            ADD_PARAM(float, k_lon);
            ADD_PARAM(float, k_j_lat);
            ADD_PARAM(float, k_j_lon);
            ADD_PARAM(float, k_T_lat);
            ADD_PARAM(float, k_T_lon);
            ADD_PARAM(float, k_d2_lat);
            ADD_PARAM(float, k_s2_lon);
            ADD_PARAM(float, k_s_prime_lon);
            ADD_PARAM(int, unleashed);
            ADD_PARAM(int, tamed);
        }
        // longitudinal lateral core
        CONFIG_SECTION(longi_lat_core) {
            ADD_PARAM(int, searcher);
            ADD_PARAM(int, optimizer);
            ADD_PARAM(double, s_horizon);
            ADD_PARAM(double, s_resolution);
            ADD_PARAM(double, t_horizon);
            ADD_PARAM(double, t_resolution);
        }

        // longitudinal lateral setting
        CONFIG_SECTION(dqq_setting) {
            // s resolution of frenet coordinate system, uint : m
            ADD_PARAM(double, frenet_resolution);
            // interval of routing line, uint : m
            ADD_PARAM(double, routing_interval);
            // number of look back timestamp
            ADD_PARAM(int, num_look_back);
            // maximum brake acceleration (positive value), uint : meter per
            // second
            ADD_PARAM(double, max_brake_acc);
            // speed limit of road, uint : meter per second
            ADD_PARAM(double, speed_limit);
            // speed reference of road. unit : meter per second
            ADD_PARAM(double, speed_ref);
            // longitudinal safe distance from back of front car to center of
            // ego car, unit : m
            ADD_PARAM(double, longi_safe_distance);
            // longitudinal safe distance(using in dp search) from back of
            // front car to center of ego car, unit : m
            ADD_PARAM(double, longi_dp_safe_distance);
            // longitudinal stop distance from back of front car to center of
            // ego car uint : m, used in calculation of follow distance by TTC
            ADD_PARAM(double, longi_stop_distance);
            // time to collision, uint : s, used in calculation of follow
            // distance by TTC
            ADD_PARAM(double, time_to_collision);
            // max deacc of vehicle, positive value, uint : m/s^2, used in
            // calculation of follow
            // distance by TTC
            ADD_PARAM(double, max_deacc_vehicle);
            // nbo(non-blocking obstalce) reponse range, unit, m
            ADD_PARAM(double, nbo_reponse_range);
            // longitudinal buffer for stop line, unit : m
            ADD_PARAM(double, stop_line_buffer);
            // longitudinal follow time, uint : s, using it to calculate follow
            // distane, follow distance equals follow_time times speed of front
            // car
            ADD_PARAM(double, follow_time);
            // allowed overspeed percentage, it is great than 1
            ADD_PARAM(double, overspeed_percentage);
            // weight of reference for longitudinal optimization
            ADD_PARAM(double, longi_w_ref);
            // weight of first order for longitudinal optimization
            ADD_PARAM(double, longi_w_first_order);
            // weight of second order for longitudinal optimization
            ADD_PARAM(double, longi_w_second_order);
            // weight of third order for longitudinal optimization
            ADD_PARAM(double, longi_w_third_order);
            // weight of last trajectory for longitudinal optimization
            ADD_PARAM(double, longi_w_start);
            // decay rate of weight of last trajectory for longitudinal
            // optimization
            ADD_PARAM(double, longi_decay_rate);
            // lateral safe distance
            ADD_PARAM(double, lateral_safe_distance);
            // weight of reference for lateral optimization
            ADD_PARAM(double, lateral_w_ref);
            // weight of first order for lateral optimization
            ADD_PARAM(double, lateral_w_first_order);
            // weight of second order for lateral optimization
            ADD_PARAM(double, lateral_w_second_order);
            // weight of third order for lateral optimization
            ADD_PARAM(double, lateral_w_third_order);
            // weight of last trajectory for longitudinal optimization
            ADD_PARAM(double, lateral_w_start);
            // decay rate of weight of last trajectory for longitudinal
            // optimization
            ADD_PARAM(double, lateral_decay_rate);
            // debug_print = 1, print all planning process to to today-logg
            ADD_PARAM(int, debug_print);
            // longitudinal overlap threshold for extracting lateral bound
            ADD_PARAM(double, longi_overlap_threshold);
            // nbo occur times threshold
            ADD_PARAM(int, nbo_counter_threshold);
            // bo occur times threshold
            ADD_PARAM(int, bo_counter_threshold);
            // lane width, unit : meter
            ADD_PARAM(double, lane_width);
            // ref acceleration setting longitudinal reference
            ADD_PARAM(double, ref_acc);
            // ref deacceleration setting longitudinal reference
            ADD_PARAM(double, ref_deacc);
            // ref jerk setting longitudinal reference
            ADD_PARAM(double, ref_jerk);
            // change period of whole change time
            ADD_PARAM(double, change_period);
            // replan threshold of leading speed
            ADD_PARAM(double, replan_leading_speed_threshold);
        }

        // RRT Setting
        CONFIG_SECTION(rrt_setting) {
            // RRT maximal distance of two adjcent nodes
            ADD_PARAM_WITH_CHECKGE(float, expand_distance, 0.0001f);
            // RRT return path interval
            ADD_PARAM_WITH_CHECKGE(float, insert_distance, 0.0001f);
            // RRT maximal new iterations
            ADD_PARAM_WITH_CHECKGE(int, max_iteration, 1);
            // (Obsolete) sample rate of goal
            ADD_PARAM_WITH_CHECKGE(float, sample_rate, 0);
            // RRT maximal iterations
            ADD_PARAM_WITH_CHECKGE(int, max_cap_iteration, 1);
            // RRT distance offset the goal when at boundary
            ADD_PARAM_WITH_CHECKGE(float, boundary_offset, 0);
            // RRT pp point smooth frames
            ADD_PARAM_WITH_CHECKGE(int, pp_point_frame, 1);
            // RRT pp trajectory smooth frames
            ADD_PARAM_WITH_CHECKGE(int, pp_traj_frame, 1);
            // Velocity Planning Mode
            ADD_PARAM_WITH_CHECKGE(int, vp_mode, 0);
            // GridMap width
            ADD_PARAM_WITH_CHECKGE(int, map_ww, 1);
            // GridMap height
            ADD_PARAM_WITH_CHECKGE(int, map_hh, 1);
            // (Obsolete) treat as free [ly, ry]
            ADD_PARAM_WITH_CHECKGE(float, as_free_ly, 0);
            ADD_PARAM_WITH_CHECKLE(float, as_free_ry, 0);
            ADD_PARAM_WITH_CHECKGE(float, as_free_xx, 0);
            // (Obsolete) if we patch the freespace
            ADD_PARAM(int, if_fix_bonnet);
            // Grid Map meters length of a grid
            ADD_PARAM_WITH_CHECKGE(float, per_grid_meter, 0.0001f);
            // Grid Map min value as free
            ADD_PARAM_WITH_CHECKGE(int, min_value_as_free, 0);
            // Grid Map as free measure length
            ADD_PARAM_WITH_CHECKGE(int, as_free_measure_length, 0);
            // Grid Map as free for RRT
            ADD_PARAM_WITH_CHECKGE(int, rrt_gridmap_as_free, 0);
            // Cost optimization used or not.
            ADD_PARAM(int, if_optimize);
            // Grid Map far than this threshold, would be consider free
            ADD_PARAM_WITH_CHECKGE(float, out_as_free, 0);
            // Grid Map if apply patch freespace at dot map
            ADD_PARAM(int, if_applybonnetfix_final);
            // If use BPP pre plan
            ADD_PARAM(int, bpp_preplan);
            // BPP sample strategy
            ADD_PARAM(int, bpp_sample);
            // if use Pure BPP
            ADD_PARAM(int, pure_bp);
            // RRT all rewire strategy
            ADD_PARAM(int, all_rewire);
            // Node Cost weight for bpp distance
            ADD_PARAM(float, w_bpp_cost);
            // Node Cost weight for risk
            ADD_PARAM(float, w_risk_cost);
            // Node Cost weight for parent cost
            ADD_PARAM(float, w_parent_cost);
            // Node Cost weight for curvature
            ADD_PARAM(float, w_curvature);
            // Node Cost weight for yaw from parent
            ADD_PARAM(float, w_yaw_from_parent);
            // Node Cost weight for dist
            ADD_PARAM(float, w_dist);
            // Node Cost weight for direction
            ADD_PARAM(float, w_direction);
            // Node Cost weight for curvature change
            ADD_PARAM(float, w_curvature_change);
            // Node Cost weight for frame alignment
            ADD_PARAM(float, w_alignment);
            // Sum Cost Optimization
            ADD_PARAM(int, sumcost_optimize);
            // Extra hop cost
            ADD_PARAM(float, extra_hop_cost);
            // if apply traj smooth
            ADD_PARAM(int, traj_smoothing);
            // Smoother use type
            ADD_PARAM(int, use_smoother);
            // Schneider Smooth error threshold
            ADD_PARAM(float, schneider_error);
            // Schneider Smooth error scale
            ADD_PARAM(float, schneider_escale);
            // Sampling density control
            ADD_PARAM_WITH_CHECKGE(int, num_ctl_nearidx, 1);
            // stopline logics
            ADD_PARAM(int, stopline_newlogic);
            // stopline close ignore distance
            ADD_PARAM_WITH_CHECKGE(float, stlcloseignore, 0);
            // density grid ctrl x
            ADD_PARAM(int, density_ctl_x);
            // density grid ctrl y
            ADD_PARAM(int, density_ctl_y);
            // density grid ctrl grids
            ADD_PARAM(int, density_per_grid);
            // sample y_standard_deviation
            ADD_PARAM(float, y_standard_deviation);
            // Relax Planner Configs
            ADD_PARAM(float, rvp_thres_keep_distance);
            ADD_PARAM(float, rvp_accel_jerk);
            ADD_PARAM(float, rvp_accel_max);
            ADD_PARAM(float, rvp_speed_eps);
            ADD_PARAM(float, extra_dacc_stop);
            // if use base path goal
            ADD_PARAM(int, use_base_path_goal);
            // BPP sample interval
            ADD_PARAM_WITH_CHECKGE(int, bpp_sample_interval, 1);
            // if choose rrt goal by min cost
            ADD_PARAM(int, rrtgoal_by_mincost);
            // rrtgoal by min cost acceptable dist
            ADD_PARAM_WITH_CHECKGE(float, rrtgoal_bymincost_dist, 0);
            // if use dot cost
            ADD_PARAM(int, using_dot_cost);
            // if neglect freespace
            ADD_PARAM(int, neglect_all_freespace);
            // if neglect freespace at intersection
            ADD_PARAM(int, neglect_intersection_freespace);
            // threshold that consider goal not reachable
            ADD_PARAM(int, goal_not_reachable_thres);
            ADD_PARAM(float, steer_far_scale);
            ADD_PARAM(float, stopline_starting_offset);
            ADD_PARAM(float, stopline_stop_offset);
            // threshold that adjust expand_dist
            ADD_PARAM_WITH_CHECKGE(float, adjust_expand_dist_thres, 0);
            // adjust adjust_expand_dist
            ADD_PARAM_WITH_CHECKGE(float, adjust_expand_dist, 0.001f);
            // (Obsolete) whole path offset
            ADD_PARAM(float, whole_path_x_offset);
            // tolerance for replan
            ADD_PARAM(float, off_track_tolerance);
            ADD_PARAM(float, length_discrepance_tolerance);
            ADD_PARAM(float, max_tjp_diff_tolerance);
            ADD_PARAM(float, avg_tjp_diff_tolerance);
            // replan mode
            ADD_PARAM(int, recycle_mode_on);
            ADD_PARAM(int, recycle_mode_on_laneline);
            // replan per second
            ADD_PARAM(float, replan_per_second);
            // PP node node_frequency
            ADD_PARAM(float, node_frequency);
            ADD_PARAM(float, goal_drift_threshold);
            // QP Param order
            ADD_PARAM(int, param_qp_order);
            // QSS parameters
            ADD_PARAM(float, qss_rdp_threshold);
            ADD_PARAM(float, qss_lr);
            ADD_PARAM(float, qss_weight_cur);
            ADD_PARAM(float, qss_weight_cur_change);
            ADD_PARAM(int, qss_cur_sample);
            ADD_PARAM(int, qss_iters);
            ADD_PARAM(int, qss_special_init_for_one);
            ADD_PARAM(float, qss_weight_dist);
            ADD_PARAM(float, qss_penalty_dist);
            ADD_PARAM(float, qss_weight_penalty_dist);
            ADD_PARAM(int, qss_secondmidpoint_method);
            // If use quadratic_bezier_turning
            ADD_PARAM(int, quadratic_bezier_turning);
            // If use test_old_can_data
            ADD_PARAM(int, test_old_can_data);
            // RRT goal near threshold
            ADD_PARAM(float, rrt_goal_near_threshold);
            // Change from boundary to Lane dist threshold
            ADD_PARAM(float, to_boundary_dist);
            ADD_PARAM(float, cross_to_lane_shift);
            // Predict Map extra dist for pedestrian safe
            ADD_PARAM(float, pedestrain_extrasafe_dist);
            // Predict Map extra dist for vehicle safe
            ADD_PARAM(float, vehicle_extrasafe_dist);
            // if jp lane
            ADD_PARAM(int, jp_lane_map);
            // steer input direction option
            ADD_PARAM(int, switch_steering_input_direction);
            // ref line interval (also affect ibpp)
            ADD_PARAM_WITH_CHECKGE(float, ref_line_interval, 0.001f);
            // ref line length
            ADD_PARAM_WITH_CHECKGE(float, ref_line_length, 0.001f);
            // if pure ref line
            ADD_PARAM(int, pure_ref_line);
            // if use ref line
            ADD_PARAM(int, use_ref_line);
            // if use improved bpp
            ADD_PARAM(int, bpp_improved);
            // ibpp maximal turning radius
            ADD_PARAM_WITH_CHECKGE(float, ibpp_radius, 0.001f);
            // ibpp extra dist
            ADD_PARAM_WITH_CHECKGE(float, ibpp_extradist, 0);
            // ibpp maximal add distance
            ADD_PARAM_WITH_CHECKGE(float, ibpp_maxdist, 0);
            // extra root sample
            ADD_PARAM_WITH_CHECKGE(int, extra_root_sample, 0);
            // ref line adding dist
            ADD_PARAM_WITH_CHECKGE(float, ref_line_adding_dist, 0);
            // gen ref line mode
            ADD_PARAM_WITH_CHECKGE(int, gen_ref_line_mode, 0);
            // key points around collision
            ADD_PARAM_WITH_CHECKGE(int, key_point_around_collision, 0);
            // extra key point sample
            ADD_PARAM_WITH_CHECKGE(int, key_extra_points, 0);
            // prob for sample same bpp
            ADD_PARAM_WITH_CHECKAE(float, sample_same_bpp, 0, 1);
            // // min_path_length
            ADD_PARAM_WITH_CHECKGE(float, min_path_length, 0);
            // sample same bpp max times
            ADD_PARAM_WITH_CHECKGE(int, sample_same_bpp_maxtime, 1);
            // max times for retrying collision
            ADD_PARAM_WITH_CHECKGE(int, retry_count_collision, 1);
            // predmap risk value as free with RRT
            ADD_PARAM_WITH_CHECKGE(int, rrt_predmap_as_free, 0);
            // predmap risk value as free
            ADD_PARAM_WITH_CHECKGE(int, predmap_as_free, 0);
            // longitudinal safe distance for lookup predictmap
            ADD_PARAM_WITH_CHECKGE(float, rrt_longi_safe_dist, 0);
            // lateral safe distance for lookup predictmap
            ADD_PARAM_WITH_CHECKGE(float, rrt_lat_safe_dist, 0);
            // should use ellipse or not, correct ellipse not implemented
            ADD_PARAM_WITH_CHECKGE(int, predmap_using_ellipse, 0);
            // Max change lane distance
            ADD_PARAM(float, max_change_lane_distance);
            // Min change lane distance
            ADD_PARAM(float, min_change_lane_distance);
            // default change lane distance
            ADD_PARAM(float, default_change_lane_distance);
            // default change lane velocity
            ADD_PARAM(float, default_change_lane_velocity);
            // default change lane offset
            ADD_PARAM(float, default_change_lane_offset);
            // 0: default homemade refline, 1: routing basepath;
            ADD_PARAM(int, use_routing_refline);
            // Param to control goal of rrt's basepath
            ADD_PARAM(int, max_goal_index);
            ADD_PARAM(int, min_goal_index);
            // QPVelocityPlanner number of segments
            ADD_PARAM_WITH_CHECKGE(int, qpp_num_seg, 0);
            // QPVelocityPlanner number of sampled t
            ADD_PARAM_WITH_CHECKGE(int, qpp_t_sample, 0);
            // QPVelocityPlanner threshold caculate new t accroding to last t
            ADD_PARAM_WITH_CHECKGE(float, qpp_t_larger_eps, 0);
            // QPVelocityPlanner continous weight
            ADD_PARAM_WITH_CHECKGE(float, qpp_cont_weight, 0);
            // QPVelocityPlanner inequal weight
            ADD_PARAM_WITH_CHECKGE(float, qpp_ineq_weight, 0);
            // QPVelocityPlanner image number ignore threshold
            ADD_PARAM_WITH_CHECKGE(float, qpp_img_threshold, 0);
            // QPVelocityPlanner regularize eps
            ADD_PARAM_WITH_CHECKGE(float, qpp_regularize_eps, 0);
            // QPVelocityPlanner minimal acceleration for S estimate
            ADD_PARAM_WITH_CHECKGE(float, qpp_minest_acc, 0);
            // QPVelocityPlanner eps distance for S minus (ensure goal applied)
            ADD_PARAM_WITH_CHECKGE(float, qpp_dist_minus_eps, 0);

            ADD_PARAM(float, upper_leeway);
            ADD_PARAM(float, lower_leeway);
            ADD_PARAM(float, acc_up_leeway);

            ADD_PARAM(float, acc_decay_v_thres);
            ADD_PARAM(float, acc_decay_v_diff_thres);
            ADD_PARAM(float, acc_decay_v_diff_end);
            ADD_PARAM(float, acc_decay_min);
            // The lateral offset of cached_path for replan check
            ADD_PARAM(float, cached_path_offset_threshold);
            // Neglect path length condition at the end of jounery
            ADD_PARAM(int, recycle_at_terminal);
            // Index of trajpoint to check cached_path's offset
            ADD_PARAM(int, cached_path_check_index);
            // Correct path
            ADD_PARAM(int, correct_path);
            // Suppress PredMap Refresh
            ADD_PARAM(int, suppress_predmap_refresh);
            // Extend Prediction Result to PredMap Horizon End
            ADD_PARAM(int, extend_pred_res_to_end);
            // If goal is unreachable, and we are not overtaking, the distance
            // maximal distance we move the goal.
            ADD_PARAM(float, goal_forward_range);
            // Overtake extend verify index
            ADD_PARAM(int, overtake_extend_verify);
            // Goal safety back index, if < 0, the logics doesn't work.
            ADD_PARAM(int, goal_safety_back);
            // If allow to override dm velocity.
            ADD_PARAM(int, allow_stop_when_fail);
            // RRT assume points of base path collision free when the index <
            // this value
            ADD_PARAM(int, bp_assume_free_index);

            ADD_PARAM(float, probe_range);
            ADD_PARAM(float, probe_step);
            ADD_PARAM(float, clearance_threshold);
            ADD_PARAM(int, collision_check_range);
            ADD_PARAM(float, emerge_stop_acc);
            // Frenet D continue threshold at `parent` and `rewire`
            ADD_PARAM(float, frenet_d_continue);
            // Frenet D continue threshold at `parent` and `rewire`
            ADD_PARAM(float, frenet_d_continue);
            ADD_PARAM(int, goal_index_threshold);
            // bias for max curvature and goal distance
            ADD_PARAM(float, max_curvature_bias);
            // slope for max curvature and goal distance
            ADD_PARAM(float, max_curvature_slope);
            // max lateral acceralation during lane change
            ADD_PARAM(float, max_lateral_acc);
            // fitting coffeficence for bezier curve
            // goal_distance = 1.0 / ((1.0 / (coeff1 * width + coeff2) *
            // max_curvature4) + coeff3 * width + coeff4)
            ADD_PARAM(float, bezier_fitting_coeff1);
            ADD_PARAM(float, bezier_fitting_coeff2);
            ADD_PARAM(float, bezier_fitting_coeff3);
            ADD_PARAM(float, bezier_fitting_coeff4);
            // max lateral acc in overtake
            ADD_PARAM(float, max_overtake_latteral_acc);
            ADD_PARAM(float, update_origin_position_threshold);
            ADD_PARAM(float, update_origin_direction_threshold);
            // alignmet = 1, use alignment
            ADD_PARAM(int, alignment);
            ADD_PARAM(float, replan_track_time_threshold);
            ADD_PARAM(float, replan_track_time_threshold_stop);
            ADD_PARAM(float, replan_position_threshold);
            ADD_PARAM(float, min_basepath_distance_uturn);
            ADD_PARAM(float, target_point_replan_threshold);
            ADD_PARAM(float, select_rrt_goal_time);
            ADD_PARAM(int, output_by_time);
            // offset of basepath in pull over
            ADD_PARAM(float, pull_over_offset);
            ADD_PARAM(float, nudge_offset);
        }
        CONFIG_SECTION(nn_tool) {
            //
            ADD_PARAM(int, nn_tool_mode);
            //
            ADD_PARAM(int, nn_down_sample_rate);
        }
    } catch (std::runtime_error& err) {
        AD_LERROR(PATH_PLANNING) << "[INIT] runtime err: " << err.what();
        return AD_INVALID_FILE_FORMAT;
    }
    return AD_SUCCESS;
}
}  // namespace pp
}  // namespace senseAD
