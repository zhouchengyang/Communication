/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */
#include <math.h>
#include <algorithm>
#include "common/log.hpp"
#include "path_planning/util.hpp"
#include "path_planning/relaxvelocityplanner.hpp"

namespace senseAD {
namespace pp {

adStatus_t RelaxVelocityPlanner::PlanVelocity(
    std::vector<TrajectoryPoint> *path_to_plan) {
    if (path_to_plan == nullptr) {
        SD_CHECK_ERROR(AD_INVALID_PARAM);
    }
    if (path_to_plan->size() == 0) {
        return AD_SUCCESS;
        // SD_CHECK_ERROR(AD_INVALID_PARAM);
    }
    float vm;
    vm = target_speed_ - g_vehicle_state.velocity;
    float32_t insert_distance = 0.2;
    if (path_to_plan->size() >= 2) {
        cv::Point2f aa =
            path_to_plan->at(1).position - path_to_plan->at(0).position;
        utils::CalcNorm(aa, &insert_distance);
    }
    for (uint32_t i = 0; i < path_to_plan->size(); i++) {
        path_to_plan->at(i).sum_distance = i * insert_distance;
        if (fabs(vm) < speed_eps_) {
            path_to_plan->at(i).velocity = target_speed_;
            path_to_plan->at(i).acceleration = 0;
            if (vppurpose_ == STOP_AT_GIVEN_POINT ||
                vppurpose_ == EMERGE_STOP ||
                vppurpose_ == REMAIN_TILL_CACHE_GOAL ||
                fabs(target_speed_) < speed_eps_) {
                path_to_plan->at(i).acceleration = extra_dacc_stop_;
            }
        }
    }
    std::vector<BVPStage> bv_plan;
    // if in eps range, set path to target_speed_ and return success.
    if (fabs(vm) < speed_eps_) {
        return AD_SUCCESS;
    }
    // check g_vehicle_state.acceleration has the same direction as
    // velocity change
    if ((vm > 0.0f && g_vehicle_state.acceleration < 0.0f) ||
        (vm < 0.0f && g_vehicle_state.acceleration > 0.0f)) {
        AD_LINFO(PATH_PLANNING)
            << "g_vehicle_state.acceleration mismatch velocity "
               "change, force reset to zero";
        g_vehicle_state.acceleration = 0;
    }
    // TODO(someone): not used
    // int32_t recommend_force_type = -1;
    // 1. first, at speed up phase, wether can use acc down for target
    float jerk = accel_jerk_;
    float tt, s_type1, v_exp, v_cha, acc_down_jerk;
    bool d_acc_down_ok = false;
    if (g_vehicle_state.acceleration > 0) jerk = -jerk;
    if (fabs(g_vehicle_state.acceleration) > 1e-3) {
        tt = -g_vehicle_state.acceleration / jerk;
        v_exp = g_vehicle_state.acceleration * tt + 0.5f * jerk * tt * tt +
                g_vehicle_state.velocity;
        v_cha = v_exp - target_speed_;
        // this means it's too early to start acc down
        if ((v_cha < 0 && vm > 0) || (v_cha > 0 && vm < 0)) {
            d_acc_down_ok = false;
        } else {
            // we should start acc down now.
            d_acc_down_ok = true;
            // recommend_force_type = 1;
            acc_down_jerk = -g_vehicle_state.acceleration *
                            g_vehicle_state.acceleration /
                            (target_speed_ - g_vehicle_state.velocity) / 2;
            tt = -g_vehicle_state.acceleration / acc_down_jerk;
        }
        s_type1 = tt * tt * tt * jerk / 6 +
                  g_vehicle_state.acceleration * tt * tt / 2 +
                  tt * g_vehicle_state.velocity;
    }
    // 2. second, caculate wether could use one stage acc up / down
    // condition: |a1| < |max_acc| && |a1| > |current_accelerate|
    bool d_onetime_accupdown = false;
    bool d_maxacc_apply = false;
    if (target_speed_ > g_vehicle_state.velocity)
        jerk = accel_jerk_;
    else
        jerk = -accel_jerk_;
    // TODO(yingdi): v1_s
    float abs_a1, a1, s_type2 = 0.0f, s_type2_1 = 0.0f, s_type2_2 = 0.0f,
                      v1_s = 0.0f;
    abs_a1 =
        sqrtf(jerk * (target_speed_ - g_vehicle_state.velocity) +
              g_vehicle_state.acceleration * g_vehicle_state.acceleration / 2);
    if (fabs(g_vehicle_state.acceleration) < abs_a1 + 1e-3 &&
        abs_a1 < accel_max_ + 1e-3) {
        d_onetime_accupdown = true;
        if (jerk > 0) {
            a1 = abs_a1;
        } else {
            a1 = -abs_a1;
        }
        tt = (a1 - g_vehicle_state.acceleration) / jerk;
        v1_s =
            (-g_vehicle_state.acceleration * g_vehicle_state.acceleration / 2 +
             a1 * a1 / 2) /
                jerk +
            g_vehicle_state.velocity;
        s_type2_1 = tt * tt * tt * jerk / 6 +
                    g_vehicle_state.acceleration * tt * tt / 2 +
                    tt * g_vehicle_state.velocity;
        tt = a1 / jerk;
        s_type2_2 = -tt * tt * tt * jerk / 6 + a1 * tt * tt / 2 + tt * v1_s;
        s_type2 = s_type2_1 + s_type2_2;
    } else {
        d_onetime_accupdown = false;
        if (abs_a1 > accel_max_) {
            d_maxacc_apply = true;
        }
    }
    // 3. acc up to acc_max, keep, acc_down
    float v2_s = 0.0f, acc_max, t1, t2, t3, s_type3 = 0.0f, s_type3_1 = 0.0f,
          s_type3_2 = 0.0f, s_type3_3;
    float maxacc_current = g_vehicle_state.acceleration;
    if (d_maxacc_apply) {
        // first acc up to acc_max, we get speed and time
        if (target_speed_ > g_vehicle_state.velocity) {
            jerk = accel_jerk_;
            acc_max = accel_max_;
        } else {
            jerk = -accel_jerk_;
            acc_max = -accel_max_;
        }
        if (fabs(maxacc_current) > fabs(acc_max)) {
            maxacc_current = acc_max;
        }
        t1 = (acc_max - maxacc_current) / jerk;
        v1_s = jerk * t1 * t1 * 0.5f + maxacc_current * t1 +
               g_vehicle_state.velocity;
        t3 = acc_max / jerk;
        v2_s = target_speed_ - acc_max * t3 / 2;
        t2 = (v2_s - v1_s) / acc_max;
        s_type3_1 = t1 * t1 * t1 * jerk / 6 + maxacc_current * t1 * t1 / 2 +
                    t1 * g_vehicle_state.velocity;
        s_type3_2 = v1_s * t2 + 0.5 * acc_max * t2 * t2;
        s_type3_3 = t3 * (-jerk * t3 * t3 / 6 + t3 * acc_max / 2 + v2_s);
        s_type3 = s_type3_1 + s_type3_2 + s_type3_3;
    }
    float sum_dist = path_to_plan->at(path_to_plan->size() - 1).sum_distance;
    bvs_.clear();
    // -- stop at some point case--
    // TODO(someone): stop_sa stop_t1 ss_type1 not used
    // float stop_sa, stop_t1, ss_type1, v_ss1_1;
    float v_ss1_1;
    float stop_jerk, s_ss1_1, s_ss1_2, s_ss1, a_ssf;
    bool use_fallback_stop;
    use_fallback_stop = false;
    if (g_vehicle_state.acceleration > 0) {
        // TODO(someone): not used
        // stop_sa = 0;
    } else {
        // stop_sa = g_vehicle_state.acceleration;
    }
    // 1. first, if we keep the acceleration until the end,
    // see how far we go
    stop_jerk = accel_jerk_;
    v_ss1_1 = g_vehicle_state.acceleration * g_vehicle_state.acceleration / 2 /
              stop_jerk;
    // this means current accleration is too large, the rest speed
    // goes to zero earlier than we expected.
    bool keep_current_acceleration = false;
    if (v_ss1_1 > g_vehicle_state.velocity) {
        use_fallback_stop = true;
    } else {
        t1 = v_ss1_1 - g_vehicle_state.velocity;
        t1 = t1 / g_vehicle_state.acceleration;
        s_ss1_1 = g_vehicle_state.acceleration * t1 * t1 * 0.5f +
                  g_vehicle_state.velocity * t1;
        t2 = -g_vehicle_state.acceleration / stop_jerk;
        s_ss1_2 = t2 * (stop_jerk * 1.0f / 6 * t2 * t2 +
                        0.5f * t2 * g_vehicle_state.acceleration + v_ss1_1);
        s_ss1 = s_ss1_1 + s_ss1_2;
        if (fabs(sum_dist - s_ss1) < thres_keep_distance_) {
            keep_current_acceleration = true;
        } else {
            // Too complicated for other strategy
            // We may have to solve a quartic equation;
            use_fallback_stop = true;
        }
    }
    if (use_fallback_stop) {
        a_ssf = -g_vehicle_state.velocity * g_vehicle_state.velocity /
                (2.0f * sum_dist);
    }
    switch (vppurpose_) {
        case KEEP_UP_NON_ZERO_VELOCITY:
            if (d_acc_down_ok == true) {
                AD_LINFO(PATH_PLANNING) << "FVD: d_acc_down_ok";
                BVPStage ba;
                ba.s_v = g_vehicle_state.velocity;
                ba.e_v = target_speed_;
                ba.s_a = g_vehicle_state.acceleration;
                ba.e_a = 0;
                ba.type = 3;
                ba.j = acc_down_jerk;
                ba.d_f_s = s_type1;
                bvs_.push_back(ba);
                applybvpstage(path_to_plan);
            } else if (d_onetime_accupdown) {
                AD_LINFO(PATH_PLANNING) << "FVD: d_onetime_accupdown";
                BVPStage ba, bb;
                // Split to two basic stage
                ba.s_a = g_vehicle_state.acceleration;
                ba.e_a = a1;
                if (target_speed_ > g_vehicle_state.velocity) {
                    ba.j = accel_jerk_;
                } else {
                    ba.j = -accel_jerk_;
                }
                ba.d_f_s = s_type2_1;
                ba.s_v = g_vehicle_state.velocity;
                ba.e_v = v1_s;
                ba.type = 2;
                bvs_.push_back(ba);
                bb.s_a = a1;
                bb.e_a = 0;
                bb.s_v = v1_s;
                bb.e_v = target_speed_;
                bb.d_f_s = s_type2;
                bb.type = 3;
                bb.j = -ba.j;
                bvs_.push_back(bb);
                applybvpstage(path_to_plan);
            } else if (d_maxacc_apply) {
                AD_LINFO(PATH_PLANNING) << "FVD: d_maxacc_apply";
                BVPStage ba, bb, bc;
                if (target_speed_ > g_vehicle_state.velocity) {
                    ba.j = accel_jerk_;
                    acc_max = accel_max_;
                } else {
                    ba.j = -accel_jerk_;
                    acc_max = -accel_max_;
                }
                ba.s_a = maxacc_current;
                ba.e_a = acc_max;
                ba.s_v = g_vehicle_state.velocity;
                ba.e_v = v1_s;
                ba.d_f_s = s_type3_1;
                ba.type = 2;
                bvs_.push_back(ba);
                bb.s_v = v1_s;
                bb.e_v = v2_s;
                bb.s_a = acc_max;
                bb.e_a = acc_max;
                bb.j = 0;
                bb.d_f_s = s_type3_1 + s_type3_2;
                bb.type = 1;
                bvs_.push_back(bb);
                bc.s_v = v2_s;
                bc.e_v = target_speed_;
                bc.s_a = acc_max;
                bc.e_a = 0;
                bc.d_f_s = s_type3;
                bc.j = -ba.j;
                bc.type = 3;
                bvs_.push_back(bc);
                applybvpstage(path_to_plan);
            } else {
                LOG(INFO) << "Final fallback, directly use target_speed_";
                for (uint32_t i = 0; i < path_to_plan->size(); i++) {
                    path_to_plan->at(i).velocity = target_speed_;
                    path_to_plan->at(i).acceleration = 0;
                }
            }
            break;
        case STOP_AT_GIVEN_POINT:
        case REMAIN_TILL_CACHE_GOAL:
        case USE_DM_S:
            // Because we need to stop excatly at the goal,
            // we need other strategy.
            if (keep_current_acceleration) {
                AD_LINFO(PATH_PLANNING) << "FVD_S: keep_current_acceleration";
                // Two stage
                BVPStage ba, bb;
                ba.s_a = g_vehicle_state.acceleration;
                ba.type = 1;
                ba.e_a = g_vehicle_state.acceleration;
                ba.d_f_s = s_ss1_1;
                ba.s_v = g_vehicle_state.velocity;
                ba.e_v = v_ss1_1;
                ba.j = 0;
                bvs_.push_back(ba);
                bb.s_v = v_ss1_1;
                bb.e_v = 0;
                bb.d_f_s = s_ss1;
                bb.s_a = g_vehicle_state.acceleration;
                bb.e_a = 0;
                bb.j = stop_jerk;
                bb.type = 3;
                bvs_.push_back(bb);
                applybvpstage(path_to_plan);
            } else if (use_fallback_stop) {
                AD_LINFO(PATH_PLANNING) << "FVD_S: use_fallback_stop";
                BVPStage ba;
                ba.s_a = a_ssf;
                ba.e_a = a_ssf;
                ba.s_v = g_vehicle_state.velocity;
                ba.e_v = 0;
                ba.j = 0;
                ba.type = 1;
                ba.d_f_s = sum_dist;
                bvs_.push_back(ba);
                applybvpstage(path_to_plan);
            }
            break;
        case EMERGE_STOP:
            AD_LWARN(PATH_PLANNING) << "FVD_S: EMERGE_STOP";
            for (uint32_t i = 0; i < path_to_plan->size(); i++) {
                path_to_plan->at(i).velocity = 0;
                path_to_plan->at(i).acceleration = extra_dacc_stop_;
            }
            break;
        default:
            AD_LWARN(PATH_PLANNING) << "FVD_S: default, suppose not go here";
            for (uint32_t i = 0; i < path_to_plan->size(); i++) {
                path_to_plan->at(i).velocity = target_speed_;
                path_to_plan->at(i).acceleration = 0;
            }
            break;
    }
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
