/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 * Qiu Cong <qiucong@sensetime.com>
 */

#include <math.h>
#include <random>
#include <cmath>
#include <chrono>  // NOLINT
#include <string>
#include <sstream>
#include <functional>
#include <algorithm>
#include "common/log.hpp"
#include "path_planning/rrt_node.hpp"
#include "ini.h"  // NOLINT
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/rrt_core.hpp"
// #include <sched.h>
// #include <unistd.h>

namespace senseAD {
namespace pp {

adStatus_t RRTCore::Init() {
    // CPU Affinity
    // cpu_set_t mask;
    // CPU_ZERO(&mask);
    // CPU_SET(0, &mask);
    // CPU_SET(1, &mask);
    // sched_setaffinity(0, sizeof(cpu_set_t), &mask);

    auto conf = g_pp_conf["rrt_setting"];
    expand_distance_ = conf["expand_distance"];
    insert_distance_ = conf["insert_distance"];
    max_iteration_ = conf["max_iteration"];
    max_cap_iteration_ = conf["max_cap_iteration"];
    sumcost_optimize_ = conf["sumcost_optimize"];
    sample_rate_ = conf["sample_rate"];
    bpp_preplan_ = conf["bpp_preplan"];
    bpp_sample_ = conf["bpp_sample"];
    pure_bp_ = conf["pure_bp"];
    pure_ref_line_ = conf["pure_ref_line"];
    all_rewire_ = conf["all_rewire"];
    traj_smoothing_ = conf["traj_smoothing"];
    w_bpp_cost_ = conf["w_bpp_cost"];
    w_risk_cost_ = conf["w_risk_cost"];
    w_parent_cost_ = conf["w_parent_cost"];
    w_curvature_ = conf["w_curvature"];
    w_yaw_from_parent_ = conf["w_yaw_from_parent"];
    w_dist_ = conf["w_dist"];
    w_direction_ = conf["w_direction"];
    w_curvature_change_ = conf["w_curvature_change"];
    w_alignment_ = conf["w_alignment"];
    use_smoother_ = conf["use_smoother"];
    extra_hop_cost_ = conf["extra_hop_cost"];
    num_ctl_nearidx_ = conf["num_ctl_nearidx"];
    replan_mode_on_ = conf["recycle_mode_on"];
    replan_mode_on_laneline_ = conf["recycle_mode_on_laneline"];
    neglect_all_freespace_ = conf["neglect_all_freespace"];
    using_dot_cost_ = conf["using_dot_cost"];
    density_ctl_x_ = conf["density_ctl_x"];
    density_ctl_y_ = conf["density_ctl_y"];
    density_per_grid_ = conf["density_per_grid"];
    y_standard_deviation_ = conf["y_standard_deviation"];
    use_base_path_goal_ = conf["use_base_path_goal"];
    bpp_sample_interval_ = conf["bpp_sample_interval"];
    rrtgoal_by_mincost_ = conf["rrtgoal_by_mincost"];
    rrtgoal_bymincost_dist_ = conf["rrtgoal_bymincost_dist"];
    steer_far_scale_ = conf["steer_far_scale"];
    stopline_stop_offset_ = conf["stopline_stop_offset"];
    adjust_expand_dist_ = conf["adjust_expand_dist"];
    whole_path_x_offset_ = conf["whole_path_x_offset"];
    replan_per_second_ = conf["replan_per_second"];
    node_frequency_ = conf["node_frequency"];
    rrt_goal_near_threshold_ = conf["rrt_goal_near_threshold"];
    ref_line_interval_ = conf["ref_line_interval"];
    ref_line_length_ = conf["ref_line_length"];
    use_ref_line_ = conf["use_ref_line"];
    bpp_improved_ = conf["bpp_improved"];
    extra_root_sample_ = conf["extra_root_sample"];
    sample_same_bpp_ = conf["sample_same_bpp"];
    sample_same_bpp_maxtime_ = conf["sample_same_bpp_maxtime"];
    retry_count_collision_ = conf["retry_count_collision"];
    rrt_gridmap_as_free_ = conf["rrt_gridmap_as_free"];
    rrt_predmap_as_free_ = conf["rrt_predmap_as_free"];
    rrt_longi_safe_dist_ = conf["rrt_longi_safe_dist"];
    rrt_lat_safe_dist_ = conf["rrt_lat_safe_dist"];
    predmap_as_free_ = conf["predmap_as_free"];
    max_goal_index_ = conf["max_goal_index"];
    min_goal_index_ = conf["min_goal_index"];
    select_rrt_goal_time_ = conf["select_rrt_goal_time"];
    goal_forward_range_ = conf["goal_forward_range"];
    goal_safety_back_ = conf["goal_safety_back"];
    allow_stop_when_fail_ = conf["allow_stop_when_fail"];
    bp_assume_free_index_ = conf["bp_assume_free_index"];
    speed_eps_ = conf["rvp_speed_eps"];
    frenet_d_continue_ = conf["frenet_d_continue"];
    goal_index_threshold_ = conf["goal_index_threshold"];
    output_by_time_ = conf["output_by_time"];
    int vp_mode = conf["vp_mode"];

    // Extra save and init
    expand_dist_ordinate_ = expand_distance_;
    density_per_grid_ordinate_ = density_per_grid_;
    density_per_grid_adjust_ = density_per_grid_ordinate_ * 2 *
                               (expand_dist_ordinate_ / adjust_expand_dist_) *
                               (expand_dist_ordinate_ / adjust_expand_dist_);
    nn_tool_cached_path_.Init();
    if (denstiy_map_ != NULL) {
        free(denstiy_map_);
    }
    denstiy_map_ = reinterpret_cast<int32_t *>(malloc(
        sizeof(int32_t) * (density_ctl_x_ + 1) * (density_ctl_y_ + 1) * 2));
    newnear_idx = reinterpret_cast<int32_t *>(
        malloc(sizeof(int32_t) * (max_cap_iteration_ + 1)));

    // Config for create some Smoother_
    int param_qp_order = conf["param_qp_order"];
    adStatus_t ret = AD_SUCCESS;
    // Create Smoother based on configuration
    switch (use_smoother_) {
        case 1:
            smoother_ = new SchneiderSmoother();
            smoother_->Init();
            break;
        case 2:
            smoother_ = new ParamPolyQPSmoother(param_qp_order);
            smoother_->Init();
            break;
        case 3:
            smoother_ = new QuintSplineSGDSmoother();
            smoother_->Init();
            break;
        default:
            // not construct a smoother,
            // because we'll use cubic bezier fitting function directy.
            ret = AD_INVALID_PARAM;
            break;
    }

    // Create Velocity Planner based on configuration
    switch (vp_mode) {
        case 5:
            vplanner_ = new RelaxVelocityPlanner();
            vplanner_->Init();
            break;
        case 6:
            vplanner_ = new QPVelocityPlanner();
            vplanner_->Init();
            break;
        default:
            // no other planner currently
            ret = AD_INVALID_PARAM;
            break;
    }
    return ret;
}

RRTCore::~RRTCore() {
    if (denstiy_map_ != nullptr) {
        free(denstiy_map_);
    }
    if (newnear_idx != nullptr) {
        free(newnear_idx);
    }
    if (smoother_ != nullptr) {
        delete smoother_;
    }
    if (vplanner_ != nullptr) {
        delete vplanner_;
    }
}

adStatus_t RRTCore::WarpTree() {
    AD_LDEBUG(PATH_PLANNING) << "RRT warping tree";
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    for (uint32_t i = 0; i < nodes_.size(); i++) {
        TrajectoryPoint traj_pt;
        traj_pt.position = nodes_[i].position;
        traj_pt.direction = nodes_[i].default_direction;
        WarpTrajectoryPoint(&traj_pt);
        nodes_[i].position = traj_pt.position;
        nodes_[i].default_direction = traj_pt.direction;
    }
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[2] += (pc_plan_end - pc_plan_start);
    function_called_nums_[2] += 1;

    AD_LDEBUG(PATH_PLANNING) << "RRT warpped tree";
    return AD_SUCCESS;
}

void RRTCore::SimplilyAddWrappedNode() {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    if (nodes_.empty()) {
        RRTNode new_root;
        new_root.id = 0;
        new_root.cost = 0.0;
        new_root.base_path_cost = 0.0;
        new_root.position = origin_point_;
        new_root.default_direction = cv::Point2f(1, 0);
        new_root.parent_id = -1;
        new_root.children_id = std::set<int>();
        nodes_.push_back(new_root);
    }
    re_calc_samples.clear();
    for (uint32_t i = 0; i < nodes_.size(); i++) {
        // if (nodes_[i].position.x >= 0) {
        re_calc_samples.push_back(nodes_[i]);
        // }
    }
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[2] += (pc_plan_end - pc_plan_start);
    function_called_nums_[2] += 1;
}
adStatus_t RRTCore::ItsRiskWithTime(float s,
                                    float d,
                                    float heading,
                                    int *pass_check) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    float accu_dist = s;
    float approx_time;
    float approx_velocity = goal_.velocity;
    float approx_acc = 2.0f;
    if (goal_.velocity < g_vehicle_state.velocity) {
        approx_acc = -approx_acc;
        approx_velocity = g_vehicle_state.velocity;
    }
    if (approx_velocity < 0.01) {
        approx_time = 0.01;
    } else {
        approx_time = accu_dist / approx_velocity;
    }
    if (func_bool_frenet_collisioncheck_predict == nullptr) {
        AD_LERROR(PATH_PLANNING) << "Planner no register "
                                    "func_bool_frenet_collisioncheck_predict "
                                    "plug()";
        return AD_NULL_PTR;
    }

    func_int_frenet_risk(s, d, heading, approx_time, rrt_longi_safe_dist_,
                         rrt_lat_safe_dist_, pass_check);
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[9] += (pc_plan_end - pc_plan_start);
    // Count on another IsFreeWithTime
    function_called_nums_[9] += 1;

    return AD_SUCCESS;
}

adStatus_t RRTCore::ItsRiskWithTime(const TrajectoryPoint &tp,
                                    int *pass_check) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    float s, ds, dds, d, dd, ddd;
    utils::CartesianToFrenet(tp, base_path_, &s, &ds, &dds, &d, &dd, &ddd);
    ItsRiskWithTime(s, d, tp.theta, pass_check);
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[9] += (pc_plan_end - pc_plan_start);
    // Count on another IsFreeWithTime
    function_called_nums_[9] += 0;
    return AD_SUCCESS;
}

adStatus_t RRTCore::IsFreeWithTime(float s,
                                   float d,
                                   float heading,
                                   bool *pass_check) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    float accu_dist = s;
    float approx_time;
    float approx_velocity = goal_.velocity;
    float approx_acc = 2.0f;
    if (goal_.velocity < g_vehicle_state.velocity) {
        approx_acc = -approx_acc;
        approx_velocity = g_vehicle_state.velocity;
    }

    // float reach_speed_t = (dm_target_.dm_velocity -
    //                        curr_vehicle_state_.velocity) / approx_acc;
    // float reach_speed_s = reach_speed_t * 0.5 *
    //                       (dm_target_.dm_velocity +
    //                        curr_vehicle_state_.velocity);
    // if (accu_dist > reach_speed_s) {
    //     if (dm_target_.dm_velocity < 0.01) {
    //         approx_time = reach_speed_t;
    //     } else {
    //         float extra_dist = accu_dist - reach_speed_s;
    //         float extra_t = extra_dist / dm_target_.dm_velocity;
    //         approx_time = reach_speed_t + extra_t;
    //     }
    // } else {
    //     // v_0t+0.5at^2=s  -> at^2+2v_0t-2s=0
    //     approx_time = (-curr_vehicle_state_.velocity +
    //                    sqrtf(curr_vehicle_state_.velocity *
    //                     curr_vehicle_state_.velocity -
    //                     2 * approx_acc * accu_dist)) / approx_acc;
    // }
    if (approx_velocity < 0.01) {
        approx_time = 0.01;
    } else {
        approx_time = accu_dist / approx_velocity;
    }
    if (func_bool_frenet_collisioncheck_predict == nullptr) {
        AD_LERROR(PATH_PLANNING) << "Planner no register "
                                    "func_bool_frenet_collisioncheck_predict "
                                    "plug()";
        return AD_NULL_PTR;
    }
    // func_bool_frenet_collisioncheck_predict(
    //     s, d, approx_time, pass_check);

    int risk;
    func_int_frenet_risk(s, d, heading, approx_time, rrt_longi_safe_dist_,
                         rrt_lat_safe_dist_, &risk);
    *pass_check = (risk <= rrt_predmap_as_free_);

    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[9] += (pc_plan_end - pc_plan_start);
    // Count on another IsFreeWithTime
    function_called_nums_[9] += 1;

    return AD_SUCCESS;
}

adStatus_t RRTCore::IsFreeWithTime(const TrajectoryPoint &tp,
                                   bool *pass_check) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    float s, ds, dds, d, dd, ddd;
    utils::CartesianToFrenet(tp, base_path_, &s, &ds, &dds, &d, &dd, &ddd);
    IsFreeWithTime(s, d, tp.theta, pass_check);
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[9] += (pc_plan_end - pc_plan_start);
    // Count on another IsFreeWithTime
    function_called_nums_[9] += 0;
    return AD_SUCCESS;
}

// TODO(congq): better strategy, too simple, somehow naive
adStatus_t RRTCore::OriginCheckExpandValidFrom(const RRTNode &node,
                                               const RRTNode &trj_pt,
                                               bool *pass_check) {
    AD_LTRACE(PATH_PLANNING)
        << "RRT Checking Collision expansion from"
        << " from " << node.position << " to " << trj_pt.position;
    cv::Point2f d_pos = trj_pt.position - node.position;
    float heading = std::atan2(d_pos.y, d_pos.x);

    bool pass_inner_check;
    // static free space
    float distance = cv::norm(d_pos);
    int32_t round = distance / (expand_distance_ / 2.0);

    for (int32_t i = 0; i < round; i++) {
        RRTCheckCollision(node.position +
                              d_pos * (1.0 / distance) * static_cast<float>(i) *
                                  (expand_distance_ / 2.0),
                          &pass_inner_check);
        /*
        CheckCollision(
            node.position +
                d_pos * (1.0 / distance) *
                static_cast<float>(i) * (expand_distance_ / 2.0),
            &pass_inner_check);
        */

        if (!pass_inner_check) {
            *pass_check = false;
            AD_LTRACE(PATH_PLANNING)
                << "RRT Checking collision expandsion false";
            return AD_SUCCESS;
        }
    }

    // predicted freespace
    IsFreeWithTime(node.frenet_s, node.frenet_d, heading, &pass_inner_check);

    if (!pass_inner_check) {
        *pass_check = false;
        return AD_SUCCESS;
    }

    *pass_check = true;
    AD_LTRACE(PATH_PLANNING) << "RRT Checking Collision expandsion true";
    return AD_SUCCESS;
}

adStatus_t RRTCore::PurgeBranch() {
    AD_LINFO(PATH_PLANNING) << "RRT Pruning branch";
    auto pc_plan_start = std::chrono::high_resolution_clock::now();

    if (nodes_.empty()) {
        RRTNode new_root;
        new_root.id = 0;
        new_root.cost = 0.0;
        new_root.sumcost = 0.0;
        new_root.base_path_cost = 0.0;
        new_root.position = origin_point_;
        new_root.default_direction = cv::Point2f(1, 0);
        new_root.parent_id = -1;
        new_root.children_id = std::set<int>();
        nodes_.push_back(new_root);
    } else {
        std::vector<RRTNode> new_node_list;
        RRTNode new_root = nodes_[0];
        new_root.position = origin_point_;
        new_root.cost = 0;
        new_node_list.push_back(new_root);
        unsigned int i = 0;
        while (i < new_node_list.size()) {
            if (!new_node_list[i].children_id.empty()) {
                std::set<int> new_children_id;
                std::set<int> old_children_id = new_node_list[i].children_id;
                // TODO(congq): delete branch that are not reachable too
                for (auto index : old_children_id) {
                    bool pass_check_collision = true;
                    // cv::Point2f position = nodes_[index].position;
                    // TODO(someone): not used
                    // cv::Point2f front_pt = nodes_[index].default_direction;

                    OriginCheckExpandValidFrom(new_node_list[i], nodes_[index],
                                               &pass_check_collision);

                    // if (position.x < 0) {
                    //    pass_check_collision = false;
                    // }
                    float dist, yaw, curvature, maintain_direction,
                        curvature_change;
                    int32_t node_feasible;

                    auto pc_cost_timer_start =
                        std::chrono::high_resolution_clock::now();
                    CostBetweenNode(new_node_list[i], nodes_[index], &dist,
                                    &yaw, &curvature, &maintain_direction,
                                    &curvature_change, &node_feasible);

                    auto pc_cost_timer_end =
                        std::chrono::high_resolution_clock::now();
                    durations_[10] += (pc_cost_timer_end - pc_cost_timer_start);
                    function_called_nums_[10] += 1;

                    if (node_feasible < 0 || curvature > 0.2) {
                        pass_check_collision = false;
                    }

                    if (pass_check_collision) {
                        new_node_list.push_back(nodes_[index]);
                        new_node_list.back().id = new_node_list.size() - 1;
                        new_node_list.back().parent_id = i;

                        auto pc_cost_timer_start =
                            std::chrono::high_resolution_clock::now();

                        new_node_list.back().cost =
                            NodeCost(new_node_list[i], new_node_list.back(),
                                     &node_feasible);
                        new_node_list.back().sumcost =
                            AccumlateCost(new_node_list[i],
                                          new_node_list.back(), &node_feasible);
                        auto pc_cost_timer_end =
                            std::chrono::high_resolution_clock::now();
                        durations_[10] +=
                            (pc_cost_timer_end - pc_cost_timer_start);
                        function_called_nums_[10] += 2;
                        new_children_id.insert(new_node_list.size() - 1);
                    } else {
                        old_children_id.insert(
                            nodes_[index].children_id.begin(),
                            nodes_[index].children_id.end());
                    }
                }
                new_node_list[i].children_id = new_children_id;
            }
            i++;
        }
        nodes_ = new_node_list;
    }

    AD_LINFO(PATH_PLANNING) << "RRT pruned branches";

    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[2] += (pc_plan_end - pc_plan_start);
    function_called_nums_[2] += 1;
    return AD_SUCCESS;
}

adStatus_t RRTCore::GenTrajPath(const TrajectoryPoint &goal,
                                std::vector<TrajectoryPoint> *trajpoint_path) {
    AD_LDEBUG(PATH_PLANNING) << "RRT Generating path from tree";
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    // adStatus_t RRTPathPlanner::GenOriginPath(
    // const cv::Point2f& goal_position,
    // std::vector<cv::Point2f>& path){

    path.clear();
    trajpoint_path->clear();

    failed_reach_goal_ = 0;
    int close_index_distance = -1;
    int close_index_cost = -1;
    int close_index = -1;
    float min_distance = std::numeric_limits<float>::max();
    float min_cost = std::numeric_limits<float>::max();
    AD_LDEBUG(PATH_PLANNING) << "RRT GenPath finding Closest node";
    for (unsigned int i = 0; i < nodes_.size(); i++) {
        cv::Point2f d_pos = nodes_[i].position - goal.position;
        float distance = cv::norm(d_pos);
        if (distance < min_distance) {
            min_distance = distance;
            close_index_distance = i;
        }
        if (distance < rrtgoal_bymincost_dist_ &&
            nodes_[i].sumcost < min_cost) {
            min_cost = nodes_[i].sumcost;
            close_index_cost = i;
        }
    }

    if (rrtgoal_by_mincost_ == 1 && close_index_cost >= 0) {
        close_index = close_index_cost;
    } else {
        close_index = close_index_distance;
    }

    if (min_distance > rrt_goal_near_threshold_) {
        // FallBack to BPP last no collision point
        // int first_unusable_bp_index, last_usable_bp_index;
        int first_unusable_bp_index;
        first_unusable_bp_index = bpp_first_usable_index_;
        // TODO(some): not used
        // last_usable_bp_index = bpp_last_usable_index_;
        if (this->base_path_.size() > 0 &&
            first_unusable_bp_index >
                static_cast<int>(this->base_path_.size())) {
            first_unusable_bp_index = this->base_path_.size() - 1;
        }
        if ((first_unusable_bp_index >=
             static_cast<int>(this->base_path_.size())) ||
            first_unusable_bp_index < 0) {
            AD_LINFO(PATH_PLANNING) << "Collision found, "
                                    << "and base_path_.size too small, "
                                    << "RRT GenPath No node found";
        } else {
            TrajectoryPoint new_goal = base_path_[first_unusable_bp_index];
            AD_LINFO(PATH_PLANNING)
                << "Failed to reach goal, rewrite goal to"
                << " " << new_goal.position << " " << new_goal.direction;
            failed_reach_goal_ = 1;
            close_index_distance = -1;
            close_index_cost = -1;
            close_index = -1;
            for (unsigned int i = 0; i < nodes_.size(); i++) {
                cv::Point2f d_pos = nodes_[i].position - new_goal.position;
                float distance = utils::cvnorm(d_pos);
                if (distance < min_distance) {
                    min_distance = distance;
                    close_index_distance = i;
                }
                if (distance < rrtgoal_bymincost_dist_ &&
                    nodes_[i].sumcost < min_cost) {
                    min_cost = nodes_[i].sumcost;
                    close_index_cost = i;
                }
            }
            if (rrtgoal_by_mincost_ == 1 && close_index_cost >= 0) {
                close_index = close_index_cost;
            } else {
                close_index = close_index_distance;
            }
        }
    }

    if (close_index == -1) {
        AD_LINFO(PATH_PLANNING) << "RRT GenPath No node found";
        // todo(cognq): handle it
    } else {
        // ---buildtree_test_mode---
        if (buildtree_test_mode_ && buildtree_test_path_res != nullptr) {
            buildtree_test_path_res->clear();
        }
        // ---buildtree_test_mode---
        // End node for iteration, close node for determine planning result
        RRTNode end_node = nodes_[close_index];
        AD_LINFO(PATH_PLANNING) << "RRT GenPath from node " << close_index
                                << " position " << end_node.position;
        RRTNode close_node = nodes_[close_index];
        while (end_node.id != 0) {
            // ---buildtree_test_mode---
            if (buildtree_test_mode_ && buildtree_test_path_res != nullptr) {
                buildtree_test_path_res->push_back(end_node.id);
            }
            // ---buildtree_test_mode---
            path.push_back(end_node.position);
            AD_LDEBUG(PATH_PLANNING) << "RRT Genpath added node " << end_node.id
                                     << " position " << end_node.position;
            end_node = nodes_[end_node.parent_id];
        }
        path.push_back(origin_point_);
        // TODO(congq): not using node default direction.
        std::stringstream ss_rrt_node_info;
        for (auto pos : path) {
            ss_rrt_node_info << pos << " ";
        }
        AD_LINFO(PATH_PLANNING)
            << "RRT GenPath RRT Origin pos: " << ss_rrt_node_info.str();

        std::reverse(path.begin(), path.end());
        cv::Point2f entering_direction = start_.direction;
        cv::Point2f exiting_direction;

        if (cv::norm(close_node.position - goal.position) <
            expand_distance_ * goal_not_reachable_thres_) {
            exiting_direction = goal.direction;
        } else {
            exiting_direction = close_node.default_direction;
            // if_cutpath_ = true;
        }

        if (use_smoother_ == 1 || use_smoother_ == 2 || use_smoother_ == 3) {
            std::vector<TrajectoryPoint> tmptp;
            for (int32_t ii = 0; ii < static_cast<int32_t>(path.size()); ii++) {
                TrajectoryPoint tp;
                tp.position = path[ii];
                if (ii == static_cast<int>(path.size()) - 1) {
                    tp.direction = goal_.direction;
                    utils::Normalize2Dvect(&tp.direction);
                } else if (ii == 0) {
                    tp.direction = entering_direction;
                    utils::Normalize2Dvect(&tp.direction);
                } else {
                    tp.direction = 0.5f * ((path[ii + 1] - path[ii]) +
                                           (path[ii] - path[ii - 1]));
                    utils::Normalize2Dvect(&tp.direction);
                }
                tmptp.push_back(tp);
                AD_LDEBUG(PATH_PLANNING) << "Schneidersmooth/QP Point " << ii
                                         << " Postion: " << tp.position
                                         << " Direction: " << tp.direction;
            }
            if (tmptp.size() > 1) {
                smoother_->SetData(tmptp);
                smoother_->Fit();
                (*trajpoint_path) = smoother_->SamplePoints(insert_distance_);
            } else {
                AD_LINFO(PATH_PLANNING)
                    << "not enough point to"
                    << " triggle schneidersmoother/parampoly_qp_smoother!";
            }
        } else {
            utils::CubicBezierSmoothing(path, entering_direction,
                                        exiting_direction, trajpoint_path);
        }
    }
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[7] += (pc_plan_end - pc_plan_start);
    function_called_nums_[7] += 1;

    AD_LINFO(PATH_PLANNING) << "RRT generated path from tree";
    return AD_SUCCESS;
}

adStatus_t RRTCore::Plan(std::vector<TrajectoryPoint> *out_path) {
    // ---------Excution Time Stats------------
    std::vector<std::string> titles = {
        "Plan           ",  // 0
        "BPPCollision   ",  // 1
        "Warp&UpdateTree",  // 2
        "Sample         ",  // 3
        "Steer          ",  // 4
        "Parenting      ",  // 5
        "Rewire         ",  // 6
        "GenSmoothPath  ",  // 7
        "Collision      ",  // 8
        "IsFreeWithTime ",  // 9
        "Cost           ",  // 10
        "VelocityPlanner",  // 11
    };
    function_called_nums_ = std::vector<int>(12, 0);
    durations_ =
        std::vector<std::chrono::nanoseconds>(12, std::chrono::nanoseconds());
    auto pp_start = std::chrono::high_resolution_clock::now();
    nn_tool_cached_path_.UpdateData(cached_path_);
    origin_point_ = start_.position;
    if (replan_flag_ == ReplanFlag::PATH_REPLAN ||
        replan_flag_ == ReplanFlag::PATH_SPEED_REPLAN) {
        // 1. plan path, i.e. execute rrt search
        if (PlanPath(out_path) != AD_SUCCESS) {
            AD_LERROR(PATH_PLANNING) << "planning path failed!!!";
        }
    } else {
        // recycle path, truncate cached trajectory
        if (TruncatePath(out_path) != AD_SUCCESS) {
            AD_LERROR(PATH_PLANNING) << "truncate cached path failed!!!";
        }
    }
    auto vp_start = std::chrono::high_resolution_clock::now();
    if (replan_flag_ == ReplanFlag::PATH_SPEED_REPLAN ||
        replan_flag_ == ReplanFlag::SPEED_REPLAN) {
        // 2. plan velocity
        PlanVelocity(out_path);
    } else {
        AD_LERROR(PATH_PLANNING) << "wrong replan flag";
    }
    auto vp_end = std::chrono::high_resolution_clock::now();

    SetTimestamp(out_path);
    utils::UpdateCurvatureYawrate(out_path);

    if (output_by_time_ || output_planning_log_) {
        Trajectory result_traj;
        utils::SegmentTrajectoryByTime(*out_path, insert_distance_,
                                       &result_traj);
        core_planning_log_.s.clear();
        core_planning_log_.v.clear();
        core_planning_log_.a.clear();
        core_planning_log_.jerk.clear();
        core_planning_log_.num = static_cast<int>(result_traj.size());
        core_planning_log_.time_interval = insert_distance_;
        int i = 0;
        for (auto &traj : result_traj) {
            core_planning_log_.s.push_back(traj.sum_distance);
            core_planning_log_.v.push_back(traj.velocity);
            core_planning_log_.a.push_back(traj.acceleration);
            if (i == 0) {
                core_planning_log_.jerk.push_back(0.0);
            } else {
                core_planning_log_.jerk.push_back(
                    (result_traj.at(i).acceleration -
                     result_traj.at(i - 1).acceleration) /
                    insert_distance_);
            }
            ++i;
        }
        if (output_by_time_) {
            *out_path = result_traj;
        }
    }

    durations_[11] += (vp_end - vp_start);
    function_called_nums_[11] += 1;

    if (out_path->size() == 0) {
        AD_LINFO(PATH_PLANNING) << "RRT failed to yeild anything";
    }

    for (uint32_t i = 0; i < nodes_.size(); i++) {
        AD_LDEBUG(PATH_PLANNING)
            << "RRTNode: " << nodes_[i].id << " " << nodes_[i].parent_id << " "
            << nodes_[i].cost << " " << nodes_[i].sumcost << " "
            << nodes_[i].base_path_cost << " " << nodes_[i].position.x << " "
            << nodes_[i].position.y;
    }

    auto pp_end = std::chrono::high_resolution_clock::now();
    durations_[0] += (pp_end - pp_start);
    function_called_nums_[0] += 1;

    std::stringstream ss_rrttime_info;

    ss_rrttime_info << "RRT_time \t ";

    for (uint32_t i = 0; i < titles.size(); i++) {
        ss_rrttime_info << titles[i] << "\t" << function_called_nums_[i] << "\t"
                        << std::chrono::duration<float>(durations_[i]).count()
                        << "\t";
    }
    AD_LINFO(PATH_PLANNING) << ss_rrttime_info.str();

    // Build Tree Test Mode should only affect one scope.
    if (buildtree_test_mode_) {
        buildtree_test_mode_ = false;
    }
    return AD_SUCCESS;
}

adStatus_t RRTCore::PlanPath(std::vector<TrajectoryPoint> *out_path) {
    if (out_path == nullptr) {
        AD_LERROR(PATH_PLANNING) << "output path is nullptr";
        return AD_NULL_PTR;
    }
    if (buildtree_test_mode_) {
        AD_LERROR(PATH_PLANNING) << "!!! Remind: Build Tree Test Mode is on! "
                                    "This should not happen online.";
    }
    // ----------------------------------------
    if (base_path_.size() == 0) {
        AD_LERROR(PATH_PLANNING) << "No base path input on NONE Target";
        return AD_SUCCESS;
    }
    // origin_point_ = cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    for (size_t i = 0; i < base_path_.size(); i++) {
        auto trajpt = base_path_[i];
        AD_LDEBUG(PATH_PLANNING)
            << "BPP " << i << " " << trajpt.position << " " << trajpt.direction
            << " " << trajpt.velocity << " " << trajpt.theta << " "
            << trajpt.curvature << " " << trajpt.sum_distance << " "
            << trajpt.time_difference << " " << trajpt.yaw_rate << " "
            << trajpt.acceleration;
    }
    AD_LDEBUG(PATH_PLANNING) << "vp_s_: " << vp_s_;
    Trajectory base_path_for_elon = base_path_;
    auto goal2 = goal_;

    // select rrt goal index bases vehicle velocity
    goal_index_ = static_cast<int>(g_vehicle_state.velocity *
                                   select_rrt_goal_time_ / insert_distance_);
    goal_index_ =
        std::max(min_goal_index_, std::min(goal_index_, max_goal_index_));
    if (vppurpose_ == STOP_AT_GIVEN_POINT ||
        vppurpose_ == FOLLOW_AT_GIVEN_POINT) {
        goal_index_ = std::min(static_cast<int>(vp_s_ / insert_distance_),
                               max_goal_index_);
        AD_LINFO(PATH_PLANNING)
            << "DM asked for stop or follow, goal_index_ set to "
            << goal_index_;
    } else if (goal_safety_back_ >= 0 && vppurpose_ == STOP_AT_STOPLINE) {
        // TODO(eteced) Very hardcode!
        goal_index_ = std::min(static_cast<int>(vp_s_ / insert_distance_),
                               max_goal_index_);
        for (int i = bp_assume_free_index_;
             i < static_cast<int>(base_path_.size()) && i < goal_index_; i++) {
            bool goal_reachable = true;
            IsFree_(base_path_[i].position, &goal_reachable);
            if (goal_reachable) {
                IsFreeWithTime(base_path_[i], &goal_reachable);
            }
            if (!goal_reachable) {
                goal_index_ = i - goal_safety_back_;
                goal_index_ = std::max(0, goal_index_);
                if (allow_stop_when_fail_ == 1) {
                    //  goal2.velocity = dm_target_.dm_velocity;
                    //  goal_.velocity = dm_target_.dm_velocity;
                    AD_LWARN(PATH_PLANNING)
                        << "DM do not aware obstacle!!! veclocity to DM";
                }
                break;
            }
        }
        AD_LINFO(PATH_PLANNING)
            << "Boss said, we should not avoid obstacle "
            << "but just follow it when we at stopline: " << goal_index_;
    }

    // bool collided_on_basepath_ = false;
    // int collided_index = -1;
    // for (int i = 0; i < base_path_.size() &&
    //         i < goal_index_; i++) {
    //     // Static Collision checkout for now
    //     collided_index = i;
    //     bool refline_is_free = true;
    //     IsFree_(base_path_[i].position, &refline_is_free);
    //     if (!refline_is_free) {
    //         collided_on_basepath_ = true;
    //         break;
    //     }
    // }
    // if (collided_index >= 0&&collided_on_basepath_) {
    //     goal_index_ = collided_index;
    // }
    goal_index_ =
        std::min(goal_index_, static_cast<int>(base_path_.size()) - 1);
    bool goal_reachable = true;
    if (goal_index_ > 0) {
        IsFree_(base_path_[goal_index_].position, &goal_reachable);
        if (goal_reachable) {
            IsFreeWithTime(base_path_[goal_index_], &goal_reachable);
        }
    }
    if (!goal_reachable) {
        float range = 0;
        for (int ii = goal_index_ + 1; ii < static_cast<int>(base_path_.size());
             ii++) {
            range = range + cv::norm(base_path_[ii].position -
                                     base_path_[ii - 1].position);
            if (range > goal_forward_range_) {
                break;
            }
            goal_reachable = true;
            IsFree_(base_path_[ii].position, &goal_reachable);
            if (goal_reachable) {
                IsFreeWithTime(base_path_[ii], &goal_reachable);
            }
            if (goal_reachable) {
                goal_index_ = ii;
                break;
            }
        }
        if (goal_reachable) {
            AD_LINFO(PATH_PLANNING)
                << "move forward goal, index: " << goal_index_
                << " rrt goal: " << base_path_[goal_index_].position;
        } else {
            int collided_index = -1;
            for (int i = 0;
                 i < static_cast<int>(base_path_.size()) && i < goal_index_;
                 i++) {
                collided_index = i;
                bool refline_is_free = true;
                IsFree_(base_path_[i].position, &refline_is_free);
                if (refline_is_free) {
                    IsFreeWithTime(base_path_[i], &goal_reachable);
                }
                if (!refline_is_free) {
                    break;
                }
            }
            goal_index_ = collided_index;
            AD_LINFO(PATH_PLANNING)
                << "move goal failed, collid_index: " << collided_index
                << " rrt goal: " << base_path_[goal_index_].position;
        }
    } else {
        AD_LINFO(PATH_PLANNING)
            << "goal_index: " << goal_index_
            << " rrt goal: " << base_path_[goal_index_].position;
    }
    base_path_ = Trajectory(
        base_path_for_elon.begin(),
        base_path_for_elon.begin() +
            std::min(static_cast<int>(base_path_for_elon.size()), goal_index_));

    if (base_path_.size() != 0) {
        goal_ = base_path_.back();
        goal_.velocity = goal2.velocity;
    }
    // base_path_ = utils::TrimProperBasePath(base_path_for_elon, goal_);

    sampled_flags_ = std::vector<int>(
        std::max(
            0,
            static_cast<int>(base_path_.size() - 1) / bpp_sample_interval_ + 1),
        0);
    BPPPathCollisionCheck();
    // TODO(someone) Init start point and direction
    AD_LINFO(PATH_PLANNING) << "start_.direction: " << start_.direction;
    memset(denstiy_map_, 0,
           sizeof(int32_t) * (density_ctl_x_ + 1) * (density_ctl_y_ + 1) * 2);
    if (out_path == NULL) {
        return AD_NULL_PTR;
    }
    AD_LINFO(PATH_PLANNING)
        << "goal: " << goal_.position << " goal_dir: " << goal_.direction;
    AD_LDEBUG(PATH_PLANNING) << "RRT preparing tree, warptree, purgebranch";
    out_path->clear();
    this->InitSampledFlag();

    re_calc_samples.clear();
    if (!buildtree_test_mode_) {
        WarpTree();
        if (all_rewire_ == 1) {
            SimplilyAddWrappedNode();
            nodes_.clear();
        } else {
            PurgeBranch();
        }
    } else {
        nodes_.clear();
    }

    // ----Switch between two expand_dist_ density_per_grid_profile----
    if (std::fabs(goal_.position.x) + std::fabs(goal_.position.y) <
        adjust_expand_dist_thres_) {
        expand_distance_ = adjust_expand_dist_;
        density_per_grid_ = density_per_grid_adjust_;
    } else {
        expand_distance_ = expand_dist_ordinate_;
        density_per_grid_ = density_per_grid_ordinate_;
    }
    if (nodes_.empty()) {
        RRTNode new_root;
        new_root.id = 0;
        new_root.cost = 0.0;
        new_root.sumcost = 0.0;
        new_root.base_path_cost = 0.0;
        new_root.position = origin_point_;
        new_root.default_direction = cv::Point2f(1, 0);
        new_root.parent_id = -1;
        new_root.children_id = std::set<int>();
        nodes_.push_back(new_root);
    }
    AD_LDEBUG(PATH_PLANNING) << "RRT start iteration";
    int32_t max_inter = max_iteration_;
    sample_the_goal_ = true;
    if (buildtree_test_mode_ && all_rewire_ == 0) {
        max_inter = buildtree_test_random_points_.size();
    } else if (all_rewire_ == 1) {
        if (buildtree_test_mode_) {
            re_calc_samples = buildtree_test_random_points_;
            max_inter = re_calc_samples.size();
        } else {
            // samples point set and put it in re_calc_samples
            SamplesPointSet();
            max_inter = re_calc_samples.size();
        }
        AD_LINFO(PATH_PLANNING)
            << "RRT re_calc_samples size: " << re_calc_samples.size();
    }
    int32_t max_nodes = 0;
    for (int i = 0; i < max_inter; i++) {
        AD_LDEBUG(PATH_PLANNING) << "RRT Internal " << i << "th iteration";

        TrajectoryPoint new_traj_point;
        new_traj_point.direction = cv::Point2f(-1.0, 0.0);
        float base_path_point_distance = 0;

        if (buildtree_test_mode_ && all_rewire_ == 0) {
            new_traj_point.direction =
                buildtree_test_random_points_[i].default_direction;
            new_traj_point.position = buildtree_test_random_points_[i].position;
            new_traj_point.sum_distance =
                buildtree_test_random_points_[i].frenet_s;
            base_path_point_distance =
                fabs(buildtree_test_random_points_[i].frenet_d);
        } else if (all_rewire_ == 1) {
            new_traj_point.direction = re_calc_samples[i].default_direction;
            new_traj_point.position = re_calc_samples[i].position;
            new_traj_point.sum_distance = re_calc_samples[i].frenet_s;
            base_path_point_distance = fabs(re_calc_samples[i].frenet_d);
        } else {
            auto pc_sample_timer_start =
                std::chrono::high_resolution_clock::now();
            RRTNode new_traj_point_node;
            SampleTrajPoint(&new_traj_point_node, &base_path_point_distance);
            auto pc_sample_timer_end =
                std::chrono::high_resolution_clock::now();
            durations_[3] += (pc_sample_timer_end - pc_sample_timer_start);
            function_called_nums_[3] += 1;
            new_traj_point.direction = new_traj_point_node.default_direction;
            new_traj_point.position = new_traj_point_node.position;
            new_traj_point.sum_distance = new_traj_point_node.frenet_s;
            base_path_point_distance = fabs(new_traj_point_node.frenet_d);
        }

        AD_LDEBUG(PATH_PLANNING) << "RRT Sampled " << new_traj_point.position
                                 << " " << new_traj_point.direction;
        // Point in dense area, skip this round
        if (new_traj_point.position.x == 0 && new_traj_point.position.y == 0) {
            AD_LDEBUG(PATH_PLANNING)
                << "RRT skipped round cuz failure in sampling qualified point";
            continue;
        }
        bool pass_check_collision = false;

        RRTCheckCollision(new_traj_point.position, &pass_check_collision);
        AD_LDEBUG(PATH_PLANNING) << "RRT Point passed collision check";

        bool steer_point_changed = true;
        if (pass_check_collision) {
            AD_LDEBUG(PATH_PLANNING)
                << "RRT Point passed collision check,steering";
            TrajectoryPoint steered_traj_point;
            if_skip_the_point_ = false;
            Steer(new_traj_point, &steered_traj_point);
            if (if_skip_the_point_) {
                AD_LINFO(PATH_PLANNING) << "steer failed and skip this point: "
                                        << steered_traj_point.position;
                continue;
            }
            if (cv::norm(new_traj_point.position -
                         steered_traj_point.position) > 0.01) {
                new_traj_point = steered_traj_point;
            } else {
                steer_point_changed = false;
            }
        } else {
            continue;
        }
        RRTCheckCollision(new_traj_point.position, &pass_check_collision);
        bool if_density = density_check(new_traj_point.position);
        if (!if_density) {
            AD_LDEBUG(PATH_PLANNING) << "RRT Density Check Failed";
        }
        if (pass_check_collision && if_density) {
            // if (pass_check_collision) {
            AD_LDEBUG(PATH_PLANNING)
                << "RRT steered Point passed collision check choosing parent";
            RRTNode point_info;
            RRTNode new_node;
            // new_node.base_path_cost =
            // base_path_point_distance/new_traj_point.position.x;
            const float small_eps = 3e-2;
            float s, ds, dds, d, dd, ddd;
            if (steer_point_changed) {
                utils::CartesianToFrenet(new_traj_point, base_path_, &s, &ds,
                                         &dds, &d, &dd, &ddd);
                if (nodes_.size() > 0 &&
                    nodes_[nodes_.size() - 1].frenet_s - s >
                        expand_distance_ * steer_far_scale_ + small_eps) {
                    AD_LDEBUG(PATH_PLANNING)
                        << "Drop steer point due to violate order heavily.";
                    continue;
                }
            } else {
                s = re_calc_samples[i].frenet_s;
                d = re_calc_samples[i].frenet_d;
            }
            point_info.position = new_traj_point.position;
            point_info.direction = new_traj_point.direction;
            point_info.frenet_s = s;
            point_info.frenet_d = d;
            new_node.base_path_cost = fabs(d);
            AD_LDEBUG(PATH_PLANNING)
                << "RRT chooseing parent in origin way pts:"
                << point_info.position << " dir:" << point_info.direction
                << " s:" << point_info.frenet_s << " d:" << point_info.frenet_d;
            ao = 0;
            OriginChooseParent(point_info, &new_node);
            if (new_node.cost >= 0) {
                AD_LDEBUG(PATH_PLANNING) << "RRT found valid parent";
                AD_LDEBUG(PATH_PLANNING)
                    << "RRT node parent_id " << new_node.parent_id;
                auto parent_node_ = nodes_[new_node.parent_id];
                AD_LDEBUG(PATH_PLANNING)
                    << "RRT node parent "
                    << " id " << parent_node_.id << " cost parent between "
                    << parent_node_.cost << " position "
                    << parent_node_.position << " default "
                    << parent_node_.default_direction << " parent_id "
                    << parent_node_.parent_id << " size of children_list"
                    << parent_node_.children_id.size();
                new_node.frenet_s = s;
                new_node.frenet_d = d;
                nodes_.push_back(new_node);
                nodes_[new_node.parent_id].children_id.insert(new_node.id);
                Rewire(&nodes_[new_node.id]);
                if (ao > max_nodes) max_nodes = ao;
            }
        }
    }
    AD_LDEBUG(PATH_PLANNING) << "RRT end of iteration";
    AD_LINFO(PATH_PLANNING) << "RRT Maxiumal Nodes: " << max_nodes;
    GenTrajPath(goal_, out_path);

    if (out_path->size() > 0) {
        AD_LINFO(PATH_PLANNING)
            << "RRT end trajPoint " << out_path->back().position;
    }
    AD_LINFO(PATH_PLANNING)
        << "RRT "
        << "node list size \t" << nodes_.size() << "\nRRT Planinternal Ends";

    auto trajpoint_path = *out_path;
    out_path->clear();

    // if output by time, sample at a finer grain first
    if (output_by_time_ == 1) {
        utils::SegmentTrajectory(trajpoint_path, 0.1, out_path);
    } else {
        utils::SegmentTrajectory(trajpoint_path, insert_distance_, out_path);
    }

    if (goal_index_ < goal_index_threshold_) {
        out_path->clear();
        failed_reach_goal_ = 0;
    }

    // if output by time, sample at a finer grain first
    if (output_by_time_ == 1) {
        utils::PathElongation(out_path, base_path_for_elon, 0.1);
    } else {
        utils::PathElongation(out_path, base_path_for_elon, insert_distance_);
    }
    return AD_SUCCESS;
}

adStatus_t RRTCore::PlanVelocity(std::vector<TrajectoryPoint> *out_path) const {
    if (out_path == nullptr) {
        AD_LERROR(PATH_PLANNING) << "output path is nullptr";
        return AD_NULL_PTR;
    }
    if (out_path->empty()) {
        AD_LERROR(PATH_PLANNING) << "output path is empty.";
        return AD_INVALID_PARAM;
    }
    int vp_index =
        std::max(0, std::min(static_cast<int>(out_path->size()) - 1,
                             static_cast<int>(vp_s_ / insert_distance_)));
    if (goal_safety_back_ >= 0 && vppurpose_ == STOP_AT_STOPLINE &&
        goal_.velocity < speed_eps_) {
        vp_index = std::min(vp_index, goal_index_);
    }
    int out_path_index = static_cast<int>(out_path->size()) - 1;
    if (failed_reach_goal_ == 1 && allow_stop_when_fail_ == 1) {
        // goal_.velocity = 0;
        AD_LWARN(PATH_PLANNING)
            << "DM do not aware obstacle!!! Set velocity to DM";
    }
    vplanner_->Update(vppurpose_, vp_index, goal_.velocity);
    vplanner_->PlanVelocity(out_path);
    return AD_SUCCESS;
}

adStatus_t RRTCore::SampleSameBPPTrajPoint(RRTNode *sample_traj_point,
                                           float *base_path_point_distance) {
    if (base_path_.size() == 0 || sample_traj_point->bpp_index < 0 ||
        sample_traj_point->bpp_index >= static_cast<int>(base_path_.size())) {
        sample_traj_point->position = origin_point_;
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampled nothing, base path empty "
                                 << " or bpp_index not valid";
        return AD_SUCCESS;
    }
    std::normal_distribution<float> y_distribution(0, y_standard_deviation_);
    auto y_generator = std::bind(y_distribution, std::ref(y_random_engine));
    int index_use = sample_traj_point->bpp_index;
    sample_traj_point->position = base_path_[index_use].position;
    sample_traj_point->direction = base_path_[index_use].direction;
    // TODO(eteced) This is a hardcode, try remove it with
    // `utils::CartesianToFrenet` and BPP Generation. = =.
    sample_traj_point->frenet_s = index_use * 0.2;
    sample_traj_point->frenet_d = 0;
    sample_traj_point->base_path_cost = 0;
    sample_traj_point->bpp_index = index_use;
    float init_y = y_generator();
    // keep rand point
    AD_LDEBUG(PATH_PLANNING) << "RRT Sampling BPP ";
    AD_LDEBUG(PATH_PLANNING) << "RRT Sampling index_use: " << index_use;
    // Find normal of velocity direction
    // normalized it
    // multiply by init_y
    cv::Point2f ydirection = cv::Point2f(-(*sample_traj_point).direction.y,
                                         (*sample_traj_point).direction.x);
    ydirection = ydirection * (1.0 / utils::cvnorm(ydirection));
    (*sample_traj_point).position += ydirection * init_y;
    sample_traj_point->frenet_d = init_y;
    AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Y normal: " << ydirection;
    AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Y offset: " << init_y;
    *base_path_point_distance = std::fabs(init_y);
    AD_LDEBUG(PATH_PLANNING)
        << "RRT Sampling basepath_dist:  " << *base_path_point_distance;
    sample_traj_point->base_path_cost = std::fabs(init_y);

    return AD_SUCCESS;
}

adStatus_t RRTCore::SampleTrajPoint(RRTNode *sample_traj_point,
                                    float *base_path_point_distance) {
    if (base_path_.size() == 0) {
        sample_traj_point->position.x = origin_point_.x;
        sample_traj_point->position.y = origin_point_.y;
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampled nothing, base path empty";
        return AD_SUCCESS;
    }
    AD_LDEBUG(PATH_PLANNING) << "RRT Sampling based BP ";
    if (!if_rand_engine_init) {
        auto seed_a =
            std::chrono::system_clock::now().time_since_epoch().count();
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampling seed: " << seed_a;
        x_random_engine.seed(seed_a + rand() + rand());
        y_random_engine.seed(seed_a + rand() + rand());
        p_random_engine.seed(seed_a + rand() + rand());
        if_rand_engine_init = true;
    }

    std::uniform_real_distribution<float> x_distribution(
        0, static_cast<float>(base_path_.size()));
    auto x_generator = std::bind(x_distribution, std::ref(x_random_engine));

    std::normal_distribution<float> y_distribution(0, y_standard_deviation_);
    auto y_generator = std::bind(y_distribution, std::ref(y_random_engine));
    std::uniform_real_distribution<float> p_distrubution(0, 1);
    // auto p_generator = std::bind(p_distrubution, std::ref(p_random_engine));

    int init_x = static_cast<int>(x_generator());

    int sampled_flags_size = static_cast<int>(sampled_flags_.size());
    if (sampled_flags_size > static_cast<int>(base_path_.size())) {
        sampled_flags_size = base_path_.size();
    }
    float scale = sampled_flags_size * 1.0f / base_path_.size();
    init_x = static_cast<int>(init_x * scale);
    // float tmp_rand = y_generator();
    float init_y = y_generator();
    // tmp_rand = p_generator();
    // float p = static_cast<float>((rand() + rand() + rand()) % 1000) / 1000;

    if (sample_the_goal_) {
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Goal ";
        sample_traj_point->position = goal_.position;
        sample_traj_point->direction = goal_.direction;
        float s, ds, dds, d, dd, ddd;
        utils::CartesianToFrenet(goal_, base_path_, &s, &ds, &dds, &d, &dd,
                                 &ddd);
        *(base_path_point_distance) = fabs(d);
        sample_traj_point->frenet_s = s;
        sample_traj_point->frenet_d = d;
        sample_traj_point->base_path_cost = fabs(d);
        sample_traj_point->bpp_index = -1;
        sample_the_goal_ = false;
    } else {
        sample_traj_point->position =
            base_path_[init_x * bpp_sample_interval_].position;
        sample_traj_point->direction =
            base_path_[init_x * bpp_sample_interval_].direction;
        // TODO(eteced) This is a hardcode, try remove it with
        // `utils::CartesianToFrenet` and BPP Generation. = =.
        sample_traj_point->frenet_s = init_x * bpp_sample_interval_ * 0.2;
        sample_traj_point->frenet_d = 0;
        sample_traj_point->base_path_cost = 0;
        sample_traj_point->bpp_index = init_x * bpp_sample_interval_;

        AD_LDEBUG(PATH_PLANNING)
            << "RRT Sampling from " << base_path_.size() << " node";
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Sampled BP index" << init_x * bpp_sample_interval_;
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Sampled BP point " << sample_traj_point->position;
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Sampled BP direction " << sample_traj_point->direction;

        if (sampled_flags_[init_x] == 0) {
            AD_LDEBUG(PATH_PLANNING) << "RRT Sampled BP point " << init_x;
            sampled_flags_[init_x] = 1;
            return AD_SUCCESS;
        } else {
            // keep rand point
            AD_LDEBUG(PATH_PLANNING) << "RRT Sampling BPP ";
            AD_LDEBUG(PATH_PLANNING) << "RRT Sampling init_x: " << init_x;
            // Find normal of velocity direction
            // normalized it
            // multiply by init_y
            cv::Point2f vec_b = (*sample_traj_point).direction;
            cv::Point2f ord_pts = (*sample_traj_point).position;
            cv::Point2f ydirection =
                cv::Point2f(-(*sample_traj_point).direction.y,
                            (*sample_traj_point).direction.x);
            ydirection = ydirection * (1.0 / cv::norm(ydirection));
            (*sample_traj_point).position += ydirection * init_y;
            auto vec_c = (*sample_traj_point).position - ord_pts;
            auto cross_b_c = vec_b.x * vec_c.y - vec_b.y * vec_c.x;
            if (cross_b_c > 1e-4) {
                (*sample_traj_point).frenet_d = std::fabs(init_y);
            } else {
                (*sample_traj_point).frenet_d = -std::fabs(init_y);
            }
            AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Y normal: " << ydirection;
            AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Y offset: " << init_y;
            *base_path_point_distance = std::fabs(init_y);
            AD_LDEBUG(PATH_PLANNING)
                << "RRT Sampling basepath_dist:  " << *base_path_point_distance;
            sample_traj_point->base_path_cost = std::fabs(init_y);
        }
    }
    AD_LDEBUG(PATH_PLANNING)
        << "RRT Sampled " << sample_traj_point->position << " "
        << sample_traj_point->direction << sample_traj_point->frenet_s
        << sample_traj_point->frenet_d;
    return AD_SUCCESS;
}

adStatus_t RRTCore::AroundRootSample(TrajectoryPoint *sample_traj_point) {
    std::default_random_engine x_random_engine;
    std::default_random_engine y_random_engine;
    auto seed_a = std::chrono::system_clock::now().time_since_epoch().count();
    AD_LDEBUG(PATH_PLANNING) << "RRT Sampling seed: " << seed_a;
    x_random_engine.seed(seed_a + rand() + rand());
    y_random_engine.seed(seed_a + rand() + rand());

    std::normal_distribution<float> y_distribution(0, y_standard_deviation_);
    auto y_generator = std::bind(y_distribution, y_random_engine);

    std::normal_distribution<float> x_distribution(0,
                                                   2 * y_standard_deviation_);
    auto x_generator = std::bind(x_distribution, x_random_engine);

    float init_x = std::abs(x_generator());
    // float tmp_rand = y_generator();
    float init_y = y_generator();
    // tmp_rand = p_generator();

    sample_traj_point->position = cv::Point2f(init_x, init_y);

    AD_LDEBUG(PATH_PLANNING) << "RRT Sampled " << sample_traj_point->position
                             << " " << sample_traj_point->direction;
    return AD_SUCCESS;
}

adStatus_t RRTCore::OriginChooseParent(const RRTNode &traj_pt,
                                       RRTNode *new_node) {
    const float small_eps = 1e-2;
    AD_LDEBUG(PATH_PLANNING) << "RRT Choosing Parent";
    auto pc_plan_start = std::chrono::high_resolution_clock::now();

    auto inner_traj_pt = traj_pt;
    int min_index = -1;
    float min_cost = std::numeric_limits<float>::max();
    float betw_cost = 0;
    RRTNode tmp_node;
    tmp_node.position = inner_traj_pt.position;
    tmp_node.default_direction = inner_traj_pt.direction;
    tmp_node.base_path_cost = new_node->base_path_cost;
    float ed2 = (expand_distance_ + small_eps) * (expand_distance_ + small_eps);
    float p2 = expand_distance_ * 1.0;
    for (int32_t i = static_cast<int>(nodes_.size()) - 1; i >= 0; i--) {
        cv::Point2f d_pos = inner_traj_pt.position - nodes_[i].position;

        float dist = d_pos.x * d_pos.x + d_pos.y * d_pos.y;
        if (traj_pt.frenet_s - nodes_[i].frenet_s > p2 + small_eps) break;
        // TODO(congq): tmp solution
        if (dist > ed2 ||
            fabs(traj_pt.frenet_d - nodes_[i].frenet_d) >
                frenet_d_continue_ + small_eps) {
            AD_LDEBUG(PATH_PLANNING) << "Continue: ID:" << nodes_[i].id;
            continue;
        }
        newnear_idx[ao] = (nodes_[i].id);
        ao = ao + 1;
        AD_LDEBUG(PATH_PLANNING) << "Considering point:" << nodes_[i].position;
        // if (inner_traj_pt.direction.x ==
        // -1.0 && inner_traj_pt.direction.y == 0.0) {
        inner_traj_pt.direction = inner_traj_pt.position - nodes_[i].position;
        tmp_node.default_direction = tmp_node.direction =
            inner_traj_pt.direction;
        // }
        bool pass_exp_collision_check = false;
        // auto tb = std::chrono::high_resolution_clock::now();
        OriginCheckExpandValidFrom(nodes_[i], inner_traj_pt,
                                   &pass_exp_collision_check);
        if (pass_exp_collision_check) {
            int32_t tmp_feasible;
            float node_cost;
            auto pc_cost_timer_start =
                std::chrono::high_resolution_clock::now();

            float cost =
                AccumlateCost(nodes_[i], tmp_node, &tmp_feasible, &node_cost);

            auto pc_cost_timer_end = std::chrono::high_resolution_clock::now();
            durations_[10] += (pc_cost_timer_end - pc_cost_timer_start);
            function_called_nums_[10] += 1;

            if (tmp_feasible == 1 && cost < min_cost) {
                min_index = i;
                min_cost = cost;
                betw_cost = node_cost;
            }
        }
        if (ao > num_ctl_nearidx_ && min_index != -1) {
            break;
        }
    }
    if (min_index < 0) {
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Choosing Parent but no valid node found";
        new_node->id = static_cast<int>(nodes_.size());
        new_node->cost = -1.0f;
        new_node->sumcost = -1.0f;
        new_node->parent_id = 0;
        new_node->base_path_cost = 0;
        new_node->position = inner_traj_pt.position;
        new_node->default_direction = inner_traj_pt.direction;
    } else {
        AD_LDEBUG(PATH_PLANNING) << "RRT Choosing Parent valid node found "
                                 << " id " << min_index << " cost " << min_cost;
        new_node->id = static_cast<int>(nodes_.size());
        new_node->cost = betw_cost;
        new_node->sumcost = min_cost;
        new_node->parent_id = min_index;
        new_node->base_path_cost = tmp_node.base_path_cost;
        new_node->position = inner_traj_pt.position;
        new_node->default_direction = inner_traj_pt.direction;
        new_node->sum_dist =
            nodes_[min_index].sum_dist +
            cv::norm(inner_traj_pt.position - nodes_[min_index].position);
    }

    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[5] += (pc_plan_end - pc_plan_start);
    function_called_nums_[5] += 1;

    AD_LDEBUG(PATH_PLANNING) << "RRT Choosing Parent complete";
    return AD_SUCCESS;
}

adStatus_t RRTCore::Rewire(RRTNode *new_node) {
    AD_LDEBUG(PATH_PLANNING)
        << "RRT Rewiring from node " << new_node->id << " " << ao;
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    for (int32_t i = 0; i < ao; i++) {
        RRTNode &node = nodes_[newnear_idx[i]];
        int32_t new_node_feasible;
        int32_t old_feasible;
        float newonecost;

        auto pc_cost_timer_start = std::chrono::high_resolution_clock::now();
        float newcost =
            AccumlateCost(*new_node, node, &new_node_feasible, &newonecost);
        auto pc_cost_timer_end = std::chrono::high_resolution_clock::now();
        durations_[10] += (pc_cost_timer_end - pc_cost_timer_start);
        function_called_nums_[10] += 1;

        if (node.id == 0 || node.parent_id == 0) {
            continue;
        }
        pc_cost_timer_start = std::chrono::high_resolution_clock::now();
        node.cost = NodeCost(nodes_[node.parent_id], node, &old_feasible);
        pc_cost_timer_end = std::chrono::high_resolution_clock::now();
        durations_[10] += (pc_cost_timer_end - pc_cost_timer_start);
        function_called_nums_[10] += 1;

        float tmpcost;
        if (sumcost_optimize_ == 1) {
            tmpcost = node.sumcost;
        } else {
            auto pc_cost_timer_start =
                std::chrono::high_resolution_clock::now();
            tmpcost =
                AccumlateCost(nodes_[node.parent_id], node, &old_feasible);
            auto pc_cost_timer_end = std::chrono::high_resolution_clock::now();
            durations_[10] += (pc_cost_timer_end - pc_cost_timer_start);
            function_called_nums_[10] += 1;
        }

        if (new_node_feasible == 1 && (newcost < tmpcost || old_feasible < 0)) {
            bool pass_exp_collision_check = false;
            OriginCheckExpandValidFrom(*new_node, node,
                                       &pass_exp_collision_check);
            if (pass_exp_collision_check) {
                AD_LDEBUG(PATH_PLANNING) << "RRT Rewiring node " << node.id
                                         << " to " << new_node->id;
                nodes_[node.parent_id].children_id.erase(node.id);
                node.parent_id = new_node->id;

                new_node->children_id.insert(node.id);
                node.cost = newonecost;
                node.sumcost = newcost;
                node.default_direction = node.position - new_node->position;
                node.sum_dist = new_node->sum_dist +
                                cv::norm(node.position - new_node->position);

                if (sumcost_optimize_ == 1) {
                    auto pc_cost_timer_start =
                        std::chrono::high_resolution_clock::now();

                    ForwardAccCost(node);
                    auto pc_cost_timer_end =
                        std::chrono::high_resolution_clock::now();
                    durations_[10] += (pc_cost_timer_end - pc_cost_timer_start);
                    function_called_nums_[10] += 1;
                }
            }
        }
    }

    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[6] += (pc_plan_end - pc_plan_start);
    function_called_nums_[6] += 1;

    AD_LDEBUG(PATH_PLANNING) << "RRT rewired";
    return AD_SUCCESS;
}

adStatus_t RRTCore::BPPPathCollisionCheck() {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();

    int extra_add = 0;
    bpp_collision_check_.clear();
    collied_bp_index_.clear();
    bpp_key_index_.clear();
    float32_t insert_distance_ = 0.2;
    if (base_path_.size() > 2) {
        cv::Point2f aa = base_path_[1].position - base_path_[0].position;
        utils::CalcNorm(aa, &insert_distance_);
    }
    for (int32_t i = 0; i < static_cast<int>(base_path_.size()); i++) {
        bool pass_check_grid = false;
        bool pass_check_time = true;
        bool pass_check = false;
        CheckCollision(base_path_[i].position, &pass_check_grid);
        // IsFreeWithTime(base_path_[i].position, &pass_check_time);
        int risk;
        ItsRiskWithTime(base_path_[i], &risk);
        pass_check_time = risk < predmap_as_free_;

        pass_check = (pass_check_grid & pass_check_time);
        bpp_collision_check_.push_back(pass_check);
        if (pass_check == false) {
            AD_LDEBUG(PATH_PLANNING)
                << "BPP point " << i << " : " << base_path_[i].position
                << "failed to pass collision check, Gridmap: "
                << pass_check_grid << " PredictMap:" << pass_check_time
                << " Final: " << pass_check;
            collied_bp_index_.push_back(i);
            int s = i - key_point_around_collision_;
            if (s < 0) s = 0;
            for (; s < static_cast<int>(i); s++) {
                if (bpp_collision_check_[s] == true &&
                    find(bpp_key_index_.begin(), bpp_key_index_.end(), s) ==
                        bpp_key_index_.end()) {
                    bpp_key_index_.push_back(s);
                }
            }
            extra_add = key_point_around_collision_;
        } else {
            if (extra_add > 0) {
                extra_add--;
                bpp_key_index_.push_back(i);
            }
        }
    }

    if (collied_bp_index_.size() == 0) {
        AD_LINFO(PATH_PLANNING) << "No collision, using origin goal";
        bpp_last_usable_index_ = base_path_.size();
        bpp_first_usable_index_ = base_path_.size();
    } else {
        int non_collided_index = base_path_.size() - 1;
        int collied_index_iter = collied_bp_index_.size() - 1;
        while (non_collided_index >= 0 && collied_index_iter >= 0) {
            if (non_collided_index != collied_bp_index_[collied_index_iter]) {
                break;
            }
            non_collided_index--;
            collied_index_iter--;
        }
        if (non_collided_index >= 0) {
            AD_LINFO(PATH_PLANNING)
                << "collided, using  goal at" << non_collided_index << " / "
                << base_path_.size() - 1
                << "last collied point: " << collied_bp_index_.back()
                << "first collied point: " << collied_bp_index_.front();
            bpp_last_usable_index_ = non_collided_index;
            bpp_first_usable_index_ = collied_bp_index_[0];
        }
    }

    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[1] += (pc_plan_end - pc_plan_start);
    function_called_nums_[1] += 1;

    return AD_SUCCESS;
}

adStatus_t RRTCore::SampleKeyTrajPoint(RRTNode *sample_traj_point,
                                       float *base_path_point_distance) {
    if (bpp_key_index_.size() == 0) {
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Key Point Sampled nothing,"
            << " no key index, use default sample instead.";
        SampleTrajPoint(sample_traj_point, base_path_point_distance);
        return AD_SUCCESS;
    }
    std::uniform_real_distribution<float> x_distribution(
        0, static_cast<float>(bpp_key_index_.size()));
    std::normal_distribution<float> y_distribution(0, y_standard_deviation_);
    auto x_generator = std::bind(x_distribution, std::ref(x_random_engine));
    auto y_generator = std::bind(y_distribution, std::ref(y_random_engine));
    int index = static_cast<int>(x_generator());
    if (index >= static_cast<int>(bpp_key_index_.size())) {
        index = bpp_key_index_.size() - 1;
    }
    int init_x = static_cast<int>(bpp_key_index_[index]);
    init_x = init_x % sampled_flags_.size();
    // float tmp_rand = y_generator();
    float init_y = y_generator();
    if (base_path_.size() == 0) {
        sample_traj_point->position = origin_point_;
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampled nothing, base path empty";
        return AD_SUCCESS;
    }
    sample_traj_point->position =
        base_path_[init_x * bpp_sample_interval_].position;
    sample_traj_point->direction =
        base_path_[init_x * bpp_sample_interval_].direction;
    // TODO(eteced) This is a hardcode, try remove it with
    // `utils::CartesianToFrenet` and BPP Generation. = =.
    sample_traj_point->frenet_s = init_x * bpp_sample_interval_ * 0.2;
    sample_traj_point->frenet_d = 0;
    sample_traj_point->base_path_cost = 0;

    AD_LDEBUG(PATH_PLANNING)
        << "RRT Sampling from " << base_path_.size() << " node";
    AD_LDEBUG(PATH_PLANNING)
        << "RRT Sampled BP index" << init_x * bpp_sample_interval_;
    AD_LDEBUG(PATH_PLANNING)
        << "RRT Sampled BP point " << sample_traj_point->position;
    AD_LDEBUG(PATH_PLANNING)
        << "RRT Sampled BP direction " << sample_traj_point->direction;

    if (sampled_flags_[init_x] == 0) {
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampled BP point " << init_x;
        sampled_flags_[init_x] = 1;
        return AD_SUCCESS;
    } else {
        // keep rand point
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampling BPP ";
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampling init_x: " << init_x;
        // Find normal of velocity direction
        // normalized it
        // multiply by init_y
        cv::Point2f ydirection = cv::Point2f(-(*sample_traj_point).direction.y,
                                             (*sample_traj_point).direction.x);
        ydirection = ydirection * (1.0 / cv::norm(ydirection));
        (*sample_traj_point).position += ydirection * init_y;
        if (sample_traj_point->position.y >
            base_path_[init_x * bpp_sample_interval_].position.y) {
            sample_traj_point->frenet_d = -std::fabs(init_y);
        } else {
            sample_traj_point->frenet_d = std::fabs(init_y);
        }
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Y normal: " << ydirection;
        AD_LDEBUG(PATH_PLANNING) << "RRT Sampling Y offset: " << init_y;
        *base_path_point_distance = std::fabs(init_y);
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Sampling basepath_dist:  " << *base_path_point_distance;
        sample_traj_point->base_path_cost = std::fabs(init_y);
    }
    return AD_SUCCESS;
}

adStatus_t RRTCore::Steer(const TrajectoryPoint &traj_pt,
                          TrajectoryPoint *steer_traj_point) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();

    AD_LDEBUG(PATH_PLANNING) << "RRT Steering "
                             << "from " << traj_pt.position;
    auto inner_traj_pt = traj_pt;
    int min_index = -1;
    float min_distance = std::numeric_limits<float>::max();
    // find the closest node, steer from it
    for (unsigned int i = 0; i < nodes_.size(); i++) {
        cv::Point2f d_pos = inner_traj_pt.position - nodes_[i].position;
        float dist = cv::norm(d_pos);
        if (dist < min_distance) {
            min_index = i;
            min_distance = dist;
        }
    }
    AD_LDEBUG(PATH_PLANNING) << "RRT Steer Got min_distance " << min_distance;
    if (min_index == -1) {
        AD_LDEBUG(PATH_PLANNING) << "RRT Steer failed of not enough node";
        if_skip_the_point_ = true;
        auto pc_plan_end = std::chrono::high_resolution_clock::now();
        durations_[4] += (pc_plan_end - pc_plan_start);
        function_called_nums_[4] += 1;

        return AD_SUCCESS;
    }
    *steer_traj_point = traj_pt;
    if (min_distance < expand_distance_) {
        AD_LDEBUG(PATH_PLANNING)
            << "RRT Steer Using origin node, cuz it's close";
    } else {
        cv::Point2f direct = traj_pt.position - nodes_[min_index].position;
        (*steer_traj_point).position = nodes_[min_index].position;
        int max_round = 4;
        direct =
            (1.0 / cv::norm(direct) / max_round) * direct * expand_distance_;

        // (Obsolete)
        // // make sure nodes_ x direction in order maintains
        // float steer_x = nodes_[nodes_.size() - 1].position.x
        //                 - (*steer_traj_point).position.x;
        // float scale_steer = 1.0f;
        // if (steer_x > expand_distance_ * steer_far_scale_) {
        //     if (fabs(direct.x) > 1e-3) {
        //         scale_steer = (steer_x -
        //             expand_distance_ * steer_far_scale_) / direct.x;
        //     } else {
        //         scale_steer = (steer_x -
        //             expand_distance_ * steer_far_scale_) / 1e-3;
        //         if (direct.x < 0)
        //             scale_steer = -scale_steer;
        //     }
        // }

        // // scale_steer < 0 means the direction is not right
        // // fabs(scale_steer > 0 && scale_steer < 1) means
        // // the oridinate `direct` is enough for keeping the order of nodes_
        // if (scale_steer < 0 || scale_steer > 1)
        //     direct = direct * scale_steer;
        bool pass_check = true;
        AD_LTRACE(PATH_PLANNING)
            << "RRT Steer Testing " << steer_traj_point->position;
        RRTCheckCollision((*steer_traj_point).position + direct, &pass_check);
        int round = 1;
        while (pass_check && round < max_round + 1) {
            (*steer_traj_point).position += direct;
            AD_LTRACE(PATH_PLANNING)
                << "RRT Steer Testing " << steer_traj_point->position;
            RRTCheckCollision((*steer_traj_point).position + direct,
                              &pass_check);
            round += 1;
        }
        // This means we use the nodes_[min_index].position,
        // to avoid such condiction, simpily drop that point
        if (round == 1) {
            AD_LDEBUG(PATH_PLANNING)
                << "RRT Steer failed due to unchanged node position.";
            steer_traj_point->position.x = -1;
            auto pc_plan_end = std::chrono::high_resolution_clock::now();
            durations_[4] += (pc_plan_end - pc_plan_start);
            function_called_nums_[4] += 1;

            return AD_SUCCESS;
        }
    }

    AD_LDEBUG(PATH_PLANNING) << "RRT Steered "
                             << "to " << (*steer_traj_point).position;
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[4] += (pc_plan_end - pc_plan_start);
    function_called_nums_[4] += 1;

    return AD_SUCCESS;
}

void RRTCore::CheckCollision(const cv::Point2f &pt, bool *result) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    PlannerCore::CheckCollision(pt, result);
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[8] += (pc_plan_end - pc_plan_start);
    function_called_nums_[8] += 1;
}

void RRTCore::CheckRisk(const cv::Point2f &pt, char *result) {
    auto pc_plan_start = std::chrono::high_resolution_clock::now();
    PlannerCore::CheckRisk(pt, result);
    auto pc_plan_end = std::chrono::high_resolution_clock::now();
    durations_[8] += (pc_plan_end - pc_plan_start);
    function_called_nums_[8] += 1;
}

void RRTCore::SamplesPointSet() {
    // erase first point (start point)
    if (re_calc_samples.size() > 0)
        re_calc_samples.erase(re_calc_samples.begin());

    if (static_cast<int>(re_calc_samples.size()) >
        max_cap_iteration_ - max_iteration_) {
        std::srand(unsigned(std::time(0)));
        std::random_shuffle(re_calc_samples.begin(), re_calc_samples.end());
        re_calc_samples.erase(
            re_calc_samples.begin() + (max_cap_iteration_ - max_iteration_),
            re_calc_samples.end());
    }
    for (uint32_t i = 0; i < re_calc_samples.size(); i++) {
        float s, ds, dds, d, dd, ddd;
        TrajectoryPoint tp;
        tp.position = re_calc_samples[i].position;
        utils::CartesianToFrenet(tp, base_path_, &s, &ds, &dds, &d, &dd, &ddd);
        re_calc_samples[i].frenet_s = s;
        re_calc_samples[i].frenet_d = d;
    }
    for (int32_t i = 0; i < max_iteration_; i++) {
        RRTNode node;
        TrajectoryPoint new_traj_point;
        float base_path_point_distance = 0;
        bool pass_check_collision = false;
        bool if_sample_same = false;
        int same_sample_count = sample_same_bpp_maxtime_;
        int retry_count_collision = retry_count_collision_;
        while (!pass_check_collision && retry_count_collision-- > 0) {
            auto pc_sample_timer_start =
                std::chrono::high_resolution_clock::now();
            if (if_sample_same && same_sample_count > 0) {
                SampleSameBPPTrajPoint(&node, &base_path_point_distance);
                same_sample_count--;
            } else {
                SampleTrajPoint(&node, &base_path_point_distance);
                same_sample_count = sample_same_bpp_maxtime_;
                if_sample_same = false;
            }
            auto pc_sample_timer_end =
                std::chrono::high_resolution_clock::now();
            durations_[3] += (pc_sample_timer_end - pc_sample_timer_start);
            function_called_nums_[3] += 1;

            RRTCheckCollision(node.position, &pass_check_collision);
            if (!pass_check_collision) {
                std::uniform_real_distribution<float> p_distrubution(0, 1);
                auto p_generator =
                    std::bind(p_distrubution, std::ref(p_random_engine));
                float prob_same_bpp = p_generator();
                if (prob_same_bpp < this->sample_same_bpp_) {
                    if_sample_same = true;
                }
                continue;
            }
            float heading_bpp = 0.0;
            utils::GetHeadingAtS(base_path_, node.frenet_s, &heading_bpp);
            IsFreeWithTime(node.frenet_s, node.frenet_d, heading_bpp,
                           &pass_check_collision);
            if (!pass_check_collision) {
                std::uniform_real_distribution<float> p_distrubution(0, 1);
                auto p_generator =
                    std::bind(p_distrubution, std::ref(p_random_engine));
                float prob_same_bpp = p_generator();
                if (prob_same_bpp < this->sample_same_bpp_) {
                    if_sample_same = true;
                }
            }
        }
        if (retry_count_collision >= 0) {
            re_calc_samples.push_back(node);
        }
    }

    if (extra_root_sample_ > 0) {
        for (int32_t i = 0; i < extra_root_sample_; i++) {
            RRTNode node;
            TrajectoryPoint new_traj_point;
            // float base_path_point_distance = 0;
            bool pass_check_collision = false;
            int retry_count_collision = 5;
            while (!pass_check_collision && retry_count_collision-- > 0) {
                auto pc_sample_timer_start =
                    std::chrono::high_resolution_clock::now();

                AroundRootSample(&new_traj_point);

                auto pc_sample_timer_end =
                    std::chrono::high_resolution_clock::now();
                durations_[3] += (pc_sample_timer_end - pc_sample_timer_start);
                function_called_nums_[3] += 1;

                RRTCheckCollision(new_traj_point.position,
                                  &pass_check_collision);
                if (!pass_check_collision) {
                    continue;
                }
                float s, ds, dds, d, dd, ddd;
                utils::CartesianToFrenet(new_traj_point, base_path_, &s, &ds,
                                         &dds, &d, &dd, &ddd);
                node.frenet_s = s;
                node.frenet_d = d;
                node.base_path_cost = std::fabs(d);
                float heading_bpp = 0.0;
                utils::GetHeadingAtS(base_path_, node.frenet_s, &heading_bpp);
                IsFreeWithTime(node.frenet_s, node.frenet_d, heading_bpp,
                               &pass_check_collision);
            }
            if (retry_count_collision >= 0) {
                re_calc_samples.push_back(node);
            }
        }
    }

    if (key_extra_points_ > 0 && bpp_key_index_.size() > 0) {
        RRTNode node;
        TrajectoryPoint new_traj_point;
        float base_path_point_distance = 0;
        for (int32_t i = 0; i < key_extra_points_; i++) {
            bool pass_check_collision = false;
            int retry_count_collision = 5;
            while (!pass_check_collision && retry_count_collision-- > 0) {
                auto pc_sample_timer_start =
                    std::chrono::high_resolution_clock::now();

                SampleKeyTrajPoint(&node, &base_path_point_distance);
                auto pc_sample_timer_end =
                    std::chrono::high_resolution_clock::now();
                durations_[3] += (pc_sample_timer_end - pc_sample_timer_start);
                function_called_nums_[3] += 1;
                RRTCheckCollision(node.position, &pass_check_collision);

                if (!pass_check_collision) {
                    continue;
                }
                float heading_bpp = 0.0;
                utils::GetHeadingAtS(base_path_, node.frenet_s, &heading_bpp);
                IsFreeWithTime(node.frenet_s, node.frenet_d, heading_bpp,
                               &pass_check_collision);
            }
            if (retry_count_collision >= 0) {
                re_calc_samples.push_back(node);
            }
        }
    }
    std::sort(re_calc_samples.begin(), re_calc_samples.end(),
              [](const RRTNode &a, const RRTNode &b) {
                  return (a.frenet_s < b.frenet_s ||
                          (a.frenet_s == b.frenet_s &&
                           std::fabs(a.frenet_d) < std::fabs(b.frenet_d)));
              });
}

void RRTCore::SetRandomPointsForTest(const std::vector<cv::Point2f> &points,
                                     bool if_sort) {
    buildtree_test_random_points_.clear();
    for (auto point : points) {
        RRTNode sample_traj_point;
        sample_traj_point.position = point;
        sample_traj_point.direction.x = 1;
        sample_traj_point.direction.y = 0;
        float s, ds, dds, d, dd, ddd;
        TrajectoryPoint tp;
        tp.position = sample_traj_point.position;
        tp.direction = sample_traj_point.direction;
        utils::CartesianToFrenet(tp, base_path_, &s, &ds, &dds, &d, &dd, &ddd);
        sample_traj_point.frenet_s = s;
        sample_traj_point.frenet_d = d;
        sample_traj_point.base_path_cost = fabs(d);
        buildtree_test_random_points_.push_back(sample_traj_point);
    }
    if (if_sort) {
        std::sort(buildtree_test_random_points_.begin(),
                  buildtree_test_random_points_.end(),
                  [](const RRTNode &a, const RRTNode &b) {
                      return (a.frenet_s < b.frenet_s ||
                              (a.frenet_s == b.frenet_s &&
                               std::fabs(a.frenet_d) < std::fabs(b.frenet_d)));
                  });
    }
}

void RRTCore::SetTimestamp(std::vector<TrajectoryPoint> *out_path) {
    if (out_path == nullptr) {
        AD_LERROR(PATH_PLANNING) << "output path is nullptr";
        return;
    }
    if (out_path->empty()) {
        AD_LERROR(PATH_PLANNING) << "output path is empty.";
        return;
    }
    MicroClock t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    out_path->front().timestamp =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 1000);
    for (uint32_t i = 1; i < out_path->size(); ++i) {
        float delta_t =
            2.0 * insert_distance_ /
            (out_path->at(i - 1).velocity + out_path->at(i).velocity + 0.0001);
        out_path->at(i).timestamp = out_path->at(i - 1).timestamp +
                                    static_cast<uint64_t>(delta_t * 1e9);
    }
}

adStatus_t RRTCore::TruncatePath(std::vector<TrajectoryPoint> *out_path) {
    if (out_path == nullptr) {
        AD_LERROR(PATH_PLANNING) << "output path is nullptr";
        return AD_NULL_PTR;
    }
    out_path->clear();
    // 1. find closest point of cached path, truncate cached path
    TrajectoryPoint ego_tjp;
    ego_tjp.position =
        std::move(cv::Point2f(g_vehicle_state.x, g_vehicle_state.y));
    int closest_index = nn_tool_cached_path_.NearestNeighbor(ego_tjp);
    if (closest_index < 0 ||
        static_cast<uint32_t>(closest_index) >= cached_path_.size()) {
        AD_LERROR(PATH_PLANNING) << "cannot find clostest point in cached path";
        return AD_INVALID_PARAM;
    }
    *out_path =
        Trajectory(cached_path_.begin() + closest_index, cached_path_.end());
    // 2. clear some attrubute of trajectorypoint in output path
    for (uint32_t i = 0; i < out_path->size(); ++i) {
        out_path->at(i).velocity = 0.0;
        out_path->at(i).acceleration = 0.0;
        out_path->at(i).time_difference = 0.0;
        out_path->at(i).timestamp = 0;
        out_path->at(i).time_difference = 0.0;
        out_path->at(i).yaw_rate = 0.0;
    }
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
