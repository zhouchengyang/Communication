/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include <glog/logging.h>
#include <math.h>
#include <cmath>
#include <string>
#include <functional>
#include <vector>
#include "path_planning/polynomial_curve.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/schneidersmooth.hpp"

namespace senseAD {
namespace pp {

SchneiderSmoother::SchneiderSmoother() {
    this->error_ = 1.0;
    this->escale_ = 2.0;
}

void SchneiderSmoother::Init() {
    auto conf = g_pp_conf["rrt_setting"];
    this->error_ = conf["schneider_error"];
    this->escale_ = conf["schneider_escale"];
}

void SchneiderSmoother::Fit() {
    this->final_result.clear();
    this->final_result = internal_fit(0, this->data.size() - 1);
}

void SchneiderSmoother::SetData(const std::vector<TrajectoryPoint> &tps) {
    this->data = tps;
}

std::vector<TrajectoryPoint> SchneiderSmoother::SamplePoints(
    float insert_distance) {
    std::vector<TrajectoryPoint> tp;
    for (uint32_t ss = 0; ss < this->final_result.size(); ss++) {
        CubicBezierCurve cbc = final_result[ss];
        if (insert_distance < 1e-2) insert_distance = 1e-2;
        int32_t num = floor(cbc.norm / insert_distance) - 1;
        if (num <= 0) num = 1;
        float dt = 1.0 / num;
        float tt = 0;
        for (int32_t ii = 0; ii < num; ii++) {
            cv::Point2f pos, pos_d, pos_dd;
            PolynomialCurve xt = cbc.xt;
            PolynomialCurve yt = cbc.yt;
            PolynomialCurve dx_dt = xt.Differential();
            PolynomialCurve dy_dt = yt.Differential();
            PolynomialCurve dx2_d2t = dx_dt.Differential();
            PolynomialCurve dy2_d2t = dy_dt.Differential();
            pos.x = xt.Value(tt);
            pos.y = yt.Value(tt);
            pos_d.x = dx_dt.Value(tt);
            pos_d.y = dy_dt.Value(tt);
            pos_dd.x = dx2_d2t.Value(tt);
            pos_dd.y = dy2_d2t.Value(tt);

            float theta = 0;
            if (pos_d.x == 0) {
                if (pos_d.y > 0) {
                    theta = M_PI / 2;
                } else if (pos_d.y < 0) {
                    theta = -M_PI / 2;
                } else {
                    theta = 0;
                }
            } else {
                theta = atan(pos_d.y / pos_d.x);
            }
            float curvature =
                (pos_d.x * pos_dd.y - pos_dd.x * pos_d.y) /
                pow(pos_d.x * pos_d.x + pos_d.y * pos_d.y, 3.0 / 2.0);
            auto direction = pos_d;

            direction = direction * (1.0 / cv::norm(direction));

            TrajectoryPoint new_traj_point = TrajectoryPoint();

            new_traj_point.position = pos;
            new_traj_point.direction = direction;
            new_traj_point.velocity = 0.0;
            new_traj_point.theta = theta;
            new_traj_point.curvature = curvature;
            VLOG(4) << "[DEBUG] "
                    << "Schneider Smooth adding " << new_traj_point.position
                    << " " << new_traj_point.direction;
            tp.push_back(new_traj_point);
            tt = tt + dt;
        }
    }
    return tp;
}

std::vector<CubicBezierCurve> SchneiderSmoother::internal_fit(int32_t b_idx,
                                                              int32_t e_idx) {
    std::vector<CubicBezierCurve> ret;
    /* 2 points case */
    if (e_idx - b_idx == 1) {
        auto pt1 = this->data[b_idx].position;
        auto pt2 = this->data[e_idx].position;
        auto dist = cv::norm(pt2 - pt1) / 3.f;
        auto pta = pt1 + this->data[b_idx].direction * dist;
        auto ptb = pt2 - this->data[e_idx].direction * dist;

        CubicBezierCurve cbc;
        std::vector<float> ref_v_x;
        std::vector<float> ref_v_y;
        ref_v_x.push_back(pt1.x);
        ref_v_x.push_back(pta.x);
        ref_v_x.push_back(ptb.x);
        ref_v_x.push_back(pt2.x);
        ref_v_y.push_back(pt1.y);
        ref_v_y.push_back(pta.y);
        ref_v_y.push_back(ptb.y);
        ref_v_y.push_back(pt2.y);
        cbc.xt.SetReferenceValue(ref_v_x);
        cbc.yt.SetReferenceValue(ref_v_y);
        cbc.keypoint_t.push_back(0.0f);
        cbc.keypoint_t.push_back(1.0f);
        cbc.norm = cv::norm(pt2 - pt1);
        ret.push_back(cbc);
        return ret;
    }

    /* parameterize points and attempt to fit the curve */
    std::vector<float> tt;
    // assign t by distance
    for (int32_t ii = b_idx; ii <= e_idx; ii++) {
        if (ii == b_idx) {
            tt.push_back(0);
        } else {
            tt.push_back(tt[tt.size() - 1] +
                         cv::norm(this->data[ii].position -
                                  this->data[ii - 1].position));
        }
    }
    for (uint32_t ii = 0; ii < tt.size(); ii++) {
        tt[ii] /= tt[tt.size() - 1];
    }

    auto maxError = (std::max)(escale_ * error_, error_ * error_);
    int split = -1;
    bool parametersInOrder = true;

    /* 4 iterations */
    for (int i = 0; i <= 10; ++i) {
        CubicBezierCurve bezier = this->gen_cubic_bezier(b_idx, e_idx, tt);

        /* Find max deviation of points to fitted curve */
        auto max = this->maxinternal_error(bezier, b_idx, e_idx);
        if (max.first < error_ && parametersInOrder) {
            ret.push_back(bezier);
            return ret;
        }

        split = max.second;
        if (max.first >= maxError) break;

        parametersInOrder = this->internal_reparam(bezier, b_idx, e_idx, &tt);
        maxError = max.first;
    }

    /* fitting failed - split at max error and fit recursively */
    std::vector<CubicBezierCurve> cbc_left;
    std::vector<CubicBezierCurve> cbc_right;
    VLOG(3) << "SchneiderSmoother Split: [" << b_idx << "," << split << "]"
            << " [" << split << "," << e_idx << "]";
    cbc_left = this->internal_fit(b_idx, split);
    cbc_right = this->internal_fit(split, e_idx);
    ret.insert(ret.end(), cbc_left.begin(), cbc_left.end());
    ret.insert(ret.end(), cbc_right.begin(), cbc_right.end());
    return ret;
}

CubicBezierCurve SchneiderSmoother::gen_cubic_bezier(
    int32_t b_idx, int32_t e_idx, const std::vector<float> &tt) {
    auto epsilon = 1.0e-6;
    auto pt1 = this->data[b_idx].position;
    auto pt2 = this->data[e_idx].position;
    auto tan1 = this->data[b_idx].direction;
    auto tan2 = -this->data[e_idx].direction;

    /* C and X matrices */
    float C[2][2] = {{0, 0}, {0, 0}};
    float X[2] = {0, 0};

    for (auto i = 0, l = e_idx - b_idx + 1; i < l; ++i) {
        auto u = tt[i];
        auto t = 1 - u, b = 3 * u * t, b0 = t * t * t, b1 = b * t, b2 = b * u,
             b3 = u * u * u;
        auto a1 = tan1 * b1, a2 = tan2 * b2,
             tmp = this->data[b_idx + i].position - (pt1 * (b0 + b1)) -
                   (pt2 * (b2 + b3));
        C[0][0] += a1.ddot(a1);
        C[0][1] += a1.ddot(a2);
        C[1][0] = C[0][1];
        C[1][1] += a2.ddot(a2);
        X[0] += a1.ddot(tmp);
        X[1] += a2.ddot(tmp);
    }

    /* determinant of C and X */
    auto detC0C1 = C[0][0] * C[1][1] - C[1][0] * C[0][1];
    float alpha1, alpha2;
    if (std::fabs(detC0C1) > epsilon) {
        /* Kramer's rule */
        auto detC0X = C[0][0] * X[1] - C[1][0] * X[0];
        auto detXC1 = X[0] * C[1][1] - X[1] * C[0][1];

        /* alpha values */
        alpha1 = detXC1 / detC0C1;
        alpha2 = detC0X / detC0C1;
    } else {
        /* matrix is under-determined, assume alpha1=alpha2 */
        auto c0 = C[0][0] + C[0][1];
        auto c1 = C[1][0] + C[1][1];
        if (std::fabs(c0) > epsilon) {
            alpha1 = alpha2 = X[0] / c0;
        } else if (std::fabs(c1) > epsilon) {
            alpha1 = alpha2 = X[1] / c1;
        } else {
            alpha1 = alpha2 = 0;
        }
    }
    /* If alpha negative, use the Wu/Barsky heuristic
     * (if alpha is 0, you get coincident control points
     * that lead to divide by zero in any subsequent
     * findRoot() call. */
    auto segLength = cv::norm(pt2 - pt1);
    auto eps = epsilon * segLength;
    cv::Point2f handle1, handle2;
    bool if_fallback = false;
    if (alpha1 < eps || alpha2 < eps) {
        /* fall back on standard (probably inaccurate) formula,
         * and subdivide further if needed. */
        alpha1 = alpha2 = segLength / 3.f;
        if_fallback = true;
    } else {
        /* Check if the found control points are in the right order
         * when projected onto the line through pt1 and pt2. */
        auto line = pt2 - pt1;
        /* Control points 1 and 2 are positioned at alpha distance out
         * on the tangent vectors, left and right, respectively */
        handle1 = tan1 * alpha1;
        handle2 = tan2 * alpha2;
        if (handle1.ddot(line) - handle2.ddot(line) > segLength * segLength) {
            /* Fall back to the Wu/Barsky heuristic above */
            alpha1 = alpha2 = segLength / 3.f;
            if_fallback = true;
        }
    }

    auto pta = (if_fallback) ? (pt1 + tan1 * alpha1) : (pt1 + handle1);
    auto ptb = (if_fallback) ? (pt2 + tan2 * alpha2) : (pt2 + handle2);

    CubicBezierCurve cbc;
    std::vector<float> x_keypoint;
    std::vector<float> y_keypoint;
    x_keypoint.push_back(pt1.x);
    x_keypoint.push_back(pta.x);
    x_keypoint.push_back(ptb.x);
    x_keypoint.push_back(pt2.x);
    y_keypoint.push_back(pt1.y);
    y_keypoint.push_back(pta.y);
    y_keypoint.push_back(ptb.y);
    y_keypoint.push_back(pt2.y);
    cbc.xt.SetReferenceValue(x_keypoint);
    cbc.yt.SetReferenceValue(y_keypoint);
    cbc.norm = cv::norm(pt2 - pt1);
    cbc.keypoint_t = tt;
    return cbc;
}

std::pair<float, int32_t> SchneiderSmoother::maxinternal_error(
    CubicBezierCurve &func, int32_t b_idx, int32_t e_idx) {
    int32_t index = std::floor((e_idx - b_idx + 1) / 2);
    float maxDist = 0;
    for (int i = b_idx + 1; i < e_idx; ++i) {
        cv::Point2f P;
        P.x = func.xt.Value(func.keypoint_t[i - b_idx]);
        P.y = func.yt.Value(func.keypoint_t[i - b_idx]);
        auto v = P - this->data[i].position;
        auto dist = cv::norm(v);  // squared distance
        if (dist >= maxDist) {
            maxDist = dist;
            index = i;
        }
    }
    return {maxDist, index};
}

bool SchneiderSmoother::internal_reparam(CubicBezierCurve &func,
                                         int32_t b_idx,
                                         int32_t e_idx,
                                         std::vector<float> *tt) {
    for (int i = b_idx; i <= e_idx; ++i) {
        (*tt)[i - b_idx] = this->update_t(func, i, (*tt)[i - b_idx]);
    }

    for (int i = 1, l = tt->size(); i < l; ++i) {
        if ((*tt)[i] <= (*tt)[i - 1]) return false;
    }
    return true;
}

float SchneiderSmoother::update_t(CubicBezierCurve &func,
                                  int32_t idx,
                                  float t) {
    PolynomialCurve dx_dt = func.xt.Differential();
    PolynomialCurve dx2_d2t = dx_dt.Differential();
    PolynomialCurve dy_dt = func.yt.Differential();
    PolynomialCurve dy2_d2t = dy_dt.Differential();

    /* compute Q(u), Q'(u) and Q''(u) */
    cv::Point2f pt, pt1, pt2;
    pt.x = func.xt.Value(t);
    pt.y = func.yt.Value(t);
    pt1.x = dx_dt.Value(t);
    pt1.y = dy_dt.Value(t);
    pt2.x = dx2_d2t.Value(t);
    pt2.y = dy2_d2t.Value(t);
    auto diff = pt - this->data[idx].position;
    // sum of dot products
    auto df = pt1.ddot(pt1) + diff.ddot(pt2);

    /* f(u) / f'(u) */
    if (std::fabs(df) < 1.0e-6) return t;

    /* u = u - f(u)/f'(u) */
    return t - (diff.ddot(pt1)) / df;
}

}  // namespace pp
}  // namespace senseAD
