/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include "path_planning/longi_lat_planner/qp_optimizer.hpp"

namespace senseAD {
namespace pp {

QPOptimizer::QPOptimizer() {
    auto core_conf = g_pp_conf["longi_lat_core"];
    auto dqq_setting = g_pp_conf["dqq_setting"];
    debug_print_ = dqq_setting["debug_print"];
}

QPOptimizer::~QPOptimizer() {
    if (lb_ != nullptr) {
        delete[] lb_;
    }
    if (ub_ != nullptr) {
        delete[] ub_;
    }
    if (lbA_ != nullptr) {
        delete[] lbA_;
    }
    if (ubA_ != nullptr) {
        delete[] ubA_;
    }
    if (A_ != nullptr) {
        delete[] A_;
    }
    if (H_ != nullptr) {
        delete[] H_;
    }
    if (g_ != nullptr) {
        delete[] g_;
    }
}

void QPOptimizer::SetConfig(const QPConfig& qp_config) {
    qp_config_ = qp_config;
}

void QPOptimizer::GenFirstDerivative() {
    /*
     * vel = A x
     * v0 = (x1 - x0) / delta
     */
    first_derivative_ = -1.0 * Eigen::MatrixXd::Identity(t_dim_ - 1, t_dim_);
    // it seems unnecessary
    first_derivative_(t_dim_ - 2, t_dim_ - 1) = 0.0;
    first_derivative_.block(0, 1, t_dim_ - 1, t_dim_ - 1) +=
        Eigen::MatrixXd::Identity(t_dim_ - 1, t_dim_ - 1);
}
void QPOptimizer::GenSecondDerivative() {
    /*
     * a = A x
     * a = (x2 - 2 * x1 + x0) / (delta * delta)
     * a = (x0 - 2 * x1 + x2) / (delta * delta)
     * ignore delta
     */
    second_derivative_ = Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_);
    second_derivative_.block(0, 1, t_dim_ - 2, t_dim_ - 2) +=
        -2.0 * Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    second_derivative_.block(0, 2, t_dim_ - 2, t_dim_ - 2) +=
        Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
}

void QPOptimizer::GenThirdDerivative() {
    /*
     * j = A x
     * j = (x3 - 3 * x2 + 3 * x1 -  x0) / (delta * delta * delta)
     * j = (-x0 + 3 * x1 - 3 * x2 + x3) / (delta * delta * delta)
     * ignore delta
     */
    third_derivative_ = -1.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_);
    third_derivative_.block(0, 1, t_dim_ - 3, t_dim_ - 3) +=
        3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    third_derivative_.block(0, 2, t_dim_ - 3, t_dim_ - 3) +=
        -3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    third_derivative_.block(0, 3, t_dim_ - 3, t_dim_ - 3) +=
        Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
}

void QPOptimizer::GenSumFirstDerivative() {
    /*
     * sum = transpose(x) * H * x
     * using forward differential method
     * sum = x0 ^ 2 + x1 ^ 2 - 2x0x1
     */
    Eigen::MatrixXd H1 = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H1(t_dim_ - 1, t_dim_ - 1) = 0.0;
    Eigen::MatrixXd H2 = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H2(0, 0) = 0.0;
    Eigen::MatrixXd H3 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H3.block(1, 0, t_dim_ - 1, t_dim_ - 1) -=
        Eigen::MatrixXd::Identity(t_dim_ - 1, t_dim_ - 1);
    H3.block(0, 1, t_dim_ - 1, t_dim_ - 1) -=
        Eigen::MatrixXd::Identity(t_dim_ - 1, t_dim_ - 1);
    sum_first_derivative_ =
        1.0f / (std::pow(t_resolution_, 2.0)) * (H1 + H2 + H3);
}

void QPOptimizer::GenSumSecondDerivative() {
    /*
     * sum = transpose(x) * H * x
     * sum = x0 ^ 2 + 4 x1^2 + x2^2 - 4x0x1 + 2x0x2 - 4x1x2
     */
    Eigen::MatrixXd H1, H2, H3, H4, H5, H6;
    H1 = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H1(t_dim_ - 1, t_dim_ - 1) = 0.0;
    H1(t_dim_ - 2, t_dim_ - 2) = 0.0;
    H2 = 4.0 * Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H2(0, 0) = 0.0;
    H2(t_dim_ - 1, t_dim_ - 1) = 0.0;
    H3 = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H3(0, 0) = 0.0;
    H3(1, 1) = 0.0;
    H4 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H4.block(0, 1, t_dim_ - 2, t_dim_ - 2) -=
        2.0 * Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    H4.block(1, 0, t_dim_ - 2, t_dim_ - 2) -=
        2.0 * Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    H5 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H5.block(0, 2, t_dim_ - 2, t_dim_ - 2) +=
        Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    H5.block(2, 0, t_dim_ - 2, t_dim_ - 2) +=
        Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    H6 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H6.block(1, 2, t_dim_ - 2, t_dim_ - 2) -=
        2.0 * Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    H6.block(2, 1, t_dim_ - 2, t_dim_ - 2) -=
        2.0 * Eigen::MatrixXd::Identity(t_dim_ - 2, t_dim_ - 2);
    sum_second_derivative_ =
        1.0f / (std::pow(t_resolution_, 4.0)) * (H1 + H2 + H3 + H4 + H5 + H6);
}

void QPOptimizer::GenSumThirdDerivative() {
    /*
     * sum = transpose(x) * H * x
     * sum = x0 ^ 2 + 9 x1 ^ 2 + 9 x2 ^ 2 + x3 ^ 2 - 6 * x0x1 + 6 x0x2
     *       - 2 x0x3 - 18 x1x2 + 6 x1x3 - 6 x2x3
     */
    Eigen::MatrixXd H1, H2, H3, H4, H5, H6, H7, H8, H9, H10;
    H1 = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H1(t_dim_ - 1, t_dim_ - 1) = 0.0;
    H1(t_dim_ - 2, t_dim_ - 2) = 0.0;
    H1(t_dim_ - 3, t_dim_ - 3) = 0.0;
    H2 = 9.0 * Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H2(0, 0) = 0.0;
    H2(t_dim_ - 2, t_dim_ - 2) = 0.0;
    H2(t_dim_ - 1, t_dim_ - 1) = 0.0;
    H3 = 9.0 * Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H3(0, 0) = 0.0;
    H3(1, 1) = 0.0;
    H3(t_dim_ - 1, t_dim_ - 1) = 0.0;
    H4 = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    H4(0, 0) = 0.0;
    H4(1, 1) = 0.0;
    H4(2, 2) = 0.0;
    H5 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H5.block(0, 1, t_dim_ - 3, t_dim_ - 3) +=
        -3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H5.block(1, 0, t_dim_ - 3, t_dim_ - 3) +=
        -3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H6 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H6.block(0, 2, t_dim_ - 3, t_dim_ - 3) +=
        3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H6.block(2, 0, t_dim_ - 3, t_dim_ - 3) +=
        3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H7 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H7.block(0, 3, t_dim_ - 3, t_dim_ - 3) +=
        -1.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H7.block(3, 0, t_dim_ - 3, t_dim_ - 3) +=
        -1.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H8 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H8.block(1, 2, t_dim_ - 3, t_dim_ - 3) +=
        -9.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H8.block(2, 1, t_dim_ - 3, t_dim_ - 3) +=
        -9.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H9 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H9.block(1, 3, t_dim_ - 3, t_dim_ - 3) +=
        3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H9.block(3, 1, t_dim_ - 3, t_dim_ - 3) +=
        3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H10 = Eigen::MatrixXd::Zero(t_dim_, t_dim_);
    H10.block(2, 3, t_dim_ - 3, t_dim_ - 3) +=
        -3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    H10.block(3, 2, t_dim_ - 3, t_dim_ - 3) +=
        -3.0 * Eigen::MatrixXd::Identity(t_dim_ - 3, t_dim_ - 3);
    sum_third_derivative_ = 1.0f / (std::pow(t_resolution_, 6.0)) *
                            (H1 + H2 + H3 + H4 + H5 + H6 + H7 + H8 + H9 + H10);
}

adStatus_t QPOptimizer::Update(const std::vector<double>& last_path,
                               const std::vector<double>& ref_seq,
                               const std::vector<double>& lower_bound,
                               const std::vector<double>& upper_bound,
                               const int num_look_back,
                               const QPConfig& qp_config,
                               const QPConfig& relax_qp_config) {
    last_seq_ = last_path;
    ref_ = ref_seq;
    lower_bound_ = lower_bound;
    upper_bound_ = upper_bound;
    num_look_back_ = num_look_back;
    qp_config_ = qp_config;
    relax_qp_config_ = relax_qp_config;
    // check feasiblily before optimization and set dimension
    CheckConstraints();
    if (t_dim_ < 40) {
        AD_LERROR(QPOptimizer) << "dim " << t_dim_;
    }
    const uint32_t min_qp_dim_ = 10;
    if (t_dim_ < min_qp_dim_) {
        AD_LINFO(QPOptimizer) << "qp dimension " << t_dim_ << " is small";
        return AD_INVALID_PARAM;
    }
    return AD_SUCCESS;
}

adStatus_t QPOptimizer::SetupMatrix() {
    if (lb_ != nullptr) {
        delete[] lb_;
    }
    lb_ = new double[t_dim_];
    std::memset(lb_, 0, t_dim_ * sizeof(double));
    if (ub_ != nullptr) {
        delete[] ub_;
    }
    ub_ = new double[t_dim_];
    std::memset(ub_, 0, t_dim_ * sizeof(double));
    if (lbA_ != nullptr) {
        delete[] lbA_;
    }
    A_dim_ = t_dim_ - 1 + t_dim_ - 2 + t_dim_ - 3;
    lbA_ = new double[A_dim_];
    std::memset(lbA_, 0, A_dim_ * sizeof(double));
    if (ubA_ != nullptr) {
        delete[] ubA_;
    }
    ubA_ = new double[A_dim_];
    std::memset(ubA_, 0, A_dim_ * sizeof(double));
    if (A_ != nullptr) {
        delete[] A_;
    }
    A_ = new double[A_dim_ * t_dim_];
    std::memset(A_, 0, A_dim_ * t_dim_ * sizeof(double));
    if (H_ != nullptr) {
        delete[] H_;
    }
    H_ = new double[t_dim_ * t_dim_];
    std::memset(H_, 0, t_dim_ * t_dim_ * sizeof(double));
    if (g_ != nullptr) {
        delete[] g_;
    }
    g_ = new double[t_dim_];
    std::memset(g_, 0, t_dim_ * sizeof(double));
    // 0. generate matrix
    // TODO(Shengfa) make it static?
    GenFirstDerivative();
    GenSecondDerivative();
    GenThirdDerivative();
    GenSumFirstDerivative();
    GenSumSecondDerivative();
    GenSumThirdDerivative();
    // 1. set up bound
    for (uint32_t i = 0; i < t_dim_; ++i) {
        lb_[i] = std::max(qp_config_.lower_limit(), lower_bound_.at(i));
        ub_[i] = std::min(qp_config_.upper_limit(), upper_bound_.at(i));
    }
    // 2. set up bound of derivatives
    // 2.1 set up bound of first derivative
    for (uint32_t i = 0; i < t_dim_ - 1; ++i) {
        lbA_[i] = qp_config_.lower_first_deriv_limit() * t_resolution_;
        ubA_[i] = qp_config_.upper_first_deriv_limit() * t_resolution_;
    }
    // 2.2 set up bound of second derivative
    // relax constraints at num_look_back
    for (uint32_t i = t_dim_ - 1; i < 2 * t_dim_ - 3; ++i) {
        if (static_cast<int>(i) - (t_dim_ - 1) < num_look_back_) {
            lbA_[i] = -100.0;
            ubA_[i] = 100.0;
        } else {
            lbA_[i] = qp_config_.lower_second_deriv_limit() * t_resolution_ *
                      t_resolution_;
            ubA_[i] = qp_config_.upper_second_deriv_limit() * t_resolution_ *
                      t_resolution_;
        }
    }
    // 2.3 set up bound of third derivative
    for (uint32_t i = 2 * t_dim_ - 3; i < 3 * t_dim_ - 6; ++i) {
        if (static_cast<int>(i) - (2.0 * t_dim_ - 3) < num_look_back_) {
            lbA_[i] = -100.0;
            ubA_[i] = 100.0;
        } else {
            lbA_[i] = qp_config_.lower_third_deriv_limit() * t_resolution_ *
                      t_resolution_ * t_resolution_;
            ubA_[i] = qp_config_.upper_third_deriv_limit() * t_resolution_ *
                      t_resolution_ * t_resolution_;
        }
    }
    // 3. set up ref
    Eigen::MatrixXd H_align = Eigen::MatrixXd::Identity(t_dim_, t_dim_);
    for (uint32_t i = 0; i < t_dim_; ++i) {
        g_[i] = -2.0 * qp_config_.w_ref() * ref_.at(i);

        if (i < last_seq_.size()) {
            // set weight of deviation from last trajectory as exponential
            // decay
            double w_align =
                qp_config_.w_start() * std::exp(-1.0 * qp_config_.decay_rate() *
                                                static_cast<double>(i));
            g_[i] += -2.0 * w_align * last_seq_.at(i);
            H_align(i, i) = w_align;
        } else {
            H_align(i, i) = 0.0;
        }
    }
    // 4. set up A matrix
    Eigen::MatrixXd derivs(first_derivative_.rows() +
                               second_derivative_.rows() +
                               third_derivative_.rows(),
                           first_derivative_.cols());
    derivs << first_derivative_, second_derivative_, third_derivative_;
    uint32_t index = 0;
    for (uint32_t r = 0; r < derivs.rows(); ++r) {
        for (uint32_t c = 0; c < derivs.cols(); ++c) {
            A_[index++] = derivs(r, c);
        }
    }
    // 5. set up H matrix
    Eigen::MatrixXd H_eigen =
        2.0 * qp_config_.w_ref() * Eigen::MatrixXd::Identity(t_dim_, t_dim_) +
        2.0 * qp_config_.w_first_order() * sum_first_derivative_ +
        2.0 * qp_config_.w_second_order() * sum_second_derivative_ +
        2.0 * qp_config_.w_third_order() * sum_third_derivative_ +
        2.0 * H_align;
    for (uint32_t r = 0; r < H_eigen.rows(); ++r) {
        for (uint32_t c = 0; c < H_eigen.cols(); ++c) {
            uint32_t index = r * t_dim_ + c;
            H_[index] = H_eigen(r, c);
        }
    }

    return AD_SUCCESS;
}

void QPOptimizer::CheckConstraints() {
    t_dim_ = ref_.size();
    double min_x = -1000.0, max_x = 1000.0;
    for (uint32_t i = 0; i < lower_bound_.size(); ++i) {
        // 1. check constraints of lb and ub
        if (lower_bound_.at(i) > upper_bound_.at(i)) {
            AD_LINFO(QPOptimizer) << i << "th is unfeasible"
                                  << "lb is " << lower_bound_.at(i)
                                  << ", ub is " << upper_bound_.at(i);
            if (i > 0) {
                t_dim_ = std::min(i - 1, t_dim_);
            } else {
                t_dim_ = 0;
            }
            break;
        }
        // 2. check consitency of lb and lbA
        if (i > 0) {
            min_x = std::max(min_x, lower_bound_.at(i - 1)) +
                    qp_config_.lower_first_deriv_limit() * t_resolution_;
            max_x = std::min(max_x, upper_bound_.at(i - 1)) +
                    qp_config_.upper_first_deriv_limit() * t_resolution_;
            if (lower_bound_.at(i) > max_x || upper_bound_.at(i) < min_x) {
                AD_LINFO(QPOptimizer) << i << "th is inconsitent "
                                      << "lb is " << lower_bound_.at(i)
                                      << ", ub is " << upper_bound_.at(i)
                                      << ", max_x is " << max_x << ", min_x is "
                                      << min_x;
                t_dim_ = std::min(t_dim_, i - 1);
                break;
            }
        }
    }
}

adStatus_t QPOptimizer::Solve(std::vector<double>* out_path) {
    if (out_path == nullptr) {
        AD_LERROR(QPOptimizer) << "out_path is nullptr";
        return AD_NULL_PTR;
    }
    if (SolveCore(out_path) == AD_SUCCESS) {
        return AD_SUCCESS;
    } else {
        RelaxConstraints();
        if (SolveCore(out_path) == AD_SUCCESS) {
            AD_LINFO(QPOptimizer)
                << "qp solve success with relaxing constriants";
            PrintDebugInfo();
            return AD_SUCCESS;
        } else {
            AD_LERROR(QPOptimizer)
                << "qp solve failed even with relaxing constriants";
            return AD_INVALID_PARAM;
        }
    }
}

adStatus_t QPOptimizer::SolveCore(std::vector<double>* out_path) {
    if (out_path == nullptr) {
        AD_LERROR(QPOptimizer) << "out_path is nullptr";
        return AD_NULL_PTR;
    }
    solution_.clear();
    out_path->clear();
    out_path->reserve(t_dim_);
    // 1. setup matrix
    if (SetupMatrix() != AD_SUCCESS) {
        AD_LERROR(QPOptimizer) << "setup matirix failed.";
        return AD_INVALID_PARAM;
    }
    // 2. qradratic programming with positive definite Hessian matrix
    double cputime = 1.0;
    int nWSR = 1000;
    qpOASES::SQProblem qpproblem(t_dim_, A_dim_, qpOASES::HST_POSDEF);
    qpproblem.setPrintLevel(qpOASES::PL_NONE);
    qpOASES::returnValue status;
    status = qpproblem.init(H_, g_, A_, lb_, ub_, lbA_, ubA_, nWSR, &cputime);
    if (status != qpOASES::SUCCESSFUL_RETURN) {
        if (status == qpOASES::RET_MAX_NWSR_REACHED) {
            AD_LERROR(QPOptimizer)
                << "qpOASES solver failed due to reached max iterations";
        } else {
            AD_LERROR(QPOptimizer) << "qpOASES solver failed due to "
                                      "infeasibility or other internal reasons";
        }
        int simple_status = qpOASES::getSimpleStatus(status);
        switch (simple_status) {
            case 0:
                AD_LERROR(QPOptimizer) << "qp was solved";
                break;
            case 1:
                AD_LERROR(QPOptimizer) << "qp could not be solved within given "
                                          "number of iterrations";
                break;
            case -1:
                AD_LERROR(QPOptimizer)
                    << "qp could not be solved due to internal error";
                break;
            case -2:
                AD_LERROR(QPOptimizer)
                    << "qp is infeasible and thus could not be solved";
                break;
            case -3:
                AD_LERROR(QPOptimizer)
                    << "qp is unbounded and thus could not be solved";
                break;
            default:
                AD_LERROR(QPOptimizer) << "it just failed";
        }
        PrintQP();
        return AD_INVALID_PARAM;
    }
    double x_opt[t_dim_];  // NOLINT
    qpproblem.getPrimalSolution(x_opt);
    for (uint32_t i = 0; i < t_dim_; ++i) {
        out_path->emplace_back(x_opt[i]);
        solution_.emplace_back(x_opt[i]);
    }

    PrintQP();
    return AD_SUCCESS;
}

void QPOptimizer::PrintQP() const {
    if (debug_print_ == 0) {
        return;
    }
    std::stringstream ss_H, ss_g, ss_A, ss_lb, ss_ub, ss_lbA, ss_ubA, ss_qp,
        ss_ref, ss_last;
    for (uint32_t r = 0; r < t_dim_; ++r) {
        for (uint32_t c = 0; c < t_dim_; ++c) {
            uint32_t index = r * t_dim_ + c;
            ss_H << H_[index] << ",";
        }
        ss_H << std::endl;
    }
    for (uint32_t r = 0; r < t_dim_; ++r) {
        for (uint32_t c = 0; c < 1; ++c) {
            uint32_t index = r * 1 + c;
            ss_g << g_[index] << ",";
        }
        ss_g << std::endl;
    }
    for (uint32_t r = 0; r < A_dim_; ++r) {
        for (uint32_t c = 0; c < t_dim_; ++c) {
            uint32_t index = r * t_dim_ + c;
            ss_A << A_[index] << ",";
        }
        ss_A << std::endl;
    }
    for (uint32_t r = 0; r < t_dim_; ++r) {
        for (uint32_t c = 0; c < 1; ++c) {
            uint32_t index = r * 1 + c;
            ss_lb << lb_[index] << ",";
        }
        ss_lb << std::endl;
    }
    for (uint32_t r = 0; r < t_dim_; ++r) {
        for (uint32_t c = 0; c < 1; ++c) {
            uint32_t index = r * 1 + c;
            ss_ub << ub_[index] << ",";
        }
        ss_ub << std::endl;
    }
    for (uint32_t r = 0; r < A_dim_; ++r) {
        for (uint32_t c = 0; c < 1; ++c) {
            uint32_t index = r * 1 + c;
            ss_lbA << lbA_[index] << ",";
        }
        ss_lbA << std::endl;
    }
    for (uint32_t r = 0; r < A_dim_; ++r) {
        for (uint32_t c = 0; c < 1; ++c) {
            uint32_t index = r * 1 + c;
            ss_ubA << ubA_[index] << ",";
        }
        ss_ubA << std::endl;
    }
    for (uint32_t i = 0; i < solution_.size(); ++i) {
        ss_qp << solution_[i] << "," << std::endl;
    }
    for (uint32_t i = 0; i < ref_.size(); ++i) {
        ss_ref << ref_[i] << "," << std::endl;
    }
    for (uint32_t i = 0; i < last_seq_.size(); ++i) {
        ss_last << last_seq_[i] << "," << std::endl;
    }
    std::string data_path = "/tmp/today-logs/" + utils::GetTimestampString() +
                            "qp_optimization.txt";
    std::ofstream outfile;
    outfile.open(data_path, std::ofstream::trunc);
    outfile << "H" << std::endl;
    outfile << ss_H.str();
    outfile << "g" << std::endl;
    outfile << ss_g.str();
    outfile << "lb" << std::endl;
    outfile << ss_lb.str();
    outfile << "ub" << std::endl;
    outfile << ss_ub.str();
    outfile << "A" << std::endl;
    outfile << ss_A.str();
    outfile << "lbA" << std::endl;
    outfile << ss_lbA.str();
    outfile << "ubA" << std::endl;
    outfile << ss_ubA.str();
    outfile << "qp_solution" << std::endl;
    outfile << ss_qp.str();
    outfile << "ref" << std::endl;
    outfile << ss_ref.str();
    outfile << "last" << std::endl;
    outfile << ss_last.str();
    outfile.close();
}

void QPOptimizer::PrintDebugInfo() const {
    Matrix derivs(first_derivative_.rows() + second_derivative_.rows() +
                      third_derivative_.rows(),
                  first_derivative_.cols());
    derivs << first_derivative_, second_derivative_, third_derivative_;
    Vector solu = Vector::Map(&solution_.front(), solution_.size());
    Vector constriants = derivs * solu;
    Matrix debug_info(
        constriants.rows(),
        constriants.cols() + lbA_failed_.cols() + ubA_failed_.cols());
    debug_info << lbA_failed_, constriants, ubA_failed_;
    std::string data_path =
        "/tmp/today-logs/" + utils::GetTimestampString() + "qp_fail_debug.txt";
    std::ofstream outfile;
    outfile.open(data_path, std::ofstream::trunc);
    outfile << debug_info;
    outfile.close();
}

void QPOptimizer::RelaxConstraints() {
    // save crime scene, hope these can be remove in the future
    lbA_failed_ = Vector::Map(lbA_, A_dim_);
    ubA_failed_ = Vector::Map(ubA_, A_dim_);
    // relax constriants
    qp_config_ = relax_qp_config_;
}

}  // namespace pp
}  // namespace senseAD
