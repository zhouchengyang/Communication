/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include "path_planning/longi_lat_planner/parser.hpp"
#include <algorithm>

namespace senseAD {
namespace pp {

adStatus_t Parser::Init() {
    // get parameters
    auto core_conf = g_pp_conf["longi_lat_core"];
    s_horizon_ = core_conf["s_horizon"];
    t_horizon_ = core_conf["t_horizon"];
    s_resolution_ = core_conf["t_resolution"];
    t_resolution_ = core_conf["t_resolution"];
    auto dqq_setting = g_pp_conf["dqq_setting"];
    debug_print_ = dqq_setting["debug_print"];
    object_map_.Init();
    return AD_SUCCESS;
}

adStatus_t Parser::Update(
    const senseAD::roadStructure::RoadStructure<cv::Point2f>& rs,
    const PredictionObjectArray& poa,
    const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
    const PlanningScenario planning_scenario,
    const bool lane_change_activated) {
    rs_ = rs;
    poa_ = poa;
    frenet_system_ = frenet_system;
    scenario_ = planning_scenario;

    // output predict reuslt for debug

    if (debug_print_ == 1) {
        std::string data_path = "/tmp/today-logs/" +
                                utils::GetTimestampString() +
                                "predict_result.json";
        common::utils::ConfigurationReader::WriteJSON(data_path, poa_);
    }

    // 2. refresh preditct map and construct sbound intervals
    if (scenario_ == PlanningScenario::LANE_KEEPING) {
        object_map_.Update(poa_, frenet_system_, t_horizon_, t_horizon_,
                           ChangeDirection::NO_CHANGE, lane_change_activated);
    } else if (scenario_ == PlanningScenario::LANE_CHANGE) {
    }
    object_map_.Refresh();
    object_map_.FindNBO();
    object_map_.ConstructSIntervals();
    AD_LINFO(PARSER) << "parser successfully update";
    return AD_SUCCESS;
}

adStatus_t Parser::GetLongiBoundAndRef(const std::vector<double>& t_seq,
                                       const double curr_s,
                                       const double curr_speed,
                                       const double curr_acc,
                                       const double target_s,
                                       const double target_speed,
                                       std::vector<double>* lower_bound,
                                       std::vector<double>* upper_bound,
                                       std::vector<double>* ref) {
    return object_map_.GetLongiBoundAndRef(t_seq, curr_s, curr_speed, curr_acc,
                                           target_s, target_speed, lower_bound,
                                           upper_bound, ref);
}

adStatus_t Parser::GetLateralBoundAndRef(const std::vector<double>& t_seq,
                                         const std::vector<double>& s_seq,
                                         std::vector<double>* lower_bound,
                                         std::vector<double>* upper_bound,
                                         std::vector<double>* ref) {
    return object_map_.GetLateralBoundAndRef(t_seq, s_seq, lower_bound,
                                             upper_bound, ref);
}

const std::unordered_map<int, Tag>& Parser::GetObstacleTag(
    const std::vector<double>& longi_search_result) {
    return object_map_.GetObstacleTag(longi_search_result);
}

double Parser::GetObstacleCost(const double s,
                               const double t,
                               const double w_follow_to_near,
                               const double w_follow_to_far) const {
    return object_map_.GetObstacleCost(s, t, w_follow_to_near, w_follow_to_far);
}

const void Parser::CheckCollision(
    const std::vector<TrajectoryPoint>& traj_to_test,
    const uint32_t check_range,
    uint32_t* collided_index) const {
    if (collided_index == nullptr) {
        AD_LERROR(PARSER) << "collided_index pointer is null";
        return;
    }
    *collided_index = traj_to_test.size();
    if (traj_to_test.empty()) {
        return;
    }
    // skip first traj_point
    const double longi_safe_dist_collision_check_ = 1.0;
    const double lateral_safe_dist_collision_check_ = 0.2;
    double time_after_first_point =
        traj_to_test.front().sum_distance / traj_to_test.front().velocity;
    for (uint32_t i = 1;
         i < std::min(check_range, static_cast<uint32_t>(traj_to_test.size()));
         ++i) {
        double after_time = time_after_first_point +
                            static_cast<double>(traj_to_test.at(i).timestamp -
                                                traj_to_test.at(0).timestamp) /
                                1.0e9;
        bool is_pass = true;
        object_map_.is_free(traj_to_test.at(i), after_time,
                            longi_safe_dist_collision_check_,
                            lateral_safe_dist_collision_check_, &is_pass);
        if (is_pass == false) {
            *collided_index = i;
            return;
        }
    }
}

}  // namespace pp
}  // namespace senseAD
