/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include "path_planning/longi_lat_planner/object_map.hpp"

namespace senseAD {
namespace pp {

adStatus_t ObjectMap::Init() {
    // get parameters
    auto core_conf = g_pp_conf["longi_lat_core"];
    s_horizon_ = core_conf["s_horizon"];
    t_horizon_ = core_conf["t_horizon"];
    s_resolution_ = core_conf["s_resolution"];
    t_resolution_ = core_conf["t_resolution"];
    auto dqq_setting = g_pp_conf["dqq_setting"];
    debug_print_ = dqq_setting["debug_print"];
    longi_overlap_threshold_ = dqq_setting["longi_overlap_threshold"];
    nbo_counter_threshold_ = dqq_setting["nbo_counter_threshold"];
    bo_counter_threshold_ = dqq_setting["bo_counter_threshold"];
    lane_width_ = dqq_setting["lane_width"];
    ref_acc_ = dqq_setting["ref_acc"];
    ref_deacc_ = dqq_setting["ref_deacc"];
    ref_jerk_ = dqq_setting["ref_jerk"];
    change_period_ = dqq_setting["change_period"];
    follow_time_ = dqq_setting["follow_time"];
    longi_safe_distance_ = dqq_setting["longi_safe_distance"];
    longi_dp_safe_distance_ = dqq_setting["longi_dp_safe_distance"];
    longi_stop_distance_ = dqq_setting["longi_stop_distance"];
    time_to_collision_ = dqq_setting["time_to_collision"];
    max_deacc_vehicle_ = dqq_setting["max_deacc_vehicle"];
    lateral_safe_distance_ = dqq_setting["lateral_safe_distance"];

    obs_tag_.clear();
    num_t_ = static_cast<uint32_t>(t_horizon_ / t_resolution_ + 1);
    num_s_ = static_cast<uint32_t>(s_horizon_ / s_resolution_ + 1);
    s_intervals_.reserve(num_t_);
    PredictMap::Init();
    return AD_SUCCESS;
}

adStatus_t ObjectMap::Update(
    const PredictionObjectArray& poa,
    const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
    const double change_start_time,
    const double change_end_time,
    const ChangeDirection change_direction,
    const bool lane_change_activated) {
    PredictMap::Update(poa, frenet_system, lane_change_activated);
    change_start_time_ = change_start_time;
    change_end_time_ = change_end_time;
    // TODO(Shengfa) add assert 0 < change_start_time_ <= change_end_time <= t
    change_direction_ = change_direction;
    // clear s_interval and nbo_obj
    s_intervals_.clear();
    NBO_obj_ = 0;
    return AD_SUCCESS;
}

adStatus_t ObjectMap::ConstructSIntervals() {
    // t index should start from 1 instead of 0
    const uint32_t s_index_start_ =
        0.5 * g_vehicle_param.length / s_resolution_;
    for (uint32_t t_index = 0; t_index < num_t_; ++t_index) {
        std::vector<SBound<decltype(obj_type_)>> s_bounds;
        // 1. find d_index based on change time and direction
        double d_start = -0.5 * lane_width_;
        double d_end = 0.5 * lane_width_;
        double t = static_cast<double>(t_index * t_resolution_);
        if (change_direction_ == ChangeDirection::CHANGE_LEFT) {
            if (t > change_start_time_ && t < change_end_time_) {
                // ego lane and target lane
                d_start = -0.5 * lane_width_;
                d_end = 1.5 * lane_width_;
            } else if (t >= change_end_time_) {
                // only target lane
                d_start = 0.5 * lane_width_;
                d_end = 1.5 * lane_width_;
            }
        } else if (change_direction_ == ChangeDirection::CHANGE_RIGHT) {
            if (t > change_start_time_ && t < change_end_time_) {
                // ego lane and target lane
                d_start = -1.5 * lane_width_;
                d_end = 0.5 * lane_width_;
            } else if (t >= change_end_time_) {
                // only target lane
                d_start = -1.5 * lane_width_;
                d_end = -0.5 * lane_width_;
            }
        }
        uint32_t d_index_start = std::ceil(d_start / d_per_grid_ +
                                           static_cast<int>(0.5 * num_d_grid_));
        uint32_t d_index_end = std::floor(d_end / d_per_grid_ +
                                          static_cast<int>(0.5 * num_d_grid_));
        // 2. bit manipulate or(|) ^ exclusive or (^)
        std::vector<decltype(obj_type_)> object_vec(num_s_, 0);
        for (uint32_t d_index = d_index_start; d_index <= d_index_end;
             ++d_index) {
            for (uint32_t s_index = 0; s_index < object_vec.size(); ++s_index) {
                uint32_t s_grid_index =
                    (s_index * s_resolution_) / s_per_front_grid_;
                if (s_grid_index >= static_cast<uint32_t>(num_s_front_grid_)) {
                    break;
                }
                uint32_t index = TripleToOne(t_index, s_grid_index, d_index);
                if (index < static_cast<uint32_t>(cell_size_)) {
                    object_vec.at(s_index) =
                        object_vec.at(s_index) | cells_3d_.GetCell(index);
                }
            }
        }
        // 3. fill s_intervals
        uint32_t k = s_index_start_;
        while (k < object_vec.size()) {
            // ignore NBO
            decltype(obj_type_) obj =
                (object_vec.at(k) ^ (object_vec.at(k) & NBO_obj_));
            SBound<decltype(obj_type_)> s_bound;
            if (obj != 0) {
                float heading = frenet_system_->GetHeadingAtS(
                    static_cast<float>(k) * s_resolution_);
                cv::Point2f heading_bpp =
                    cv::Point2f(std::cos(heading), std::sin(heading));
                s_bound.SetSMin(k * s_resolution_);
                s_bound.SetSMax(k * s_resolution_);
                double min_speed = 0.0, max_speed = 0.0;
                GetSpeed(obj, t, heading_bpp, &min_speed, &max_speed);
                s_bound.SetVMin(std::fmin(min_speed, s_bound.v_min()));
                s_bound.SetVMax(std::fmax(max_speed, s_bound.v_max()));
                s_bound.SetObjID(obj);
                ++k;
                if (k < object_vec.size()) {
                    obj = (object_vec.at(k) ^ (object_vec.at(k) & NBO_obj_));
                }
                while (obj != 0 && k < object_vec.size()) {
                    heading = frenet_system_->GetHeadingAtS(
                        static_cast<float>(k) * s_resolution_);
                    obj = (object_vec.at(k) ^ (object_vec.at(k) & NBO_obj_));
                    heading_bpp =
                        cv::Point2f(std::cos(heading), std::sin(heading));
                    GetSpeed(obj, t, heading_bpp, &min_speed, &max_speed);
                    s_bound.SetSMax(k * s_resolution_);
                    s_bound.SetVMin(std::fmin(min_speed, s_bound.v_min()));
                    s_bound.SetVMax(std::fmax(max_speed, s_bound.v_max()));
                    s_bound.SetObjID(obj);
                    ++k;
                }
            }
            if (s_bound.s_min() < kMax) {
                s_bounds.emplace_back(s_bound);
            }
            ++k;
        }
        s_intervals_.emplace_back(s_bounds);
    }
    // output s_intervals for debug
    if (debug_print_ == 1) {
        std::string data_path = "/tmp/today-logs/" +
                                utils::GetTimestampString() +
                                "s_intervals.json";
        common::utils::ConfigurationReader::WriteJSON(data_path, s_intervals_);
    }
    return AD_SUCCESS;
}

adStatus_t ObjectMap::GetSpeed(const int obj_id,
                               const double t,
                               const cv::Point2f& heading_bpp,
                               double* min_speed,
                               double* max_speed) const {
    if (nullptr == min_speed || nullptr == max_speed) {
        AD_LERROR(OBJECT_MAP) << "speed pointer is nullptr";
        return AD_NULL_PTR;
    }
    *min_speed = kMax;
    *max_speed = kMin;
    // 1. decode obj_id into ID
    std::vector<int> ids;
    cells_3d_.Decode(obj_id, &ids);
    // 2. find max and min speed
    for (const int& id : ids) {
        if (id_to_index_.find(id) != id_to_index_.end()) {
            auto& ta_max_prob =
                poa_.prediction_object_array.at(id_to_index_.at(id))
                    .trajectory_array.front();
            double predict_interval =
                static_cast<double>(ta_max_prob.point_interval_time / 1e9);
            double speed = 0.0;
            uint32_t index1 = std::floor(t / predict_interval);
            uint32_t index2 = std::ceil(t / predict_interval);
            if (index1 < ta_max_prob.trajectory_point_array.size() &&
                index2 < ta_max_prob.trajectory_point_array.size()) {
                cv::Point2f velocity =
                    0.5 * (ta_max_prob.trajectory_point_array.at(index1).speed +
                           ta_max_prob.trajectory_point_array.at(index2).speed);
                cv::Point2f direction =
                    0.5 *
                    (ta_max_prob.trajectory_point_array.at(index1).direction +
                     ta_max_prob.trajectory_point_array.at(index2).direction);
                speed = cv::norm(velocity) * direction.dot(heading_bpp);
            } else if (index1 < ta_max_prob.trajectory_point_array.size()) {
                cv::Point2f velocity =
                    ta_max_prob.trajectory_point_array.at(index1).speed;
                cv::Point2f direction =
                    ta_max_prob.trajectory_point_array.at(index1).direction;
                speed = cv::norm(velocity) * direction.dot(heading_bpp);
            } else {
                cv::Point2f velocity =
                    ta_max_prob.trajectory_point_array.back().speed;
                cv::Point2f direction =
                    ta_max_prob.trajectory_point_array.back().direction;
                speed = cv::norm(velocity) * direction.dot(heading_bpp);
            }
            *min_speed = std::fmin(speed, *min_speed);
            *max_speed = std::fmax(speed, *max_speed);
        }
    }
    return AD_SUCCESS;
}

const std::unordered_map<int, Tag>& ObjectMap::GetObstacleTag(
    const std::vector<double>& longi_search_result) {
    obs_tag_.clear();

    // set tag according to longitudinal search result
    for (decltype(s_intervals_.size()) t_index = 0;
         t_index < s_intervals_.size(); ++t_index) {
        for (auto& s_bound : s_intervals_.at(t_index)) {
            if (t_index >= longi_search_result.size()) {
                // 1. the max s is less than longi_sesult, we still surpass this
                // 2. otherwise, we have to yeild rest obstalces
                if (s_bound.s_max() < longi_search_result.back()) {
                    s_bound.SetTag(Tag::SURPASS);
                    std::vector<int> ids;
                    cells_3d_.Decode(s_bound.GetObjID(), &ids);
                    for (const auto& id : ids) {
                        if (obs_tag_.find(id) == obs_tag_.end()) {
                            obs_tag_[id] = Tag::SURPASS;
                        }
                    }
                } else {
                    s_bound.SetTag(Tag::YEILD);
                    std::vector<int> ids;
                    cells_3d_.Decode(s_bound.GetObjID(), &ids);
                    for (const auto& id : ids) {
                        if (obs_tag_.find(id) == obs_tag_.end() ||
                            obs_tag_[id] == Tag::SURPASS) {
                            obs_tag_[id] = Tag::YEILD;
                        }
                    }
                }
            } else {
                if (longi_search_result.at(t_index) > s_bound.s_max()) {
                    s_bound.SetTag(Tag::SURPASS);
                    std::vector<int> ids;
                    cells_3d_.Decode(s_bound.GetObjID(), &ids);
                    for (const auto& id : ids) {
                        if (obs_tag_.find(id) == obs_tag_.end()) {
                            obs_tag_[id] = Tag::SURPASS;
                        }
                    }
                } else if (longi_search_result.at(t_index) < s_bound.s_min()) {
                    s_bound.SetTag(Tag::YEILD);
                    std::vector<int> ids;
                    cells_3d_.Decode(s_bound.GetObjID(), &ids);
                    for (const auto& id : ids) {
                        if (obs_tag_.find(id) == obs_tag_.end() ||
                            obs_tag_[id] == Tag::SURPASS) {
                            obs_tag_[id] = Tag::YEILD;
                        }
                    }
                } else {
                    AD_LERROR(OBJECT_MAP) << "there are some bugs in "
                                             "longitudinal s-t graph search!";
                }
            }
        }
    }

    // set all nbo tag with surpass
    std::vector<int> nbo_ids;
    cells_3d_.Decode(NBO_obj_, &nbo_ids);
    for (auto& id : nbo_ids) {
        obs_tag_[id] = Tag::SURPASS;
    }

    // print obs tag to debug
    for (auto& item : obs_tag_) {
        AD_LINFO(ObjectMap) << "obs id " << item.first << " ===> "
                            << item.second;
    }
    return obs_tag_;
}

double ObjectMap::GetObstacleCost(const double s,
                                  const double t,
                                  const double w_follow_to_near,
                                  const double w_follow_to_far) const {
    if (t < 0.0 || s < 0.0 || s > s_horizon_) {
        // exceed consider range
        return 0.0;
    }
    uint32_t t_index = static_cast<uint32_t>(t / t_resolution_);
    if (t_index >= s_intervals_.size()) {
        return 0.0;
    }
    auto& s_bounds = s_intervals_.at(t_index);
    if (s_bounds.empty()) {
        // no obstalce at t
        return 0.0;
    }
    double cost = 0.0;
    for (auto s_bound : s_bounds) {
        if (s - g_vehicle_param.length * 0.5 <=
                s_bound.s_max() +
                    longi_dp_safe_distance_ *
                        longi_dp_safe_distance_rear_ratio_ &&
            s + g_vehicle_param.length * 0.5 >=
                s_bound.s_min() - longi_dp_safe_distance_) {
            // s within s_bound
            return kMax;
        } else if (s < s_bound.s_min() - longi_dp_safe_distance_) {
            double follow_distance =
                CalcFollowDistance(s_bound.v_max(), g_vehicle_state.velocity);
            double s_diff = s + follow_distance - s_bound.s_min();
            if (s_diff < 0.0) {
                // follow too far
                cost += w_follow_to_far * s_diff * s_diff;
            } else {
                // follow too near
                cost += w_follow_to_near * s_diff * s_diff;
            }
        }
    }
    return cost;
}

adStatus_t ObjectMap::GetLongiBoundAndRef(const std::vector<double>& t_seq,
                                          const double curr_s,
                                          const double curr_speed,
                                          const double curr_acc,
                                          const double target_s,
                                          const double target_speed,
                                          std::vector<double>* lower_bound,
                                          std::vector<double>* upper_bound,
                                          std::vector<double>* ref_seq) {
    if (lower_bound == nullptr || upper_bound == nullptr ||
        ref_seq == nullptr) {
        AD_LERROR(OBJECT_MAP) << "lower_bound or upper_bound is nullptr";
        return AD_NULL_PTR;
    }
    for (auto item : obs_tag_) {
        AD_LINFO(ObjectMap) << "obstacle tag " << item.first << " ===> "
                            << item.second;
    }
    lower_bound->clear();
    upper_bound->clear();
    ref_seq->clear();
    lower_bound->reserve(t_seq.size());
    upper_bound->reserve(t_seq.size());

    // set longitudinal ref
    const double speed_lower_limit = 0.0;
    const double speed_upper_limit = 40.0 / 3.6;
    const double acc_lower_limit = -1.0;
    const double acc_upper_limit = 1.5;
    // determine target speed based on NBO and leader car
    double target_speed_final = ChooseTargetSpeed(target_speed);
    SetLongiRef(t_seq, curr_s, curr_speed, curr_acc, target_s,
                target_speed_final, speed_lower_limit, speed_upper_limit,
                acc_lower_limit, acc_upper_limit, ref_seq);

    for (uint32_t i = 0; i < t_seq.size(); ++i) {
        uint32_t t_index = static_cast<uint32_t>(t_seq.at(i) / t_resolution_);
        if (t_index >= num_t_) {
            AD_LERROR(OBJECT_MAP) << "enquired t exceeds scope";
            return AD_SUCCESS;
        }
        double curr_ref = ref_seq->at(i);
        double curr_lower_bound = std::min(-2.0, curr_s);
        double curr_upper_bound = (target_speed + curr_speed) * t_horizon_;
        for (const auto& s_bound : s_intervals_.at(t_index)) {
            std::vector<int> ids;
            cells_3d_.Decode(s_bound.GetObjID(), &ids);
            if (ids.empty() == true) {
                continue;
            }
            Tag s_bound_tag = Tag::IGNORE;
            for (auto& id : ids) {
                if (obs_tag_.find(id) != obs_tag_.end()) {
                    s_bound_tag = obs_tag_.at(id);
                    break;
                } else {
                    AD_LINFO(ObjectMap) << "id " << id
                                        << " doesnot existed in obs_tag_";
                }
            }
            if (s_bound_tag == Tag::SURPASS) {
                curr_lower_bound = std::max(
                    s_bound.s_max() + longi_safe_distance_, curr_lower_bound);
            } else if (s_bound_tag == Tag::YEILD) {
                double follow_distance =
                    std::max(longi_safe_distance_,
                             CalcFollowDistance(s_bound.v_max(), curr_speed));
                curr_upper_bound = std::min(
                    curr_upper_bound, s_bound.s_min() - longi_safe_distance_);
                curr_ref =
                    std::min(curr_ref, s_bound.s_min() - follow_distance);
                AD_LINFO(ObjectMap) << "obs velocity " << s_bound.v_max()
                                    << " curr_ref " << curr_ref;
            }
        }
        curr_upper_bound = std::max(curr_upper_bound, curr_lower_bound + 0.2);
        curr_ref =
            std::min(curr_upper_bound, std::max(curr_ref, curr_lower_bound));
        lower_bound->emplace_back(curr_lower_bound);
        upper_bound->emplace_back(curr_upper_bound);
        ref_seq->at(i) = curr_ref;
    }
    return AD_SUCCESS;
}

adStatus_t ObjectMap::GetLateralBoundAndRef(const std::vector<double>& t_seq,
                                            const std::vector<double>& s_seq,
                                            std::vector<double>* lower_bound,
                                            std::vector<double>* upper_bound,
                                            std::vector<double>* ref_seq) {
    // TODO(Shengfa) print size of t_seq and s_seq, when assert failed
    assert(t_seq.size() == s_seq.size());
    if (lower_bound == nullptr || upper_bound == nullptr ||
        ref_seq == nullptr) {
        AD_LERROR(OBJECT_MAP)
            << "lower_bound, upper_bound or ref_seq is nullptr";
        return AD_NULL_PTR;
    }
    // get lateral reference without obs
    CalculateLateralRef(t_seq, ref_seq);

    lower_bound->clear();
    upper_bound->clear();
    lower_bound->reserve(s_seq.size());
    upper_bound->reserve(s_seq.size());
    for (uint32_t i = 0; i < t_seq.size(); ++i) {
        double t = t_seq.at(i);
        double s = s_seq.at(i);
        // 1. set default lower and upper bound based on change time
        double d_start = -0.5 * lane_width_;
        double d_end = 0.5 * lane_width_;
        if (change_direction_ == ChangeDirection::CHANGE_LEFT) {
            if (t > change_start_time_ && t < change_end_time_) {
                // ego lane and target lane
                d_start = -0.5 * lane_width_;
                d_end = 1.5 * lane_width_;
            } else if (t >= change_end_time_) {
                // only target lane
                d_start = 0.5 * lane_width_;
                d_end = 1.5 * lane_width_;
            }
        } else if (change_direction_ == ChangeDirection::CHANGE_RIGHT) {
            if (t > change_start_time_ && t < change_end_time_) {
                // ego lane and target lane
                d_start = -1.5 * lane_width_;
                d_end = 0.5 * lane_width_;
            } else if (t >= change_end_time_) {
                // only target lane
                d_start = -1.5 * lane_width_;
                d_end = -0.5 * lane_width_;
            }
        }
        double curr_lower_bound = d_start;
        double curr_upper_bound = d_end;
        // 2. traverse predict trajectory to get lower and upper bound
        for (uint32_t k = 0; k < poa_.prediction_object_array.size(); ++k) {
            // Note: only need to consider obstacle with tag of SURPASS,
            // if you never try to surpass others, you will never get a
            // chance
            // to stand at same level with them.
            int obs_id = poa_.prediction_object_array.at(k).id;
            if (obs_tag_.find(obs_id) == obs_tag_.end() ||
                obs_tag_[obs_id] != Tag::SURPASS) {
                continue;
            }
            auto& ta_max_prob =
                poa_.prediction_object_array.at(k).trajectory_array.front();
            const double predict_interval =
                static_cast<double>(ta_max_prob.point_interval_time / 1e9);
            uint32_t t_index_floor =
                static_cast<uint32_t>(std::floor(t / predict_interval));
            uint32_t t_index_ceil =
                static_cast<uint32_t>(std::ceil(t / predict_interval));
            if (t_index_ceil < ta_max_prob.trajectory_point_array.size() &&
                t_index_floor < ta_max_prob.trajectory_point_array.size()) {
                double ratio = 0.0;
                if (t_index_ceil == t_index_floor) {
                    ratio = 1.0;
                } else {
                    ratio = (t - t_index_floor * predict_interval) /
                            ((t_index_ceil - t_index_floor) * predict_interval);
                }
                std::vector<cv::Point2f> polygon_sd_floor, polygon_sd_ceil;
                auto& tjp_floor =
                    ta_max_prob.trajectory_point_array.at(t_index_floor);
                auto& tjp_ceil =
                    ta_max_prob.trajectory_point_array.at(t_index_ceil);
                CalculateFrenet(tjp_floor.polygon_contour, tjp_floor.position,
                                &polygon_sd_floor);
                double s_min_floor = 0.0, s_max_floor = 0.0, d_min_floor = 0.0,
                       d_max_floor = 0.0;
                GetSDBound(polygon_sd_floor, &s_min_floor, &s_max_floor,
                           &d_min_floor, &d_max_floor);
                CalculateFrenet(tjp_ceil.polygon_contour, tjp_ceil.position,
                                &polygon_sd_ceil);
                double s_min_ceil = 0.0, s_max_ceil = 0.0, d_min_ceil = 0.0,
                       d_max_ceil = 0.0;
                GetSDBound(polygon_sd_ceil, &s_min_ceil, &s_max_ceil,
                           &d_min_ceil, &d_max_ceil);
                double s_min = s_min_floor + (s_min_ceil - s_min_floor) * ratio;
                double s_max = s_max_floor + (s_max_ceil - s_max_floor) * ratio;
                double d_min = d_min_floor + (d_min_ceil - d_min_floor) * ratio;
                double d_max = d_max_floor + (d_max_ceil - d_max_floor) * ratio;
                // consider it if obstacle is overlap with enquired s at
                // longitudinal direction
                if (s > (s_min - longi_overlap_threshold_) &&
                    s < (s_max + longi_overlap_threshold_)) {
                    // 3. decide surpass in left side or right side by
                    // relative position of center point.
                    // TODO(Shengfa) more rigorous method
                    if ((d_max + d_min) / 2.0 < (d_start + d_end) / 2.0) {
                        // obs is right side
                        curr_lower_bound = std::max(d_max, curr_lower_bound);
                    } else {
                        // obs is in left side
                        curr_upper_bound = std::min(d_min, curr_upper_bound);
                    }
                }
            }
        }
        lower_bound->emplace_back(curr_lower_bound +
                                  g_vehicle_param.width / 2.0f +
                                  lateral_safe_distance_);
        upper_bound->emplace_back(curr_upper_bound -
                                  g_vehicle_param.width / 2.0f -
                                  lateral_safe_distance_);
        ref_seq->at(i) = ref_seq->at(i) + (curr_upper_bound - d_end) +
                         (curr_lower_bound - d_start);
    }
    return AD_SUCCESS;
}

void ObjectMap::GetSDBound(const std::vector<cv::Point2f>& sd_seq,
                           double* s_min,
                           double* s_max,
                           double* d_min,
                           double* d_max) const {
    if (s_max == nullptr || s_min == nullptr || d_min == nullptr ||
        d_max == nullptr) {
        AD_LERROR(OBJECT_MAP) << "null points";
        return;
    }
    *s_min = std::numeric_limits<double>::max();
    *s_max = -std::numeric_limits<double>::max();
    *d_min = std::numeric_limits<double>::max();
    *d_max = -std::numeric_limits<double>::max();
    for (const auto& sd : sd_seq) {
        *s_min = std::min(*s_min, static_cast<double>(sd.x));
        *s_max = std::max(*s_max, static_cast<double>(sd.x));
        *d_min = std::min(*d_min, static_cast<double>(sd.y));
        *d_max = std::max(*d_max, static_cast<double>(sd.y));
    }
}

void ObjectMap::CalculateLateralRef(const std::vector<double>& t_seq,
                                    std::vector<double>* ref_seq) const {
    if (ref_seq == nullptr) {
        AD_LERROR(OBJECT_MAP) << "ref_seq is nullptr";
        return;
    }
    ref_seq->clear();
    if (change_direction_ == ChangeDirection::NO_CHANGE) {
        *ref_seq = std::vector<double>(t_seq.size(), 0.0);
    } else {
        ref_seq->reserve(t_seq.size());
        double is_positive = 0.0;
        if (change_direction_ == ChangeDirection::CHANGE_LEFT) {
            is_positive = 1.0;
        } else if (change_direction_ == ChangeDirection::CHANGE_RIGHT) {
            is_positive = -1.0;
        }
        // TODO(Shengfa) more curve type for lane change
        /*
         * using sine curve as change lane ref curve
         * assume v_lat = v_lat_max * sin(omega * t)
         * thus, omega = pi / change_period_
         * d = integate(v) = v_lat_max / omega * (1 - cos(omega * t))
         * due to d(change_period_) = lane_width
         * v_lat_max = (omega * lane_width) / (1 - cos(omega *
         * change_period_))
         */
        // lane change period set to 6.0 seconds
        const double oemga = static_cast<double>(M_PI) / change_period_;
        const double v_lat_max =
            (oemga * lane_width_) / (1 - std::cos(oemga * change_period_));
        const double t_change_half =
            (change_start_time_ + change_end_time_) / 2.0;
        double curr_ref = 0.0;
        for (const auto& t : t_seq) {
            double t_relative = (t - t_change_half + 0.5 * change_period_);
            if (t_relative <= 0.0) {
                curr_ref = 0.0;
            } else if (t_relative >= change_period_) {
                curr_ref = is_positive * lane_width_;
            } else {
                curr_ref =
                    v_lat_max / (oemga) * (1 - std::cos(oemga * t_relative));
            }
            ref_seq->emplace_back(curr_ref);
        }
    }
}

void ObjectMap::FindNBO() {
    // 1. set lateral range for L(left) and R(right) region
    const double vehicle_lateral_buffer_ = 0.4;
    const double driving_width =
        vehicle_lateral_buffer_ * 2.0 + g_vehicle_param.width;
    double left_d_start = -0.5 * lane_width_ + driving_width;
    double left_d_end = 0.5 * lane_width_;
    int left_index_start =
        static_cast<int>(left_d_start / d_per_grid_ + 0.5f * num_d_grid_);
    int left_index_end =
        static_cast<int>(left_d_end / d_per_grid_ + 0.5f * num_d_grid_);
    int center_index = static_cast<int>(0.5f * num_d_grid_);
    int right_index_start = center_index > (left_index_end - center_index)
                                ? (2 * center_index - left_index_end)
                                : 0;
    int right_index_end = center_index > (left_index_start - center_index)
                              ? (2 * center_index - left_index_start)
                              : 0;

    // 2. calculate obj_id in L(left), and R(right) region with union
    // bit operation
    std::vector<std::vector<decltype(obj_type_)>> l_st, r_st;
    auto l_obj_id = CalculateObjId(left_index_start, left_index_end, &l_st);
    auto l_reverse_obj_id =
        CalculateObjId(left_index_start - 3, left_index_start - 1);
    auto r_obj_id = CalculateObjId(right_index_start, right_index_end, &r_st);
    auto r_reverse_obj_id =
        CalculateObjId(right_index_end + 1, right_index_end + 3);

    AD_LINFO(ObjectMap) << "l_obj_id " << l_obj_id << " r_obj_id " << r_obj_id
                        << " l_reverse_obj_id " << l_reverse_obj_id
                        << " r_reverse_obj_id " << r_reverse_obj_id;

    // 3. calculate nbo_candidate in L, C region
    auto l_nbo_candidate = (l_obj_id & (~l_reverse_obj_id));
    auto r_nbo_candidate = (r_obj_id & (~r_reverse_obj_id));
    AD_LINFO(OBJECT_MAP) << "l_nbo_candidate " << l_nbo_candidate
                         << " r_nbo_candidate " << r_nbo_candidate;

    // 4. calculate scenario when two nbos take both side of road and they are
    // near in longitudinal direction
    decltype(obj_type_) bo_obj_id = 0;
    for (uint32_t i = 0; i < l_st.size(); ++i) {
        for (uint32_t j = 0; j < l_st.at(i).size(); ++j) {
            if ((l_st.at(i).at(j) != 0) && (r_st.at(i).at(j) != 0)) {
                // there are objects on both side of road,
                // thus, detect drivable width
                int d_right = center_index, d_left = center_index;
                while (d_right >= right_index_start) {
                    if (cells_3d_.IsOccupied(TripleToOne(i, j, d_right)) ==
                        true) {
                        break;
                    }
                    d_right--;
                }
                while (d_left <= left_index_end) {
                    if (cells_3d_.IsOccupied(TripleToOne(i, j, d_left)) ==
                        true) {
                        break;
                    }
                    d_left++;
                }
                double drivable_width =
                    static_cast<double>(d_left - d_right - 1) * d_per_grid_;
                if (drivable_width < driving_width) {
                    bo_obj_id =
                        (bo_obj_id | (l_st.at(i).at(j) | r_st.at(i).at(j)));
                }
            }
        }
    }
    AD_LINFO(OBJECT_MAP) << "bo_obj_id " << bo_obj_id;

    // 5. calculate bo in the center of lane
    auto center_bo_obj_id = CalculateObjId(center_index - 1, center_index + 1);
    AD_LINFO(OBJECT_MAP) << "center_bo_obj_id " << center_bo_obj_id;
    std::vector<int> bo_ids;
    std::set<int> bo_set;
    cells_3d_.Decode(center_bo_obj_id, &bo_ids);
    for (uint32_t i = 0; i < bo_ids.size(); ++i) {
        bo_set.emplace(bo_ids.at(i));
        AD_LINFO(OBJECT_MAP) << "bo candidate id " << bo_ids.at(i);
        if (bo_counter_.find(bo_ids.at(i)) == bo_counter_.end()) {
            bo_counter_[bo_ids.at(i)] = 1;
        } else {
            bo_counter_[bo_ids.at(i)] = bo_ids[bo_ids.at(i)] + 1;
        }
    }
    for (auto& item : bo_counter_) {
        if (bo_set.find(item.first) == bo_set.end()) {
            AD_LINFO(OBJECT_MAP) << "erase bo no. " << item.first;
            bo_counter_.erase(item.first);
        }
    }

    // 5. remove nbo who take both side from nbo candidate to get real nbo
    decltype(obj_type_) nbo_candidate = 0;
    nbo_candidate = (l_nbo_candidate | r_nbo_candidate);

    // 6. maintain nbo counter
    std::vector<int> ids;
    std::set<int> nbo_candidate_ids;
    cells_3d_.Decode(nbo_candidate, &ids);
    for (uint32_t i = 0; i < ids.size(); ++i) {
        AD_LINFO(OBJECT_MAP) << "nbo candidate id " << ids.at(i);
        nbo_candidate_ids.emplace(ids.at(i));
        if (nbo_counter.find(ids.at(i)) != nbo_counter.end()) {
            nbo_counter[ids.at(i)]++;
        } else {
            nbo_counter[ids.at(i)] = 1;
        }
    }
    // clear counter if the obstacle is not including in candidate
    // make nbo candidate become nbo if its counter more than threshold
    for (auto& item : nbo_counter) {
        if (nbo_candidate_ids.find(item.first) == nbo_candidate_ids.end()) {
            AD_LINFO(OBJECT_MAP) << "erase nbo " << item.first;
            nbo_counter.erase(item.first);
        } else {
            if (item.second > nbo_counter_threshold_) {
                AD_LINFO(OBJECT_MAP) << "real nbo id " << item.first;
                NBO_obj_ = NBO_obj_ | cells_3d_.Encode(item.first);
            }
        }
    }

    for (auto& item : nbo_counter) {
        AD_LINFO(OBJECT_MAP) << "id " << item.first << ", counter "
                             << item.second;
    }

    // 7. fill nbo_speed with longitudinal speed of nearest s nbo
    nbo_speed_ = 120.0 / 3.6;
    nbo_distance_ = s_horizon_;
    double left_nbo_speed = 120.0 / 3.6, right_nbo_speed = 120.0 / 3.6;
    double left_nbo_distance = s_horizon_, right_nbo_distance = s_horizon_;
    if (!l_st.empty()) {
        CalcNBOSpeedAndDistance(l_st.at(0), &left_nbo_speed,
                                &left_nbo_distance);
    }
    if (!r_st.empty()) {
        CalcNBOSpeedAndDistance(r_st.at(0), &right_nbo_speed,
                                &right_nbo_distance);
    }
    // choose by distance
    if (left_nbo_distance < right_nbo_distance) {
        nbo_speed_ = left_nbo_speed;
        nbo_distance_ = left_nbo_distance;
    } else {
        nbo_speed_ = right_nbo_speed;
        nbo_distance_ = right_nbo_distance;
    }
}

void ObjectMap::SetLongiRef(const std::vector<double>& t_seq,
                            const double init_s,
                            const double init_speed,
                            const double init_acc,
                            const double target_s,
                            const double target_speed,
                            const double speed_lower_limit,
                            const double speed_upper_limit,
                            const double acc_lower_limit,
                            const double acc_upper_limit,
                            std::vector<double>* result_seq) const {
    if (result_seq == nullptr) {
        AD_LERROR(OBJECT_MAP) << "pointer of result_seq is nullptr";
        return;
    }
    result_seq->clear();
    result_seq->reserve(t_seq.size());
    result_seq->push_back(init_s);
    double curr_s = init_s;
    double curr_speed = init_speed;
    double curr_acc = init_acc;
    double curr_jerk = 0.0;
    // TODO(Shengfa Zhu) using decent way
    if (target_speed > init_speed) {
        // increase speed
        if (init_acc < ref_acc_) {
            // increase acceleration
            curr_jerk = ref_jerk_;
            for (uint32_t i = 1; i < t_seq.size(); ++i) {
                double delta_t = t_seq.at(i) - t_seq.at(i - 1);
                curr_acc = curr_acc + curr_jerk * delta_t;
                curr_acc =
                    std::max(std::min(curr_acc, ref_acc_), acc_lower_limit);
                curr_speed = curr_speed + curr_acc * delta_t;
                curr_speed = std::max(std::min(curr_speed, target_speed),
                                      speed_lower_limit);
                curr_s = curr_s + curr_speed * delta_t;
                result_seq->emplace_back(curr_s);
            }
        } else {
            // decrease acceleration
            curr_jerk = -1.0 * ref_jerk_;
            for (uint32_t i = 1; i < t_seq.size(); ++i) {
                double delta_t = t_seq.at(i) - t_seq.at(i - 1);
                curr_acc = curr_acc + curr_jerk * delta_t;
                curr_acc = std::max(curr_acc, ref_acc_);
                curr_speed = curr_speed + curr_acc * delta_t;
                curr_speed = std::max(std::min(curr_speed, target_speed),
                                      speed_lower_limit);
                curr_s = curr_s + curr_speed * delta_t;
                result_seq->emplace_back(curr_s);
            }
        }
    } else {
        // decrease speed
        if (init_acc < ref_deacc_) {
            // increase acceleration
            curr_jerk = ref_jerk_;
            for (uint32_t i = 1; i < t_seq.size(); ++i) {
                double delta_t = t_seq.at(i) - t_seq.at(i - 1);
                curr_acc = curr_acc + curr_jerk * delta_t;
                curr_acc = std::min(curr_acc, ref_deacc_);
                curr_speed = curr_speed + curr_acc * delta_t;
                curr_speed = std::max(std::min(curr_speed, speed_upper_limit),
                                      target_speed);
                curr_s = curr_s + curr_speed * delta_t;
                result_seq->emplace_back(curr_s);
            }
        } else {
            // decrease acceleration
            curr_jerk = -1.0 * ref_jerk_;
            for (uint32_t i = 1; i < t_seq.size(); ++i) {
                double delta_t = t_seq.at(i) - t_seq.at(i - 1);
                curr_acc = curr_acc + curr_jerk * delta_t;
                curr_acc = std::max(curr_acc, ref_deacc_);
                curr_speed = curr_speed + curr_acc * delta_t;
                curr_speed = std::max(std::min(curr_speed, speed_upper_limit),
                                      target_speed);
                curr_s = curr_s + curr_speed * delta_t;
                result_seq->emplace_back(curr_s);
            }
        }
    }
}

const double ObjectMap::CalcFollowDistance(const double front_v,
                                           const double ego_v) const {
    // using min value between distance by TTC and follow time
    // because the follow distance is convergent value instead of instant value
    // TODO(Shengfa) what if front_v is negative
    double follow_distance_time =
        std::fabs(front_v) * follow_time_ + longi_stop_distance_;
    double follow_distance_TTC =
        ego_v * time_to_collision_ - (front_v - ego_v) * time_to_collision_ +
        (ego_v * ego_v) / (2.0 * max_deacc_vehicle_) -
        (front_v * front_v) / (2.0 * max_deacc_vehicle_) + longi_stop_distance_;
    return std::min(follow_distance_TTC, follow_distance_time);
}

void ObjectMap::ChooseLeaderCar(const double v_limit,
                                double* v_leader,
                                double* s_leader) const {
    bool leader_car_choosed = false;
    *v_leader = 120.0 / 3.6, *s_leader = s_horizon_;
    for (uint32_t t_index = 0;
         t_index < static_cast<uint32_t>(s_intervals_.size()); ++t_index) {
        for (const auto& s_bound : s_intervals_.at(t_index)) {
            if (s_bound.GetTag() == Tag::YEILD && s_bound.v_min() < v_limit) {
                *v_leader = s_bound.v_min();
                *s_leader = s_bound.s_min();
                leader_car_choosed = true;
                break;
            }
        }
        if (leader_car_choosed) {
            break;
        }
    }
    AD_LINFO(OBJECT_MAP) << "v_leader " << *v_leader << ", s_leader "
                         << *s_leader;
}

const double ObjectMap::ChooseTargetSpeed(const double v_limit) {
    double target_speed = v_limit;
    constexpr double reasonable_deacc = 1.0;                     // unit, m/s^2
    constexpr double speed_increment = 10.0 / 3.6;               // unit, m/s
    constexpr double target_speed_change_threshold = 5.0 / 3.6;  // unit, m/s

    // 1. get v and s of NBO and leader car
    // consider NBO
    double nbo_respond_range =
        nbo_speed_ < v_limit
            ? (v_limit * v_limit - nbo_speed_ * nbo_speed_) /
                  (2.0 * reasonable_deacc)
            : -kMax;
    // leader car
    double v_leader = 120.0 / 3.6, s_leader = s_horizon_;
    ChooseLeaderCar(v_limit, &v_leader, &s_leader);
    double leader_car_respond_range =
        v_limit > v_leader
            ? (v_limit * v_limit - v_leader * v_leader) /
                  (2.0 * reasonable_deacc)
            : -kMax;

    // 2. compare distance
    double target_speed_new = 0.0;
    if (nbo_distance_ < nbo_respond_range &&
        s_leader > leader_car_respond_range) {
        // only consider nbo
        AD_LINFO(OBJECT_MAP) << "decrease due to nbo";
        target_speed_new = nbo_speed_ + speed_increment;
    } else if (nbo_distance_ > nbo_respond_range &&
               s_leader < leader_car_respond_range) {
        // only consider leader car
        AD_LINFO(OBJECT_MAP) << "decrease due to leader car";
        target_speed_new = v_leader + speed_increment;
    } else if (nbo_distance_ < nbo_respond_range &&
               s_leader < leader_car_respond_range) {
        // consider nbo and leader car
        AD_LINFO(OBJECT_MAP) << "decrease due to leader car and nbo";
        target_speed_new = std::min(nbo_speed_, v_leader) + speed_increment;
    } else {
        target_speed_new = v_limit;
    }

    // 3. update target speed
    if (std::abs(target_speed_new - target_speed_old_) >
        target_speed_change_threshold) {
        target_speed = target_speed_new;
        target_speed_old_ = target_speed_new;
    } else {
        target_speed = target_speed_old_;
    }

    // debug info
    AD_LINFO(OBJECT_MAP) << "nbo max speed " << nbo_speed_
                         << ", nbo min distance " << nbo_distance_
                         << ", leader speed " << v_leader << ", s_leader "
                         << s_leader << ",  nbo_respond_range "
                         << nbo_respond_range << ", leading car respond range "
                         << leader_car_respond_range << ", target_speed "
                         << target_speed;
    return target_speed;
}

void ObjectMap::CalcNBOSpeedAndDistance(
    const std::vector<decltype(obj_type_)>& st_seq,
    double* nbo_speed,
    double* nbo_distance) const {
    if (nbo_speed == nullptr || nbo_distance == nullptr) {
        AD_LERROR(OBJECT_MAP) << "nullptr!!!";
        return;
    }

    *nbo_distance = s_horizon_;
    *nbo_speed = 120.0 / 3.6;
    for (uint32_t s_index = 0; s_index < st_seq.size(); ++s_index) {
        auto nbo = (st_seq.at(s_index) & NBO_obj_);
        if (nbo != 0) {
            *nbo_distance = static_cast<double>(s_index) * s_per_front_grid_;
            float heading = frenet_system_->GetHeadingAtS(*nbo_distance);
            cv::Point2f heading_bpp(std::cos(heading), std::sin(heading));
            double min_speed = 0.0;
            GetSpeed(nbo, 0.0, heading_bpp, &min_speed, nbo_speed);
            break;
        }
    }
}

}  // namespace pp
}  // namespace senseAD
