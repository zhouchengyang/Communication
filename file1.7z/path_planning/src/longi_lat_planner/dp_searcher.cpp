/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include <algorithm>
#include "path_planning/longi_lat_planner/dp_searcher.hpp"

namespace senseAD {
namespace pp {

adStatus_t DPSearcher::Update(const double& vehicle_speed,
                              const double& vehicle_acc,
                              const double& speed_limit) {
    // update vehicle speed and acc along with frenet frame
    vehicle_speed_ = vehicle_speed;
    vehicle_acc_ = vehicle_acc;
    speed_limit_ = speed_limit;
    return AD_SUCCESS;
}

adStatus_t DPSearcher::Search(std::vector<double>* out_path) {
    if (nullptr == out_path) {
        AD_LERROR(DPSearcher) << "out_path is nullptr";
        return AD_NULL_PTR;
    }
    // 1. contruct cost table
    if (AD_SUCCESS != ConstructCostTable()) {
        AD_LERROR(DPSearcher) << "cost table constructed failed!";
    }
    // 2. generate speed profile by cost table
    if (AD_SUCCESS != GenerateSpeedProfile(out_path)) {
        AD_LERROR(DPSearcher) << "speed profile generated failed!";
    }
    // 3. output for debug
    if (debug_print_ == 1) {
        std::string data_path =
            "/tmp/today-logs/" + utils::GetTimestampString() + "longi_dp.json";
        common::utils::ConfigurationReader::WriteJSON(data_path, *out_path);
        // 4. output cost table if search maybe failed
        if (out_path->size() < 10) {
            std::string cost_table_data_path = "/tmp/today-logs/" +
                                               utils::GetTimestampString() +
                                               "cost_table.json";
            common::utils::ConfigurationReader::WriteJSON(cost_table_data_path,
                                                          cost_table_);
        }
    }
    return AD_SUCCESS;
}

double DPSearcher::GetVelCost(const STPoint& first_point,
                              const STPoint& second_point,
                              const double speed_limit) const {
    // driving back is forbidden
    if (first_point.s() > (second_point.s() + 0.1)) {
        return kMax;
    }
    double speed = (second_point.s() - first_point.s()) / t_resolution_;
    double delta_speed = (speed - speed_limit) / speed_limit;
    double cost = 0.0;
    if (delta_speed > 0) {
        // if exceed speed is prohibited, more infinity will appear in cost
        // table
        cost = w_exceed_speed_ * delta_speed * delta_speed;
    } else {
        cost = w_low_speed_ * delta_speed * delta_speed;
    }
    return cost;
}

double DPSearcher::GetAccCost(const double acc) const {
    double ref_acc = acc / max_acc_;
    return (w_acc_ * ref_acc * ref_acc);
}

double DPSearcher::GetAccCost(const STPoint& pre_point,
                              STPoint curr_point,
                              const double speed) const {
    double curr_speed = (curr_point.s() - pre_point.s()) / t_resolution_;
    double acc = (curr_speed - speed) / t_resolution_;
    return GetAccCost(acc);
}

double DPSearcher::GetAccCost(const STPoint& first_point,
                              const STPoint& second_point,
                              const STPoint& third_point) const {
    double pre_speed = (second_point.s() - first_point.s()) / t_resolution_;
    double curr_speed = (third_point.s() - second_point.s()) / t_resolution_;
    double acc = (curr_speed - pre_speed) / t_resolution_;
    return GetAccCost(acc);
}

double DPSearcher::GetJerkCost(const double jerk) const {
    double ref_jerk = jerk / max_jerk_;
    return (w_jerk_ * ref_jerk * ref_jerk);
}

double DPSearcher::GetJerkCost(const double first_speed,
                               const double first_acc,
                               const STPoint& first_point,
                               const STPoint& second_point) const {
    double curr_speed = (second_point.s() - first_point.s()) / t_resolution_;
    double curr_acc = (curr_speed - first_speed) / t_resolution_;
    double jerk = (curr_acc - first_acc) / t_resolution_;
    return GetJerkCost(jerk);
}

double DPSearcher::GetJerkCost(const double first_speed,
                               const STPoint& first_point,
                               const STPoint& second_point,
                               const STPoint& third_point) const {
    double pre_speed = (second_point.s() - first_point.s()) / t_resolution_;
    double pre_acc = (pre_speed - first_speed) / t_resolution_;
    double curr_speed = (third_point.s() - second_point.s()) / t_resolution_;
    double curr_acc = (curr_speed - pre_speed) / t_resolution_;
    double jerk = (curr_acc - pre_acc) / t_resolution_;
    return GetJerkCost(jerk);
}

double DPSearcher::GetJerkCost(const STPoint& first_point,
                               const STPoint& second_point,
                               const STPoint& third_point,
                               const STPoint& fourth_point) const {
    double jerk = (fourth_point.s() - 3.0f * third_point.s() +
                   3.0f * second_point.s() - first_point.s()) /
                  (t_resolution_ * t_resolution_ * t_resolution_);
    return GetJerkCost(jerk);
}

bool DPSearcher::CalculateCostAt(const STPoint& st_point) {
    uint32_t t_index = static_cast<uint32_t>(st_point.t() / t_resolution_);
    uint32_t s_index = static_cast<uint32_t>(st_point.s() / s_resolution_);
    if (0 == t_index) {
        if (0 != s_index) {
            AD_LERROR(DPSearcher)
                << "bug!!, s_index must be zero, when t_index is zero";
            return false;
        }
        // cost of start point is zero
        cost_table_[t_index][s_index].SetCost(0.0f);
    } else if (1 == t_index) {
        double tmp_cost = GetObstacleCost(st_point.s(), st_point.t(),
                                          w_follow_to_near_, w_follow_to_far_) +
                          cost_table_[0][0].cost() +
                          CalculateCostForSecondCol(st_point);
        cost_table_[t_index][s_index].SetCost(tmp_cost);
        cost_table_[t_index][s_index].SetPrePoint(cost_table_[0][0]);
    } else if (2 == t_index) {
        double s_low = st_point.s() - speed_limit_ * t_resolution_;
        uint32_t s_index_low =
            static_cast<uint32_t>(std::max(0.0, s_low / s_resolution_));
        for (uint32_t s_pre_index = s_index_low; s_pre_index <= s_index;
             ++s_pre_index) {
            if (cost_table_[t_index - 1][s_pre_index].pre_point() == nullptr) {
                continue;
            }
            double tmp_cost =
                GetObstacleCost(st_point.s(), st_point.t(), w_follow_to_near_,
                                w_follow_to_far_) +
                cost_table_[t_index - 1][s_pre_index].cost() +
                CalculateCostForThirdCol(st_point, s_pre_index);
            if (tmp_cost < cost_table_[t_index][s_index].cost()) {
                cost_table_[t_index][s_index].SetCost(tmp_cost);
                cost_table_[t_index][s_index].SetPrePoint(
                    cost_table_[t_index - 1][s_pre_index]);
            }
        }
    } else {
        double s_low = st_point.s() - speed_limit_ * t_resolution_;
        uint32_t s_index_low =
            static_cast<uint32_t>(std::max(0.0, s_low / s_resolution_));
        for (uint32_t s_pre_index = s_index_low; s_pre_index <= s_index;
             ++s_pre_index) {
            if (cost_table_[t_index - 1][s_pre_index].pre_point() == nullptr) {
                continue;
            }
            double tmp_cost =
                GetObstacleCost(st_point.s(), st_point.t(), w_follow_to_near_,
                                w_follow_to_far_) +
                cost_table_[t_index - 1][s_pre_index].cost() +
                CalculateEdgeCost(st_point, s_pre_index);
            if (tmp_cost < cost_table_[t_index][s_index].cost()) {
                cost_table_[t_index][s_index].SetCost(tmp_cost);
                cost_table_[t_index][s_index].SetPrePoint(
                    cost_table_[t_index - 1][s_pre_index]);
            }
        }
    }
    if (t_index < cost_table_.size() &&
        s_index < cost_table_.at(t_index).size() &&
        cost_table_[t_index][s_index].cost() < kMax) {
        return true;
    } else {
        return false;
    }
}

double DPSearcher::CalculateCostForSecondCol(const STPoint& curr_point) const {
    STPoint first_point = cost_table_[0][0];
    double cost =
        GetVelCost(first_point, curr_point, speed_limit_) +
        GetAccCost(first_point, curr_point, vehicle_speed_) +
        GetJerkCost(vehicle_speed_, vehicle_acc_, first_point, curr_point);
    return cost;
}

double DPSearcher::CalculateCostForThirdCol(const STPoint& curr_point,
                                            const uint32_t s_pre_index) const {
    uint32_t t_index = static_cast<uint32_t>(curr_point.t() / t_resolution_);
    STPoint first_point = cost_table_[0][0];
    STPoint second_point = cost_table_[t_index - 1][s_pre_index];
    double cost =
        GetVelCost(second_point, curr_point, speed_limit_) +
        GetAccCost(first_point, second_point, curr_point) +
        GetJerkCost(vehicle_speed_, first_point, second_point, curr_point);
    return cost;
}

double DPSearcher::CalculateEdgeCost(const STPoint& curr_point,
                                     const uint32_t& s_pre_index) const {
    uint32_t t_index = static_cast<uint32_t>(curr_point.t() / t_resolution_);
    STPoint pre_point = cost_table_[t_index - 1][s_pre_index];
    STPoint prepre_point = *pre_point.pre_point();
    STPoint tripre_point = *prepre_point.pre_point();
    double cost =
        GetVelCost(pre_point, curr_point, speed_limit_) +
        GetAccCost(prepre_point, pre_point, curr_point) +
        GetJerkCost(tripre_point, prepre_point, pre_point, curr_point);
    return cost;
}

void DPSearcher::CalcNextAvailabelSIndex(const uint32_t t_index,
                                         uint32_t* s_index_low,
                                         uint32_t* s_index_upp) {
    *s_index_low = 0;
    *s_index_upp = num_s_ - 1;
    double t = static_cast<double>((t_index + 1) * t_resolution_);
    double s_min = vehicle_speed_ * t + 0.5 * max_deacc_ * t * t;
    double s_max = vehicle_speed_ * t + 0.5 * max_acc_ * t * t;
    if (s_min > (s_resolution_ / 2.0)) {
        *s_index_low =
            std::max(static_cast<uint32_t>(std::floor(s_min / s_resolution_)),
                     *s_index_low);
    }
    *s_index_upp = std::min(
        *s_index_upp, static_cast<uint32_t>(std::ceil(s_max / s_resolution_)));
    AD_LDEBUG(DPSearcher) << "s_min " << s_min << " s_max " << s_max;
}

adStatus_t DPSearcher::ConstructCostTable() {
    reacheable_time_ = 0.0;
    // 1. initializate cost table
    cost_table_ = std::vector<std::vector<STPoint>>(
        num_t_, std::vector<STPoint>(num_s_, STPoint()));
    // 2. calculate cost at each st_point
    uint32_t next_highest_row = 0;
    uint32_t next_lowest_row = 0;
    for (uint32_t t_index = 0; t_index < num_t_; ++t_index) {
        bool is_reacheable = false;
        for (uint32_t s_index = next_lowest_row; s_index <= next_highest_row;
             ++s_index) {
            cost_table_[t_index][s_index].SetT(t_index * t_resolution_);
            cost_table_[t_index][s_index].SetS(s_index * s_resolution_);
            if (CalculateCostAt(cost_table_[t_index][s_index]) == true) {
                is_reacheable = true;
            }
        }
        if (is_reacheable == true) {
            reacheable_time_ = static_cast<double>(t_index) * t_resolution_;
        } else {
            return AD_SUCCESS;
        }
        CalcNextAvailabelSIndex(t_index, &next_lowest_row, &next_highest_row);
        AD_LDEBUG(DPSearcher) << "t_index " << t_index << " lowerst index "
                              << next_lowest_row << ", next_highest_row "
                              << next_highest_row;
    }
    return AD_SUCCESS;
}

adStatus_t DPSearcher::GenerateSpeedProfile(std::vector<double>* out_path) {
    if (nullptr == out_path) {
        AD_LERROR(DPSearcher) << "out_path is nullptr";
        return AD_NULL_PTR;
    }
    out_path->clear();
    double min_cost = kMax;
    const STPoint* min_cost_point = nullptr;
    // 1. find min cost in last col i.e. at t_end
    uint32_t t_end_index =
        static_cast<uint32_t>(reacheable_time_ / t_resolution_);
    for (uint32_t s_index = 0; s_index < num_s_; ++s_index) {
        if (min_cost > cost_table_[t_end_index][s_index].cost()) {
            min_cost_point = &cost_table_[t_end_index][s_index];
            min_cost = cost_table_[t_end_index][s_index].cost();
        }
    }
    // 2. find min cost in last row i.e. at s_end
    for (uint32_t t_index = 0; t_index < num_t_; ++t_index) {
        if (min_cost > cost_table_[t_index][num_s_ - 1].cost()) {
            min_cost_point = &cost_table_[t_index][num_s_ - 1];
            min_cost = cost_table_[t_index][num_s_ - 1].cost();
        }
    }
    // gerenate speed profile
    while (min_cost_point != nullptr) {
        out_path->emplace_back(min_cost_point->s());
        min_cost_point = min_cost_point->pre_point();
    }
    std::reverse(out_path->begin(), out_path->end());
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
