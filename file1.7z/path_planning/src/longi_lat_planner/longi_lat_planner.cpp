/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include "path_planning/longi_lat_planner/longi_lat_planner.hpp"

namespace senseAD {
namespace pp {

adStatus_t LongiLatPlanner::Init(const std::string& config) {
    auto core_conf = g_pp_conf["longi_lat_core"];
    // parameters of searcher and optimizer
    int searcher_id = core_conf["searcher"];
    int optimizer_id = core_conf["optimizer"];

    // parameters of planning horizons and resolutions
    s_horizon_ = core_conf["s_horizon"];
    s_resolution_ = core_conf["s_resolution"];
    t_horizon_ = core_conf["t_horizon"];
    t_resolution_ = core_conf["t_resolution"];

    // parameters of vehicle
    auto veh_conf = g_pp_conf["vehicle_setting"];
    g_vehicle_param.width = veh_conf["car_width"];
    g_vehicle_param.length = veh_conf["car_length"];
    g_vehicle_param.curb_weight = veh_conf["car_weight"];
    g_vehicle_param.min_turning_radius = veh_conf["min_turn_radius"];

    // parameters of calculation
    auto dqq_setting = g_pp_conf["dqq_setting"];
    frent_resolution_ = dqq_setting["frenet_resolution"];
    routing_interval_ = dqq_setting["routing_interval"];
    int num_look_back_tmp = dqq_setting["num_look_back"];
    num_look_back_ = static_cast<uint32_t>(num_look_back_tmp);
    max_brake_acc_ = dqq_setting["max_brake_acc"];
    speed_limit_ = dqq_setting["speed_limit"];
    speed_ref_ = dqq_setting["speed_ref"];
    longi_safe_distance_ = dqq_setting["longi_safe_distance"];
    stop_line_buffer_ = dqq_setting["stop_line_buffer"];
    follow_time_ = dqq_setting["follow_time"];
    overspeed_percentage_ = dqq_setting["overspeed_percentage"];
    longi_w_ref_ = dqq_setting["longi_w_ref"];
    longi_w_first_order_ = dqq_setting["longi_w_first_order"];
    longi_w_second_order_ = dqq_setting["longi_w_second_order"];
    longi_w_third_order_ = dqq_setting["longi_w_third_order"];
    longi_w_start_ = dqq_setting["longi_w_start"];
    longi_decay_rate_ = dqq_setting["longi_decay_rate"];
    lateral_safe_distance_ = dqq_setting["lateral_safe_distance"];
    lateral_w_ref_ = dqq_setting["lateral_w_ref"];
    lateral_w_first_order_ = dqq_setting["lateral_w_first_order"];
    lateral_w_second_order_ = dqq_setting["lateral_w_second_order"];
    lateral_w_third_order_ = dqq_setting["lateral_w_third_order"];
    lateral_decay_rate_ = dqq_setting["lateral_decay_rate"];
    replan_leading_speed_threshold_ =
        dqq_setting["replan_leading_speed_threshold"];
    nbo_reponse_range_ = dqq_setting["nbo_reponse_range"];

    // 1. intializer parser or interface
    scene_interface_.Init();
    frenet_system_.reset(new FrenetCoordinateSystem());
    frenet_system_->Init();

    // 2. initialize searcher
    if (searcher_id == 1) {
        auto func_obs_cost =
            std::bind(&Parser::GetObstacleCost, &scene_interface_,
                      std::placeholders::_1, std::placeholders::_2,
                      std::placeholders::_3, std::placeholders::_4);
        searcher_.reset(new DPSearcher(s_horizon_, s_resolution_, t_horizon_,
                                       t_resolution_, func_obs_cost));
    } else {
        AD_LERROR(PATH_PLANNING) << "invalid searcher";
        return AD_INVALID_PARAM;
    }

    // 3. initialize longitudinal and lateral optimizer
    if (optimizer_id == 1) {
        longi_optimizer_.reset(new QPOptimizer());
        lat_optimizer_.reset(new QPOptimizer());
    } else {
        AD_LERROR(PATH_PLANNING) << "invalid optimizer";
        return AD_INVALID_PARAM;
    }
    AD_LINFO(PLANNING) << "LongiLatPlanner initialized";
    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::Plan(std::vector<TrajectoryPoint>* out_path) {
    if (out_path == nullptr || BasePathPlanner::base_path_.forward.empty()) {
        AD_LERROR(PLANNER) << "out_path pointer is nullptr or bpp in empty";
        return AD_NULL_PTR;
    }
    out_path->clear();

    use_cashed_path_flag_ = false;
    // 1. update origin_state, scene interface and cached path
    // calculate moving distance of frenet coordinate system origin
    senseAD::TimingLoggerSharedGuard time_logger(TIME_LOGGER_CONTEXT);

    time_logger.Start("LongiLatPlanner::SceneUpdate");
    // hack for lane change
    bool lane_change_activated = (dm_target_.signal_blub != 0) &&
                                 (dm_target_.state != DMTarget::State::ONCROSS);
    if (scene_interface_.Update(rs_, poa_, frenet_system_,
                                PlanningScenario::LANE_KEEPING,
                                lane_change_activated) != AD_SUCCESS) {
        AD_LERROR(PLANNING) << "update secne interface failed";
        return AD_INVALID_PARAM;
    }
    time_logger.End();

    time_logger.Start("LongiLatPlanner::UpdateCachedPath");
    if (UpdateCachedPath() != AD_SUCCESS) {
        AD_LERROR(LongiLatPlanner) << "update cached path failed";
        return AD_SUCCESS;
    }

    time_logger.End();
    time_logger.Start("LongiLatPlanner::UpdateInitalState");
    if (UpdateInitalState() != AD_SUCCESS) {
        AD_LERROR(LongiLatPlanner)
            << "update vehicle initial planning state failed";
        return AD_SUCCESS;
    }
    time_logger.End();
    // 2. determine if recycle or not
    time_logger.Start("LongiLatPlanner::ShouldRecycle");
    std::vector<double> longi_search_result, longi_result, lateral_result;
    // tmp method to calculate speed limit
    curr_speed_ref_ = speed_ref_;
    curr_s_ref_ = 200.0;
    curr_speed_limit_ = speed_limit_;
    if (dm_target_.dm_velocity > 1.0) {
        curr_speed_ref_ = dm_target_.dm_velocity;
        curr_speed_limit_ =
            std::min(speed_limit_, curr_speed_ref_ * overspeed_percentage_);
    }

    if (ShouldRecycle() == false) {
        time_logger.End();
        AD_LINFO(LongiLatPlanner) << "replan";
        bool is_brake = false;
        // 3. st_graph search
        time_logger.Start("LongiLatPlanner::LongitudinalSearch");
        if (LongitudinalSearch(&longi_search_result) != AD_SUCCESS) {
            AD_LERROR(LongiLatPlanner) << "longitudinal serach failed";
            ApplyFallback(&longi_result, &lateral_result, out_path);
            is_brake = true;
        }
        time_logger.End();
        time_logger.Start("LongiLatPlanner::LongitudinalOptimize");

        // 4. longitudinal optimize
        if (is_brake == false &&
            LongitudinalOptimize(longi_search_result, &longi_result) !=
                AD_SUCCESS) {
            AD_LERROR(LongiLatPlanner) << "longitudinal optimization failed";
            ApplyFallback(&longi_result, &lateral_result, out_path);
            is_brake = true;
        }
        time_logger.End();
        time_logger.Start("LongiLatPlanner::LateralOptimize");

        // 5. lateral optimize
        if (is_brake == false) {
            std::vector<double> longi_result_true(
                longi_result.begin() + num_look_back_, longi_result.end());
            if (LateralOptimize(longi_result_true, &lateral_result) !=
                AD_SUCCESS) {
                ApplyFallback(&longi_result, &lateral_result, out_path);
                AD_LERROR(LongiLatPlanner) << "lateral optimization failed";
                is_brake = true;
            }
        }
        time_logger.End();
        time_logger.Start("LongiLatPlanner::LateralOptimize");

        // 6. setting up trajectory point
        if (use_cashed_path_flag_ == false) {
            out_path->clear();
            time_logger.End();
            time_logger.Start("LongiLatPlanner::FillupTrajectory");
            if (FillupTrajectory(longi_result, lateral_result, out_path) !=
                AD_SUCCESS) {
                AD_LERROR(LongiLatPlanner) << "fill up trajectory failed";
                // ApplyFallback(out_path);
            }
            time_logger.End();
        }
        if (is_brake == false) {
            continous_solve_fail_ = 0;
        }

        cached_path_ = *out_path;
        if (is_brake == false) {
            is_last_brake_ = false;
        }
    } else {
        AD_LINFO(LongiLatPlanner) << "recycle";
        *out_path = cached_path_;
    }

    // update autodriving status
    if (vehicle_status_.AutoCtrlStat == 1) {
        last_autodriving_status_on_ = true;
    } else {
        last_autodriving_status_on_ = false;
    }

    // set turning signal blub
    auto SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
    switch (dm_target_.signal_blub) {
        case 0:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
            break;
        case 1:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_RIGHT;
            break;
        case 2:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_LEFT;
            break;
        default:
            SignalToFill = ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
            break;
    }
    for (uint32_t i = 0; i < out_path->size(); i++) {
        out_path->at(i).turn_signal = SignalToFill;
    }

    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::LongitudinalSearch(
    std::vector<double>* longi_result) {
    searcher_->Update(longi_speed_, longi_acc_, curr_speed_ref_);
    searcher_->Search(longi_result);
    if (longi_result->size() < 5) {
        AD_LERROR(LongiLatPlanner) << "longi_search size "
                                   << longi_result->size();
        return AD_INVALID_PARAM;
    }
    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::LongitudinalOptimize(
    const std::vector<double>& longi_search_result,
    std::vector<double>* longi_result) {
    // longi_upper_rate_limit_ = curr_speed_limit_;
    // calculate stop distance base on dm velocity and index
    stop_distance_ = 10000.0;
    if (dm_target_.dm_velocity < 0.2 && dm_target_.velocity_flag == 1) {
        constexpr double stop_line_ref_speed = 20.0 / 3.6;  // unit, m/s
        stop_distance_ = std::max(0.2 * dm_target_.dm_velocity_index, 0.0);
        // TODO(Shengfa) hack for stop line, maybe not hack
        curr_speed_ref_ = std::min(stop_line_ref_speed, curr_speed_ref_);
    }
    AD_LINFO(OBJECT_MAP) << "stop distance " << stop_distance_;

    std::vector<double> lower_bound, upper_bound, ref;
    planning_log_.obstacle_tag =
        scene_interface_.GetObstacleTag(longi_search_result);
    std::vector<double> t_seq(longi_search_result.size(), 0.0);
    for (uint32_t i = 0; i < t_seq.size(); ++i) {
        t_seq.at(i) = i * t_resolution_;
    }

    scene_interface_.GetLongiBoundAndRef(
        t_seq, longi_s_, longi_speed_, longi_acc_, curr_s_ref_, curr_speed_ref_,
        &lower_bound, &upper_bound, &ref);

    for (uint32_t i = 0; i < upper_bound.size() && i < ref.size(); ++i) {
        upper_bound.at(i) =
            std::min(stop_distance_ - stop_line_buffer_, upper_bound.at(i));
        lower_bound.at(i) =
            std::min(upper_bound.at(i) - 0.1, lower_bound.at(i));
        ref.at(i) = std::min(
            ref.at(i),
            std::max(stop_distance_ - stop_line_buffer_ * 1.5, longi_s_));
    }

    // fix start point
    const uint32_t fix_point_num = 1;
    for (uint32_t i = 0; i < fix_point_num && i < upper_bound.size(); ++i) {
        double t = static_cast<double>(i) * t_resolution_;
        double s = longi_s_ + t * longi_speed_ + 0.5 * longi_acc_ * t * t;
        upper_bound.at(i) = s + 0.00001;
        lower_bound.at(i) = s - 0.00001;
    }

    // look back to make sure initial acc and jerk are calculated
    std::vector<double> ref_back(num_look_back_, 0.0),
        upper_bound_back(num_look_back_, 0.0),
        lower_bound_back(num_look_back_, 0.0);
    for (uint32_t i = 0; i < num_look_back_; i = i + 1) {
        double t = static_cast<double>(static_cast<int>(i) -
                                       static_cast<int>(num_look_back_)) *
                   t_resolution_;
        double s = longi_s_ + longi_speed_ * t + 0.5 * longi_acc_ * t * t;
        ref_back.at(i) = s;
        lower_bound_back.at(i) = (s - 0.0001);
        upper_bound_back.at(i) = (s + 0.0001);
    }
    ref.insert(ref.begin(), ref_back.begin(), ref_back.end());
    lower_bound.insert(lower_bound.begin(), lower_bound_back.begin(),
                       lower_bound_back.end());
    upper_bound.insert(upper_bound.begin(), upper_bound_back.begin(),
                       upper_bound_back.end());
    // override bounds in case they violate rate constraints
    double min_x = -1000.0, max_x = 1000.0;
    for (uint32_t i = 1; i < lower_bound.size(); ++i) {
        assert(lower_bound.at(i) < upper_bound.at(i));
        min_x = std::max(min_x, lower_bound.at(i - 1)) +
                longi_lower_rate_limit_ * t_resolution_;
        max_x = std::min(max_x, upper_bound.at(i - 1)) +
                longi_upper_rate_limit_ * t_resolution_;
        if (lower_bound.at(i) > max_x) {
            lower_bound.at(i) = max_x - 0.1;
        }
        if (upper_bound.at(i) < min_x) {
            upper_bound.at(i) = min_x + 0.1;
        }
    }

    if (longi_optimizer_->Update(
            last_longi_path_, ref, lower_bound, upper_bound, num_look_back_,
            QPConfig(
                longi_lower_limit_, longi_upper_limit_, longi_lower_rate_limit_,
                longi_upper_rate_limit_, longi_lower_second_deriv_limit_,
                longi_upper_second_deriv_limit_, longi_lower_third_deriv_limit_,
                longi_upper_third_deriv_limit_, longi_w_ref_,
                longi_w_first_order_, longi_w_second_order_,
                longi_w_third_order_, longi_w_start_, longi_decay_rate_),
            QPConfig(longi_lower_limit_, longi_upper_limit_,
                     longi_lower_rate_limit_, longi_upper_rate_limit_, -100.0,
                     100.0, -100.0, 100.0, longi_w_ref_, longi_w_first_order_,
                     longi_w_second_order_, longi_w_third_order_,
                     longi_w_start_, longi_decay_rate_)) != AD_SUCCESS) {
        AD_LINFO(LongiLatPlanner) << "longi optimizer update failed";
        return AD_INVALID_PARAM;
    }
    if (longi_optimizer_->Solve(longi_result) != AD_SUCCESS) {
        AD_LINFO(LongiLatPlanner) << "longi optimization solve failed";
        return AD_INVALID_PARAM;
    }

    // save cached path
    last_longi_path_ = *longi_result;
    if (longi_result->size() < 5) {
        AD_LERROR(LongiLatPlanner) << "longi_optimizer size "
                                   << longi_result->size();
        return AD_NULL_PTR;
    }
    AD_LINFO(LongiLatPlanner) << "longi result size " << longi_result->size();
    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::LateralOptimize(
    const std::vector<double>& longi_result,
    std::vector<double>* lateral_result) {
    std::vector<double> lower_bound, upper_bound, ref;
    std::vector<double> t_seq(longi_result.size(), 0.0);
    for (uint32_t i = 0; i < t_seq.size(); ++i) {
        t_seq.at(i) = i * t_resolution_;
    }
    scene_interface_.GetLateralBoundAndRef(t_seq, longi_result, &lower_bound,
                                           &upper_bound, &ref);

    // fix start point
    const uint32_t fix_point_num = 1;
    for (uint32_t i = 0; i < fix_point_num && i < upper_bound.size(); ++i) {
        double t = static_cast<double>(i) * t_resolution_;
        double d = lateral_d_ + t * lateral_speed_ +
                   0.5 * std::max(lateral_acc_, 0.2) * t * t + 0.0001;
        upper_bound.at(i) = d + 0.0001;
        lower_bound.at(i) = d - 0.0001;
    }

    // look back to make sure initial second and third derivative are
    // calculated
    std::vector<double> ref_back(num_look_back_, 0.0),
        upper_bound_back(num_look_back_, 0.0),
        lower_bound_back(num_look_back_, 0.0);
    for (uint32_t i = 0; i < num_look_back_; i = i + 1) {
        double t = static_cast<double>(static_cast<int>(i) -
                                       static_cast<int>(num_look_back_)) *
                   t_resolution_;
        double d = lateral_d_ + lateral_speed_ * t + 0.5 * lateral_acc_ * t * t;
        ref_back.at(i) = d;
        lower_bound_back.at(i) = (d - 0.0001);
        upper_bound_back.at(i) = (d + 0.0001);
    }
    ref.insert(ref.begin(), ref_back.begin(), ref_back.end());
    lower_bound.insert(lower_bound.begin(), lower_bound_back.begin(),
                       lower_bound_back.end());
    upper_bound.insert(upper_bound.begin(), upper_bound_back.begin(),
                       upper_bound_back.end());
    // override bounds in case they violate rate constraints
    double min_x = -1000.0, max_x = 1000.0;
    for (uint32_t i = 1; i < num_look_back_; ++i) {
        assert(lower_bound.at(i) < upper_bound.at(i));
        min_x = std::max(min_x, lower_bound.at(i - 1)) +
                lateral_lower_rate_limit_ * t_resolution_;
        max_x = std::min(max_x, upper_bound.at(i - 1)) +
                lateral_upper_rate_limit_ * t_resolution_;
        if (lower_bound.at(i) > max_x) {
            lower_bound.at(i) = max_x - 0.1;
        }
        if (upper_bound.at(i) < min_x) {
            upper_bound.at(i) = min_x + 0.1;
        }
    }

    if (lat_optimizer_->Update(
            last_lateral_path_, ref, lower_bound, upper_bound, num_look_back_,
            QPConfig(lateral_lower_limit_, lateral_upper_limit_,
                     lateral_lower_rate_limit_, lateral_upper_rate_limit_,
                     lateral_lower_second_deriv_limit_,
                     lateral_upper_second_deriv_limit_,
                     lateral_lower_third_deriv_limit_,
                     lateral_upper_third_deriv_limit_, lateral_w_ref_,
                     lateral_w_first_order_, lateral_w_second_order_,
                     lateral_w_third_order_, lateral_w_start_,
                     lateral_decay_rate_),
            QPConfig()) != AD_SUCCESS) {
        AD_LINFO(LongiLatPlanner) << "lateral optimizer update failed";
        return AD_INVALID_PARAM;
    }
    if (lat_optimizer_->Solve(lateral_result) != AD_SUCCESS) {
        AD_LINFO(LongiLatPlanner) << "lateral optimizer solve failed";
        return AD_INVALID_PARAM;
    }
    last_lateral_path_ = *lateral_result;
    if (lateral_result->size() < 5) {
        AD_LERROR(LongiLatPlanner) << "lateral_optimizte size "
                                   << lateral_result->size();
        return AD_INVALID_PARAM;
    }
    AD_LINFO(LongiLatPlanner) << "lateral result size "
                              << lateral_result->size();
    return AD_SUCCESS;
}

bool LongiLatPlanner::ShouldRecycle() {
    // disable recycle for now
    return false;
    // 1. if auto driving status is off, refuse recycle
    if (vehicle_status_.AutoCtrlStat != 1) {
        return false;
    }

    // 2. refuse recycle emergency brake trajectory
    if (is_last_brake_ == true) {
        AD_LINFO(LongiLatPlanner) << "last trajectory is emergency brake";
        return false;
    }

    // 3. check cached path length
    const double min_recycle_path_length_ = 30.0;
    if (cached_path_.empty() == true ||
        cached_path_.back().sum_distance - cached_path_.front().sum_distance <
            min_recycle_path_length_) {
        AD_LINFO(LongiLatPlanner) << "cached_path is empty or short";
        return false;
    }

    // 4. check collision of cached path
    // TODO(Shengfa) set collision checkout range related to velocity
    uint32_t collided_index = 0;
    const uint32_t collision_check_range_ = 200;  // 40m
    scene_interface_.CheckCollision(cached_path_, collision_check_range_,
                                    &collided_index);
    if (collided_index < collision_check_range_) {
        AD_LINFO(LongiLatPlanner) << "cached path collied at "
                                  << collided_index;
        return false;
    }

    // 5. compare current speed and speed limit, in order to decrease speed when
    // coming into junction in time
    if (g_vehicle_state.velocity > curr_speed_limit_) {
        AD_LINFO(LongiLatPlanner) << "exceed speed "
                                  << "curr speed " << g_vehicle_state.velocity
                                  << ", speed limit " << curr_speed_limit_;
        return false;
    }

    // 7. evaluate mobility efficiency
    const uint32_t num_acc_counter_ = 5;
    const double effective_acc_threshold_ = 0.4;
    double average_acc = 0.0;
    uint32_t i = 0;
    for (; i < std::min(num_acc_counter_,
                        static_cast<uint32_t>(cached_path_.size()));
         ++i) {
        average_acc = average_acc + cached_path_.at(i).acceleration;
    }
    average_acc = average_acc / static_cast<double>(i + 1);

    auto t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    uint64_t curr_time =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 1000);
    AD_LINFO(LongiLatPlanner) << "t now " << curr_time / 1.0e9;

    double max_planning_dist =
        curr_speed_ref_ * static_cast<double>(cached_path_.back().timestamp -
                                              cached_path_.front().timestamp) /
        1.0e9;
    constexpr double mobility_efficency_threshold_ = 0.85;
    if (average_acc < effective_acc_threshold_ &&
        ((cached_path_.back().sum_distance -
          cached_path_.front().sum_distance) <
         mobility_efficency_threshold_ * max_planning_dist)) {
        AD_LINFO(LongiLatPlanner) << "low mobility efficency, "
                                  << "max planning dist " << max_planning_dist
                                  << " cached planning dist "
                                  << cached_path_.back().sum_distance -
                                         cached_path_.front().sum_distance
                                  << " ,average_acc " << average_acc;
        return false;
    }
    return true;
}

adStatus_t LongiLatPlanner::UpdateCachedPath() {
    auto t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    uint64_t curr_timestamp =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 1000);
    bool entering_autodriving = false;
    if (last_autodriving_status_on_ == false &&
        vehicle_status_.AutoCtrlStat == 1) {
        entering_autodriving = true;
    }

    cv::Point2f vehicle_cart =
        cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    cv::Point2f vehicle_frenet = frenet_system_->Cartesian2Frenet(vehicle_cart);
    if (cached_path_.empty() || entering_autodriving == true) {
        AD_LERROR(LongiLatPlanner) << "cached path is empty, use vehicle state "
                                      "to calculate last trajctory";
        float s = vehicle_frenet.x, d = vehicle_frenet.y;
        last_longi_path_.clear();
        last_lateral_path_.clear();
        const uint32_t num_initial_point = 10;
        for (uint32_t i = 0; i < num_initial_point; ++i) {
            double t = static_cast<double>(i * t_resolution_);
            last_longi_path_.emplace_back(s + longi_speed_ * t);
            last_lateral_path_.emplace_back(d + lateral_speed_ * t);
        }
        origin_point_.s = s;
        origin_point_.d = d;
        float heading_bpp = frenet_system_->GetHeadingAtS(s);
        double tanv = tan(vehicle_info_.steering_angle / 14.8) / 2.0;
        double v_heading = g_vehicle_state.heading + std::atan(tanv);
        double angle = v_heading - heading_bpp;
        double cos_angle = std::cos(angle);
        double sin_angle = std::sin(angle);
        origin_point_.ds = g_vehicle_state.velocity * cos_angle;
        origin_point_.dd = g_vehicle_state.velocity * sin_angle;
        // heading of veloctiy doesnot equal to heading of acceleration,
        // but accurate heading of accerelation is hard to calculated
        origin_point_.dds = g_vehicle_state.acceleration * cos_angle;
        origin_point_.ddd = g_vehicle_state.acceleration * sin_angle;
        last_timestamp_ = curr_timestamp;
        return AD_SUCCESS;
    }

    // 1. set planning origin
    // update by time
    // update by distance
    double time_passed =
        curr_timestamp > last_timestamp_
            ? static_cast<double>(curr_timestamp - last_timestamp_) / 1.0e9
            : 0.1;
    last_timestamp_ = curr_timestamp;
    AD_LINFO(LongiLatPlanner) << "time passed " << time_passed;

    PlanningState ideal_point;

    polynomial<double> longi_first_deriv = longi_poly_.differential();
    polynomial<double> lateral_first_deriv = lateral_poly_.differential();
    polynomial<double> longi_second_deriv = longi_first_deriv.differential();
    polynomial<double> lateral_second_deriv =
        lateral_first_deriv.differential();
    ideal_point.s = longi_poly_(time_passed) - frenet_origin_move_vec_.x;
    ideal_point.ds = longi_first_deriv(time_passed);
    ideal_point.dds = longi_second_deriv(time_passed);
    ideal_point.d = lateral_poly_(time_passed) - frenet_origin_move_vec_.y;
    ideal_point.dd = lateral_first_deriv(time_passed);
    ideal_point.ddd = lateral_second_deriv(time_passed);

    double velocity_error =
        std::fabs(ideal_point.velocity() - g_vehicle_state.velocity);
    float s_ego = vehicle_frenet.x;

    double position_error = std::fabs(s_ego - ideal_point.s);

    const double update_origin_velocity_threshold_ = 1.0;
    // TODO(Shengfa) TBD disable position error for now
    const double update_origin_position_threshold_ = 1.5;
    AD_LINFO(LongiLatPlanner) << "velocity_error " << velocity_error
                              << ", position error " << position_error;
    if (velocity_error > update_origin_velocity_threshold_ ||
        position_error > update_origin_position_threshold_) {
        AD_LINFO(LongiLatPlanner) << "using vehicle state as planning origin";
        origin_point_.s = vehicle_frenet.x;
        origin_point_.d = vehicle_frenet.y;
        double tanv = tan(vehicle_info_.steering_angle / 14.8) / 2.0;
        double v_heading = g_vehicle_state.heading + std::atan(tanv);
        float heading_bpp = frenet_system_->GetHeadingAtS(vehicle_frenet.x);
        double angle = v_heading - heading_bpp;
        AD_LINFO(LongiLatPlanner) << "v_heading is " << v_heading << ", "
                                  << "heading bpp " << heading_bpp;
        origin_point_.ds = g_vehicle_state.velocity * std::cos(angle);
        origin_point_.dd = g_vehicle_state.velocity * std::sin(angle);
        // heading of veloctiy doesnot equals to heading of acceleration,
        // but accurate heading of accerelation is hard to calculated
        origin_point_.dds = g_vehicle_state.acceleration * std::cos(angle);
        origin_point_.ddd = g_vehicle_state.acceleration * std::sin(angle);
    } else {
        AD_LINFO(LongiLatPlanner) << "using last trajectory as planning origin";
        origin_point_ = ideal_point;
    }
    AD_LINFO(LongiLatPlanner) << "origin_point_ " << origin_point_;

    // 2. update last longitudinal and lateral result based fitted spline
    last_longi_path_.clear();
    last_lateral_path_.clear();
    double t = -1.0 * static_cast<double>(num_look_back_) * t_resolution_ +
               time_passed;
    double s_move_distance = longi_poly_(time_passed) - origin_point_.s;
    double d_move_distance = lateral_poly_(time_passed) - origin_point_.d;
    while (t < last_planning_horizon_) {
        last_longi_path_.emplace_back(longi_poly_(t) - s_move_distance);
        last_lateral_path_.emplace_back(lateral_poly_(t) - d_move_distance);
        t = t + t_resolution_;
    }

    // 3. update cached trajectory to curr vehicle state
    constexpr double search_range = 10.0;
    auto curr_position = cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    int closest_index = static_cast<int>(
        utils::MatchClosestPoint(cached_path_, 0, curr_position, search_range));
    AD_LINFO(PATH_PLANNING) << "closest_index: " << closest_index;
    if (closest_index < static_cast<int>(cached_path_.size())) {
        cached_path_ = Trajectory(cached_path_.begin() + closest_index,
                                  cached_path_.end());
        utils::UpdateSumDistance(&cached_path_, curr_position);
    }

    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::FillupTrajectory(
    const std::vector<double>& longi_result,
    const std::vector<double>& lateral_result,
    std::vector<TrajectoryPoint>* out_path) {
    assert(longi_result.size() > 2);
    if (out_path == nullptr) {
        AD_LERROR(LongiLatPlanner) << "out_path pointer is nullptr";
        return AD_NULL_PTR;
    }
    // 1. frenet to cartesian
    std::vector<TrajectoryPoint> tmp_path;
    for (uint32_t i = num_look_back_;
         i < static_cast<uint32_t>(
                 std::min(longi_result.size(), lateral_result.size()));
         ++i) {
        TrajectoryPoint tjp;
        tjp.position = frenet_system_->Frenet2Cartesian(longi_result.at(i),
                                                        lateral_result.at(i));
        tmp_path.emplace_back(tjp);
    }
    // 2. calculate velocity, acceleration (scalar), only consider
    // longitudianl
    std::vector<double> t_seq;
    auto common_size = std::min(longi_result.size(), lateral_result.size());
    for (uint32_t i = 0; i < common_size; ++i) {
        t_seq.emplace_back(
            (static_cast<double>(i) - static_cast<double>(num_look_back_)) *
            t_resolution_);
    }
    std::vector<double> tmp_longi_result(longi_result.begin(),
                                         longi_result.begin() + common_size);
    std::vector<double> tmp_lateral_result(
        lateral_result.begin(), lateral_result.begin() + common_size);
    last_planning_horizon_ = t_seq.back();
    std::vector<double> longi_init_derivs = {longi_s_, longi_speed_,
                                             longi_acc_};
    std::vector<double> lateral_init_derivs = {lateral_d_, lateral_speed_,
                                               lateral_acc_};
    utils::FitPolynomialDerivs<double>(
        t_seq, tmp_longi_result, longi_init_derivs, poly_order_, &longi_poly_);
    utils::FitPolynomialDerivs<double>(t_seq, tmp_lateral_result,
                                       lateral_init_derivs, poly_order_,
                                       &lateral_poly_);
    polynomial<double> longi_first_deriv = longi_poly_.differential();
    polynomial<double> lateral_first_deriv = lateral_poly_.differential();
    polynomial<double> longi_second_deriv = longi_first_deriv.differential();
    polynomial<double> lateral_second_deriv =
        lateral_first_deriv.differential();
    polynomial<double> longi_third_deriv = longi_second_deriv.differential();
    polynomial<double> lateral_third_deriv =
        lateral_second_deriv.differential();
    for (uint32_t i = 0; i < tmp_path.size(); ++i) {
        uint32_t ii = i + num_look_back_;
        // calculate velocity and acceleration with spline interpolation
        tmp_path.at(i).velocity = longi_first_deriv(t_seq.at(ii));
        tmp_path.at(i).acceleration = longi_second_deriv(t_seq.at(ii));
    }
    // set planning log for longitudinal control
    constexpr double traj_time_interval = 0.02;  // unit, s
    constexpr double traj_time_length = 1.0;     // unit, s
    constexpr double traj_target_time = 0.02;    // unit, s
    planning_log_.time_interval = traj_time_interval;
    planning_log_.num = static_cast<int>(traj_time_length / traj_time_interval);
    planning_log_.s.clear();
    planning_log_.x.clear();
    planning_log_.y.clear();
    planning_log_.v.clear();
    planning_log_.a.clear();
    planning_log_.jerk.clear();

    planning_log_.s.reserve(planning_log_.num);
    planning_log_.x.reserve(planning_log_.num);
    planning_log_.y.reserve(planning_log_.num);
    planning_log_.v.reserve(planning_log_.num);
    planning_log_.a.reserve(planning_log_.num);
    planning_log_.jerk.reserve(planning_log_.num);
    for (auto i = 0; i < planning_log_.num; ++i) {
        double t = static_cast<double>(i) * traj_time_interval;
        double curr_s = longi_poly_(t);
        double curr_d = lateral_poly_(t);
        TrajectoryPoint tjp;
        tjp.position = frenet_system_->Frenet2Cartesian(curr_s, curr_d);
        planning_log_.s.emplace_back(curr_s);
        planning_log_.x.emplace_back(tjp.position.x);
        planning_log_.y.emplace_back(tjp.position.y);
        planning_log_.v.emplace_back(longi_first_deriv(t));
        planning_log_.a.emplace_back(longi_second_deriv(t));
        planning_log_.jerk.emplace_back(longi_third_deriv(t));
    }
    planning_log_.lateral_d = lateral_poly_(traj_target_time);
    planning_log_.lateral_v = lateral_first_deriv(traj_target_time);
    planning_log_.lateral_a = lateral_second_deriv(traj_target_time);

    constexpr double zero_velocity_threshold_ = 0.3;
    constexpr double zero_acceleration_threshold_ = 0.1;
    bool set_zero_before_seg = false;
    for (uint32_t i = 0; i < tmp_path.size(); ++i) {
        if (tmp_path.at(i).velocity < zero_velocity_threshold_ &&
            tmp_path.at(i).acceleration < zero_acceleration_threshold_) {
            tmp_path.at(i).velocity = 0.0;
            tmp_path.at(i).acceleration = 0.0;
            set_zero_before_seg = true;
        } else if (tmp_path.at(i).velocity < 0.001) {
            tmp_path.at(i).velocity = 0.0;
        }
        tmp_path.at(i).yaw_rate = 0.0;
    }
    if (set_zero_before_seg == true) {
        AD_LINFO(LongiLatPlanner) << "set zero before segmentation";
    }
    const bool debug_print = true;
    AD_LINFO(LongiLatPlanner) << "DQQ result";
    if (debug_print == true) {
        for (uint32_t i = 0; i < tmp_path.size(); ++i) {
            if (i + num_look_back_ <
                std::min(longi_result.size(), lateral_result.size())) {
                AD_LINFO(LongiLatPlanner)
                    << i << ", " << longi_result.at(i + num_look_back_) << ", "
                    << lateral_result.at(i + num_look_back_) << ", "
                    << tmp_path.at(i).position << ", "
                    << tmp_path.at(i).velocity << ", "
                    << tmp_path.at(i).acceleration;
            } else {
                AD_LINFO(LongiLatPlanner) << i << ", "
                                          << tmp_path.at(i).position << ", "
                                          << tmp_path.at(i).velocity << ", "
                                          << tmp_path.at(i).acceleration;
            }
        }
    }

    // 3. elongate if trajectory is short
    const double trajectory_insert_interval = 0.2;
    const double min_trajectory_ = 30.0;
    if (tmp_path.empty() == false && longi_result.empty() == false &&
        longi_result.back() < min_trajectory_) {
        PathElongation(&tmp_path, trajectory_insert_interval);
    }

    // 4. segment trajectory with equal distance and set time stamp
    utils::SegmentTrajectory(tmp_path, trajectory_insert_interval, out_path);
    utils::SetTimestamp(out_path, trajectory_insert_interval);
    // 5. set yaw_rate to zero
    bool set_zero_after_seg = false;
    for (uint32_t i = 0; i < out_path->size(); ++i) {
        if (out_path->at(i).velocity < zero_velocity_threshold_ &&
            out_path->at(i).acceleration < zero_acceleration_threshold_) {
            out_path->at(i).velocity = 0.0;
            out_path->at(i).acceleration = 0.0;
            set_zero_after_seg = true;
        } else if (out_path->at(i).velocity < 0.0) {
            out_path->at(i).velocity = 0.0;
        }
        out_path->at(i).yaw_rate = 0.0;
    }
    if (set_zero_after_seg == true) {
        AD_LINFO(LongiLatPlanner) << "set zero after segmentation";
    }

    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::UpdateInitalState() {
    AD_LINFO(LongiLatPlanner) << "vehicle state " << g_vehicle_state.x << ", "
                              << g_vehicle_state.y;
    longi_s_ = origin_point_.s;
    lateral_d_ = origin_point_.d;
    longi_speed_ = origin_point_.ds;
    lateral_speed_ = origin_point_.dd;
    longi_acc_ = origin_point_.dds;
    lateral_acc_ = origin_point_.ddd;
    AD_LINFO(LongiLatPlanner)
        << "planning initial longitudinal state : " << longi_s_ << ", "
        << longi_speed_ << ", " << longi_acc_;
    AD_LINFO(LongiLatPlanner)
        << "planning initial lateral state : " << lateral_d_ << ", "
        << lateral_speed_ << ", " << lateral_acc_;
    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::ApplyEmergencyBrake(
    std::vector<double>* longi_s,
    std::vector<double>* lateral_d,
    std::vector<TrajectoryPoint>* out_path) {
    is_last_brake_ = true;
    longi_s->clear();
    lateral_d->clear();
    std::vector<double> lon_acc, lon_vel;
    const int t_dim_ = 41;

    for (uint32_t k = 0; k < num_look_back_; ++k) {
        lon_acc.push_back(longi_acc_);
        lon_vel.push_back(longi_speed_);
        longi_s->push_back(longi_s_);
        lateral_d->push_back(lateral_d_);
    }

    // wdk::add frenet const jerk brake
    for (int j = static_cast<int>(num_look_back_) - 1; j >= 0; --j) {
        if (j == (static_cast<int>(num_look_back_) - 1)) {
            lon_vel.at(j) = longi_speed_ - longi_acc_ * t_resolution_;
            longi_s->at(j) =
                longi_s_ - t_resolution_ * (lon_vel.at(j) + longi_speed_) / 2.0;
        } else {
            lon_vel.at(j) = lon_vel.at(j + 1) - longi_acc_ * t_resolution_;
            longi_s->at(j) =
                longi_s->at(j + 1) -
                t_resolution_ * (lon_vel.at(j) + lon_vel.at(j + 1)) / 2.0;
        }
    }

    for (uint32_t i = num_look_back_; i < t_dim_ + num_look_back_; ++i) {
        if (i == num_look_back_) {
            longi_s->push_back(longi_s_);
            lon_acc.push_back(longi_acc_);
            lon_vel.push_back(longi_speed_);
            lateral_d->push_back(lateral_d_);
        } else {
            lon_acc.push_back(
                std::max(lon_acc.at(i - 1) + max_brake_jerk_ * t_resolution_,
                         -max_brake_acc_));
            lon_vel.push_back(std::max(
                lon_vel.at(i - 1) +
                    t_resolution_ * (lon_acc.at(i - 1) + lon_acc.at(i)) / 2.0,
                0.0));
            longi_s->push_back(longi_s->at(i - 1) +
                               t_resolution_ *
                                   (lon_vel.at(i - 1) + lon_vel.at(i)) / 2.0);

            if (std::fabs(lateral_d_) < 0.05) {
                lateral_d->push_back(0.0);
            } else {
                lateral_d->push_back(
                    (static_cast<int>(t_dim_) - 1 - static_cast<int>(i)) *
                    lateral_d_ / (static_cast<int>(t_dim_) - 1));
            }
        }
    }
    AD_LERROR(LongiLatPlanner) << "EMERGENCY BRAKE";
    out_path->clear();
    return AD_SUCCESS;
}

adStatus_t LongiLatPlanner::ApplyFallback(
    std::vector<double>* longi_s,
    std::vector<double>* lateral_d,
    std::vector<TrajectoryPoint>* out_path) {
    if (continous_solve_fail_ > continous_solve_fail_threshold_) {
        AD_LERROR(LongiLatPlanner)
            << "continous_solve_fail_ times reach threshold";
        ApplyEmergencyBrake(longi_s, lateral_d, out_path);
    } else {
        uint32_t collided_index = 0;
        const uint32_t collision_check_range_ = 50;  // 10m
        scene_interface_.CheckCollision(cached_path_, collision_check_range_,
                                        &collided_index);
        if (collided_index < collision_check_range_) {
            AD_LINFO(LongiLatPlanner) << "cached path collied at "
                                      << collided_index;
            ApplyEmergencyBrake(longi_s, lateral_d, out_path);
        } else {
            AD_LERROR(LongiLatPlanner)
                << "something went wrong, using cached path";
            *out_path = cached_path_;
            use_cashed_path_flag_ = true;
        }
        continous_solve_fail_ += 1;
    }
    return AD_SUCCESS;
}

void LongiLatPlanner::PathElongation(std::vector<TrajectoryPoint>* path,
                                     const float insert_distance) const {
    float s = 0.0f, d = 0.0f;
    float velocity_to_append = 0;
    if (path->size() > 0) {
        auto path_end_tjpoint = path->back();
        auto frenet_point =
            frenet_system_->Cartesian2Frenet(path_end_tjpoint.position);
        s = frenet_point.x;
        d = frenet_point.y;
        velocity_to_append = path_end_tjpoint.velocity;
        AD_LINFO(PATH_PLANNING)
            << "path end velocity " << velocity_to_append << "\npath end "
            << path_end_tjpoint.position << " " << path_end_tjpoint.direction
            << " " << path_end_tjpoint.theta << "\npath end frenet" << s << " "
            << d;
    }
    std::vector<TrajectoryPoint> extended_path;
    constexpr float extend_length = 30.0f;
    for (float es = s + insert_distance; es < extend_length;
         es += insert_distance) {
        TrajectoryPoint trajpt_to_insert;
        trajpt_to_insert.position = frenet_system_->Frenet2Cartesian(es, d);
        extended_path.push_back(trajpt_to_insert);
        AD_LDEBUG(PATH_PLANNING) << "ELON traj pt to insert"
                                 << trajpt_to_insert.position;
    }

    std::vector<TrajectoryPoint> result_extended_path;
    result_extended_path.clear();
    utils::SegmentTrajectory(extended_path, insert_distance,
                             &result_extended_path);
    for (auto& pt : result_extended_path) {
        pt.velocity = velocity_to_append;
    }
    path->insert(path->end(), result_extended_path.begin(),
                 result_extended_path.end());
    utils::SegmentTrajectory(extended_path, insert_distance,
                             &result_extended_path);
}

}  // namespace pp
}  // namespace senseAD
