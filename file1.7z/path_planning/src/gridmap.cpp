/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include <math.h>
#include <queue>
#include <path_planning/common_structure.hpp>
#include "path_planning/gridmap.hpp"
#include "path_planning/util.hpp"

namespace senseAD {
namespace pp {
GridMap::GridMap() {}

GridMap::~GridMap() {}

adStatus_t GridMap::Init() {
    this->map_ww = 400;
    this->map_hh = 400;
    this->fix_bonnet_xx = 147;
    this->fix_bonnet_yy = 278;
    this->fix_bonnet_ww = 135;
    this->fix_bonnet_hh = 72;
    this->if_fix_bonnet = true;
    this->per_grid_meter = 0.2f;
    this->min_value_as_free = 8;
    this->as_free_measure_length = 10;
    this->if_optimize = true;
    this->out_as_free = 25;
    this->if_applybonnetfix_final = true;
    AD_LINFO(PATH_PLANNING) << "Gridmap Initing";
    // not for configuration
    dot_default_scalar = 1;
    init_draw_color = 1;
    this->map_maxrealw = this->map_ww * this->per_grid_meter / 2.0f;
    this->map_maxrealh = this->map_hh * this->per_grid_meter / 2.0f;
    map = cv::Mat(map_hh, map_ww, CV_8UC1, cv::Scalar(0));
    dot_map = cv::Mat(map_hh, map_ww, CV_8UC1, cv::Scalar(0));
    this->ifvisit.resize(map_hh * map_ww, false);
    qx.resize(this->map_ww * this->map_hh);
    qy.resize(this->map_ww * this->map_hh);

    AD_LINFO(PATH_PLANNING) << "Gridmap Inited";
    return AD_SUCCESS;
}

adStatus_t GridMap::Reconf() {
    AD_LINFO(PATH_PLANNING) << "Gridmap reconfiguring";
    dot_default_scalar = 1;
    init_draw_color = 1;
    this->map_maxrealw = this->map_ww * this->per_grid_meter / 2.0f;
    this->map_maxrealh = this->map_hh * this->per_grid_meter / 2.0f;
    map = cv::Mat(map_hh, map_ww, CV_8UC1, cv::Scalar(0));
    dot_map = cv::Mat(map_hh, map_ww, CV_8UC1, cv::Scalar(0));
    this->ifvisit.resize(map_hh * map_ww, false);
    qx.resize(this->map_ww * this->map_hh);
    qy.resize(this->map_ww * this->map_hh);
    AD_LINFO(PATH_PLANNING) << "Reconfig "
                            << "map_maxrealw" << this->map_maxrealw;
    AD_LINFO(PATH_PLANNING) << "Reconfig "
                            << "map_maxrealh" << this->map_maxrealh;
    AD_LINFO(PATH_PLANNING) << "Gridmap reconfiguring";
    return AD_SUCCESS;
}

adStatus_t GridMap::Update(roadStructure::RoadStructure<cv::Point2f> *rs,
                           ObjectTrajectory *object_trajectory) {
    AD_LINFO(PATH_PLANNING) << "Gridmap Updating input";
    if (rs == nullptr || object_trajectory == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    this->rs_ = rs;
    this->object_trajectory_ = object_trajectory;
    AD_LINFO(PATH_PLANNING) << "Gridmap Updated";
    return AD_SUCCESS;
}

adStatus_t GridMap::Update(roadStructure::RoadStructure<cv::Point2f> *rs) {
    AD_LINFO(PATH_PLANNING) << "Gridmap Updating input";
    if (rs == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    this->rs_ = rs;
    AD_LINFO(PATH_PLANNING) << "Gridmap Updated";
    return AD_SUCCESS;
}

adStatus_t GridMap::Refresh(int32_t type,
                            std::string road_id,
                            std::string l_lanelineid,
                            std::string r_lanelineid) {
    AD_LDEBUG(PATH_PLANNING) << "GridMap Refreshing";
    if (this->rs_ == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    this->centerenu.x = g_vehicle_state.x;
    this->centerenu.y = g_vehicle_state.y;
    auto begin = std::chrono::high_resolution_clock::now();
    this->draw_sr_freespacemap();
    this->crop_out_illegal_lanes_in_a_road(road_id);
    this->draw_cone_freespacemap();
    // TODO(congq): to be understood
    bool l_laneline_valid, r_laneline_valid;
    l_laneline_valid = r_laneline_valid = false;
    roadStructure::LaneLine<cv::Point2f> lanel, laner;
    auto road = this->rs_->road_map[road_id];
    auto laneline_map = road.lane_line_map;
    if (laneline_map.find(l_lanelineid) != laneline_map.end()) {
        lanel = laneline_map[l_lanelineid];
        l_laneline_valid = true;
    }
    if (laneline_map.find(r_lanelineid) != laneline_map.end()) {
        laner = laneline_map[r_lanelineid];
        r_laneline_valid = true;
    }
    if (l_laneline_valid && r_laneline_valid) {
        AD_LDEBUG(PATH_PLANNING) << "GridMap Refreshing both laneline exist";
        this->draw_laneline_dotmap(lanel, laner);
    }
    this->rewrite_freespacemap();
    auto end = std::chrono::high_resolution_clock::now();
    AD_LINFO(PATH_PLANNING)
        << "BUILD GRIDMAP TIME: "
        << std::chrono::duration_cast<std::chrono::microseconds>(end - begin)
               .count()
        << " us";
    std::chrono::milliseconds ms =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch());
    std::string file_name = std::to_string(ms.count()) + ".png";
    // cv::imshow("map", map);
    // cv::imwrite("/data2/engineering/png/" + file_name, map);
    // cv::waitKey();
    AD_LINFO(PATH_PLANNING) << "GridMap Refreshed: " << file_name;
    return AD_SUCCESS;
}

void GridMap::draw_sr_freespacemap() {
    AD_LDEBUG(PATH_PLANNING) << "GridMap Drawing sr freespace map ";
    map.setTo(cv::Scalar(0));
    if (rs_->freespace_contour.size() > 0) {
        std::vector<senseAD::Polygon> fs_draw_contour;
        fs_draw_contour.resize(rs_->freespace_contour.size());
        for (uint32_t i = 0; i < rs_->freespace_contour.size(); i++) {
            uint32_t current_size = rs_->freespace_contour[i].size();
            fs_draw_contour[i].resize(current_size);
            for (uint32_t j = 0; j < current_size; j++) {
                auto current_pt = rs_->freespace_contour[i][j];
                current_pt = convert_to_gridmap_coordinate(current_pt);
                fs_draw_contour[i][j].x = int32_t(
                    -current_pt.y / this->per_grid_meter + this->map_ww / 2);
                fs_draw_contour[i][j].y = int32_t(
                    -current_pt.x / this->per_grid_meter + this->map_hh / 2);
            }
        }
        cv::drawContours(map, fs_draw_contour, -1, cv::Scalar(init_draw_color),
                         CV_FILLED, 1, rs_->freespace_hierarchy);
    } else {
        map.setTo(cv::Scalar(init_draw_color));
    }

    AD_LDEBUG(PATH_PLANNING) << "GridMap Drawn sr freespace map ";
    // imwrite("000.png", map);
}

void GridMap::draw_cone_freespacemap() {
    AD_LDEBUG(PATH_PLANNING) << "GridMap Drawing cone freespace map ";
    if (object_trajectory_ == nullptr) {
        AD_LDEBUG(PATH_PLANNING)
            << "object_trajectory_ is nullptr, skip draw cone";
        return;
    }
    if (object_trajectory_->cones.size() > 0) {
        unsigned char *data = static_cast<unsigned char *>(map.data);
        for (auto it = object_trajectory_->cones.begin();
             it != object_trajectory_->cones.end(); ++it) {
            cv::Point2f cone_pos = it->position;
            cone_pos = convert_to_gridmap_coordinate(cone_pos);
            int32_t x =
                int32_t(-cone_pos.y / this->per_grid_meter + this->map_ww / 2);
            int32_t y =
                int32_t(-cone_pos.x / this->per_grid_meter + this->map_hh / 2);
            // Unlike draw_sr_freespace, for cone, we crop out the region. So we
            // actually draw the region that is unable to pass
            if (x < 0 || y < 0 || x >= this->map_ww || y >= this->map_hh) {
                // if out of gridmap region, ignore this point
                AD_LDEBUG(PATH_PLANNING) << "GridMap ignore cone: " << cone_pos;
                continue;
            }
            int index = y * this->map_ww + x;
            data[index] = 0;
        }
    }
    AD_LDEBUG(PATH_PLANNING) << "GridMap Drawn cone freespace map ";
}

void GridMap::crop_out_illegal_lanes_in_a_road(std::string road_id) {
    auto road = this->rs_->road_map[road_id];
    for (auto iter = road.lane_map.begin(); iter != road.lane_map.end();
         iter++) {
        if (iter->second.lane_type != hdmap::LaneType::DRIVING) {
            auto left_laneline_idx = iter->second.left_laneline_idx;
            auto right_laneline_idx = iter->second.right_laneline_idx;
            if (road.lane_line_map.find(left_laneline_idx) ==
                    road.lane_line_map.end() ||
                road.lane_line_map.find(right_laneline_idx) ==
                    road.lane_line_map.end()) {
                AD_LERROR(PATH_PLANNING)
                    << "Wrong non-Driving Lane: " << iter->first
                    << " with Lane ID:" << left_laneline_idx << ", "
                    << right_laneline_idx;
                continue;
            }
            auto lanel = road.lane_line_map[left_laneline_idx];
            auto laner = road.lane_line_map[right_laneline_idx];
            crop_out_illegal_lane(lanel, laner);
        }
    }
}

void GridMap::crop_out_illegal_lane(
    roadStructure::LaneLine<cv::Point2f> lanel,
    roadStructure::LaneLine<cv::Point2f> laner) {
    std::vector<cv::Point2f> lanepts_l, lanepts_r;
    float l_start_pos = lanel.data.GetStartLanelinePos();
    float l_end_pos = lanel.data.GetEndLanelinePos();
    if (l_start_pos < -1.0f && l_end_pos > 0) {
        l_start_pos = -1.0f;
    }
    if (l_end_pos > 0) {
        lanel.data.Sample(l_start_pos, l_end_pos, -1, 0.1f, &lanepts_l);
    }
    float r_start_pos = laner.data.GetStartLanelinePos();
    float r_end_pos = laner.data.GetEndLanelinePos();
    if (r_start_pos < -1.0 && r_end_pos > 0) {
        r_start_pos = -1.0f;
    }
    if (r_end_pos > 0) {
        laner.data.Sample(r_start_pos, r_end_pos, -1, 0.1f, &lanepts_r);
    }
    if (lanepts_l.size() < 2 || lanepts_r.size() < 2) {
        AD_LDEBUG(PATH_PLANNING) << "Sample LaneLine points failed!";
        return;
    }
    // build polygon
    std::vector<cv::Point> polyfill;
    for (int32_t i = lanepts_l.size() - 1; i >= 0; i--) {
        cv::Point aa;
        aa.x =
            int32_t(-lanepts_l[i].y / this->per_grid_meter + this->map_ww / 2);
        aa.y =
            int32_t(-lanepts_l[i].x / this->per_grid_meter + this->map_hh / 2);
        polyfill.push_back(aa);
    }
    for (uint32_t i = 0; i < lanepts_r.size(); i++) {
        cv::Point2f aa;
        aa.x =
            int32_t(-lanepts_r[i].y / this->per_grid_meter + this->map_ww / 2);
        aa.y =
            int32_t(-lanepts_r[i].x / this->per_grid_meter + this->map_hh / 2);
        polyfill.push_back(aa);
    }
    // because we are croping out the region
    cv::fillConvexPoly(map, polyfill, cv::Scalar(0));
}

void GridMap::draw_laneline_dotmap(roadStructure::LaneLine<cv::Point2f> lanel,
                                   roadStructure::LaneLine<cv::Point2f> laner) {
    AD_LDEBUG(PATH_PLANNING) << "GridMap Drawing laneline dotmap";
    dot_map.setTo(cv::Scalar(0));
    std::vector<cv::Point2f> lanepts_l, lanepts_r;
    float l_start_pos = lanel.data.GetStartLanelinePos();
    float l_end_pos = lanel.data.GetEndLanelinePos();
    if (l_start_pos < -1.0f && l_end_pos > 0) {
        l_start_pos = -1.0f;
    }
    if (l_end_pos > 0) {
        lanel.data.Sample(l_start_pos, l_end_pos, -1, 0.1f, &lanepts_l);
    }
    float r_start_pos = laner.data.GetStartLanelinePos();
    float r_end_pos = laner.data.GetEndLanelinePos();
    if (r_start_pos < -1.0 && r_end_pos > 0) {
        r_start_pos = -1.0f;
    }
    if (r_end_pos > 0) {
        laner.data.Sample(r_start_pos, r_end_pos, -1, 0.1f, &lanepts_r);
    }
    if (lanepts_l.size() < 2 || lanepts_r.size() < 2) {
        AD_LDEBUG(PATH_PLANNING) << "Sample LaneLine points failed!";
        return;
    }
    // if the lane line is not reached, ignore this lane line constraints
    // (especially at turning)
    if (lanepts_l[0].x > 0.5f || lanepts_r[0].x > 0.5f) {
        AD_LDEBUG(PATH_PLANNING) << "LaneLine is not so close!";
        return;
    }
    float x_end_far = 0.0f;
    x_end_far = lanepts_l[lanepts_l.size() - 1].x;
    if (x_end_far > lanepts_r[lanepts_r.size() - 1].x) {
        x_end_far = lanepts_r[lanepts_r.size() - 1].x;
    }
    // extend laneline (bottom)
    cv::Point2f ext_dir, cand_pts;
    ext_dir = lanepts_l[0] - lanepts_l[1];
    utils::Normalize2Dvect(&ext_dir);
    cand_pts = lanepts_l[0] + ext_dir;
    while (cand_pts.x >= -1 && fabs(cand_pts.y) < this->map_maxrealw + 1) {
        lanepts_l.insert(lanepts_l.begin(), cand_pts);
        cand_pts = lanepts_l[0] + ext_dir;
    }

    ext_dir = lanepts_r[0] - lanepts_r[1];
    utils::Normalize2Dvect(&ext_dir);
    cand_pts = lanepts_r[0] + ext_dir;
    while (cand_pts.x >= -1 && fabs(cand_pts.y) < this->map_maxrealw + 1) {
        lanepts_r.insert(lanepts_r.begin(), cand_pts);
        cand_pts = lanepts_r[0] + ext_dir;
    }

    // extend laneline (top)
    // ext_dir = lanepts_l[lanepts_l.size() - 1] -
    //        lanepts_l[lanepts_l.size() - 2];
    // utils::Normalize2Dvect(&ext_dir);
    // cand_pts = lanepts_l[lanepts_l.size() - 1] + ext_dir;
    // while (cand_pts.x < this->map_maxrealh + 1 &&
    //     fabs(cand_pts.y) < this->map_maxrealw + 1) {
    //     lanepts_l.push_back(cand_pts);
    //     cand_pts = lanepts_l[lanepts_l.size() - 1] + ext_dir;
    // }

    // ext_dir =
    //    lanepts_r[lanepts_r.size() - 1] - lanepts_r[lanepts_r.size() - 2];
    // utils::Normalize2Dvect(&ext_dir);
    // cand_pts = lanepts_r[lanepts_r.size() - 1] + ext_dir;
    // while (cand_pts.x < this->map_maxrealh + 1 &&
    //     fabs(cand_pts.y) < this->map_maxrealw + 1) {
    //     lanepts_r.push_back(cand_pts);
    //     cand_pts = lanepts_r[lanepts_r.size() - 1] + ext_dir;
    // }

    // mask top (out as free)
    cv::Point2f p1;
    cv::Point2f p2;
    p1.x = 0;
    p1.y = 0;
    p2.x = p1.x + this->map_ww;
    if (this->out_as_free < x_end_far) {
        x_end_far = this->out_as_free;
    }
    p2.y = p1.y + this->map_hh - x_end_far / this->per_grid_meter;
    cv::rectangle(dot_map, p1, p2, cv::Scalar(dot_default_scalar), CV_FILLED);
    // build polygon
    std::vector<cv::Point> polyfill;
    for (int32_t i = lanepts_l.size() - 1; i >= 0; i--) {
        cv::Point aa;
        aa.x =
            int32_t(-lanepts_l[i].y / this->per_grid_meter + this->map_ww / 2);
        aa.y =
            int32_t(-lanepts_l[i].x / this->per_grid_meter + this->map_hh / 2);
        polyfill.push_back(aa);
    }
    for (uint32_t i = 0; i < lanepts_r.size(); i++) {
        cv::Point2f aa;
        aa.x =
            int32_t(-lanepts_r[i].y / this->per_grid_meter + this->map_ww / 2);
        aa.y =
            int32_t(-lanepts_r[i].x / this->per_grid_meter + this->map_hh / 2);
        polyfill.push_back(aa);
    }
    cv::fillConvexPoly(dot_map, polyfill, cv::Scalar(dot_default_scalar));
    // test if feasible
    // TODO(eteced) remove this hardcode
    float32_t st_x[] = {1.0f, 3.0f, 6.0f};
    float32_t st_y[] = {1.0f, 0.0f, -1.0f};
    int32_t st_num = 3;
    int32_t x, y;
    bool check_feasible;
    check_feasible = true;
    unsigned char *data = static_cast<unsigned char *>(dot_map.data);
    for (int32_t ii = 0; ii < st_num; ii++) {
        for (int32_t jj = 0; jj < st_num; jj++) {
            x = int32_t(-st_y[jj] / this->per_grid_meter + this->map_ww / 2);
            y = int32_t(-st_x[ii] / this->per_grid_meter + this->map_hh / 2);
            if (data[y * this->map_ww + x] != dot_default_scalar) {
                check_feasible = false;
                // std::cout << "Failed: " << st_x[ii] << " ," <<
                //    int32_t(data[y * this->map_ww + x]) << std::endl;
                // std::cout << " (" << x << ", " << y << ")" << std::endl;
            }
            if (!check_feasible) break;
        }
        if (!check_feasible) break;
    }
    if (check_feasible) {
        cv::Mat tmp_map;
        // imwrite("222.png", dot_map);
        tmp_map = map.mul(dot_map);
        map = tmp_map;
    } else {
        AD_LDEBUG(PATH_PLANNING) << "Feasible check failed, Remain unchanged";
    }
    AD_LDEBUG(PATH_PLANNING) << "GridMap Drawn Laneline freespace";
}

void GridMap::rewrite_freespacemap() {
    AD_LDEBUG(PATH_PLANNING) << "GridMap rewriting freespace map";
    // auto begin = std::chrono::high_resolution_clock::now();
    std::vector<std::vector<cv::Point>> contours;
    int32_t qe, qb;
    int32_t op_fb_qe;
    qe = qb = -1;
    const int32_t dx[] = {-1, 0, 1};
    const int32_t dy[] = {-1, 0, 1};
    const int32_t n_dx = 3, n_dy = 3;
    std::fill(this->ifvisit.begin(), this->ifvisit.end(), false);
    unsigned char *data = static_cast<unsigned char *>(map.data);
    cv::findContours(map.clone(), contours, CV_RETR_LIST, CV_CHAIN_APPROX_NONE);
    // auto end = std::chrono::high_resolution_clock::now();
    // std::cout << "--- findContours: " <<
    //  std::chrono::duration_cast<std::chrono::microseconds>(end - begin)
    //    .count()
    // << " us" << std::endl;
    // auto b2 = std::chrono::high_resolution_clock::now();
    for (uint32_t ii = 0; ii < contours.size(); ii++) {
        for (uint32_t jj = 0; jj < contours[ii].size(); jj++) {
            cv::Point pt = contours[ii][jj];
            if (!this->ifvisit[pt.y * this->map_ww + pt.x]) {
                if (pt.x == 1 || pt.x == map_ww - 2 || pt.y == 1 ||
                    pt.y == map_hh - 2) {
                    bool if_meet_obstacle;
                    if_meet_obstacle = false;
                    int32_t nx, ny;
                    for (int32_t dj = 0; dj < n_dy; dj++) {
                        ny = pt.y + dy[dj];
                        if (!(ny >= 0 && ny < this->map_hh)) continue;
                        int32_t tp_r_index;
                        int32_t tp_index;
                        tp_r_index = ny * this->map_ww;
                        for (int32_t di = 0; di < n_dx; di++) {
                            nx = pt.x + dx[di];
                            if (nx >= 0 && nx < this->map_ww) {
                                tp_index = tp_r_index + nx;
                                if (data[tp_index] == 0) {
                                    if_meet_obstacle = true;
                                    break;
                                }
                            }
                        }
                        if (if_meet_obstacle) break;
                    }
                    if (if_meet_obstacle) {
                        qe++;
                        qx[qe] = pt.x;
                        qy[qe] = pt.y;
                        this->ifvisit[pt.y * this->map_ww + pt.x] = true;
                    }
                } else {
                    qe++;
                    qx[qe] = pt.x;
                    qy[qe] = pt.y;
                    this->ifvisit[pt.y * this->map_ww + pt.x] = true;
                }
            }
        }
    }
    op_fb_qe = qe;
    // end = std::chrono::high_resolution_clock::now();
    // std::cout << "--- init_point_push_back: "
    //    << std::chrono::duration_cast<std::chrono::microseconds>(end - b2)
    //        .count() << " us" << std::endl;
    // b2 = std::chrono::high_resolution_clock::now();
    // for (int32_t ii = 0; ii < 2000; ii++)
    //     for (int32_t jj = 0; jj < 400; jj++)
    //         int32_t a=1;
    // end = std::chrono::high_resolution_clock::now();
    // std::cout <<
    //  "--- max_for_loop: "
    //  << std::chrono::duration_cast<std::chrono::microseconds>(end - b2)
    //  .count()
    //            << " us" << std::endl;
    // b2 = std::chrono::high_resolution_clock::now();
    int32_t nx, ny;
    unsigned char opo;
    opo = as_free_measure_length + 1;
    while (qb < qe) {
        qb++;
        int32_t ox = qx[qb];
        int32_t oy = qy[qb];
        unsigned char o;
        o = data[oy * this->map_ww + ox];
        o = o + 1;
        if (o > as_free_measure_length && if_optimize) {
            break;
        }
        if (o > 120) o = 120;
        for (int32_t dj = 0; dj < n_dy; dj++) {
            ny = oy + dy[dj];
            if (!(ny >= 0 && ny < this->map_hh)) continue;
            int32_t tp_r_index;
            int32_t tp_index;
            tp_r_index = ny * this->map_ww;
            for (int32_t di = 0; di < n_dx; di++) {
                nx = ox + dx[di];
                tp_index = tp_r_index + nx;
                if (nx >= 0 && nx < this->map_ww &&
                    data[tp_index] == init_draw_color &&
                    !this->ifvisit[tp_index]) {
                    this->ifvisit[tp_index] = true;
                    data[tp_index] = o;
                    qe++;
                    qx[qe] = nx;
                    qy[qe] = ny;
                }
            }
        }
    }
    // end = std::chrono::high_resolution_clock::now();
    // std::cout <<
    //   "--- main fill while logical: " <<
    //    std::chrono::duration_cast<std::chrono::microseconds>(end - b2).
    //    count()
    //    << " us" << std::endl;
    // b2 = std::chrono::high_resolution_clock::now();
    if (opo && if_optimize) {
        map.setTo(opo, map == init_draw_color);
        for (int32_t ii = 0; ii <= op_fb_qe; ii++) {
            int32_t ox = qx[ii];
            int32_t oy = qy[ii];
            data[oy * this->map_ww + ox] = init_draw_color;
        }
    }
    // end = std::chrono::high_resolution_clock::now();
    // std::cout <<
    //    "--- main fill setTo logical: " <<
    //    std::chrono::duration_cast<std::chrono::microseconds>(end - b2).
    //    count() <<
    //    " us" << std::endl;
    // end = std::chrono::high_resolution_clock::now();
    // std::cout << "--- rewrite_freespacemap: "
    //    << std::chrono::duration_cast<std::chrono::microseconds>(end - begin)
    //    .count() << " us" << std::endl;
    AD_LDEBUG(PATH_PLANNING) << "GridMap rewrote freespace map";
}

adStatus_t GridMap::LoadMapFromFile(std::string filename) {
    map = cv::imread(filename, cv::IMREAD_UNCHANGED);
    map.convertTo(map, CV_8UC1);
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
