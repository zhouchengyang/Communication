/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#include "path_planning/honda_ctl_input_converter.hpp"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

namespace senseAD {
namespace pp {

const int MAX_POINTS = 150;

int HondaCtlInputConverter::fake_run_timef = 0;

HondaCtlInputConverter::HondaCtlInputConverter() {}

HondaCtlInputConverter::~HondaCtlInputConverter() {}

adStatus_t HondaCtlInputConverter::SetDefaultVelocity(const float& vel) {
    this->default_velocity = vel;
    return AD_SUCCESS;
}

adStatus_t HondaCtlInputConverter::ToHondaCtl(
    const float& run_timef,
    const float& insert_interval,
    const std::vector<TrajectoryPoint>& input_traj_pts,
    HondaCtlInput* honda_ctl_input) {
    if (honda_ctl_input == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }

    // ----lateral: tgt_points & tgt_update_lat----
    std::vector<float> tgt_points(MAX_POINTS * 3 + 1, 100.0f);
    for (uint32_t i = MAX_POINTS + 1; i < tgt_points.size(); i++) {
        tgt_points[i] = 0;
    }

    // tgt_points[0] = run_timef;
    tgt_points[0] = static_cast<float>(fake_run_timef) * 0.1;
    fake_run_timef += 1;
    for (int i = 1; i <= MAX_POINTS; i++) {
        tgt_points[i] = (static_cast<float>(i) * 0.1);
    }
    for (uint32_t i = 0; i < MAX_POINTS && i < input_traj_pts.size(); i++) {
        tgt_points[MAX_POINTS + 1 + i] = input_traj_pts[i].position.x;
        tgt_points[MAX_POINTS * 2 + 1 + i] = input_traj_pts[i].position.y;
    }

    honda_ctl_input->tgt_points = tgt_points;
    honda_ctl_input->tgt_update_lat = 1;
    // -----------------
    honda_ctl_input->road_id = 0;

    // ----Hard Code----
    if (input_traj_pts.size() == 0) {
        AD_LINFO(PATH_PLANNING) << "GOT ZERO OUTPUT";
        honda_ctl_input->tgt_speed = default_velocity;
        AD_LINFO(PATH_PLANNING) << "velocity 0 " << honda_ctl_input->tgt_speed;
        // TODO(congq): what to fill in togo mode
        honda_ctl_input->stop_distance = 1000.0;
        honda_ctl_input->tgt_update_lon = 1;
        honda_ctl_input->go_ok = 1;
    } else if (input_traj_pts.back().velocity < 0.01) {
        // ----STOP MODE----
        honda_ctl_input->tgt_speed = 0;
        AD_LINFO(PATH_PLANNING) << "velocity " << honda_ctl_input->tgt_speed;
        honda_ctl_input->stop_detected = 1;

        int first_non_zero_index = input_traj_pts.size() - 1;
        while (first_non_zero_index >= 0) {
            if (input_traj_pts[first_non_zero_index].velocity > 0.01) {
                break;
            }
            first_non_zero_index--;
        }

        honda_ctl_input->stop_distance =
            static_cast<float>(first_non_zero_index + 1) * insert_interval;
        honda_ctl_input->tgt_update_lon = 1;
        honda_ctl_input->go_ok = 0;  // TODO(congq): what to fill
        AD_LINFO(PATH_PLANNING) << "STOP_FLAG: 1 stop_distance: "
                                << honda_ctl_input->stop_distance;
    } else {
        // ----TOGO MODE----
        honda_ctl_input->tgt_speed = input_traj_pts.back().velocity < 2.0
                                         ? 2.0
                                         : input_traj_pts.back().velocity;

        AD_LINFO(PATH_PLANNING) << "velocity " << honda_ctl_input->tgt_speed;
        honda_ctl_input->stop_detected = 0;
        // TODO(congq): what to fill in togo mode
        honda_ctl_input->stop_distance = 1000.0;
        honda_ctl_input->tgt_update_lon = 1;
        honda_ctl_input->go_ok = 1;
    }
    // ----------------
    hci_ = *honda_ctl_input;
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
