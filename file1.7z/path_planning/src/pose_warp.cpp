/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Liang Yu <liangyu@sensetime.com>
 */

#include "path_planning/pose_warp.hpp"

#include "common/service_querier/localization_querier.hpp"
#include "common/data_type/hdmap/hdmap_base.h"
#include "hdmap/hdmap_util.hpp"
#include <iomanip>

namespace senseAD {
namespace pp {

adStatus_t PoseWarp::SetVehicleInfo(const VehicleInfo& vehicle_info) {
    this->vehicle_info_ = vehicle_info;
    this->last_valid_velocity_m_per_s_ = this->curr_velocity_m_per_s_;
    this->curr_velocity_m_per_s_ = vehicle_info_.vehicle_speed;
    this->curr_yaw_rate_rad_per_s_ = vehicle_info_.angular_yaw_rate;
    this->curr_acc_m_per_s2_ = vehicle_info_.acceleration_long;
    AD_LINFO(PATH_PLANNING)
        << " VehicleInfo: "
        << " Velocity: " << vehicle_info_.vehicle_speed
        << " Angular yaw : " << vehicle_info_.angular_yaw_rate
        << " AccLon: " << vehicle_info_.acceleration_long
        << " AccLat: " << vehicle_info_.acceleration_lat << " Steering angle"
        << vehicle_info_.steering_angle;
    senseAD::OdometryInfo latest_odometry;
    senseAD::CarPose latest_car_pose;
    uint64_t latest_timestamp_ns;
    SD_CHECK_ERROR(senseAD::common::g_localization_querier.LatestInfo(
        &latest_odometry, &latest_car_pose, &latest_timestamp_ns));
    AD_LINFO(PATH_PLANNING) << "CarPose: "
                            << " X: " << latest_car_pose.position.x
                            << " Y: " << latest_car_pose.position.y
                            << " heading: " << latest_car_pose.heading;

    senseAD::OdometryInfo current_odometry;
    auto location_status =
        senseAD::common::g_localization_querier.LatestInfo(&current_odometry);

    g_vehicle_state.x = current_odometry.position.x;
    g_vehicle_state.y = current_odometry.position.y;
    g_vehicle_state.heading = current_odometry.heading;
    g_vehicle_state.velocity = current_odometry.linear_velocity.x;
    g_vehicle_state.acceleration = current_odometry.linear_acceleration.x;
    g_vehicle_state.yaw_rate = curr_yaw_rate_rad_per_s_;
    g_vehicle_state.front_wheel_angle = vehicle_info.steering_angle / 16.0;
    return AD_SUCCESS;
}

adStatus_t PoseWarp::WarpPoint(cv::Point2f* point) {
    if (nullptr == point) {
        return AD_NULL_PTR;
    }
    AD_LDEBUG(MATRIX) << "point1 " << *point;
    Eigen::Matrix<double, 3, 1> p;
    p(0, 0) = point->x;
    p(1, 0) = point->y;
    p(2, 0) = 1;
    p = matrix_ * p;
    point->x = p(0, 0);
    point->y = p(1, 0);
    AD_LDEBUG(MATRIX) << "point2 " << *point;
    return AD_SUCCESS;
}
}  // namespace pp
}  // namespace senseAD
