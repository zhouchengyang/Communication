/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */
#include <math.h>
#include <algorithm>
#include <limits>
#include "common/log.hpp"
#include "path_planning/util.hpp"
#include "path_planning/qpvelocityplanner.hpp"

namespace senseAD {
namespace pp {

using Eigen::MatrixXd;
using Eigen::RowVectorXd;

adStatus_t QPVelocityPlanner::PlanVelocity(
    std::vector<TrajectoryPoint> *path_to_plan) {
    if (path_to_plan == nullptr) {
        SD_CHECK_ERROR(AD_INVALID_PARAM);
    }
    if (path_to_plan->size() == 0) {
        return AD_SUCCESS;
        // SD_CHECK_ERROR(AD_INVALID_PARAM);
    }
    if (path_to_plan->size() == 1) {
        path_to_plan->at(0).velocity = g_vehicle_state.velocity;
        path_to_plan->at(0).acceleration = 0;
        return AD_SUCCESS;
        // SD_CHECK_ERROR(AD_INVALID_PARAM);
    }
    int32_t to_index = this->to_index_;
    if (to_index < 0) {
        to_index = 0;
    }
    if (to_index >= static_cast<int32_t>(path_to_plan->size())) {
        to_index = path_to_plan->size() - 1;
    }
    float vm;
    vm = target_speed_ - g_vehicle_state.velocity;
    for (uint32_t i = 0; i < path_to_plan->size(); i++) {
        float norm = 0;
        if (i == 0) {
            path_to_plan->at(i).sum_distance = 0;
            path_to_plan->at(i).time_difference = 0.0;
        } else {
            utils::CalcNorm(
                path_to_plan->at(i).position - path_to_plan->at(i - 1).position,
                &norm);
            path_to_plan->at(i).sum_distance =
                path_to_plan->at(i - 1).sum_distance + norm;
        }
        if (fabs(vm) < speed_eps_) {
            path_to_plan->at(i).velocity = target_speed_;
            path_to_plan->at(i).acceleration = 0;
            if (i > 0) {
                if (target_speed_ > 0.001) {
                    path_to_plan->at(i).time_difference =
                        path_to_plan->at(i - 1).time_difference +
                        norm / path_to_plan->at(i).velocity;
                } else {
                    path_to_plan->at(i).time_difference =
                        path_to_plan->at(i - 1).time_difference + 10.0;
                }
            }
            if (vppurpose_ == STOP_AT_GIVEN_POINT ||
                vppurpose_ == EMERGE_STOP ||
                vppurpose_ == REMAIN_TILL_CACHE_GOAL ||
                fabs(target_speed_) < speed_eps_) {
                path_to_plan->at(i).acceleration = extra_dacc_stop_;
            }
        }
    }
    if (fabs(vm) < speed_eps_) {
        return AD_SUCCESS;
    }
    // check g_vehicle_state.acceleration has the same direction as
    // velocity change
    if ((vm > 0.0f && g_vehicle_state.acceleration < 0.0f) ||
        (vm < 0.0f && g_vehicle_state.acceleration > 0.0f)) {
        AD_LINFO(PATH_PLANNING)
            << "g_vehicle_state.acceleration mismatch velocity "
               "change, force reset to zero";
        g_vehicle_state.acceleration = 0;
    }
    double t_est, S, v0, vt, a0, at, estimated_acc, estimated_s;
    std::vector<double> coeffs;
    S = path_to_plan->at(to_index).sum_distance;
    v0 = g_vehicle_state.velocity;
    vt = target_speed_;
    a0 = g_vehicle_state.acceleration;
    at = 0;
    estimated_acc = a0 / 2;
    if (fabs(estimated_acc) < minacc_est_ / 2.0f) {
        estimated_acc = minacc_est_ / 2.0f;
    }

    estimated_acc = std::fabs(estimated_acc);
    if ((vt > acc_decay_v_thres_) && fabs(vt - v0) < acc_decay_v_diff_thres_) {
        estimated_acc =
            std::max(static_cast<double>(acc_decay_min_),
                     acc_decay_min_ +
                         (estimated_acc - acc_decay_min_) *
                             (fabs(vt - v0) - acc_decay_v_diff_end_) /
                             (acc_decay_v_diff_thres_ - acc_decay_v_diff_end_));
        AD_LINFO(PATH_PLANNING) << "Rewrote estimated_acc: " << estimated_acc;
    }

    if (vm < 0.0f) {
        estimated_acc = -fabs(estimated_acc);
    }

    estimated_s = std::fabs((vt * vt - v0 * v0) / (2 * estimated_acc));
    // will neglect dm's urge to accelerate
    creep_distance_ = 0;
    if ((estimated_s < S && fabs(vt) > 1e-2 && vppurpose_ != USE_DM_S) ||
        vm > 0.0f) {
        AD_LINFO(PATH_PLANNING) << "Rewrite S:" << S
                                << " to eS: " << estimated_s;
        S = estimated_s;
    } else if (fabs(vt) < 1e-2) {
        if (estimated_s < S && a0 < -1e-1) {
            if (creep_to_target_first_ == 1 &&
                g_vehicle_state.velocity < creep_velocity_threshold_) {
                AD_LINFO(PATH_PLANNING)
                    << "target s is too far away, creep "
                       "slowly close to target first S before"
                    << S;
                creep_distance_ = S - estimated_s;
                S = estimated_s;
                AD_LINFO(PATH_PLANNING) << "creeping distance will be "
                                        << creep_distance_;
                AD_LINFO(PATH_PLANNING) << "S rewrote to " << S;
            } else {
                // a large acc0 will result in a abnormal solution
                double a_new = 0;
                if (S > 1e-1) {
                    a_new = (vt * vt - v0 * v0) / (2.0 * S);
                    a_new = a_new / 2.0;
                }
                AD_LINFO(PATH_PLANNING)
                    << "Abnormal init accel for stop, rewrite a:" << a0
                    << " to " << a_new;
                a0 = a_new;
            }
        }
    }
    S = S - dist_minus_eps_;
    if (S < 0) {
        S = 0;
    }
    auto cc_start = std::chrono::high_resolution_clock::now();
    CalulateCoefficients(S, v0, a0, vt, at, &coeffs, &t_est);
    if (coeffs.size() > 0) {
        for (int i = 0; i < num_seg_; i++) {
            coeffs[i * 5 + 0] = 0;
        }
    }
    auto cc_end = std::chrono::high_resolution_clock::now();
    auto cc_count = cc_end - cc_start;
    LOG(INFO) << "ApplyQPVelocityProfile time: "
              << std::chrono::duration<float>(cc_count).count() << "s";
    if (coeffs.size() == 0) {
        AD_LINFO(PATH_PLANNING) << "QPVP fallback";
        FallBackVelocityProfile(path_to_plan);
    } else {
        AD_LINFO(PATH_PLANNING) << "QPVP success";
        ApplyQPVelocityProfile(path_to_plan, coeffs, t_est, creep_distance_);
    }
    if (!PassFinalCheck(*path_to_plan)) {
        AD_LINFO(PATH_PLANNING) << "Did't satified final check, QPVP fallback";
        FallBackVelocityProfile(path_to_plan);
    }
    return AD_SUCCESS;
}

void QPVelocityPlanner::ApplyQPVelocityProfile(
    std::vector<TrajectoryPoint> *path_to_plan,
    const std::vector<double> &coeffs,
    double t_est,
    float32_t creep_distance) {
    auto aqp_start = std::chrono::high_resolution_clock::now();
    {
        std::stringstream ss;
        ss << "[";
        for (int i = 0; i < degree_ * num_seg_; i++) {
            if (i != 0) {
                ss << ",";
            }
            ss << coeffs[i];
        }
        ss << "]"
           << " " << t_est;
        AD_LINFO(PATH_PLANNING) << "QPVelocityPlanner Coeffs: " << ss.str();
    }
    std::vector<double> S;
    // S[s ranges]
    for (int i = 0; i < num_seg_; i++) {
        double ss = coeffs[i * 5 + 0] + coeffs[i * 5 + 1] * t_est +
                    coeffs[i * 5 + 2] * t_est * t_est +
                    coeffs[i * 5 + 3] * t_est * t_est * t_est +
                    coeffs[i * 5 + 4] * t_est * t_est * t_est * t_est;
        if (i > 0) {
            S.push_back(S[i - 1] + ss);
        } else {
            S.push_back(ss);
        }
    }
    {
        std::stringstream ss;
        ss << "[";
        for (size_t i = 0; i < S.size(); i++) {
            if (i != 0) {
                ss << ",";
            }
            ss << S[i];
        }
        ss << "]";
        AD_LINFO(PATH_PLANNING) << "QPVelocityPlanner S: " << ss.str();
    }
    int ii = 0;
    size_t i;
    double t = 0;
    double end_creep_time = 0;
    for (i = 0; i < path_to_plan->size(); i++) {
        if (path_to_plan->at(i).sum_distance < creep_distance) {
            path_to_plan->at(i).velocity = g_vehicle_state.velocity;
            path_to_plan->at(i).acceleration = 0;
            if (i == 0) {
                path_to_plan->at(i).time_difference = 0;
            } else {
                if (this->target_speed_ > 0.001)
                    path_to_plan->at(i).time_difference =
                        path_to_plan->at(i - 1).time_difference +
                        cv::norm(path_to_plan->at(i).position -
                                 path_to_plan->at(i - 1).position) /
                            ((path_to_plan->at(i).velocity +
                              path_to_plan->at(i - 1).velocity) /
                             2.0);
                else {
                    path_to_plan->at(i).time_difference =
                        path_to_plan->at(i - 1).time_difference + 1.0;
                }
            }
            end_creep_time = path_to_plan->at(i).time_difference;
            AD_LDEBUG(PATH_PLANNING) << "creeping i " << i;
            continue;
        }
        while (ii < num_seg_ &&
               path_to_plan->at(i).sum_distance > S[ii] + creep_distance) {
            ii++;
            AD_LINFO(PATH_PLANNING) << "next ii " << ii;
            t = 0;
        }
        if (ii >= num_seg_) {
            break;
            AD_LINFO(PATH_PLANNING) << "braek ";
        }
        double ss = 0;
        if (ii > 0) {
            ss = path_to_plan->at(i).sum_distance - S[ii - 1] - creep_distance;
        } else {
            ss = path_to_plan->at(i).sum_distance - creep_distance;
        }
        double t_tmp =
            solveT(coeffs[ii * 5 + 0], coeffs[ii * 5 + 1], coeffs[ii * 5 + 2],
                   coeffs[ii * 5 + 3], coeffs[ii * 5 + 4], ss, t);
        if (t_tmp > 0 - t_larger_eps_) {
            AD_LDEBUG(PATH_PLANNING) << "Solve OK, current_ii = " << ii
                                     << ", t = " << t << ", t_tmp = " << t_tmp;
            t = t_tmp;
            path_to_plan->at(i).velocity = coeffs[ii * 5 + 1] +
                                           coeffs[ii * 5 + 2] * t * 2 +
                                           coeffs[ii * 5 + 3] * t * t * 3 +
                                           coeffs[ii * 5 + 4] * t * t * t * 4;
            path_to_plan->at(i).acceleration = coeffs[ii * 5 + 2] * 2 +
                                               coeffs[ii * 5 + 3] * t * 6 +
                                               coeffs[ii * 5 + 4] * t * t * 12;
            path_to_plan->at(i).time_difference =
                end_creep_time + t + ii * t_est;
            AD_LTRACE(PATH_PLANNING) << "path_to_plan time " << i << " "
                                     << t + ii * t_est << " "
                                     << path_to_plan->at(i).sum_distance;

        } else {
            LOG(INFO) << "Error, utils::SolveP4 failed: " << coeffs[ii * 5 + 0]
                      << " " << coeffs[ii * 5 + 1] << " " << coeffs[ii * 5 + 2]
                      << " " << coeffs[ii * 5 + 3] << " " << coeffs[ii * 5 + 4]
                      << " " << ss << " " << t;
            if (i > 0) {
                // TODO(congq): try current velocity&acc
                path_to_plan->at(i).velocity = target_speed_;
                path_to_plan->at(i).acceleration = 0;
                if (path_to_plan->at(i).velocity +
                        path_to_plan->at(i - 1).velocity >
                    0.001) {
                    path_to_plan->at(i).time_difference =
                        path_to_plan->at(i - 1).time_difference +
                        cv::norm(path_to_plan->at(i).position -
                                 path_to_plan->at(i - 1).position) /
                            ((path_to_plan->at(i).velocity +
                              path_to_plan->at(i - 1).velocity) /
                             2.0);
                } else {
                    path_to_plan->at(i).time_difference =
                        path_to_plan->at(i - 1).time_difference + 1.0;
                }
            } else {
                path_to_plan->at(i).velocity = target_speed_;
                path_to_plan->at(i).acceleration = 0;
                path_to_plan->at(i).time_difference = 0;
            }
        }
    }

    if (ii >= num_seg_) {
        for (; i < path_to_plan->size(); i++) {
            path_to_plan->at(i).velocity = this->target_speed_;
            path_to_plan->at(i).acceleration = 0;
            if (path_to_plan->at(i).velocity +
                    path_to_plan->at(i - 1).velocity >
                0.001) {
                path_to_plan->at(i).time_difference =
                    path_to_plan->at(i - 1).time_difference +
                    cv::norm(path_to_plan->at(i).position -
                             path_to_plan->at(i - 1).position) /
                        ((path_to_plan->at(i).velocity +
                          path_to_plan->at(i - 1).velocity) /
                         2.0);
            } else {
                path_to_plan->at(i).time_difference =
                    path_to_plan->at(i - 1).time_difference + 1.0;
            }
            if (vppurpose_ == STOP_AT_GIVEN_POINT ||
                vppurpose_ == EMERGE_STOP ||
                vppurpose_ == REMAIN_TILL_CACHE_GOAL ||
                fabs(target_speed_) < speed_eps_) {
                path_to_plan->at(i).acceleration = extra_dacc_stop_;
            }
        }
    }
    auto aqp_end = std::chrono::high_resolution_clock::now();
    auto aqp_count = aqp_end - aqp_start;
    LOG(INFO) << "ApplyQPVelocityProfile time: "
              << std::chrono::duration<float>(aqp_count).count() << "s";
}

void QPVelocityPlanner::FallBackVelocityProfile(
    std::vector<TrajectoryPoint> *path_to_plan) {
    if (path_to_plan == nullptr) {
        return;
    }
    int to_index = this->to_index_;
    if (to_index < 0) {
        to_index = 0;
    }
    if (to_index >= static_cast<int32_t>(path_to_plan->size())) {
        to_index = path_to_plan->size() - 1;
    }
    AD_LINFO(PATH_PLANNING)
        << "Failed to solve QP Velocity Profile, use fallback solution";
    BVPStage bvs;
    double S = path_to_plan->at(to_index).sum_distance;
    // TODO(someone) send insert_interval to qp velocity planner
    const double insert_inverval = 0.2;
    if (S < insert_inverval) {
        S = insert_inverval;
    }
    double v0 = g_vehicle_state.velocity;
    double v1 = this->target_speed_;
    double a = (v1 * v1 - v0 * v0) / S / 2;
    bvs.type = 1;
    bvs.s_a = a;
    bvs.e_a = a;
    bvs.s_v = v0;
    bvs.e_v = v1;
    bvs.d_f_s = S;
    bvs.j = 0;
    bvs_.clear();
    bvs_.push_back(bvs);
    applybvpstage(path_to_plan);
}

MatrixXd QPVelocityPlanner::generateH(double t_int) {
    MatrixXd H = MatrixXd::Zero(degree_ * num_seg_, degree_ * num_seg_);
    float t;
    for (int i = 0; i < num_seg_; i++) {
        MatrixXd Hi = MatrixXd::Zero(degree_, degree_);
        for (int j = 1; j < t_sample_ + 1; j++) {
            t = j * t_int;
            MatrixXd Hi1_slash(3, 3), Hi2_slash(2, 2);
            Hi1_slash << 1, 3 * t, 6 * t * t, 3 * t, 9 * t * t, 18 * pow(t, 3),
                6 * t * t, 18 * pow(t, 3), 36 * pow(t, 4);
            Hi1_slash *= 8;
            Hi2_slash << 1, 4 * t, 4 * t, 16 * t * t;
            Hi2_slash *= 72;
            Hi.block(2, 2, 3, 3) += Hi1_slash;
            Hi.block(3, 3, 2, 2) += Hi2_slash;
        }
        H.block(5 * i, 5 * i, 5, 5) += Hi;
    }
    return H;
}

// generate equal A and b matrix
std::vector<MatrixXd> QPVelocityPlanner::generateEq(double s_tgt,
                                                    double v_0,
                                                    double a_0,
                                                    double v_tgt,
                                                    double a_tgt,
                                                    double t_est) {
    // Initial and end parameter constraints A_e1 4 * 25
    MatrixXd A_e1 = MatrixXd::Zero(4, degree_ * num_seg_);
    A_e1(0, 1) = 1;
    A_e1(1, 2) = 2;
    A_e1.bottomRightCorner(2, 5) << dti(t_est), ddti(t_est);

    // Total S constraints
    MatrixXd A_e2 = MatrixXd::Zero(1, degree_ * num_seg_);
    for (int i = 0; i < num_seg_; i++) {
        A_e2.block(0, i * degree_, 1, degree_) += ti(t_est);
    }
    RowVectorXd b_e12(5);
    b_e12 << v_0, a_0, v_tgt, a_tgt, s_tgt;

    // joint smoothness constraints (Velocity, Acceleration, Jerk)
    MatrixXd dT, ddT, dddT;
    dT = MatrixXd::Zero(num_seg_ - 1, degree_ * num_seg_);
    ddT = MatrixXd::Zero(num_seg_ - 1, degree_ * num_seg_);
    dddT = MatrixXd::Zero(num_seg_ - 1, degree_ * num_seg_);
    for (int i = 0; i < num_seg_ - 1; i++) {
        dT(i, degree_ * (i + 1) + 1) = -1;
        dT.block(i, degree_ * i, 1, degree_) += dti(t_est);
        ddT(i, degree_ * (i + 1) + 2) = -2;
        ddT.block(i, degree_ * i, 1, degree_) += ddti(t_est);
        dddT(i, degree_ * (i + 1) + 3) = -6;
        dddT.block(i, degree_ * i, 1, degree_) += dddti(t_est);
    }
    MatrixXd A_e3(3 * (num_seg_ - 1), degree_ * num_seg_);
    A_e3 << dT, ddT, dddT;
    // si(0) == 0 constraints A_e4 4 * 25
    MatrixXd A_e4 = MatrixXd::Zero(num_seg_, degree_ * num_seg_);
    for (int i = 0; i < num_seg_; i++) {
        A_e4.block(i, i * degree_, 1, degree_) += ti(0);
    }
    RowVectorXd b_e34 = RowVectorXd::Zero(4 * num_seg_ - 3);

    MatrixXd A_eq(A_e1.rows() + A_e2.rows() + A_e3.rows() + A_e4.rows(),
                  A_e1.cols());
    RowVectorXd b_eq(b_e12.cols() + b_e34.cols());
    A_eq << A_e1, A_e2, A_e3, A_e4;
    b_eq << b_e12, b_e34;

    std::vector<MatrixXd> results;
    results.emplace_back(A_eq);
    results.emplace_back(b_eq);
    return results;
}

// generate unequal A and b matrix
std::vector<MatrixXd> QPVelocityPlanner::generateUEq(double v_0,
                                                     double v_tgt,
                                                     double t_int) {
    // Acceleration direction constraints
    MatrixXd A_ueq = MatrixXd::Zero(num_seg_ * t_sample_, degree_ * num_seg_);
    float t;
    for (int i = 0; i < num_seg_; i++) {
        for (int j = 1; j < t_sample_ + 1; j++) {
            t = j * t_int;
            A_ueq.block(i * t_sample_ + j - 1, i * degree_, 1, degree_) +=
                ddti(t);
        }
    }
    if (v_tgt > v_0) {
        A_ueq *= -1;
    }
    RowVectorXd b_ueq = RowVectorXd::Zero(t_sample_ * num_seg_);
    std::vector<MatrixXd> results;
    results.emplace_back(A_ueq);
    results.emplace_back(b_ueq);
    return results;
}

void QPVelocityPlanner::CalulateCoefficients(double s_tgt,
                                             double v_0,
                                             double a_0,
                                             double v_tgt,
                                             double a_tgt,
                                             std::vector<double> *coeffs,
                                             double *t_est_out) {
    if (coeffs == nullptr || t_est_out == nullptr) {
        return;
    }
    AD_LINFO(PATH_PLANNING) << "s_tgt: " << s_tgt << " v_0: " << v_0
                            << " a_0: " << a_0 << " v_tgt: " << v_tgt
                            << " a_tgt: " << a_tgt;
    double v_mid, t_est, t_int;
    v_mid = (v_tgt + v_0) / 2.0;
    t_est = s_tgt / num_seg_ / v_mid;
    // if (fabs(a_0) > 1e-1) {
    //     double tmp_time = (v_tgt - v_0) / a_0;
    //     if (tmp_time > 0 && t_est > tmp_time) {
    //         AD_LINFO(PATH_PLANNING)
    //             << "rewrite t_est from " << t_est << " to " << tmp_time;
    //         t_est = tmp_time;
    //     }
    // }
    // t_int = t_est / t_sample_;
    // generate H

    // TODO(qiucong): t_int not initialized
    MatrixXd H = generateH(t_int);
    RowVectorXd q = RowVectorXd::Zero(degree_ * num_seg_);  //??
    // generate equal parameters A_eq b_eq
    std::vector<MatrixXd> Eq_Ab =
        generateEq(s_tgt, v_0, a_0, v_tgt, a_tgt, t_est);
    MatrixXd A_eq = cont_weight_ * Eq_Ab[0];
    RowVectorXd b_eq = cont_weight_ * Eq_Ab[1];
    // generate unequal parameters A_ueq b_ueq
    std::vector<MatrixXd> UEq_Ab = generateUEq(v_0, v_tgt, t_int);
    MatrixXd A_ueq = ineq_weight_ * UEq_Ab[0];
    RowVectorXd b_ueq = ineq_weight_ * UEq_Ab[1];

    double inf = std::numeric_limits<double>::infinity() / 2;

    MatrixXd A(A_eq.rows() + A_ueq.rows(), A_eq.cols());
    MatrixXd lbA(b_eq.rows(), b_eq.cols() + b_ueq.cols());
    MatrixXd ubA(lbA.rows(), lbA.cols());
    A << A_eq, A_ueq;
    lbA << b_eq, MatrixXd::Ones(b_ueq.rows(), b_ueq.cols()) * -inf;
    ubA << b_eq, b_ueq;

    // qpOASES solver_
    int rows, cols;
    rows = H.rows();
    cols = H.cols();
    double H_new[rows * cols];
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            H_new[i * cols + j] = H(i, j);
            if (i == j) {
                H_new[i * cols + j] += regularize_eps_;
            }
        }
    }
    rows = q.rows();
    cols = q.cols();
    double q_new[rows * cols];
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            q_new[i * cols + j] = q(i, j);
        }
    }

    rows = A.rows();
    cols = A.cols();
    double A_new[rows * cols];
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            A_new[i * cols + j] = A(i, j);
        }
    }

    rows = lbA.rows();
    cols = lbA.cols();
    double lbA_new[rows * cols];
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            lbA_new[i * cols + j] = lbA(i, j);
        }
    }

    rows = ubA.rows();
    cols = ubA.cols();
    double ubA_new[rows * cols];
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            ubA_new[i * cols + j] = ubA(i, j);
        }
    }

    double cputime = 1.0;
    qpOASES::SQProblem qpproblem(degree_ * num_seg_, A.rows(),
                                 qpOASES::HST_SEMIDEF);
    // qpOASES::Options qpoption;
    // qpoption.setToMPC();
    // qpproblem.setOptions(qpoption);
    qpproblem.setPrintLevel(qpOASES::PL_NONE);

    int nWSR = 1000;

    auto status = qpproblem.init(H_new, q_new, A_new, 0, 0, lbA_new, ubA_new,
                                 nWSR, &cputime);
    // cputime = 1.0;
    // qpproblem.hotstart(q_new, 0, 0, lbA_new, ubA_new, nWSR, &cputime);

    double xOpt[degree_ * num_seg_];
    qpproblem.getPrimalSolution(xOpt);

    coeffs->clear();
    if (status != qpOASES::SUCCESSFUL_RETURN ||
        qpproblem.isSolved() != qpOASES::BT_TRUE) {
        AD_LERROR(PATH_PLANNING)
            << "Failed to solve velocity profile QP problem. status = "
            << status << " isSolved = " << qpproblem.isSolved();
        return;
    }

    for (int i = 0; i < degree_ * num_seg_; i++) {
        coeffs->push_back(xOpt[i]);
    }
    *t_est_out = t_est;
}

bool QPVelocityPlanner::PassFinalCheck(const Trajectory &path_planned) const {
    // 1. the velocity overshoot
    // 2. target velocity < 0
    auto upper_bound =
        std::max(static_cast<float32_t>(g_vehicle_state.velocity),
                 target_speed_) +
        upper_leeway_;
    auto lower_bound =
        std::min(0.0f,
                 std::min(static_cast<float32_t>(g_vehicle_state.velocity),
                          target_speed_)) +
        lower_leeway_;

    for (const auto &pt : path_planned) {
        if (pt.velocity > upper_bound || pt.velocity < lower_bound) {
            return false;
        }
    }
    if (target_speed_ < 1e-2) {
        for (auto pt : path_planned) {
            if (pt.acceleration > acc_up_leeway_) {
                return false;
            }
        }
    }
    return true;
}

}  // namespace pp
}  // namespace senseAD
