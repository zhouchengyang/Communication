/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 * Qiu Cong <qiucong@sensetime.com>
 */

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/log.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "path_planning/util.hpp"
#include "path_planning/nn_tool.hpp"

using senseAD::LaneLine;

namespace senseAD {
namespace pp {

namespace utils {
adStatus_t FrenetToCartesian(const float &s,
                             const float &ds,
                             const float &dds,
                             const float &d,
                             const float &dd,
                             const float &ddd,
                             const std::vector<TrajectoryPoint> &ref_path,
                             TrajectoryPoint *result_pt) {
    // s / accumulated dist ~= indeiix
    int match_id = std::min(static_cast<int>(s / (ref_path[1].sum_distance -
                                                  ref_path[0].sum_distance)),
                            static_cast<int>(ref_path.size() - 1));
    match_id = std::max(0, match_id);

    auto matched_ref_pt = ref_path[match_id];
    AD_LTRACE(PATH_PLANNING)
        << "s d input"
        << " " << s << " " << d << "\nmatched " << matched_ref_pt.position
        << " " << matched_ref_pt.direction << " " << matched_ref_pt.theta;
    auto base_position = matched_ref_pt.position;

    AD_LDEBUG(PATH_PLANNING) << "FRENET2CART base_point before "
                             << base_position;
    if (match_id < static_cast<int32_t>(ref_path.size()) - 2) {
        base_position = base_position +
                        (ref_path[match_id + 1].position - base_position) *
                            (s - ref_path[match_id].sum_distance) * 5.0;
    }

    AD_LDEBUG(PATH_PLANNING) << "FRENET2CART base_point after "
                             << base_position;

    result_pt->position.x = base_position.x - d * sin(matched_ref_pt.theta);
    result_pt->position.y = base_position.y + d * cos(matched_ref_pt.theta);
    return AD_SUCCESS;
}

adStatus_t CartesianToFrenet(const TrajectoryPoint &pt,
                             const std::vector<TrajectoryPoint> &ref_path,
                             float *s,
                             float *ds,
                             float *dds,
                             float *d,
                             float *dd,
                             float *ddd) {
    // TODO(congq): Assertion?
    if (ref_path.size() < 1) return AD_SUCCESS;
    // TODO(congq): to make sure the ref_path is the same of the ref_path used
    auto min_index = g_nn_tool.NearestNeighbor(pt);
    if (min_index >= static_cast<int32_t>(ref_path.size())) {
        min_index = ref_path.size() - 1;
        AD_LDEBUG(PATH_PLANNING) << "CART2FRENET ecced ";
    }

    AD_LDEBUG(PATH_PLANNING) << "CART2FRENET to convert " << pt.position;
    float cos_A = -1;
    float l_v_c = 0;
    float l_v_b = 0;
    float ref_line_interval =
        ref_path[1].sum_distance - ref_path[0].sum_distance;
    cv::Point2f vec_b(1, 0), vec_c(1, 0);

    AD_LDEBUG(PATH_PLANNING) << "CART2FRENET matched "
                             << ref_path[min_index].position;
    vec_b = ref_path[min_index].direction;
    vec_c = pt.position - ref_path[min_index].position;
    l_v_b = cv::norm(vec_b);
    l_v_c = cv::norm(vec_c);

    if ((l_v_c) < 0.0001) {
        *s = static_cast<float>(min_index) * ref_line_interval;
        cos_A = 1;
    } else {
        cos_A = (vec_b.x * vec_c.x + vec_b.y * vec_c.y) / (l_v_b * l_v_c);
    }

    AD_LDEBUG(PATH_PLANNING) << "CART2FRENET vec_b vec_c l_v_b l_v_c cos_A"
                             << vec_b << " " << vec_c << " " << l_v_b << " "
                             << l_v_c << " " << cos_A;
    while (min_index > 0 && cos_A < 0) {
        min_index--;
        AD_LDEBUG(PATH_PLANNING) << "CART2FRENET matched changed "
                                 << ref_path[min_index].position;
        vec_b = ref_path[min_index].direction;
        vec_c = pt.position - ref_path[min_index].position;
        l_v_b = cv::norm(vec_b);
        l_v_c = cv::norm(vec_c);
        if ((l_v_c) < 0.0001) {
            *s = static_cast<float>(min_index) * ref_line_interval;
            cos_A = 1;
            AD_LDEBUG(PATH_PLANNING) << "CART2FRENET s " << *s;
        } else {
            cos_A = (vec_b.x * vec_c.x + vec_b.y * vec_c.y) / (l_v_b * l_v_c);
        }
        AD_LDEBUG(PATH_PLANNING) << "CART2FRENET vec_b vec_c l_v_b l_v_c cos_A"
                                 << vec_b << " " << vec_c << " " << l_v_b << " "
                                 << l_v_c << " " << cos_A;
    }
    *s = l_v_c * cos_A + static_cast<float>(min_index) * ref_line_interval;
    AD_LDEBUG(PATH_PLANNING) << "CART2FRENET s " << *s << " min_index"
                             << min_index;
    float sin_A = 0;
    float mid_val = 1 - cos_A * cos_A;
    if (mid_val > 0) {
        sin_A = std::sqrt(1 - cos_A * cos_A);
    }

    // auto abs_d = sqrt(l_v_c * l_v_c + l_v_b * l_v_b);
    auto abs_d = std::abs(l_v_c * sin_A);
    auto cross_b_c = vec_b.x * vec_c.y - vec_b.y * vec_c.x;
    if (cross_b_c > 1e-4) {
        *d = abs_d;
    } else {
        *d = -abs_d;
    }
    return AD_SUCCESS;
}

adStatus_t GetHeadingAtS(const std::vector<TrajectoryPoint> &ref_path,
                         const float s,
                         float *heading) {
    // just accord to sum distance to find heading, due to equal insert distance
    // and sum distance start from zero
    if (ref_path.size() < 2) {
        *heading = 0.0;
        AD_LERROR(REF_LINE) << "size of ref_path is less than 2";
        return AD_INVALID_PARAM;
    }
    if (s <= 0.0) {
        *heading = std::atan2(ref_path.front().direction.y,
                              ref_path.front().direction.x);
        return AD_SUCCESS;
    }
    float insert_interval =
        ref_path.at(1).sum_distance - ref_path.at(0).sum_distance;
    uint32_t index1 = std::floor(s / insert_interval);
    uint32_t index2 = std::ceil(s / insert_interval);
    if (index1 < ref_path.size() && index2 < ref_path.size()) {
        cv::Point2f dir = 0.5 * (ref_path.at(index1).direction +
                                 ref_path.at(index2).direction);
        *heading = std::atan2(dir.y, dir.x);
    } else if (index1 < ref_path.size()) {
        *heading = std::atan2(ref_path.at(index1).direction.y,
                              ref_path.at(index1).direction.x);
    } else {
        *heading = std::atan2(ref_path.back().direction.y,
                              ref_path.back().direction.x);
    }
    return AD_SUCCESS;
}

adStatus_t GetHeadingAtS(const std::vector<TrajectoryPoint> &ref_path,
                         const float s,
                         cv::Point2f *heading) {
    // just accord to sum distance to find heading, due to equal insert distance
    // and sum distance start from zero
    if (nullptr == heading) {
        AD_LERROR(REF_LINE) << "heading pointer is nullptr";
        return AD_NULL_PTR;
    }
    if (ref_path.size() < 2) {
        *heading = cv::Point2f(1.0, 0.0);
        AD_LERROR(REF_LINE) << "size of ref_path is less than 2";
        return AD_INVALID_PARAM;
    }
    if (s <= 0.0) {
        *heading = ref_path.front().direction;
        return AD_SUCCESS;
    }
    float insert_interval =
        ref_path.at(1).sum_distance - ref_path.at(0).sum_distance;
    uint32_t index1 = std::floor(s / insert_interval);
    uint32_t index2 = std::ceil(s / insert_interval);
    if (index1 < ref_path.size() && index2 < ref_path.size()) {
        *heading = 0.5 * (ref_path.at(index1).direction +
                          ref_path.at(index2).direction);
    } else if (index1 < ref_path.size()) {
        *heading = ref_path.at(index1).direction;
    } else {
        *heading = ref_path.back().direction;
    }
    return AD_SUCCESS;
}

cv::RotatedRect GetErrorEllipse(double chisquare_val,
                                cv::Point2f mean,
                                cv::Mat covmat) {
    // Get the eigenvalues and eigenvectors
    cv::Mat eigenvalues, eigenvectors;
    cv::eigen(covmat, true, eigenvalues, eigenvectors);

    // Calculate the angle between the largest eigenvector and the x-axis
    double angle =
        atan2(eigenvectors.at<double>(0, 1), eigenvectors.at<double>(0, 0));

    // Shift the angle to the [0, 2pi] interval instead of [-pi, pi]
    if (angle < 0) angle += 2 * M_PI;

    // Conver to degrees instead of radians
    angle = 180 * angle / M_PI;

    // Calculate the size of the minor and major axes
    double halfmajoraxissize = chisquare_val * sqrt(eigenvalues.at<double>(0));
    double halfminoraxissize = chisquare_val * sqrt(eigenvalues.at<double>(1));

    // Return the oriented ellipse
    // The -angle is used because OpenCV defines
    //  the angle clockwise instead of anti-clockwise
    return cv::RotatedRect(
        mean, cv::Size2f(halfmajoraxissize, halfminoraxissize), -angle);
}

adStatus_t SampleLanelinepts(const senseAD::LaneLine &laneline,
                             float from,
                             float to,
                             float delta,
                             int num,
                             int farfirst,
                             std::vector<cv::Point2f> *out) {
    if (out == NULL) {
        return senseAD::AD_NULL_PTR;
    }
    out->clear();
    if (laneline.GetFittingResultValidState() == false) {
        return senseAD::AD_INVALID_PARAM;
    }
    float a0, a1, a2, y_min, y_max;
    cv::Point2f st0, st1;
    laneline.GetQuadraticCurveParameters(&a0, &a1, &a2, &y_min, &y_max);
    if (from < 0 && to < 0) {
        from = y_min;
        to = y_max;
    } else {
        if (from < y_min) from = y_min;
        if (to > y_max) to = y_max;
    }
    if (delta < 0 && num > 1) {
        delta = (to - from) * 1.0 / (num - 1);
    }
    if (delta < 1e-7) {
        delta = 0.001;
    }
    if ((to - from) / delta + 1 < num || num < 0) {
        num = (to - from) / delta + 1;
    }
    if (laneline.GetXYRelation()) {
        st0.y = y_min;
        st0.x = a0 + a1 * st0.y + a2 * st0.y * st0.y;
        st1.y = y_max;
        st1.x = a0 + a1 * st1.y + a2 * st1.y * st1.y;
    } else {
        st0.x = y_min;
        st0.y = a0 + a1 * st0.x + a2 * st0.x * st0.x;
        st1.x = y_max;
        st1.y = a0 + a1 * st1.x + a2 * st1.x * st1.x;
    }
    if (farfirst == 0) {
        if (st0.x > st1.x || (st0.x == st1.x && fabs(st0.y) > fabs(st1.y))) {
            // float swap_ft;
            // swap_ft = from;
            // TODO(some): unused
            from = to;
            to = from;
            delta = -delta;
        }
    } else if (farfirst == 1) {
        if (st0.x < st1.x || (st0.x == st1.x && fabs(st0.y) < fabs(st1.y))) {
            // float swap_ft;
            // swap_ft = from;
            // TODO(some): unused
            from = to;
            to = from;
            delta = -delta;
        }
    }
    for (int32_t i = 0; i < num; i++) {
        cv::Point2f vl;
        if (laneline.GetXYRelation()) {
            vl.y = i * delta + from;
            vl.x = a0 + a1 * vl.y + a2 * vl.y * vl.y;
        } else {
            vl.x = i * delta + from;
            vl.y = a0 + a1 * vl.x + a2 * vl.x * vl.x;
        }
        out->push_back(vl);
    }
    return senseAD::AD_SUCCESS;
}
adStatus_t Normalize2Dvect(cv::Point2f *a) {
    float norm_;
    norm_ = a->x * a->x + a->y * a->y;
    norm_ = sqrtf(norm_);
    if (norm_ == 0) {
        return senseAD::AD_INVALID_PARAM;
    }
    a->x = a->x / norm_;
    a->y = a->y / norm_;
    return senseAD::AD_SUCCESS;
}
adStatus_t Cosine2Dvect(const cv::Point2f &a,
                        const cv::Point2f &b,
                        float *cosine) {
    float norm_a, norm_b;
    norm_a = sqrtf(a.x * a.x + a.y * a.y);
    norm_b = sqrtf(b.x * b.x + b.y * b.y);
    if ((norm_a * norm_b) == 0) {
        return senseAD::AD_INVALID_PARAM;
    }
    *cosine = (a.x * b.x + a.y * b.y) / (norm_a * norm_b);
    return senseAD::AD_SUCCESS;
}

adStatus_t PointsToLine(const std::vector<cv::Point2f> &ce,
                        float *a,
                        float *b,
                        float *c) {
    cv::Point2f t = ce[0] - ce[1];
    if (t.x == 0) {
        *a = 1;
        *b = 0;
        *c = -ce[0].x;
    } else if (t.y == 0) {
        *a = 0;
        *b = 1;
        *c = -ce[0].y;
    } else {
        *a = t.y / t.x;
        *b = -1;
        *c = ce[0].y - (*a) * ce[0].x;
    }
    return senseAD::AD_SUCCESS;
}
adStatus_t IntersectionPoint(float a1,
                             float b1,
                             float c1,
                             float a2,
                             float b2,
                             float c2,
                             cv::Point2f *pts) {
    if (a1 < 0) {
        a1 = -a1;
        b1 = -b1;
        c1 = -c1;
    }
    if (a2 < 0) {
        a2 = -a2;
        b2 = -b2;
        c2 = -c2;
    }
    float y, x;
    if (a1 * b2 - a2 * b1 == 0) return senseAD::AD_INVALID_PARAM;
    if (a1 == 0 || a2 == 0) {
        if (a1 == 0) {
            y = -c1 / b1;
            x = (c1 / b1 * b2 - c2) / a2;
        } else {
            y = -c2 / b2;
            x = (c2 / b2 * b1 - c1) / a1;
        }
        (*pts).x = x;
        (*pts).y = y;
        return senseAD::AD_SUCCESS;
    } else {
        y = (a2 * c1 - a1 * c2) / (a1 * b2 - a2 * b1);
        x = (-c1 - b1 * y) / a1;
        (*pts).x = x;
        (*pts).y = y;
        return senseAD::AD_SUCCESS;
    }
}
adStatus_t CalcbyPoint(const cv::Point2f &pts, float a, float b, float *c) {
    (*c) = -(a * pts.x + b * pts.y);
    return senseAD::AD_SUCCESS;
}
adStatus_t SortidoflanesByFaraway(const std::vector<LaneLine> &lanelines,
                                  std::vector<int> *ids) {
    std::vector<cv::Point2f> sp, tsp;
    ids->clear();
    for (uint32_t i = 0; i < lanelines.size(); i++) {
        if (lanelines[i].GetFittingResultValidState() == true) {
            SampleLanelinepts(lanelines[i], -1, -1, 0.01, 1, 0, &tsp);
            ids->push_back(i);
            sp.push_back(tsp[0]);
        } else {
            cv::Point2f emp_pts;
            emp_pts.x = 0;
            emp_pts.y = 0;
            sp.push_back(emp_pts);
        }
    }
    for (uint32_t i = 0; i < ids->size(); i++) {
        for (uint32_t j = i + 1; j < ids->size(); j++) {
            int ii = ids->at(i);
            int jj = ids->at(j);
            if (sp[ii].x < sp[jj].x) {
                ids->at(i) = jj;
                ids->at(j) = ii;
            }
        }
    }
    return senseAD::AD_SUCCESS;
}
adStatus_t isptsafarawayfromb(const cv::Point2f &pta,
                              const cv::Point2f &ptb,
                              int *isfar) {
    // isfar > 0, far
    // isfar < 0, close
    // isfar == 0, are you kidding me?
    if (pta.x == ptb.x && fabs(pta.y) == fabs(ptb.y)) {
        (*isfar) = 0;
    } else {
        if (ptb.x > pta.x || (pta.x == ptb.x && fabs(pta.y) < fabs(ptb.y))) {
            (*isfar) = 1;
        } else {
            (*isfar) = -1;
        }
    }
    return senseAD::AD_SUCCESS;
}
adStatus_t CalcNorm(const cv::Point2f &pts, float *norm) {
    *(norm) = pts.x * pts.x + pts.y * pts.y;
    *(norm) = sqrtf(*(norm));
    return senseAD::AD_SUCCESS;
}
adStatus_t SmoothDirection(std::vector<cv::Point2f> *directions,
                           cv::Point2f *newdirection,
                           int num) {
    if (directions == NULL || newdirection == NULL) {
        return senseAD::AD_NULL_PTR;
    }
    cv::Point2f cand_dir;
    cand_dir = *(newdirection);
    for (uint32_t i = 0; i < directions->size(); i++) {
        cand_dir = cand_dir + directions->at(i);
        AD_LTRACE(PATH_PLANNING) << "smooth_"
                                 << "i" << i << ": x:" << directions->at(i).x
                                 << " y:" << directions->at(i).y;
    }
    Normalize2Dvect(&cand_dir);
    *(newdirection) = cand_dir;
    return senseAD::AD_SUCCESS;
}
adStatus_t UpdateSmooth(std::vector<cv::Point2f> *directions,
                        cv::Point2f *newdirection,
                        int num) {
    while (static_cast<int>(directions->size()) > num) {
        directions->erase(directions->begin());
    }
    directions->push_back(*newdirection);
    return senseAD::AD_SUCCESS;
}

adStatus_t SolveCubic(
    float a, float b, float c, float d, std::vector<float> *res) {
    static const float cos120 = -0.5f;
    static const float sin120 = 0.866025404f;
    // int n = 0;
    if (res == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    res->clear();
    if (fabs(d) < FLT_EPSILON) {
        // first solution is x = 0
        res->push_back(0.0f);
        // divide all terms by x, converting to quadratic equation
        d = c;
        c = b;
        b = a;
        a = 0.0f;
    }
    if (fabs(a) < FLT_EPSILON) {
        if (fabs(b) < FLT_EPSILON) {
            // linear equation
            if (fabs(c) > FLT_EPSILON) {
                res->push_back(-d / c);
            }
        } else {
            // quadratic equation
            float yy = c * c - 4 * b * d;
            if (yy >= 0) {
                float inv2b = 1 / (2 * b);
                float y = sqrt(yy);
                res->push_back((-c + y) * inv2b);
                res->push_back((-c - y) * inv2b);
            }
        }
    } else {
        // cubic equation
        float inva = 1.0f / a;
        float invaa = inva * inva;
        float bb = b * b;
        float bover3a = b * (1.0f / 3.0f) * inva;
        float p = (3 * a * c - bb) * (1 / 3.0f) * invaa;
        float halfq = (2.0f * bb * b - 9.0f * a * b * c + 27.0f * a * a * d) *
                      (0.5f / 27.0f) * invaa * inva;
        if (fabs(halfq) > 1e12 || fabs(p) > 1e7) return AD_SUCCESS;
        if (fabs(p) < 1e-7f) p = 0;
        if (fabs(halfq) < 1e-7f) halfq = 0;
        float yy = p * p * p / 27.0f + halfq * halfq;
        if (yy > FLT_EPSILON) {
            // sqrt is positive: one real solution
            float y = sqrt(yy);
            float uuu = -halfq + y;
            float vvv = -halfq - y;
            float www = fabs(uuu) > fabs(vvv) ? uuu : vvv;
            float w = (www < 0) ? -powf(fabs(www), 1.0f / 3.0f)
                                : pow(www, 1.0f / 3.0f);
            res->push_back(w - p / (3.0f * w) - bover3a);
        } else if (yy < -FLT_EPSILON) {
            // sqrt is negative: three real solutions
            float x = -halfq;
            float y = sqrt(-yy);
            float theta;
            float r;
            float ux;
            float uyi;
            // convert to polar form
            if (fabs(x) > FLT_EPSILON) {
                theta = (x > 0) ? atanf(y / x) : (atanf(y / x) + 3.14159625f);
                r = sqrt(x * x - yy);
            } else {
                // vertical line
                theta = 3.14159625f / 2.0f;
                r = y;
            }
            // calc cube root
            theta /= 3.0f;
            r = powf(r, 1.0f / 3.0f);
            // convert to complex coordinate
            ux = cosf(theta) * r;
            uyi = sinf(theta) * r;
            // first solution
            res->push_back(ux + ux - bover3a);
            // second solution, rotate +120 degrees
            res->push_back(2 * (ux * cos120 - uyi * sin120) - bover3a);
            // third solution, rotate -120 degrees
            res->push_back(2 * (ux * cos120 + uyi * sin120) - bover3a);
        } else {
            // sqrt is zero: two real solutions
            float www = -halfq;
            float w = (www < 0) ? -pow(fabs(www), 1.0f / 3.0f)
                                : powf(www, 1.0f / 3.0f);
            // first solution
            res->push_back(w + w - bover3a);
            // second solution, rotate +120 degrees
            res->push_back(2 * w * cos120 - bover3a);
        }
    }
    return AD_SUCCESS;
}

// TODO(congq): a lot of computation here..
adStatus_t CubicBezierSmoothing(const std::vector<cv::Point2f> &path,
                                const cv::Point2f &entering_direction,
                                const cv::Point2f &exiting_direction,
                                std::vector<TrajectoryPoint> *smooth_path,
                                bool if_quadratic_bezier_first) {
    // TODO(congq): as input
    float insert_distance_ = 0.2;
    AD_LTRACE(PATH_PLANNING) << "Trajectory Planner "
                             << "Using bezier smoothing";
    if (path.size() < 2) {
        TrajectoryPoint result;
        // assert path.size()> 0
        result.position = path[0];
        result.direction = entering_direction;
        result.curvature = 0;
        smooth_path->push_back(result);
        return AD_SUCCESS;
    }
    if (cv::norm(path[0] - path.back()) < insert_distance_) {
        TrajectoryPoint begin_traj_point;
        begin_traj_point.position = path[0];
        begin_traj_point.direction = entering_direction;
        begin_traj_point.curvature = 0;
        begin_traj_point.theta = 0;
        begin_traj_point.velocity = 0.0;

        TrajectoryPoint end_traj_point;
        end_traj_point.position = path[0];
        end_traj_point.direction = entering_direction;
        end_traj_point.curvature = 0;
        end_traj_point.theta = 0;
        end_traj_point.velocity = 0.0;
        smooth_path->push_back(begin_traj_point);
        smooth_path->push_back(end_traj_point);
        return AD_SUCCESS;
    }

    // direction of each points
    std::vector<cv::Point2f> directions;
    directions.push_back(entering_direction);
    AD_LINFO(PATH_PLANNING) << "Trajectory Planner "
                            << "CubicBezierSmoothing entering_direciton"
                            << entering_direction;
    /*
     * for (unsigned int  i = 1; i < path.size()-1; i ++) {
     *     directions.push_back(path[i+1]-path[i-1]);
     * }
     */
    for (unsigned int i = 1; i < path.size() - 1; i++) {
        directions.push_back(path[i] - path[i - 1]);
    }

    // the last point's direction
    directions.push_back(exiting_direction);

    // find two reference point
    // create a vector<point> as cubic bezier representation
    // TODO(congq): bezier class instead
    std::vector<std::vector<cv::Point2f> > cubic_bezier_rep;

    for (unsigned int i = 0; i < path.size() - 1; i++) {
        std::vector<cv::Point2f> bezier;
        bezier.push_back(path[i]);
        float distance = cv::norm(path[i + 1] - path[i]);
        // float distance = std::min(cv::norm(path[i+1] - path[i]), 20.0);
        // if (i == 0) {
        //     distance = std::min(distance, 20.0f);
        // }

        cv::Point2f ref0 =
            directions[i] * (1.0 / cv::norm(directions[i])) * (distance / 2) +
            path[i];

        // if (i == 0) {
        //     distance = std::min(cv::norm(path[i+1] - path[i]), 20.0);
        // }
        cv::Point2f ref1 = -directions[i + 1] *
                               (1.0 / cv::norm(directions[i + 1])) *
                               (distance / 2) +
                           path[i + 1];

        // if the control point has the different sign with the goal
        // and there is a good quadratic bezier solution. use it instead
        if (((ref1.y > 0 && path[i + 1].y < 0) ||
             (ref1.y < 0 && path[i + 1].y > 0)) &&
            if_quadratic_bezier_first) {
            std::vector<cv::Point2f> ptsforline;
            float a1, b1, c1, a2, b2, c2;
            ptsforline.push_back(path[i]);
            ptsforline.push_back(ref0);
            PointsToLine(ptsforline, &a1, &b1, &c1);
            ptsforline.clear();
            ptsforline.push_back(ref1);
            ptsforline.push_back(path[i + 1]);
            PointsToLine(ptsforline, &a2, &b2, &c2);
            cv::Point2f int_pts;
            IntersectionPoint(a1, b1, c1, a2, b2, c2, &int_pts);
            cv::Point2f in_a, in_b;
            in_a = path[0] - int_pts;
            in_b = path[1] - int_pts;
            float cosine_int;
            Cosine2Dvect(in_a, in_b, &cosine_int);
            if (cosine_int < 0) {
                ref0 = int_pts;
                ref1 = int_pts;
            }
        }

        if (BezierCurveAmend(bezier.at(0), &ref0, &ref1, path[i + 1]) !=
            AD_SUCCESS) {
            AD_LERROR(PATH_PLANNING)
                << "control point of bezier curve amendation failed!";
        }

        bezier.push_back(ref0);
        bezier.push_back(ref1);
        bezier.push_back(path[i + 1]);
        AD_LINFO(PATH_PLANNING) << "Bezier " << i << ": " << path[i] << " "
                                << ref0 << " " << ref1 << " " << path[i + 1];
        cubic_bezier_rep.push_back(bezier);
    }
    // Yeild x, y, thetax, thetay,  and curvature
    for (auto bezier : cubic_bezier_rep) {
        float path_length_approx =
            (cv::norm(bezier[0] - bezier[1]) + cv::norm(bezier[1] - bezier[2]) +
             cv::norm(bezier[2] - bezier[3]) +
             cv::norm(bezier[0] - bezier[3])) /
            2;
        // TODO(congq): could result in empty path;
        if (path_length_approx < insert_distance_) {
            continue;
        }

        float dt = insert_distance_ / path_length_approx;

        float t = 0;

        while (t < 1) {
            cv::Point2f pos = bezier[0] * (1 - 3 * t + 3 * t * t - t * t * t) +
                              bezier[1] * (3 * t - 6 * t * t + 3 * t * t * t) +
                              bezier[2] * (3 * t * t - 3 * t * t * t) +
                              bezier[3] * (t * t * t);

            cv::Point2f pos_d = bezier[0] * (-3 + 6 * t - 3 * t * t) +
                                bezier[1] * (3 - 12 * t + 9 * t * t) +
                                bezier[2] * (6 * t - 9 * t * t) +
                                bezier[3] * (3 * t * t);

            cv::Point2f pos_dd = bezier[0] * (6 - 6 * t) +
                                 bezier[1] * (-12 + 18 * t) +
                                 bezier[2] * (6 - 18 * t) + bezier[3] * (6 * t);

            float theta = 0;

            theta = atan2(pos_d.y, pos_d.x);
            /*
            if (pos_d.x == 0) {
                if (pos_d.y > 0) { theta = M_PI / 2;
                } else if (pos_d.y < 0) {
                    theta = -M_PI / 2;
                } else {
                    theta = 0;
                }
            } else {
                theta = atan(pos_d.y / pos_d.x);
            }
            */
            float curvature =
                (pos_d.x * pos_dd.y - pos_dd.x * pos_d.y) /
                pow(pos_d.x * pos_d.x + pos_d.y * pos_d.y, 3.0 / 2.0);
            auto direction = pos_d;

            direction = direction * (1.0 / cv::norm(direction));

            TrajectoryPoint new_traj_point;

            new_traj_point.position = pos;
            new_traj_point.direction = direction;
            new_traj_point.velocity = 0.0;
            new_traj_point.theta = theta;
            new_traj_point.curvature = curvature;
            AD_LTRACE(PATH_PLANNING) << "Trajectory planner adding "
                                     << new_traj_point.position << " "
                                     << new_traj_point.direction;
            smooth_path->push_back(new_traj_point);
            // smooth_path->push_back(
            //     {pos, direction,
            //     static_cast<float>(theta), static_cast<float>(curvature)});

            t += dt;
        }
    }
    AD_LDEBUG(PATH_PLANNING) << "Trajectory Planner "
                             << "Bezier smoothed";
    return AD_SUCCESS;
}

// TODO(congq): float check
adStatus_t SegmentTrajectoryByTime(
    const std::vector<TrajectoryPoint> &trajectory,
    const float &interval_dist,
    std::vector<TrajectoryPoint> *result_trajectory) {
    if (result_trajectory == nullptr) {
        return AD_NULL_PTR;
    }
    result_trajectory->clear();
    if (trajectory.size() < 2) {
        *result_trajectory = trajectory;
        return AD_SUCCESS;
    }
    TrajectoryPoint begin_tp = trajectory[0];

    result_trajectory->push_back(begin_tp);
    int i = 1;

    float32_t time_difference_left = interval_dist;

    AD_LINFO(PATH_PLANNING) << "start time inserting";

    while (i < static_cast<int>(trajectory.size())) {
        if (result_trajectory->size() > 1000) {
            AD_LERROR(PATH_PLANNING) << "Anormal input to SegmentTrajector,"
                                     << "disengagement is needed now!";
            break;
        }
        if (begin_tp.time_difference > 20) break;
        AD_LDEBUG(PATH_PLANNING) << "the time " << trajectory[i].time_difference
                                 << " " << begin_tp.time_difference;
        if (trajectory[i].time_difference - begin_tp.time_difference -
                time_difference_left >
            0.0001) {
            auto time_portion =
                time_difference_left /
                (trajectory[i].time_difference - begin_tp.time_difference);
            auto tjp = begin_tp;
            auto diff_posi = trajectory[i].position - begin_tp.position;
            tjp.position += diff_posi * time_portion;
            tjp.direction = diff_posi * (1.0 / cv::norm(diff_posi));
            tjp.velocity =
                tjp.velocity +
                (trajectory[i].velocity - tjp.velocity) * time_portion;
            tjp.acceleration =
                tjp.acceleration +
                (trajectory[i].acceleration - tjp.acceleration) * time_portion;
            tjp.theta = std::atan2(tjp.direction.y, tjp.direction.x);
            tjp.timestamp =
                tjp.timestamp +
                (trajectory[i].timestamp - tjp.timestamp) * time_portion;
            // TODO(congq): linear interpolation is not ideal for it
            tjp.curvature =
                tjp.curvature +
                (trajectory[i].curvature - tjp.curvature) * time_portion;
            tjp.sum_distance = tjp.sum_distance + cv::norm(diff_posi);
            tjp.time_difference = tjp.time_difference + time_difference_left;
            tjp.yaw_rate = tjp.velocity * tjp.curvature;
            result_trajectory->push_back(tjp);
            AD_LDEBUG(PATH_PLANNING)
                << tjp.position << " " << tjp.direction << " " << tjp.velocity
                << " " << tjp.acceleration << " " << tjp.theta << " "
                << tjp.sum_distance << " " << tjp.time_difference << " "
                << tjp.curvature << " " << tjp.yaw_rate;

            AD_LDEBUG(PATH_PLANNING) << "inserting time "
                                     << tjp.time_difference;

            begin_tp = tjp;
            time_difference_left = interval_dist;
        } else if (trajectory[i].time_difference - begin_tp.time_difference -
                       time_difference_left <
                   -0.0001) {
            time_difference_left -=
                trajectory[i].time_difference - begin_tp.time_difference;
            begin_tp = trajectory[i];
            i++;
            AD_LDEBUG(PATH_PLANNING) << "else if time differecnt "
                                     << time_difference_left;
        } else {
            auto tjp = trajectory[i];
            result_trajectory->push_back(tjp);
            begin_tp = tjp;
            time_difference_left = interval_dist;
            i++;
            AD_LDEBUG(PATH_PLANNING) << "time differecnt "
                                     << time_difference_left;
        }
        AD_LDEBUG(PATH_PLANNING) << "time differecnt " << time_difference_left;
    }
    for (auto tjp : *result_trajectory) {
        AD_LDEBUG(PATH_PLANNING)
            << tjp.position << " " << tjp.direction << " " << tjp.velocity
            << " " << tjp.acceleration << " " << tjp.theta << " "
            << tjp.sum_distance << " " << tjp.time_difference << " "
            << tjp.curvature << " " << tjp.yaw_rate << " " << tjp.timestamp;
    }
    return AD_SUCCESS;
}

// TODO(congq): float check
adStatus_t SegmentTrajectory(const std::vector<TrajectoryPoint> &trajectory,
                             const float &interval_dist,
                             std::vector<TrajectoryPoint> *result_trajectory) {
    if (result_trajectory == nullptr) {
        return AD_NULL_PTR;
    }
    if (trajectory.size() < 2) {
        *result_trajectory = trajectory;
        return AD_SUCCESS;
    }
    TrajectoryPoint begin_tp = trajectory[0];

    int i = 1;
    int fresh_cut_flag = 1;
    while (i < static_cast<int>(trajectory.size())) {
        AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got begin_tp: "
                                 << begin_tp.position;
        AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got trajectory: "
                                 << trajectory[i].position;
        if (cv::norm(begin_tp.position - trajectory[i].position) -
                interval_dist >
            0.0001) {
            // if(i-1 behind begin_tp) {
            //  find point b in beginpoint-tp[i] that
            //      pointb - begin_point = R
            // }
            // else
            //  find point b in [i-1] [i]] that
            //      pb -bp  == R
            // result .push _back(begin point)
            // beginpoint = point b
            TrajectoryPoint tjpoint_end = begin_tp;

            AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory begin to cut ";
            if (fresh_cut_flag == 1) {
                // find point b in begin_tp tp[i]
                AD_LTRACE(PATH_PLANNING)
                    << "SegmentTrajectory freshed cut, cut ahead ";
                auto delta = trajectory[i].position - begin_tp.position;
                delta = delta * (interval_dist / cv::norm(delta));
                auto pos_end = begin_tp.position + delta;
                tjpoint_end.position = pos_end;
                tjpoint_end.velocity =
                    tjpoint_end.velocity +
                    (trajectory[i].velocity - tjpoint_end.velocity) *
                        (interval_dist / cv::norm(delta));
                tjpoint_end.acceleration =
                    tjpoint_end.acceleration +
                    (trajectory[i].acceleration - tjpoint_end.acceleration) *
                        (interval_dist / cv::norm(delta));
                tjpoint_end.direction =
                    tjpoint_end.direction +
                    (trajectory[i].direction - tjpoint_end.direction) *
                        (interval_dist / cv::norm(delta));
            } else {
                AD_LTRACE(PATH_PLANNING)
                    << "SegmentTrajectory rotten cut, trinometry";
                // find point_end in tp[i-1] tp[i]
                // in triangle tp[i-1], begin_tp, posi_end
                //   use cos therum to find length of (tp[i-1], posi_end)
                auto lb = begin_tp.position - trajectory[i - 1].position;
                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got lb: " << lb;
                auto lc = trajectory[i].position - trajectory[i - 1].position;
                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got lc: " << lc;
                auto cos_A = (lb.x * lc.x + lb.y * lc.y) /
                             sqrtf((lb.x * lb.x + lb.y * lb.y) *
                                   (lc.x * lc.x + lc.y * lc.y));

                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got cos_A: "
                                         << cos_A;
                auto dist_lb = cv::norm(lb);

                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got dist_lb: "
                                         << dist_lb;
                auto dist_c =
                    sqrtf(dist_lb * dist_lb * cos_A * cos_A -
                          dist_lb * dist_lb + interval_dist * interval_dist) +
                    dist_lb * cos_A;
                if (dist_lb < 0.001) {
                    dist_c = cv::norm(interval_dist);
                }

                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got dist_c: "
                                         << dist_c;
                auto delta =
                    trajectory[i].position - trajectory[i - 1].position;
                delta = delta * (dist_c / cv::norm(delta));
                auto pos_end = trajectory[i - 1].position + delta;
                tjpoint_end.position = pos_end;

                tjpoint_end.velocity =
                    tjpoint_end.velocity +
                    (trajectory[i].velocity - tjpoint_end.velocity) *
                        (dist_c / cv::norm(delta));
                tjpoint_end.acceleration =
                    tjpoint_end.acceleration +
                    (trajectory[i].acceleration - tjpoint_end.acceleration) *
                        (dist_c / cv::norm(delta));
                tjpoint_end.direction =
                    tjpoint_end.direction +
                    (trajectory[i].direction - tjpoint_end.direction) *
                        (dist_c / cv::norm(delta));
                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got position: "
                                         << pos_end;
            }
            // catch bug
            try {
                result_trajectory->push_back(begin_tp);
            } catch (const std::bad_alloc &e) {
                AD_LERROR(LongiLatPlanner) << e.what();
                AD_LERROR(LongiLatPlanner) << "trajectory size "
                                           << result_trajectory->size();
                AD_LERROR(LongiLatPlanner)
                    << "i " << i << " i - 1 : " << trajectory.at(i - 1).position
                    << ", i : " << trajectory.at(i).position;
                return AD_SUCCESS;
            }

            begin_tp = tjpoint_end;
            fresh_cut_flag = 1;
        } else if (cv::norm(begin_tp.position - trajectory[i].position) -
                       interval_dist <
                   -0.0001) {
            AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory no candidate";
            i++;
            fresh_cut_flag = 0;
        } else {
            TrajectoryPoint tjpoint_end = trajectory[i];
            i++;
            result_trajectory->push_back(begin_tp);
            begin_tp = tjpoint_end;
            fresh_cut_flag = 1;
            // point b = tp[i]
            // i++
            // result .push_back(begin point)
            // begin point = point b
        }
    }
    if (result_trajectory->size() == 0) {
        return AD_SUCCESS;
    }

    if (result_trajectory->size() == 1) {
        // TODO(congq): should have used real direciton
        result_trajectory->at(0).direction = cv::Point2f(1, 0);
        result_trajectory->at(0).theta = 0;
        result_trajectory->at(0).curvature = 0;
        return AD_SUCCESS;
    }
    // for size > 2
    // fill in first point

    result_trajectory->push_back(trajectory.back());

    auto raw_direction =
        result_trajectory->at(1).position - result_trajectory->at(0).position;

    result_trajectory->at(0).direction =
        raw_direction * (1 / cv::norm(raw_direction));

    result_trajectory->at(0).theta = atan2(raw_direction.y, raw_direction.x);

    // if (raw_direction.x <= 0) {
    //    if (raw_direction.y > 0) {
    //        result_trajectory->at(0).theta = M_PI / 2.0;
    //    } else {
    //        result_trajectory->at(0).theta = -M_PI / 2.0;
    //    }
    // } else {
    //    result_trajectory->at(0).theta =
    //        atan(raw_direction.y / raw_direction.x);
    // }
    result_trajectory->at(0).curvature = 0;
    result_trajectory->at(0).sum_distance = 0;

    // fill in last point
    auto size = result_trajectory->size();
    raw_direction = result_trajectory->at(size - 1).position -
                    result_trajectory->at(size - 2).position;

    result_trajectory->at(size - 1).direction =
        raw_direction * (1 / cv::norm(raw_direction));

    result_trajectory->at(size - 1).theta =
        atan2(raw_direction.y, raw_direction.x);

    result_trajectory->at(size - 1).curvature = 0;

    // fill in what are in between
    for (uint32_t i = 1; i < size - 1; i++) {
        result_trajectory->at(i).sum_distance =
            result_trajectory->at(i - 1).sum_distance +
            cv::norm(result_trajectory->at(i).position -
                     result_trajectory->at(i - 1).position);
        raw_direction = result_trajectory->at(i + 1).position -
                        result_trajectory->at(i - 1).position;
        result_trajectory->at(i).direction =
            raw_direction * (1 / cv::norm(raw_direction));
        AD_LTRACE(PATH_PLANNING) << "Segmented Trajectory " << i << "direction "
                                 << result_trajectory->at(i).direction;

        result_trajectory->at(i).theta =
            atan2(raw_direction.y, raw_direction.x);

        AD_LTRACE(PATH_PLANNING) << "Segmented Trajectory " << i << "theta "
                                 << result_trajectory->at(i).theta;
        auto v1 = result_trajectory->at(i + 1).position -
                  result_trajectory->at(i).position;
        auto v2 = result_trajectory->at(i).position -
                  result_trajectory->at(i - 1).position;

        auto vc = (v2 - v1) * 0.5;
        float v2_mod = cv::norm(v2);
        auto curvature = std::abs(v2_mod) < 0.00001
                             ? 0
                             : cv::norm(vc) / v2_mod / (interval_dist / 0.5);

        result_trajectory->at(i).curvature = curvature;
        AD_LTRACE(PATH_PLANNING) << "Segmented Trajectory " << i << "curvature"
                                 << result_trajectory->at(i).curvature;
    }

    AD_LINFO(PATH_PLANNING) << "result size" << result_trajectory->size();
    AD_LDEBUG(PATH_PLANNING) << "Trajectory Planner "
                             << "Segmented Trajectory";
    return AD_SUCCESS;
}

adStatus_t SingleSegByDistance(const Trajectory &traj,
                               const TrajectoryPoint &current_tjp,
                               uint32_t begin_index,
                               TrajectoryPoint *next_tjp,
                               uint32_t *next_begin_index,
                               double target_distance) {
    TrajectoryPoint begin_tp = current_tjp;
    int i = begin_index;
    while (i < static_cast<int>(traj.size())) {
        AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got begin_tp: "
                                 << begin_tp.position;
        AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got trajectory: "
                                 << traj[i].position;
        if (cv::norm(begin_tp.position - traj[i].position) - target_distance >
            0.0001) {
            // if(i-1 behind begin_tp) {
            //  find point b in beginpoint-tp[i] that
            //      pointb - begin_point = R
            // }
            // else
            //  find point b in [i-1] [i]] that
            //      pb -bp  == R
            // result .push _back(begin point)
            // beginpoint = point b
            TrajectoryPoint tjpoint_end = TrajectoryPoint();

            AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory begin to cut ";
            if (i == static_cast<int>(begin_index)) {
                // find point b in begin_tp tp[i]
                AD_LTRACE(PATH_PLANNING)
                    << "SegmentTrajectory freshed cut, cut ahead ";
                auto delta = traj[i].position - begin_tp.position;
                delta = delta * (target_distance / cv::norm(delta));
                auto pos_end = begin_tp.position + delta;
                tjpoint_end.position = pos_end;
            } else {
                AD_LTRACE(PATH_PLANNING)
                    << "SegmentTrajectory rotten cut, trinometry";
                // find point_end in tp[i-1] tp[i]
                // in triangle tp[i-1], begin_tp, posi_end
                //   use cos therum to find length of (tp[i-1], posi_end)
                auto lb = begin_tp.position - traj[i - 1].position;
                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got lb: " << lb;
                auto lc = traj[i].position - traj[i - 1].position;
                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got lc: " << lc;
                auto cos_A = (lb.x * lc.x + lb.y * lc.y) /
                             sqrtf((lb.x * lb.x + lb.y * lb.y) *
                                   (lc.x * lc.x + lc.y * lc.y));

                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got cos_A: "
                                         << cos_A;
                auto dist_lb = cv::norm(lb);

                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got dist_lb: "
                                         << dist_lb;
                auto dist_c = sqrtf(dist_lb * dist_lb * cos_A * cos_A -
                                    dist_lb * dist_lb +
                                    target_distance * target_distance) +
                              dist_lb * cos_A;
                if (dist_lb < 0.001) {
                    dist_c = cv::norm(target_distance);
                }

                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got dist_c: "
                                         << dist_c;
                auto delta = traj[i].position - traj[i - 1].position;
                delta = delta * (dist_c / cv::norm(delta));
                auto pos_end = traj[i - 1].position + delta;
                tjpoint_end.position = pos_end;
                AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory Got position: "
                                         << pos_end;
            }
            *next_tjp = tjpoint_end;
            *next_begin_index = i;
        } else if (cv::norm(begin_tp.position - traj[i].position) -
                       target_distance <
                   -0.0001) {
            AD_LTRACE(PATH_PLANNING) << "SegmentTrajectory no candidate";
            i++;
        } else {
            TrajectoryPoint tjpoint_end = traj[i];
            i++;
            *next_tjp = tjpoint_end;
            *next_begin_index = i;
        }
    }
    return AD_SUCCESS;
}

adStatus_t EstimatePathTime(std::vector<TrajectoryPoint> *traj_path) {
    if (traj_path == nullptr) {
        return AD_NULL_PTR;
    }
    if (traj_path->size() == 0) {
        return AD_SUCCESS;
    }
    // 1. fill the first of the traj
    // 2. fill the rest based on avg_velocity, and distance
    traj_path->at(0).time_difference = 0;

    for (uint32_t i = 1; i < traj_path->size(); i++) {
        float dist =
            traj_path->at(i).sum_distance - traj_path->at(i - 1).sum_distance;
        float avgv =
            (traj_path->at(i).velocity + traj_path->at(i - 1).velocity) * 0.5;
        traj_path->at(i).time_difference =
            traj_path->at(i - 1).time_difference +
            (avgv > 0.01 ? dist / avgv : 1000);
    }
    return AD_SUCCESS;
}
// TODO(congq): complete the funciton
std::vector<TrajectoryPoint> CombineTrajectory(
    const std::vector<TrajectoryPoint> &traj_a,
    const std::vector<TrajectoryPoint> &traj_b) {
    return traj_b;
}

void PathElongation(Trajectory *path,
                    const Trajectory &ref_line_,
                    const float &insert_distance_) {
    float s = 0, ds, dds, d = 0, dd, ddd;
    float velocity_to_append = 0;
    if (ref_line_.size() == 0) {
        return;
    }
    if (path->size() > 0) {
        auto path_end_tjpoint = path->back();
        g_nn_tool.UpdateData(ref_line_);
        utils::CartesianToFrenet(path_end_tjpoint, ref_line_, &s, &ds, &dds, &d,
                                 &dd, &ddd);
        velocity_to_append = path_end_tjpoint.velocity;
        AD_LINFO(PATH_PLANNING)
            << "path end velocity " << velocity_to_append << "\npath end "
            << path_end_tjpoint.position << " " << path_end_tjpoint.direction
            << " " << path_end_tjpoint.theta << "\npath end frenet" << s << " "
            << d;
    }
    float rs, rds, rdds, rd, rdd, rddd;
    utils::CartesianToFrenet(ref_line_.back(), ref_line_, &rs, &rds, &rdds, &rd,
                             &rdd, &rddd);
    Trajectory extended_path;
    for (float es = s + insert_distance_; es < rs; es += insert_distance_) {
        TrajectoryPoint trajpt_to_insert;
        float esd = 0, esdd = 0;
        utils::FrenetToCartesian(es, esd, esdd, d, dd, ddd, ref_line_,
                                 &trajpt_to_insert);
        // trajpt_to_insert.velocity = velocity_to_append;
        extended_path.push_back(trajpt_to_insert);
        AD_LDEBUG(PATH_PLANNING) << "ELON traj pt to insert"
                                 << trajpt_to_insert.position;
    }

    Trajectory result_extended_path;
    result_extended_path.clear();
    utils::SegmentTrajectory(extended_path, insert_distance_,
                             &result_extended_path);
    for (auto &pt : result_extended_path) {
        pt.velocity = velocity_to_append;
    }
    path->insert(path->end(), result_extended_path.begin(),
                 result_extended_path.end());
    utils::SegmentTrajectory(extended_path, insert_distance_,
                             &result_extended_path);
}
static unsigned int solveP3(double *x, double a, double b, double c) {
    const double eps = 1e-12;
    const double PI = 3.141592653589793238463L;
    const double M_2PI = 2 * PI;
    double a2 = a * a;
    double q = (a2 - 3 * b) / 9;
    double r = (a * (2 * a2 - 9 * b) + 27 * c) / 54;
    double r2 = r * r;
    double q3 = q * q * q;
    if (r2 < q3) {
        double t = r / sqrt(q3);
        if (t < -1) t = -1;
        if (t > 1) t = 1;
        t = acos(t);
        a /= 3;
        q = -2 * sqrt(q);
        x[0] = q * cos(t / 3) - a;
        x[1] = q * cos((t + M_2PI) / 3) - a;
        x[2] = q * cos((t - M_2PI) / 3) - a;
        return 3;
    } else {
        double A, B;
        A = -pow(fabs(r) + sqrt(r2 - q3), 1. / 3);
        if (r < 0) A = -A;
        B = (0 == A ? 0 : q / A);

        a /= 3;
        x[0] = (A + B) - a;
        x[1] = -0.5 * (A + B) - a;
        x[2] = 0.5 * sqrt(3.) * (A - B);
        if (fabs(x[2]) < eps) {
            x[2] = x[1];
            return 2;
        }

        return 1;
    }
}

void solve_quartic(
    std::complex<double> *retval, double a, double b, double c, double d) {
    if (retval == nullptr) {
        return;
    }
    const double eps = 1e-12;
    double a3 = -b;
    double b3 = a * c - 4. * d;
    double c3 = -a * a * d - c * c + 4. * b * d;

    // cubic resolvent
    // y^3 − b*y^2 + (ac−4d)*y − a^2*d−c^2+4*b*d = 0

    double x3[3];
    unsigned int iZeroes = solveP3(x3, a3, b3, c3);

    double q1, q2, p1, p2, D, sqD, y;

    y = x3[0];
    // The essence - choosing Y with maximal absolute value.
    if (iZeroes != 1) {
        if (fabs(x3[1]) > fabs(y)) y = x3[1];
        if (fabs(x3[2]) > fabs(y)) y = x3[2];
    }

    // h1+h2 = y && h1*h2 = d  <=>  h^2 -y*h + d = 0    (h === q)
    D = y * y - 4 * d;
    // in other words - D==0
    if (fabs(D) < eps) {
        q1 = q2 = y * 0.5;
        // g1+g2 = a && g1+g2 = b-y   <=>   g^2 - a*g + b-y = 0    (p === g)
        D = a * a - 4 * (b - y);
        if (fabs(D) < eps) {
            // in other words - D==0
            p1 = p2 = a * 0.5;
        } else {
            sqD = sqrt(D);
            p1 = (a + sqD) * 0.5;
            p2 = (a - sqD) * 0.5;
        }
    } else {
        sqD = sqrt(D);
        q1 = (y + sqD) * 0.5;
        q2 = (y - sqD) * 0.5;
        // g1+g2 = a && g1*h2 + g2*h1 = c       ( && g === p )  Krammer
        p1 = (a * q1 - c) / (q1 - q2);
        p2 = (c - a * q2) / (q1 - q2);
    }

    // solving quadratic eq. - x^2 + p1*x + q1 = 0
    D = p1 * p1 - 4 * q1;
    if (D < 0.0) {
        retval[0].real(-p1 * 0.5);
        retval[0].imag(sqrt(-D) * 0.5);
        retval[1] = std::conj(retval[0]);
    } else {
        sqD = sqrt(D);
        retval[0].real((-p1 + sqD) * 0.5);
        retval[1].real((-p1 - sqD) * 0.5);
    }

    // solving quadratic eq. - x^2 + p2*x + q2 = 0
    D = p2 * p2 - 4 * q2;
    if (D < 0.0) {
        retval[2].real(-p2 * 0.5);
        retval[2].imag(sqrt(-D) * 0.5);
        retval[3] = std::conj(retval[2]);
    } else {
        sqD = sqrt(D);
        retval[2].real((-p2 + sqD) * 0.5);
        retval[3].real((-p2 - sqD) * 0.5);
    }
}

Trajectory TrimProperBasePath(const Trajectory &path,
                              const TrajectoryPoint &goal) {
    float min_distance = std::numeric_limits<float>::max();
    int min_idx = -1;
    for (size_t i = 0; i < path.size(); i++) {
        auto dist = cv::norm(goal.position - path[i].position);
        if (dist < min_distance) {
            min_idx = i;
            min_distance = dist;
        }
    }
    return Trajectory(path.begin(), path.begin() + min_idx + 1);
}

adStatus_t cos_pt2f(const cv::Point2f &pt_a,
                    const cv::Point2f &pt_b,
                    float *result) {
    auto norm_axb = cv::norm(pt_a) * cv::norm(pt_b);
    float ekp = 0.00001;
    if (norm_axb < ekp) {
        AD_LINFO(PATH_PLANNING) << "Not valid input";
        *result = 1;
    } else {
        *result = (pt_a.x * pt_b.x + pt_a.y * pt_b.y) / norm_axb;
    }
    return AD_SUCCESS;
}

// TODO(congq): use lambda
int MatchClosestPoint(const Trajectory &trajectory,
                      int start_index,
                      const cv::Point2f &position,
                      double range) {
    float min_distance = std::numeric_limits<float>::max();
    int min_index = trajectory.size();
    for (uint32_t i = start_index; i < trajectory.size(); i++) {
        auto dist =
            cv::norm(trajectory.front().position - trajectory[i].position);
        if (dist > range) {
            break;
        }
        auto dist_to_car = cv::norm(trajectory[i].position - position);
        if (dist_to_car < min_distance) {
            min_distance = dist_to_car;
            min_index = i;
        }
    }
    return min_index;
}

void UpdateSumDistance(Trajectory *trajectory, const cv::Point2f &pt) {
    // 1. find sum_distance of the the first trajectory point
    if (trajectory->empty()) {
        return;
    }
    float32_t init_sumdist = 0;
    auto vec_traj0_to_position = pt - trajectory->at(0).position;
    auto direct_0 = trajectory->at(0).direction;
    if (cv::norm(vec_traj0_to_position) > 0.0001) {
        init_sumdist = (vec_traj0_to_position.x * direct_0.x +
                        vec_traj0_to_position.y * direct_0.y) /
                       cv::norm(direct_0);
    }
    AD_LINFO(PATH_PLANNING) << "init_sumdist " << init_sumdist;

    trajectory->at(0).sum_distance = init_sumdist;
    for (size_t i = 1; i < trajectory->size(); i++) {
        trajectory->at(i).sum_distance =
            cv::norm(trajectory->at(i).position -
                     trajectory->at(i - 1).position) +
            trajectory->at(i - 1).sum_distance;
    }

    trajectory->at(0).sum_distance = -init_sumdist;
}

void UpdateCurvatureYawrate(Trajectory *trajectory, int step) {
    if (trajectory->empty()) {
        return;
    }
    if (trajectory->size() == 1) {
        trajectory->at(0).curvature = 0;
        trajectory->at(0).yaw_rate = 0;
    }
    for (size_t i = 0; i < trajectory->size(); i++) {
        int upper = std::min(static_cast<int>(i) + step,
                             static_cast<int>(trajectory->size()) - 1);
        int lower = std::max(static_cast<int>(i) - step, 0);
        auto ds = trajectory->at(upper).sum_distance -
                  trajectory->at(lower).sum_distance;
        auto curvature = 0.0;
        if (ds > 0.00001) {
            auto dtangent =
                trajectory->at(upper).theta - trajectory->at(lower).theta;
            if (dtangent > M_PI) {
                dtangent = -M_PI + (dtangent - M_PI);
            }
            if (dtangent < -M_PI) {
                dtangent = M_PI - (-M_PI - dtangent);
            }
            curvature = dtangent / ds;
        }
        trajectory->at(i).curvature = curvature;
        trajectory->at(i).yaw_rate = curvature * trajectory->at(i).velocity;
    }
    return;
}

adStatus_t BezierCurveAmend(const cv::Point2f &p0,
                            cv::Point2f *p1,
                            cv::Point2f *p2,
                            const cv::Point2f &p3) {
    // 1. check if p0 and p1 in two side of line p2p3
    cv::Point2f p3p2 = *p2 - p3;
    cv::Point2f p3p0 = p0 - p3;
    cv::Point2f p3p1 = *p1 - p3;
    float is_two_side = p3p2.cross(p3p0) * p3p2.cross(p3p1);
    AD_LINFO(BEZIER) << "two side product " << is_two_side;
    if (is_two_side >= 0) {
        // p0 and p1 in one side of line p2p3
        return AD_SUCCESS;
    }
    // 2. calculate intersection of line p0p1 and line p2p3
    std::vector<cv::Point2f> line_p2p3 = {*p2, p3};
    std::vector<cv::Point2f> line_p0p1 = {p0, *p1};
    float a1, b1, c1, a2, b2, c2;
    if (PointsToLine(line_p0p1, &a1, &b1, &c1) != AD_SUCCESS) {
        AD_LERROR("calculation of line equation by points failed!");
        return AD_INVALID_PARAM;
    }
    if (PointsToLine(line_p2p3, &a2, &b2, &c2) != AD_SUCCESS) {
        AD_LERROR("calculation of line equation by points failed!");
        return AD_INVALID_PARAM;
    }
    if (IntersectionPoint(a1, b1, c1, a2, b2, c2, p1) != AD_SUCCESS) {
        AD_LERROR("calculation of intersection of two lines failed!");
        return AD_INVALID_PARAM;
    }
    return AD_SUCCESS;
}

void CalcPerpendicularFoot(const cv::Point2f &point,
                           const std::vector<cv::Point2f> &line,
                           cv::Point2f *foot) {
    if (foot == nullptr) {
        AD_LERROR(PATH_PLANNING) << "pointer of foot is nullptr";
        return;
    }
    // 1. calculate equation of staight line
    float a = 1.0, b = 1.0, c = 1.0;
    PointsToLine(line, &a, &b, &c);

    // 2. calculate coordinates of perpendicular foot
    foot->x = (b * b * point.x - a * b * point.y - a * c) / (a * a + b * b);
    foot->y = (-a * b * point.x + a * a * point.y - b * c) / (a * a + b * b);
}

void SetTimestamp(std::vector<TrajectoryPoint> *out_path,
                  const float insert_distance) {
    if (out_path == nullptr) {
        AD_LERROR(PATH_PLANNING) << "output path is nullptr";
        return;
    }
    if (out_path->empty()) {
        AD_LERROR(PATH_PLANNING) << "output path is empty.";
        return;
    }
    auto t_now = std::chrono::time_point_cast<std::chrono::microseconds>(
        std::chrono::high_resolution_clock::now());
    out_path->front().timestamp =
        static_cast<uint64_t>(t_now.time_since_epoch().count() * 1000);
    for (uint32_t i = 1; i < out_path->size(); ++i) {
        float delta_t =
            2.0 * insert_distance /
            (out_path->at(i - 1).velocity + out_path->at(i).velocity + 0.0001);
        delta_t = std::max<float>(delta_t, 0.0f);
        out_path->at(i).timestamp = out_path->at(i - 1).timestamp +
                                    static_cast<uint64_t>(delta_t * 1e9);
    }
}

const std::string GetTimestampString() {
    std::chrono::high_resolution_clock::time_point p =
        std::chrono::high_resolution_clock::now();
    std::time_t local_t = std::chrono::system_clock::to_time_t(p);
    std::stringstream ss1;
    std::chrono::milliseconds ms =
        std::chrono::duration_cast<std::chrono::milliseconds>(
            p.time_since_epoch());
    std::size_t fractional_seconds = ms.count() % 1000;
    std::string extra_zero = "";
    if (fractional_seconds < 100) {
        extra_zero = "0";
    }
    ss1 << std::put_time(std::localtime(&local_t), "%Y-%m-%d-%H-%M-%S") << "-"
        << extra_zero << fractional_seconds;
    return ss1.str();
}

}  // namespace utils
}  // namespace pp
}  // namespace senseAD
