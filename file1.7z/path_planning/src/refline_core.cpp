/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong<qiucong@sensetime.com>
 */

#include <math.h>
#include <random>
#include <cmath>
#include <chrono>  // NOLINT
#include <string>
#include <functional>
#include "common/log.hpp"
#include "path_planning/rrt_node.hpp"
#include "ini.h"  // NOLINT
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/refline_core.hpp"

namespace senseAD {
namespace pp {

adStatus_t ReflineCore::Init() { return AD_SUCCESS; }

ReflineCore::~ReflineCore() {}

adStatus_t ReflineCore::Plan(std::vector<TrajectoryPoint> *out_path) {
    // Implying a refpath with 1m interval
    *out_path = std::vector<TrajectoryPoint>(
        base_path_.begin(),
        base_path_.begin() +
            std::min(static_cast<int>(base_path_.size()), 250));
    for (size_t i = 0; i < out_path->size(); i++) {
        out_path->at(i).velocity = goal_.velocity;
    }
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
