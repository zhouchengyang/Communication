/*
 * Copyright (C) 2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include "path_planning/frenet_coordinate_system.hpp"
#include <iostream>

namespace senseAD {
namespace pp {

void FrenetCoordinateSystem::Init() { nn_tool_.Init(); }

bool FrenetCoordinateSystem::Update(const std::vector<TrajectoryPoint>& points,
                                    const uint32_t origin_index) {
    if (points.size() < 2 || origin_index >= points.size()) {
        return false;
    }
    cv::Point2f origin_point = points.at(origin_index).position;
    return UpdateReflineAndOrigin(points, origin_point);
}

bool FrenetCoordinateSystem::Update(const std::vector<TrajectoryPoint>& points,
                                    const cv::Point2f& origin_point) {
    if (points.size() < 2) {
        return false;
    }
    return UpdateReflineAndOrigin(points, origin_point);
}

bool FrenetCoordinateSystem::UpdateReflineAndOrigin(
    const std::vector<TrajectoryPoint>& points,
    const cv::Point2f& origin_point) {
    const uint32_t min_refline_points = 10;
    if (points.size() < min_refline_points) {
        AD_LERROR(FrenetCoordinateSystem) << "invalid refline";
        return false;
    }
    ref_line_.clear();
    utils::SegmentTrajectory(points, frenet_resolution_, &ref_line_);
    nn_tool_.UpdateData(ref_line_);

    cv::Point2f frenet_from_front = CalcSDFromFront(origin_point);
    // calculate origin point
    start_sum_distance_ = -1.0 * frenet_from_front.x;
    is_valid_ = true;
    return true;
}

cv::Point2f FrenetCoordinateSystem::Frenet2Cartesian(const float s,
                                                     const float d) const {
    if (ref_line_.size() < 2) {
        AD_LERROR(FrenetCoordinateSystem) << "invalid ref line";
        return cv::Point2f(-10000.0f, -10000.0f);
    }
    // s / accumulated dist ~= indeiix
    float accumulative_s = s - start_sum_distance_;
    int match_id =
        std::min(static_cast<int>(accumulative_s / frenet_resolution_),
                 static_cast<int>(ref_line_.size() - 1));
    match_id = std::max(0, match_id);

    auto matched_ref_pt = ref_line_[match_id];
    auto base_position = matched_ref_pt.position;

    if (match_id < static_cast<int32_t>(ref_line_.size()) - 2) {
        float ratio = (accumulative_s - ref_line_[match_id].sum_distance) /
                      frenet_resolution_;
        base_position =
            base_position +
            (ref_line_[match_id + 1].position - base_position) * ratio;
    }

    cv::Point2f result_pt;
    result_pt.x = base_position.x - d * sin(matched_ref_pt.theta);
    result_pt.y = base_position.y + d * cos(matched_ref_pt.theta);
    return result_pt;
}

cv::Point2f FrenetCoordinateSystem::Cartesian2Frenet(
    const cv::Point2f& cartesian_point) const {
    auto result_pt = CalcSDFromFront(cartesian_point);
    result_pt.x = result_pt.x + start_sum_distance_;
    return result_pt;
}

float FrenetCoordinateSystem::GetHeadingAtS(const float s) const {
    // just accord to sum distance to find heading, due to equal insert distance
    // and sum distance start from zero
    float result_heading = 0.0f;
    if (ref_line_.size() < 2) {
        AD_LERROR(REF_LINE) << "size of ref_line_ is less than 2";
        return result_heading;
    }
    float accumulative_s = s - start_sum_distance_;
    if (accumulative_s <= 0.0) {
        result_heading = std::atan2(ref_line_.front().direction.y,
                                    ref_line_.front().direction.x);
        return AD_SUCCESS;
    }
    uint32_t index1 = std::floor(accumulative_s / frenet_resolution_);
    uint32_t index2 = std::ceil(accumulative_s / frenet_resolution_);
    if (index1 < ref_line_.size() && index2 < ref_line_.size()) {
        cv::Point2f dir = 0.5 * (ref_line_.at(index1).direction +
                                 ref_line_.at(index2).direction);
        result_heading = std::atan2(dir.y, dir.x);
    } else if (index1 < ref_line_.size()) {
        result_heading = std::atan2(ref_line_.at(index1).direction.y,
                                    ref_line_.at(index1).direction.x);
    } else {
        result_heading = std::atan2(ref_line_.back().direction.y,
                                    ref_line_.back().direction.x);
    }
    return result_heading;
}

const bool FrenetCoordinateSystem::IsValid() const { return is_valid_; }

const cv::Point2f FrenetCoordinateSystem::CalcSDFromFront(
    const cv::Point2f& cart_point) const {
    cv::Point2f result_pt;
    TrajectoryPoint pt;
    pt.position = cart_point;
    auto min_index = nn_tool_.NearestNeighbor(pt);
    if (min_index >= static_cast<int32_t>(ref_line_.size())) {
        min_index = ref_line_.size() - 1;
    }

    float cos_A = -1.0f;
    cv::Point2f vec_b(1, 0), vec_c(1, 0);

    vec_b = ref_line_[min_index].direction;
    vec_c = pt.position - ref_line_[min_index].position;
    float l_v_b = cv::norm(vec_b);
    float l_v_c = cv::norm(vec_c);

    if ((l_v_c) < 0.0001) {
        result_pt.x = static_cast<float>(min_index) * frenet_resolution_;
        cos_A = 1;
    } else {
        cos_A = (vec_b.x * vec_c.x + vec_b.y * vec_c.y) / (l_v_b * l_v_c);
    }

    while (min_index > 0 && cos_A < 0) {
        min_index--;
        vec_b = ref_line_[min_index].direction;
        vec_c = pt.position - ref_line_[min_index].position;
        l_v_b = cv::norm(vec_b);
        l_v_c = cv::norm(vec_c);
        if ((l_v_c) < 0.0001) {
            result_pt.x = static_cast<float>(min_index) * frenet_resolution_;
            cos_A = 1;
        } else {
            cos_A = (vec_b.x * vec_c.x + vec_b.y * vec_c.y) / (l_v_b * l_v_c);
        }
    }
    result_pt.x =
        l_v_c * cos_A + static_cast<float>(min_index) * frenet_resolution_;
    float sin_A = 0;
    float mid_val = 1 - cos_A * cos_A;
    if (mid_val > 0) {
        sin_A = std::sqrt(1 - cos_A * cos_A);
    }

    // auto abs_d = sqrt(l_v_c * l_v_c + l_v_b * l_v_b);
    auto abs_d = std::abs(l_v_c * sin_A);
    auto cross_b_c = vec_b.x * vec_c.y - vec_b.y * vec_c.x;
    if (cross_b_c > 1e-4) {
        result_pt.y = abs_d;
    } else {
        result_pt.y = -abs_d;
    }
    return result_pt;
}
}  // namespace pp
}  // namespace senseAD

