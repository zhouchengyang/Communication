/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 * Liang Yu <liangyu@sensetime.com>
 */

#include "common/log.hpp"
#include "path_planning/cache_point.hpp"

namespace senseAD {
namespace pp {

CachePoint::CachePoint() {}

CachePoint::~CachePoint() {}

adStatus_t CachePoint::Init() {
    auto conf = g_pp_conf["rrt_setting"];
    max_pool_size_ = conf["max_pool_size_"];
    max_tj_pool_size_ = conf["max_tj_pool_size"];
    off_track_tolerance_ = conf["off_track_tolerance"];
    length_discrepance_tolerance_ = conf["length_discrepance_tolerance"];
    max_tjp_diff_tolerance_ = conf["max_tjp_diff_tolerance"];
    avg_tjp_diff_tolerance_ = conf["avg_tjp_diff_tolerance"];
    return AD_SUCCESS;
}
adStatus_t CachePoint::WarpPoint(cv::Point2f* point) {
    return WarpPoint_(point);
}

adStatus_t CachePoint::WarpPoint(TrajectoryPoint* traj_pt) {
    auto new_position = traj_pt->position;
    auto new_direction = traj_pt->direction;
    auto new_position_with_direction = new_position + new_direction;
    WarpPoint(&new_position);
    WarpPoint(&new_position_with_direction);
    traj_pt->position = new_position;
    traj_pt->direction = new_position_with_direction - new_position;
    return AD_SUCCESS;
}

adStatus_t CachePoint::SetParameters(const int& max_pool_size,
                                     const int& max_tj_pool_size) {
    AD_LINFO(PATH_PLANNING) << "PPTracker setting parameter";

    this->max_pool_size_ = max_pool_size;
    this->max_tj_pool_size_ = max_tj_pool_size;

    AD_LINFO(PATH_PLANNING) << "PPTracker pool_size: " << max_pool_size;
    AD_LINFO(PATH_PLANNING) << "PPTracker tj_pool_size: " << max_tj_pool_size;

    AD_LINFO(PATH_PLANNING) << "PPTracker setting parameter";
    return AD_SUCCESS;
}

adStatus_t CachePoint::Update(const int64_t& timestamp) {
    this->last_timestamp_ = timestamp;
    AD_LDEBUG(PATH_PLANNING) << "PPTracker finding dated trajectory point";
    std::vector<int> to_be_deleted;
    for (auto access_time : last_access_time_) {
        // TODO(congq): Shove them in config
        if (this->last_timestamp_ - access_time.second > timeout_) {
            to_be_deleted.push_back(access_time.first);
        }
    }

    AD_LDEBUG(PATH_PLANNING) << "PPTracker deleting trajectory point";
    for (auto idx : to_be_deleted) {
        // TODO(congq): vlog(4) to output deleted
        history_trajectroy_pool_.erase(idx);
    }

    AD_LINFO(PATH_PLANNING)
        << "PPTracker warping history points and their direction"
        << " total number:" << history_trajectroy_pool_.size();
    for (auto traj_pool : history_trajectroy_pool_) {
        auto index = traj_pool.first;
        for (uint32_t i = 0; i < history_trajectroy_pool_[index].size(); i++) {
            // WarpPoint(history_trajectroy_pool_[index][i].position);
            auto new_position = history_trajectroy_pool_[index][i].position;
            auto new_direction = history_trajectroy_pool_[index][i].direction;
            auto new_position_with_direction = new_position + new_direction;
            WarpPoint_(&new_position);
            WarpPoint_(&new_position_with_direction);
            history_trajectroy_pool_[index][i].position = new_position;
            history_trajectroy_pool_[index][i].direction =
                new_position_with_direction - new_position;
        }
    }

    // warp the cached trajectory
    std::vector<TrajectoryPoint> new_trajectory;
    new_trajectory.clear();

    AD_LINFO(PATH_PLANNING) << "Before length of cached trjec "
                            << cached_trajectory_.size();
    for (uint32_t i = 0; i < cached_trajectory_.size(); i++) {
        auto new_trajectory_point = cached_trajectory_[i];
        WarpPoint(&new_trajectory_point);

        // fill theta
        auto raw_direction = new_trajectory_point.direction;

        float len = cv::norm(raw_direction);
        if (len < 10e-5) {
            new_trajectory_point.theta = 0.0;
        } else {
            new_trajectory_point.theta =
                std::atan2(raw_direction.y, raw_direction.x);
        }

        if (new_trajectory_point.position.x > 0) {
            new_trajectory.push_back(new_trajectory_point);
        }
    }
    cached_trajectory_ = new_trajectory;

    std::map<int, std::vector<TrajectoryPoint> > new_pool;

    for (auto& traj : trajectory_pool_) {
        new_trajectory.clear();
        auto& old_traj = traj.second;

        for (uint32_t i = 0; i < old_traj.size(); i++) {
            TrajectoryPoint new_trajectory_point = old_traj[i];
            WarpPoint(&new_trajectory_point);
            if (new_trajectory_point.position.x > 0) {
                new_trajectory.push_back(new_trajectory_point);
            }
        }
        new_pool[traj.first] = new_trajectory;
    }
    trajectory_pool_ = new_pool;
    // if off track replan
    AD_LINFO(PATH_PLANNING) << "After length of cached trjec "
                            << cached_trajectory_.size();
    return AD_SUCCESS;
}

adStatus_t CachePoint::CacheTrajectoryPoint(const int& id,
                                            const TrajectoryPoint& tj_point) {
    AD_LDEBUG(PATH_PLANNING) << "PPTracker cachingPoint"
                             << "ID: " << std::to_string(id);
    auto tail_posi = pool_tail_[id];
    if (static_cast<int>(history_trajectroy_pool_[id].size()) <
        max_pool_size_) {
        // Append new node
        history_trajectroy_pool_[id].push_back(tj_point);
    } else {
        // sliding window
        history_trajectroy_pool_[id][tail_posi] = tj_point;
    }
    tail_posi = (tail_posi + 1) % max_pool_size_;
    pool_tail_[id] = tail_posi;
    AD_LDEBUG(PATH_PLANNING) << "taiposi : " << tail_posi;
    AD_LDEBUG(PATH_PLANNING) << "this is the history trajectrpy size: "
                             << history_trajectroy_pool_[id].size();
    last_access_time_[id] = this->last_timestamp_;

    AD_LDEBUG(PATH_PLANNING) << "PPTracker cached Point";
    return AD_SUCCESS;
}

adStatus_t CachePoint::ClearPointByID(const int& id) {
    AD_LINFO(PATH_PLANNING) << "PPTracker Clearing ID" << id;
    history_trajectroy_pool_.erase(id);
    AD_LINFO(PATH_PLANNING) << "PPTracker Cleared by ID";
    return AD_SUCCESS;
}

adStatus_t CachePoint::QueryTrajectoryPoint(const int& id,
                                            TrajectoryPoint* tj_point) {
    AD_LDEBUG(PATH_PLANNING) << "PPTracker Querying by ID";
    AD_LINFO(PATH_PLANNING) << "ID: " << id
                            << " Point: " << (*tj_point).position;

    TrajectoryPoint result_point = TrajectoryPoint();
    int size = history_trajectroy_pool_[id].size();
    cv::Point2f result_positon;
    cv::Point2f result_direction;
    // TODO(congq): possible bug here, could have return nothing
    //      resulting in unknow behavior
    if (size == 0) {
        AD_LDEBUG(PATH_PLANNING) << "No such point cached at id: " << id;
        return AD_SUCCESS;
    }
    for (auto traj_p : history_trajectroy_pool_[id]) {
        result_positon = result_positon + traj_p.position * (1.0 / size);
        result_direction = result_direction + traj_p.direction * (1.0 / size);
    }

    result_point.position = result_positon;
    result_point.direction = result_direction;

    *tj_point = result_point;

    last_access_time_[id] = this->last_timestamp_;
    AD_LINFO(PATH_PLANNING) << "ID: " << id
                            << " Got result: " << (*tj_point).position;
    AD_LDEBUG(PATH_PLANNING) << "PPTracker Queried by ID";
    return AD_SUCCESS;
}

adStatus_t CachePoint::CachePathWithSmooth(
    const std::vector<TrajectoryPoint>& new_trajectory) {
    AD_LINFO(PATH_PLANNING) << "PP Tracker Caching Trajectory "
                            << new_trajectory.size();
    AD_LINFO(PATH_PLANNING) << "PPTracker got trajectory before "
                            << cached_trajectory_.size();
    if (new_trajectory.size() < cached_trajectory_.size()) {
        // truncatte cached trajectory
        cached_trajectory_.resize(new_trajectory.size());
    }
    // Average the path, cached trajectory using weigth 50 to 0,
    //  new trajectory using weight 50 to 100
    std::vector<TrajectoryPoint> result_trajectory;
    float weight_begin = 0.1;
    float weight_end = 1.0;

    float weight_step =
        (cached_trajectory_.size() == 0 ? 0 : ((weight_end - weight_begin) /
                                               cached_trajectory_.size()));

    for (uint32_t i = 0; i < cached_trajectory_.size(); i++) {
        float weight_new_point = weight_begin + weight_step * i;
        float weight_cached_point = 1.0 - weight_new_point;
        // average the two trajectroy point from two trajectory
        TrajectoryPoint average_point;
        TrajectoryPoint cached_point = cached_trajectory_[i];
        TrajectoryPoint new_point = new_trajectory[i];

        AD_LDEBUG(PATH_PLANNING) << "PPTracker avevaging cached: "
                                 << cached_point.position;
        AD_LDEBUG(PATH_PLANNING) << "PPTracker avevaging new : "
                                 << new_point.position;
        average_point.position = cached_point.position * weight_cached_point +
                                 new_point.position * weight_new_point;
        AD_LDEBUG(PATH_PLANNING) << "PPTracker avevaging: "
                                 << average_point.position;
        result_trajectory.push_back(average_point);
    }

    for (uint32_t i = cached_trajectory_.size(); i < new_trajectory.size();
         i++) {
        result_trajectory.push_back(new_trajectory[i]);
        AD_LDEBUG(PATH_PLANNING) << "PPTracker keepadding: "
                                 << new_trajectory[i].position;
    }
    cached_trajectory_ = result_trajectory;
    AD_LINFO(PATH_PLANNING) << "PPTracker got trajectory "
                            << cached_trajectory_.size();
    return AD_SUCCESS;
}

adStatus_t CachePoint::CachePath(
    const std::vector<TrajectoryPoint>& new_trajectory) {
    AD_LINFO(PATH_PLANNING) << "PP Tracker Caching Trajectory "
                            << new_trajectory.size();
    cached_trajectory_ = new_trajectory;
    return AD_SUCCESS;
}

adStatus_t CachePoint::QueryPath(std::vector<TrajectoryPoint>* result_path) {
    AD_LINFO(PATH_PLANNING) << "PPTracker quering trajectory "
                            << result_path->size();
    *result_path = cached_trajectory_;
    return AD_SUCCESS;
}

// TODO(congq): complete this function
adStatus_t CachePoint::TrackPath(
    const int& id, const std::vector<TrajectoryPoint>& trajectory) {
    trajectory_pool_.erase(id);
    trajectory_pool_[id] = trajectory;
    return AD_SUCCESS;
}
adStatus_t CachePoint::QueryPath(const int& id,
                                 std::vector<TrajectoryPoint>* trajectory) {
    *trajectory = trajectory_pool_[id];
    return AD_SUCCESS;
}

adStatus_t CachePoint::TryTrajectoryPoint(const int& id,
                                          TrajectoryPoint* tj_point) {
    AD_LINFO(PATH_PLANNING) << "PPTracker Trying Trajectory Point ";
    if (tj_point == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    int size = history_trajectroy_pool_[id].size();
    tj_point->position = tj_point->position * (1.0 / (size + 1));
    tj_point->direction = tj_point->direction * (1.0 / (size + 1));
    for (auto traj_p : history_trajectroy_pool_[id]) {
        tj_point->position =
            tj_point->position + traj_p.position * (1.0 / (size + 1));
        tj_point->direction =
            tj_point->direction + traj_p.direction * (1.0 / (size + 1));
    }
    AD_LINFO(PATH_PLANNING) << "PPTracker Tried Trajectory Point";
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
