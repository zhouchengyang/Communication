/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#include "path_planning/honda_ctl_tgt_sender.hpp"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

namespace senseAD {
namespace pp {

const int MAX_POINTS = 150;

union TgtPtPacket {
    struct {
        int x[MAX_POINTS];  // Position X     ( m   * DECIMAL_GAIN )
        int y[MAX_POINTS];  // Position Y     ( m   * DECIMAL_GAIN )
        int id;             // Marker ID      ( waypoint id        )
    } msg_buf;
    char content[sizeof(int) * (MAX_POINTS * 2 + 1)];
};

HondaCtlTgtSender::HondaCtlTgtSender() {}

adStatus_t HondaCtlTgtSender::SetHCI(const HondaCtlInput& hci) {
    this->hci_ = hci;
    return AD_SUCCESS;
}

adStatus_t HondaCtlTgtSender::set_ip_addr(const std::string ip_addr) {
    pt_sock = socket(AF_INET, SOCK_DGRAM, 0);
    pt_addr.sin_addr.s_addr = inet_addr(ip_addr.c_str());
    pt_addr.sin_port = htons(pt_PORT);

    pt_addr.sin_family = AF_INET;
    return AD_SUCCESS;
}

HondaCtlTgtSender::~HondaCtlTgtSender() {}

adStatus_t HondaCtlTgtSender::SendHCIPacket() {
    TgtPtPacket tgt_pt_packet;
    for (int i = 0; i < MAX_POINTS; i++) {
        // tgt_pt_packet.msg_buf.x[i] = i * DECIMAL_GAIN;
        tgt_pt_packet.msg_buf.x[i] =
            hci_.tgt_points[MAX_POINTS + 1 + i] * DECIMAL_GAIN;
        // tgt_pt_packet.msg_buf.y[i] =
        // sin(i * 2 * M_PI / MAX_POINTS) * DECIMAL_GAIN;
        tgt_pt_packet.msg_buf.y[i] =
            hci_.tgt_points[MAX_POINTS * 2 + 1 + i] * DECIMAL_GAIN;
    }
    tgt_pt_packet.msg_buf.id = hci_.road_id;
    AD_LINFO(PATH_PLANNING) << "road_id " << hci_.road_id;
    sendto(pt_sock, tgt_pt_packet.content, sizeof(tgt_pt_packet), 0,
           (struct sockaddr*)&pt_addr, sizeof(pt_addr));
    errno = 0;
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
