/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 * Guo Yingdi <guoyingdi@sensetime.com>
 */
#include <math.h>
#include <algorithm>
#include <iomanip>
#include <ctime>
#include <fstream>
#include "common/log.hpp"
#include "path_planning/scene_parser.hpp"
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/nn_tool.hpp"

using senseAD::LaneLine;

namespace senseAD {
namespace pp {
VehicleParam g_vehicle_param;
SceneParser::SceneParser() {}

SceneParser::~SceneParser() {}
adStatus_t SceneParser::Init() {
    g_nn_tool.Init();
    map.Init();
    predict_map_.Init();
    curr_dm_target_.type = DMTarget::NONE;
    curr_dm_target_.dm_velocity = -1.0;
    cached_lane_end_.position = cv::Point2f(0, 0);
    cached_lane_end_.direction = cv::Point2f(1, 0);
    auto conf = g_pp_conf["rrt_setting"];

    // SceneParser Params
    neglect_all_freespace_ = conf["neglect_all_freespace"];
    neglect_intersection_freespace_ = conf["neglect_intersection_freespace"];
    quadratic_bezier_turning_ = conf["quadratic_bezier_turning"];
    ibpp_radius_ = conf["ibpp_radius"];
    ibpp_extradist_ = conf["ibpp_extradist"];
    ibpp_maxdist_ = conf["ibpp_maxdist"];
    jp_lane_map_ = conf["jp_lane_map"];
    key_point_around_collision_ = conf["key_point_around_collision"];
    gen_ref_line_mode_ = conf["gen_ref_line_mode"];
    ref_line_interval_ = conf["ref_line_interval"];
    max_change_lane_distance_ = conf["max_change_lane_distance"];
    min_change_lane_distance_ = conf["min_change_lane_distance"];
    use_routing_refline_ = conf["use_routing_refline"];
    suppress_predmap_refresh_ = conf["suppress_predmap_refresh"];

    default_change_lane_distance_ = conf["default_change_lane_distance"];
    default_change_lane_velocity_ = conf["default_change_lane_velocity"];
    default_change_lane_offset_ = conf["default_change_lane_offset"];

    probe_range_ = conf["probe_range"];
    probe_step_ = conf["probe_step"];
    clearance_threshold_ = conf["clearance_threshold"];
    collision_check_range_ = conf["collision_check_range"];
    fixed_goal_index_ = conf["fixed_goal_index"];
    goal_forward_range_ = conf["goal_forward_range"];
    overtake_extend_verify_ = conf["overtake_extend_verify"];

    goal_safety_back_ = conf["goal_safety_back"];
    emerge_stop_acc_ = conf["emerge_stop_acc"];

    max_curvature_bias_ = conf["max_curvature_bias"];
    max_curvature_slope_ = conf["max_curvature_slope"];
    max_lateral_acc_ = conf["max_lateral_acc"];
    bezier_fitting_coeff1_ = conf["bezier_fitting_coeff1"];
    bezier_fitting_coeff2_ = conf["bezier_fitting_coeff2"];
    bezier_fitting_coeff3_ = conf["bezier_fitting_coeff3"];
    bezier_fitting_coeff4_ = conf["bezier_fitting_coeff4"];
    update_origin_position_threshold_ =
        conf["update_origin_position_threshold"];
    update_origin_direction_threshold_ =
        conf["update_origin_direction_threshold"];
    alignment_ = conf["alignment"];
    min_basepath_distance_uturn_ = conf["min_basepath_distance_uturn"];
    pull_over_offset_ = conf["pull_over_offset"];
    nudge_offset_ = conf["nudge_offset"];
    // map Params
    int32_t g_map_ww = 400;
    int32_t g_map_hh = 350;
    int32_t g_fix_bonnet_xx = 147;
    int32_t g_fix_bonnet_yy = 278;
    int32_t g_fix_bonnet_ww = 135;
    int32_t g_fix_bonnet_hh = 72;
    float32_t g_as_free_ly = 2.0f;
    float32_t g_as_free_ry = -2.0f;
    float32_t g_as_free_xx = 5.0f;
    // bool g_if_fix_bonnet = true;
    float32_t g_per_grid_meter = 0.1f;
    // int32_t g_min_value_as_free = 8;
    // bool g_if_optimize = true;
    // float32_t g_out_as_free = 25;
    // bool g_if_applybonnetfix_final = true;
    // float schneidersmooth_error = 0.5f;
    // float schneidersmooth_escale = 3.0f;

    g_as_free_ly = conf["as_free_ly"];
    g_as_free_ry = conf["as_free_ry"];
    g_as_free_xx = conf["as_free_xx"];

    int32_t x1, x2, yy;
    x1 = int32_t(-g_as_free_ly / g_per_grid_meter + g_map_ww / 2);
    x2 = int32_t(-g_as_free_ry / g_per_grid_meter + g_map_ww / 2);

    g_fix_bonnet_ww = x2 - x1 + 1;
    yy = int32_t(-g_as_free_xx / g_per_grid_meter + g_map_hh);
    g_fix_bonnet_hh = g_map_hh - yy + 1;
    g_fix_bonnet_xx = x1;
    g_fix_bonnet_yy = yy;

    map.map_ww = conf["map_ww"];
    map.map_hh = conf["map_hh"];
    map.fix_bonnet_xx = g_fix_bonnet_xx;
    map.fix_bonnet_yy = g_fix_bonnet_yy;
    map.fix_bonnet_hh = g_fix_bonnet_hh;
    map.fix_bonnet_ww = g_fix_bonnet_ww;
    int conf_if_fix_bonnet = conf["if_fix_bonnet"];
    map.if_fix_bonnet = conf_if_fix_bonnet == 1;
    map.per_grid_meter = conf["per_grid_meter"];
    map.min_value_as_free = conf["min_value_as_free"];
    map.as_free_measure_length = conf["as_free_measure_length"];
    int conf_if_optimize = conf["if_optimize"];
    map.if_optimize = conf_if_optimize == 1;
    map.out_as_free = conf["out_as_free"];
    int conf_if_applybonnetfix_final = conf["if_applybonnetfix_final"];
    map.if_applybonnetfix_final =
        conf_if_applybonnetfix_final == 1 ? true : false;
    map.Reconf();
    function_called_nums = std::vector<int>(7, 0);
    durations =
        std::vector<std::chrono::nanoseconds>(7, std::chrono::nanoseconds());
    return AD_SUCCESS;
}

bool SceneParser::notCollided(
    const std::vector<TrajectoryPoint>& to_test_path) {
    // only checkout what has been percepted
    for (int32_t i = 0; i < static_cast<int32_t>(to_test_path.size()) &&
                        i < collision_check_range_;
         i++) {
        auto tp = to_test_path[i];
        bool test_result = true;
        is_free(tp.position, &test_result);
        if (!test_result) return false;
        is_free_with_time(tp, tp.time_difference, &test_result);
        if (!test_result) {
            AD_LINFO(COLLOID) << i << "collied";
            return false;
        }
    }
    return true;
}

int SceneParser::notCollided(const std::vector<TrajectoryPoint>& to_test_path,
                             int range_,
                             bool if_gridmap_pure) {
    // only checkout what has been percepted
    for (int32_t i = 0;
         i < static_cast<int32_t>(to_test_path.size()) && i < range_; i++) {
        auto tp = to_test_path[i];
        bool test_result = true;
        if (!if_gridmap_pure) {
            is_free(tp.position, &test_result);
        } else {
            char risk_dist;
            its_risk(tp.position, &risk_dist);
            if (static_cast<int>(risk_dist) > 1) {
                test_result = true;
            } else {
                test_result = false;
            }
        }
        if (!test_result) return i;
        is_free_with_time(tp, tp.time_difference, &test_result);
        if (!test_result) return i;
    }
    return -1;
}

void SceneParser::notCollided(const std::vector<TrajectoryPoint>& to_test_path,
                              int range_,
                              int* continued_first_index,
                              int* continued_last_index) {
    *continued_first_index = -1;
    *continued_last_index = -1;
    // only checkout what has been percepted
    for (int32_t i = 0;
         i < static_cast<int32_t>(to_test_path.size()) && i < range_; i++) {
        auto tp = to_test_path[i];
        bool test_result = true;
        is_free(tp.position, &test_result);
        if (test_result) {
            is_free_with_time(tp, tp.time_difference, &test_result);
        }
        if (!test_result) {
            if (*continued_first_index == -1) {
                *continued_first_index = *continued_last_index = i;
            } else {
                *continued_last_index = i;
            }
        } else {
            if (*continued_first_index != -1) {
                break;
            }
        }
    }
}

adStatus_t SceneParser::Update(
    senseAD::roadStructure::RoadStructure<cv::Point2f>* rs,
    ObjectTrajectory* object_trajectory,
    PredictionResult* prediction_result,
    std::shared_ptr<FrenetCoordinateSystem> frenet_system,
    DMTarget* dm_target) {
    frenet_system = frenet_system_;
    this->dm_target_ = dm_target;
    this->object_trajectory_ = object_trajectory;
    this->prediction_result_ = prediction_result;
    this->rs_ = *rs;
    this->map.Update(&this->rs_, object_trajectory);
    this->predict_map_.Update(object_trajectory, prediction_result,
                              frenet_system_);

    this->dm_target_ = dm_target;
    return AD_SUCCESS;
}

adStatus_t SceneParser::Update(
    senseAD::roadStructure::RoadStructure<cv::Point2f>* rs,
    const PredictionObjectArray& poa,
    std::shared_ptr<FrenetCoordinateSystem> frenet_system,
    DMTarget* dm_target) {
    frenet_system = frenet_system_;
    this->dm_target_ = dm_target;
    this->rs_ = *rs;
    // this->map.Update(&this->rs_, object_trajectory);
    this->map.Update(&this->rs_);

    this->predict_map_.Update(poa, frenet_system_);

    this->dm_target_ = dm_target;
    return AD_SUCCESS;
}

adStatus_t SceneParser::Parse() {
    // ---------Excution Time Stats------------
    titles = {
        "Parse       ",  // 0
        "ParseGoal   ",  // 1
        "buildmap    ",  // 2
        "GenRefNBPP  ",  // 3
        "buildPreMap ",  // 4
        "FreeNRisk   ",  // 5
        "FreeWTime   ",  // 6
    };
    function_called_nums = std::vector<int>(7, 0);
    durations =
        std::vector<std::chrono::nanoseconds>(7, std::chrono::nanoseconds());
    auto sp_start = std::chrono::high_resolution_clock::now();
    // ----------------------------------------
    last_dm_target_ = curr_dm_target_;
    curr_dm_target_ = *dm_target_;
    buildmap();
    auto sp_bp_start = std::chrono::high_resolution_clock::now();
    if (use_routing_refline_) {
        ref_line_ = routing_refline_;
    }
    auto sp_bp_end = std::chrono::high_resolution_clock::now();
    durations[3] += (sp_bp_end - sp_bp_start);
    function_called_nums[3] += 1;

    SelectGoalPurposeVelocity(&goal_, &vp_purpose_, &target_velocity_,
                              &use_cached_goal_);
    goal_.velocity = target_velocity_;
    single_goal_ = goal_;
    sp_bp_start = std::chrono::high_resolution_clock::now();

    sp_bp_end = std::chrono::high_resolution_clock::now();
    durations[3] += (sp_bp_end - sp_bp_start);
    function_called_nums[3] += 1;

    auto sp_pm_start = std::chrono::high_resolution_clock::now();

    int goal_index = 400;

    auto trimed_bp = Trajectory(
        base_path_.begin(),
        base_path_.begin() +
            std::min(static_cast<int>(base_path_.size()), goal_index));

    // auto trimed_bp = utils::TrimProperBasePath(base_path_, goal_);
    g_nn_tool.UpdateData(trimed_bp);
    if (suppress_predmap_refresh_ == 0) {
        predict_map_.Refresh();
    }
    AD_LINFO(PATH_PLANNING) << "sceneparser finished parsing";

    auto sp_pm_end = std::chrono::high_resolution_clock::now();
    durations[4] += (sp_pm_end - sp_pm_start);
    function_called_nums[4] += 1;

    auto sp_end = std::chrono::high_resolution_clock::now();
    durations[0] += (sp_end - sp_start);
    function_called_nums[0] += 1;

    /*
    if (curr_dm_target_.state == DMTarget::State::CHANGELANE) {
        SetBasePathAndUpdateCollisionIndex(base_path_);
        UpdateGoal(&goal_, &vp_purpose_);
    }
    */
    return AD_SUCCESS;
}

adStatus_t SceneParser::GetTrajPointGoal(TrajectoryPoint* goal) {
    *goal = this->goal_;
    return AD_SUCCESS;
}

adStatus_t SceneParser::GetVPPurpose(VPPurpose* vp_purpose) {
    *vp_purpose = this->vp_purpose_;
    return AD_SUCCESS;
}

adStatus_t SceneParser::SetStartPoint(
    const std::vector<TrajectoryPoint>& cached_path,
    bool entering_autodriving,
    TrajectoryPoint* single_start,
    TrajectoryPoint* closest_point) {
    if (single_start == nullptr || closest_point == nullptr) {
        AD_LERROR(PATH_PLANNING) << "single_start or closest_point is nullptr";
        return AD_NULL_PTR;
    }
    this->single_start_ = *single_start;
    if (cached_path.empty()) {
        AD_LINFO(PATH_PLANNING)
            << "cached path is empty, set origion point to car position";
        return AD_SUCCESS;
    }
    // 1. find closest point
    uint32_t i = 0;
    int closest_index = -1;
    float closest_dist = 10000.0;
    for (; i < cached_path.size(); ++i) {
        float curr_dist =
            utils::cvnorm(cached_path.at(i).position - single_start->position);
        if (curr_dist < closest_dist) {
            closest_dist = curr_dist;
            closest_index = i;
        }
    }
    if (closest_index < 0 ||
        closest_index >= static_cast<int32_t>(cached_path.size())) {
        AD_LINFO(PATH_PLANNING) << "cannot find closest point";
        return AD_SUCCESS;
    }
    *closest_point = cached_path[closest_index];
    // 2. compare normal distance
    cv::Point2f distance = closest_point->position - single_start->position;
    float cross_distance = distance.x * closest_point->direction.y -
                           distance.y * closest_point->direction.x;
    // AD_LINFO(PATH_PLANNING) << "cross distance " << cross_distance;
    cross_distance = std::fabs(cross_distance);
    // alignment debug
    if (alignment_ != 1) {
        AD_LINFO(PATH_PLANNING) << "no alignment!!";
        return AD_SUCCESS;
    }
    if (entering_autodriving == true) {
        AD_LINFO(PATH_PLANNING) << "set start point to car position when "
                                   "entring auto driving state";
        return AD_SUCCESS;
    }
    if (cross_distance < update_origin_position_threshold_ &&
        utils::cvnorm(closest_point->direction - single_start->direction) <
            update_origin_direction_threshold_ &&
        std::fabs(g_vehicle_state.velocity) > 1.0) {
        single_start->position = closest_point->position;
        single_start->direction = closest_point->direction;
        single_start->theta =
            std::atan2(single_start->direction.y, single_start->direction.x);
        AD_LINFO(PATH_PLANNING) << "set start point to closest point.";
        alignment_activated_ = true;
    } else {
        AD_LINFO(PATH_PLANNING) << "cross distance " << cross_distance;
        AD_LINFO(PATH_PLANNING) << "direction error "
                                << utils::cvnorm(closest_point->direction -
                                                 single_start->direction);
    }
    this->single_start_ = *single_start;
    return AD_SUCCESS;
}

adStatus_t SceneParser::SetCachedGoal(const TrajectoryPoint& cached_goal) {
    this->cached_goal_ = cached_goal;
    return AD_SUCCESS;
}

void SceneParser::buildmap() {
    AD_LDEBUG(PATH_PLANNING) << "SceneParse Building Map ";
    auto pp_start = std::chrono::high_resolution_clock::now();
    bool is_finish;
    is_finish = false;
    if (this->dm_target_ != nullptr &&
        this->dm_target_->type == DMTarget::LANE) {
        std::string cur_road_id = this->dm_target_->current_road_id;
        std::string tgt_road_id = this->dm_target_->target_road_id;
        LaneId cur_lane = this->dm_target_->current_lane_id;
        LaneId tgt_lane = this->dm_target_->target_lane_id;
        AD_LDEBUG(PATH_PLANNING)
            << "cur_road_id: " << cur_road_id << " cur_lane: " << cur_lane
            << " tgt_road_id: " << tgt_road_id << " tgt_lane" << tgt_lane;
        if (cur_road_id != tgt_road_id) {
            // we are at corner, use original freespace
            is_finish = false;
        } else if ((cur_lane > 0 && jp_lane_map_ == 0) ||
                   (cur_lane < 0 && jp_lane_map_ == 1)) {
            // we are at opposite lane, use original freespace
            is_finish = false;
        } else if (this->dm_target_->state == DMTarget::OVERTAKE) {
            // we are asked to overtake some obstacle, use original freespace
            is_finish = false;
        } else {
            // Road
            auto target_road = rs_.road_map[cur_road_id];
            if (cur_lane == tgt_lane) {
                // we are keeping laneline
                // Lane
                auto target_lane = target_road.lane_map[cur_lane];
                map.Refresh(0, cur_road_id, target_lane.left_laneline_idx,
                            target_lane.right_laneline_idx);
                is_finish = true;
            } else {
                // we are changing lane
                LaneId dt_id = tgt_lane - cur_lane;
                if (dt_id > 0) {
                    dt_id = 1;
                } else {
                    dt_id = -1;
                }
                LaneId next_to = cur_lane + dt_id;
                auto src_laneline =
                    target_road.lane_map[cur_lane].left_laneline_idx;
                if (src_laneline ==
                        target_road.lane_map[next_to].left_laneline_idx ||
                    src_laneline ==
                        target_road.lane_map[next_to].right_laneline_idx) {
                    src_laneline =
                        target_road.lane_map[cur_lane].right_laneline_idx;
                }
                auto dst_laneline =
                    target_road.lane_map[tgt_lane].left_laneline_idx;
                next_to = tgt_lane - dt_id;
                if (dst_laneline ==
                        target_road.lane_map[next_to].left_laneline_idx ||
                    dst_laneline ==
                        target_road.lane_map[next_to].right_laneline_idx) {
                    dst_laneline =
                        target_road.lane_map[tgt_lane].right_laneline_idx;
                }
                map.Refresh(0, cur_road_id, src_laneline, dst_laneline);
                is_finish = true;
            }
        }
    }
    if (!is_finish) {
        map.Refresh(0, this->dm_target_->current_road_id);
    }
    AD_LDEBUG(PATH_PLANNING) << "SceneParser Built Map";
    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[2] += (pp_end - pp_start);
    function_called_nums[2] += 1;
    return;
}

adStatus_t SceneParser::SetMapParameter(int32_t map_ww,
                                        int32_t map_hh,
                                        int32_t fix_bonnet_xx,
                                        int32_t fix_bonnet_yy,
                                        int32_t fix_bonnet_hh,
                                        int32_t fix_bonnet_ww,
                                        bool if_fix_bonnet,
                                        float32_t per_grid_meter,
                                        int32_t min_value_as_free,
                                        bool if_optimize,
                                        float32_t out_as_free,
                                        bool if_applybonnetfix_final,
                                        float pedestrain_extrasafe_dist,
                                        float vehicle_extrasafe_dist) {
    AD_LINFO(PATH_PLANNING) << "SceneParser setting map Parameter";
    map.map_ww = map_ww;
    map.map_hh = map_hh;
    map.fix_bonnet_xx = fix_bonnet_xx;
    map.fix_bonnet_yy = fix_bonnet_yy;
    map.fix_bonnet_hh = fix_bonnet_hh;
    map.fix_bonnet_ww = fix_bonnet_ww;
    map.if_fix_bonnet = if_fix_bonnet;
    map.per_grid_meter = per_grid_meter;
    map.min_value_as_free = min_value_as_free;
    map.if_optimize = if_optimize;
    map.out_as_free = out_as_free;
    map.if_applybonnetfix_final = if_applybonnetfix_final;
    map.Reconf();
    predict_map_.SetParam(pedestrain_extrasafe_dist, vehicle_extrasafe_dist);

    AD_LINFO(PATH_PLANNING) << "map.map_ww " << map.map_ww;
    AD_LINFO(PATH_PLANNING) << "map.map_hh " << map.map_hh;
    AD_LINFO(PATH_PLANNING) << "map.fix_bonnet_xx " << map.fix_bonnet_xx;
    AD_LINFO(PATH_PLANNING) << "map.fix_bonnet_yy " << map.fix_bonnet_yy;
    AD_LINFO(PATH_PLANNING) << "map.fix_bonnet_hh " << map.fix_bonnet_hh;
    AD_LINFO(PATH_PLANNING) << "map.fix_bonnet_ww " << map.fix_bonnet_ww;
    AD_LINFO(PATH_PLANNING) << "map.if_fix_bonnet " << map.if_fix_bonnet;
    AD_LINFO(PATH_PLANNING) << "map.per_grid_meter " << map.per_grid_meter;
    AD_LINFO(PATH_PLANNING) << "map.min_value_as_free "
                            << map.min_value_as_free;
    AD_LINFO(PATH_PLANNING) << "map.if_optimize " << map.if_optimize;
    AD_LINFO(PATH_PLANNING) << "map.out_as_free " << map.out_as_free;
    AD_LINFO(PATH_PLANNING) << "map.if_applybonnetfix_final "
                            << map.if_applybonnetfix_final;

    AD_LINFO(PATH_PLANNING) << "SceneParser Set map Parameter";
    return AD_SUCCESS;
}

adStatus_t SceneParser::SelectGoalFromRefline(TrajectoryPoint* goal) {
    if (goal == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }

    if (ref_line_.size() <= 0) {
        AD_LINFO(PATH_PLANNING) << "Refline size == 0";
        return AD_SUCCESS;
    }

    int32_t collided_index = -1;
    ref_line_ = routing_refline_;
    this->vp_purpose_ = KEEP_UP_NON_ZERO_VELOCITY;

    auto curr_position = cv::Point2f(g_vehicle_state.x, g_vehicle_state.y);
    int32_t closest_index =
        utils::MatchClosestPoint(ref_line_, 0, curr_position, 20);
    if (closest_index >= static_cast<int32_t>(ref_line_.size())) {
        closest_index = ref_line_.size() - 1;
    }
    *goal = ref_line_[closest_index];

    AD_LINFO(PATH_PLANNING) << "goal position" << goal->position;
    single_goal_ = *goal;

    float basepath_goal_distance = min_change_lane_distance_;
    if (dm_target_->state == DMTarget::CRUISE &&
        (dm_target_->current_lane_id != dm_target_->target_lane_id ||
         dm_target_->current_road_id != dm_target_->target_road_id)) {
        AD_LINFO(PATH_PLANNING) << "MAYBE LANE CHANGE";
        const float kEps = 0.00001;
        basepath_goal_distance =
            max_curvature_slope_ /
            ((std::fabs(max_lateral_acc_) + kEps) /
                 (g_vehicle_state.velocity * g_vehicle_state.velocity) -
             max_curvature_bias_);
        basepath_goal_distance = std::min(
            max_change_lane_distance_,
            std::max(basepath_goal_distance, min_change_lane_distance_));
    } else {
        basepath_goal_distance =
            std::min(static_cast<double>(max_change_lane_distance_),
                     std::max(static_cast<double>(min_change_lane_distance_),
                              default_change_lane_distance_ *
                                  std::pow(g_vehicle_state.velocity, 2) /
                                  std::pow(default_change_lane_velocity_, 2) *
                                  cv::norm(ref_line_[closest_index].position -
                                           cv::Point2f(g_vehicle_state.x,
                                                       g_vehicle_state.y)) /
                                  default_change_lane_offset_));
    }
    // decrease basepath distance is UTURN
    if (dm_target_->state == DMTarget::UTURN) {
        basepath_goal_distance =
            std::min(basepath_goal_distance, min_basepath_distance_uturn_);
    }
    int32_t basepath_goal_index = basepath_goal_distance / ref_line_interval_;

    // if target type is none
    //      prompt ERROR code and brace for impact....... no more~
    // INSTEAD:
    if (dm_target_->type == DMTarget::Type::NONE ||
        // dm_target_->target_point_index == 0) {
        (dm_target_->type != DMTarget::Type::STOPPED &&
         dm_target_->target_point_index == 0)) {
        auto emerge_stop_distance = g_vehicle_state.velocity *
                                    g_vehicle_state.velocity /
                                    emerge_stop_acc_ / 2.0;
        AD_LINFO(WORLD_DEBUG) << "in none process";
        int32_t number_of_points = std::min(
            150,
            static_cast<int32_t>(emerge_stop_distance / ref_line_interval_));
        if (number_of_points <= 0) {
            return AD_SUCCESS;
        }  // else use default 0, 0 goal
        AD_LINFO(WORLD_DEBUG) << "none process number_of_points: "
                              << number_of_points;
        if (number_of_points >= static_cast<int32_t>(ref_line_.size())) {
            ref_line_ = Trajectory(number_of_points, TrajectoryPoint());
            for (int i = ref_line_.size() - 1; i >= 0; i--) {
                ref_line_[i].position.x =
                    static_cast<float>(i) * ref_line_interval_;
                ref_line_[i].position.y = 0.0;
                ref_line_[i].direction.x = 1.0;
                ref_line_[i].direction.y = 0.0;
                ref_line_[i].theta = 0.0;
            }
        }
        int last_free_index_in_first_free_zone = 0;
        while (last_free_index_in_first_free_zone < number_of_points) {
            bool point_in_free;
            is_free(ref_line_[last_free_index_in_first_free_zone].position,
                    &point_in_free);
            if (!point_in_free) {
                AD_LINFO(WORLD_COORDS_DEBUG) << "NONE process not in free";
                break;
            }
            last_free_index_in_first_free_zone++;
        }

        int goal_index =
            std::max(0, last_free_index_in_first_free_zone -
                            static_cast<int>(g_vehicle_param.length / 2.0 /
                                             ref_line_interval_));

        AD_LINFO(WORLD_DEBUG) << "goal index in none: " << goal_index;
        base_path_ = ref_line_;
        if (ref_line_.size() > 0) {
            *goal = ref_line_[goal_index];
        }  // else use the default 00 goal
        return AD_SUCCESS;
    }
    basepath_goal_index = basepath_goal_distance / ref_line_interval_;
    AD_LINFO(PATH_PLANNING) << "base_path_goal_index " << basepath_goal_index;

    if (basepath_goal_index > static_cast<int32_t>(ref_line_.size()) - 1)
        basepath_goal_index = static_cast<int32_t>(ref_line_.size()) - 1;

    for (size_t i = 0; i < ref_line_.size(); i++) {
        ref_line_[i].velocity = dm_target_->dm_velocity;
    }
    AD_LINFO(PATH_PLANNING) << "basepath goal: " << single_goal_.position;

    auto handle_intention = DMTarget::Intention::NONEINTENTION;
    if (dm_target_->state == DMTarget::State::OVERTAKE) {
        AD_LINFO(PATH_PLANNING) << "overtaking";
        if (dm_target_->intention == DMTarget::Intention::LEFTCHANGELANE ||
            dm_target_->intention == DMTarget::Intention::RIGHTCHANGELANE) {
            last_dm_intention_ = dm_target_->intention;
            handle_intention = dm_target_->intention;
        } else if (dm_target_->intention ==
                   DMTarget::Intention::NONEINTENTION) {
            handle_intention = last_dm_intention_;
        } else {
            last_dm_intention_ = dm_target_->intention;
            handle_intention = dm_target_->intention;
        }
        if (handle_intention == DMTarget::Intention::LEFTCHANGELANE ||
            handle_intention == DMTarget::Intention::RIGHTCHANGELANE) {
            SelectPointByDistance(max_lateral_acc_, min_change_lane_distance_,
                                  max_change_lane_distance_, handle_intention,
                                  default_change_lane_offset_, goal);
            single_goal_ = *goal;
        } else if (handle_intention == DMTarget::Intention::CHANGELANEBACK) {
            *goal = ref_line_[std::min(basepath_goal_index,
                                       static_cast<int>(ref_line_.size()) - 1)];
            // offset due to DM deviation
            cv::Point2f cross_dir;
            cross_dir.x = -goal->direction.y;
            cross_dir.y = goal->direction.x;
            if (dm_target_->deviation_direction == 1) {
                // nudge right
                AD_LINFO(NUDGE) << "nudge right due to dm deviation";
                goal->position = goal->position - nudge_offset_ * cross_dir;
                curr_basepath_offset_ = -nudge_offset_;
            } else if (dm_target_->deviation_direction == 2) {
                // nudge left
                goal->position = goal->position + nudge_offset_ * cross_dir;
                curr_basepath_offset_ = nudge_offset_;
                AD_LINFO(NUDGE) << "nudge left due to dm deviation";
            } else {
                curr_basepath_offset_ = 0.0;
            }
            single_goal_ = *goal;
        }
    } else if (dm_target_->state == DMTarget::State::PARK &&
               (dm_target_->intention == DMTarget::Intention::LEFTCHANGELANE ||
                dm_target_->intention ==
                    DMTarget::Intention::RIGHTCHANGELANE)) {
        last_dm_intention_ = dm_target_->intention;
        handle_intention = dm_target_->intention;
        // not collided point found, select goal by distance
        const float k_park_lat_acc = 1.0;
        SelectPointByDistance(k_park_lat_acc, min_change_lane_distance_,
                              max_change_lane_distance_, handle_intention,
                              pull_over_offset_, goal);
        single_goal_ = *goal;
    } else {
        *goal = ref_line_[std::min(basepath_goal_index,
                                   static_cast<int>(ref_line_.size()) - 1)];
        // offset due to DM deviation
        cv::Point2f cross_dir;
        cross_dir.x = -goal->direction.y;
        cross_dir.y = goal->direction.x;
        if (dm_target_->deviation_direction == 1) {
            // nudge right
            AD_LINFO(NUDGE) << "nudge right due to dm deviation";
            goal->position = goal->position - nudge_offset_ * cross_dir;
            curr_basepath_offset_ = -nudge_offset_;
        } else if (dm_target_->deviation_direction == 2) {
            // nudge left
            goal->position = goal->position + nudge_offset_ * cross_dir;
            curr_basepath_offset_ = nudge_offset_;
            AD_LINFO(NUDGE) << "nudge left due to dm deviation";
        } else {
            curr_basepath_offset_ = 0.0;
        }
        single_goal_ = *goal;
    }
    if (!(true == alignment_activated_ && false == cached_base_path_.empty() &&
          (std::fabs(last_basepath_offset_ - curr_basepath_offset_) < 0.1) &&
          AD_SUCCESS == GenBasePathFromCached())) {
        GenBasePath();
        AD_LINFO(PATH_PLANNING) << "alignment_activated "
                                << alignment_activated_;
        AD_LINFO(PATH_PLANNING) << "cached_base_path_.empty() "
                                << cached_base_path_.size();
    }
    utils::EstimatePathTime(&base_path_);
    collided_index = -1;
    collided_index = notCollided(base_path_, fixed_goal_index_);
    if (collided_index != -1) {
        if (goal_safety_back_ >= 0 && dm_target_->type == DMTarget::STOPLINE) {
            // TODO(eteced) very hardcode logics, avoid overtake before
            // stopline
            // and oncross
            // not release the constrains on freespace
        } else {
            AD_LINFO(PATH_PLANNING)
                << "collised, release the constrains on freespace";
            auto pp_start = std::chrono::high_resolution_clock::now();
            map.Refresh(0, this->dm_target_->current_road_id);
            auto pp_end = std::chrono::high_resolution_clock::now();
            durations[2] += (pp_end - pp_start);
        }
    }
    if (dm_target_->type == DMTarget::STOPPED) {
        // goal->position = dm_target_->stop_ped_pos;
        // TODO(congq): use config
        float insert_distance_ = 0.2;
        if (ref_line_.size() > 0) {
            auto goal_direction_index =
                std::min(static_cast<int>(ref_line_.size() - 1),
                         static_cast<int>(vp_length_ / insert_distance_));
            goal->direction = ref_line_[goal_direction_index].direction;
        } else {
            goal->direction = cv::Point2f(1, 0);
        }
        this->vp_purpose_ = STOP_AT_GIVEN_POINT;
    } else if (dm_target_->velocity_flag == 1) {
        // To use dm's S
        this->vp_purpose_ = USE_DM_S;
    } else if (dm_target_->state == DMTarget::FOLLOW) {
        // if we follow something, no planning or collision check after the
        // given point
        this->vp_purpose_ = FOLLOW_AT_GIVEN_POINT;
    } else if (dm_target_->type == DMTarget::STOPLINE) {
        this->vp_purpose_ = STOP_AT_STOPLINE;
    } else if (dm_target_->dm_velocity < 0.01) {
        this->vp_purpose_ = STOP_AT_GIVEN_POINT;
    }

    AD_LINFO(PATH_PLANNING) << "vehicle width " << g_vehicle_param.width
                            << "\trefline goal: " << goal->position
                            << "\t direction: " << goal->direction
                            << "\t velocity: " << goal->velocity;
    AD_LDEBUG(DEBUG) << "curr basepath offset " << curr_basepath_offset_;
    AD_LDEBUG(DEBUG) << "last basepath offset " << last_basepath_offset_;
    last_basepath_offset_ = curr_basepath_offset_;
    return AD_SUCCESS;
}

adStatus_t SceneParser::SelectGoalPurposeVelocity(TrajectoryPoint* goal,
                                                  VPPurpose* purpose,
                                                  float* target_velocity,
                                                  bool* ifusecachegoal) {
    AD_LDEBUG(PATH_PLANNING)
        << "SceneParser Getting Goal Purpose TargetVelocity";
    auto pp_start = std::chrono::high_resolution_clock::now();

    if (goal == nullptr || purpose == nullptr || dm_target_ == nullptr ||
        target_velocity == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }

    *purpose = REMAIN_TILL_CACHE_GOAL;
    if (dm_target_->dm_velocity < 0.01) {
        *purpose = STOP_AT_GIVEN_POINT;
    } else {
        *purpose = KEEP_UP_NON_ZERO_VELOCITY;
    }
    *target_velocity = dm_target_->dm_velocity;

    SceneParser::SelectGoalFromRefline(goal);
    single_goal_ = *goal;
    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[1] += (pp_end - pp_start);
    function_called_nums[1] += 1;
    return AD_SUCCESS;
}

adStatus_t SceneParser::SetRefLineInterval(const float& interval,
                                           const float& ref_line_adding_dist) {
    ref_line_interval_ = interval;
    ref_line_adding_dist_ = ref_line_adding_dist;
    return AD_SUCCESS;
}

bool SceneParser::point_in_rect(const cv::Point2f& pt,
                                const cv::Point2f& pt0,
                                const cv::Point2f& pt1,
                                const cv::Point2f& pt2,
                                const cv::Point2f& pt3) {
    AD_LINFO(PATH_PLANNING) << "SceneParser Point in rect";
    return (pt - pt0).cross(pt1 - pt0) > 0 && (pt - pt1).cross(pt2 - pt1) > 0 &&
           (pt - pt2).cross(pt3 - pt2) > 0 && (pt - pt3).cross(pt0 - pt3) > 0;
}

adStatus_t SceneParser::is_free(const cv::Point2f& pt, bool* in_free_space) {
    AD_LTRACE(PATH_PLANNING) << "SceneParser check if free " << pt;

    auto pp_start = std::chrono::high_resolution_clock::now();
    if (in_free_space == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    // this->map.is_free(pt, in_free_space);
    if (neglect_all_freespace_ == 1 ||
        (curr_dm_target_.type == DMTarget::BOUNDARY &&
         neglect_intersection_freespace_ == 1)) {
        *in_free_space = true;
    } else {
        this->map.is_free(pt, in_free_space);
    }
    // *in_free_space = true;
    AD_LTRACE(PATH_PLANNING) << "SceneParser checked if free "
                             << *in_free_space;
    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[5] += (pp_end - pp_start);
    function_called_nums[5] += 1;

    return AD_SUCCESS;
}

adStatus_t SceneParser::is_free_with_time(const TrajectoryPoint& pt,
                                          const float& after_time,
                                          bool* in_free_space) {
    auto pp_start = std::chrono::high_resolution_clock::now();
    if (in_free_space == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    // this->map.is_free(pt, in_free_space);
    if (neglect_all_freespace_ == 1 ||
        (curr_dm_target_.type == DMTarget::BOUNDARY &&
         neglect_intersection_freespace_ == 1)) {
        *in_free_space = true;
    } else {
        const float longi_safe_dist = 0.5;
        const float lat_safe_dist = 0.0;
        this->predict_map_.is_free(pt, after_time, longi_safe_dist,
                                   lat_safe_dist, in_free_space);
        // *in_free_space = true;
    }
    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[6] += (pp_end - pp_start);
    function_called_nums[6] += 1;

    AD_LTRACE(PATH_PLANNING) << "SceneParser checked if free "
                             << *in_free_space;
    return AD_SUCCESS;
}

adStatus_t SceneParser::sdt_is_free(float s,
                                    float d,
                                    float heading,
                                    float t,
                                    float longi_safe_dist,
                                    float lat_safe_dist,
                                    bool* in_free_space) {
    auto pp_start = std::chrono::high_resolution_clock::now();
    if (in_free_space == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    // this->map.is_free(pt, in_free_space);
    if (neglect_all_freespace_ == 1 ||
        (curr_dm_target_.type == DMTarget::BOUNDARY &&
         neglect_intersection_freespace_ == 1)) {
        *in_free_space = true;
    } else {
        this->predict_map_.is_free(s, d, heading, t, longi_safe_dist,
                                   lat_safe_dist, in_free_space);
        // *in_free_space = true;
    }
    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[6] += (pp_end - pp_start);
    function_called_nums[6] += 1;

    AD_LTRACE(PATH_PLANNING) << "SceneParser checked if free "
                             << *in_free_space;
    return AD_SUCCESS;
}

adStatus_t SceneParser::sdt_its_risk(float s,
                                     float d,
                                     float heading,
                                     float t,
                                     float longi_safe_dist,
                                     float lat_safe_dist,
                                     int* in_free_space) {
    auto pp_start = std::chrono::high_resolution_clock::now();
    if (in_free_space == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    // this->map.is_free(pt, in_free_space);
    if (neglect_all_freespace_ == 1 ||
        (curr_dm_target_.type == DMTarget::BOUNDARY &&
         neglect_intersection_freespace_ == 1)) {
        *in_free_space = 0;
    } else {
        this->predict_map_.its_risk(s, d, heading, t, longi_safe_dist,
                                    lat_safe_dist, in_free_space);
        // *in_free_space = true;
    }
    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[6] += (pp_end - pp_start);
    function_called_nums[6] += 1;

    AD_LTRACE(PATH_PLANNING) << "SceneParser checked if free "
                             << *in_free_space;
    return AD_SUCCESS;
}

adStatus_t SceneParser::its_risk(const cv::Point2f& pt, char* in_free_space) {
    auto pp_start = std::chrono::high_resolution_clock::now();
    AD_LTRACE(PATH_PLANNING) << "SceneParser check if free " << pt;
    if (in_free_space == nullptr) {
        SD_CHECK_ERROR(AD_NULL_PTR);
    }
    this->map.is_free(pt, in_free_space);

    AD_LTRACE(PATH_PLANNING) << "SceneParser checked if free "
                             << *in_free_space;

    auto pp_end = std::chrono::high_resolution_clock::now();
    durations[5] += (pp_end - pp_start);
    function_called_nums[5] += 1;

    return AD_SUCCESS;
}

adStatus_t SceneParser::GetBasePath(std::vector<TrajectoryPoint>* base_path) {
    *base_path = this->base_path_;
    AD_LINFO(PATH_PLANNING) << "Returned base path: " << base_path->size();
    return AD_SUCCESS;
}

adStatus_t SceneParser::SetVPEnd(const float& vp_length) {
    this->vp_length_ = vp_length;
    return AD_SUCCESS;
}

adStatus_t SceneParser::GenBasePath() {
    base_path_.clear();
    std::vector<cv::Point2f> path;
    path.push_back(single_start_.position);
    path.push_back(cv::Point2f(single_goal_.position));

    auto entering_direction = single_start_.direction;
    auto exiting_direction = single_goal_.direction;

    if (quadratic_bezier_turning_ == 0) {
        utils::CubicBezierSmoothing(path, entering_direction, exiting_direction,
                                    &base_path_);
    } else {
        utils::CubicBezierSmoothing(path, entering_direction, exiting_direction,
                                    &base_path_, true);
    }
    float32_t insert_distance_ = 0.2;
    utils::PathElongation(&base_path_, ref_line_, insert_distance_);
    auto trajpoint_path = base_path_;
    base_path_.clear();
    utils::SegmentTrajectory(trajpoint_path, insert_distance_, &base_path_);
    // TODO(someone): to use the true velocity planner
    for (size_t i = 0; i < base_path_.size(); i++) {
        base_path_[i].velocity = dm_target_->dm_velocity;
    }

    /*
    if (dm_target_->type == DMTarget::Type::STOPLINE
        || dm_target_->type == DMTarget::Type::STOPPED) {
        goal_index = std::min(static_cast<int>(base_path_.size()-1),
                              static_cast<int>(vp_length_/insert_distance_));
    }
    */
    /*
    goal_index = std::min(static_cast<int>(base_path_.size()-1),
                               static_cast<int> (40/insert_distance_));
    single_goal_ = base_path_[goal_index];
    */
    AD_LINFO(PATH_PLANNING) << "Generated basepath " << base_path_.size();
    return AD_SUCCESS;
}

adStatus_t SceneParser::GetReferenceLine(
    std::vector<TrajectoryPoint>* ref_line) {
    *ref_line = ref_line_;
    return AD_SUCCESS;
}

adStatus_t SceneParser::GenImprovedBPP() {
    this->improved_base_path_.clear();
    std::vector<cv::Point2f> lanepts_l, lanepts_r, lanepts_m;
    if (dm_target_->current_road_id != dm_target_->target_road_id) {
        std::vector<cv::Point2f> lanepts_l, lanepts_r;
        auto road_id = dm_target_->current_road_id;
        auto lane_id = dm_target_->current_lane_id;
        // Lane
        auto target_road = rs_.road_map[road_id];
        auto target_lane = target_road.lane_map[lane_id];
        auto lanel = target_road.lane_line_map[target_lane.left_laneline_idx];
        auto laner = target_road.lane_line_map[target_lane.right_laneline_idx];
        std::vector<TrajectoryPoint> tp;
        float l_start_pos = lanel.data.GetStartLanelinePos();
        float l_end_pos = lanel.data.GetEndLanelinePos();
        if (l_start_pos < -1.0f && l_end_pos > 0) {
            l_start_pos = -1.0f;
        }
        if (l_end_pos > 0) {
            lanel.data.Sample(l_start_pos, l_end_pos, -1, 1.0f, &lanepts_l);
        }
        float r_start_pos = laner.data.GetStartLanelinePos();
        float r_end_pos = laner.data.GetEndLanelinePos();
        if (r_start_pos < -1.0 && r_end_pos > 0) {
            r_start_pos = -1.0f;
        }
        if (r_end_pos > 0) {
            laner.data.Sample(r_start_pos, r_end_pos, -1, 1.0f, &lanepts_r);
        }
        for (uint32_t i = 0; i < lanepts_l.size(); i++) {
            if (i >= lanepts_r.size()) break;
            cv::Point2f mid;
            mid = (lanepts_l[i] + lanepts_r[i]) * 0.5;
            if (mid.x >= 0) {
                lanepts_m.push_back(mid);
            }
        }
    }
    auto road_id = dm_target_->target_road_id;
    auto lane_id = dm_target_->target_lane_id;
    // Lane
    auto target_road = rs_.road_map[road_id];
    auto target_lane = target_road.lane_map[lane_id];
    auto lanel = target_road.lane_line_map[target_lane.left_laneline_idx];
    auto laner = target_road.lane_line_map[target_lane.right_laneline_idx];
    std::vector<TrajectoryPoint> tp;
    float l_start_pos = lanel.data.GetStartLanelinePos();
    float l_end_pos = lanel.data.GetEndLanelinePos();
    if (l_start_pos < -1.0f && l_end_pos > 0) {
        l_start_pos = -1.0f;
    }
    if (l_end_pos > 0) {
        lanel.data.Sample(l_start_pos, l_end_pos, -1, 1.0f, &lanepts_l);
    }
    float r_start_pos = laner.data.GetStartLanelinePos();
    float r_end_pos = laner.data.GetEndLanelinePos();
    if (r_start_pos < -1.0 && r_end_pos > 0) {
        r_start_pos = -1.0f;
    }
    if (r_end_pos > 0) {
        laner.data.Sample(r_start_pos, r_end_pos, -1, 1.0f, &lanepts_r);
    }
    for (uint32_t i = 0; i < lanepts_l.size(); i++) {
        if (i >= lanepts_r.size()) break;
        cv::Point2f mid;
        mid = (lanepts_l[i] + lanepts_r[i]) * 0.5;
        if (mid.x >= 0) {
            lanepts_m.push_back(mid);
        }
    }
    if (lanepts_m.size() < 1) {
        AD_LERROR(PATH_PLANNING) << "Sample LaneLine points failed!";
        return AD_SUCCESS;
    }
    uint32_t align_index = 0;
    while (align_index < lanepts_m.size() - 1) {
        float cosa, cosb, arca, arcb, len, dist;
        cv::Point2f direction_mid, direction_final;
        direction_mid = lanepts_m[align_index] - single_start_.position;
        utils::CalcNorm(direction_mid, &dist);
        utils::Normalize2Dvect(&direction_mid);
        if (align_index + 1 < lanepts_m.size()) {
            direction_final =
                lanepts_m[align_index + 1] - lanepts_m[align_index];
        } else {
            direction_final = single_goal_.direction;
        }
        utils::Normalize2Dvect(&direction_final);
        utils::Cosine2Dvect(single_start_.direction, direction_mid, &cosa);
        utils::Cosine2Dvect(direction_mid, direction_final, &cosb);
        arca = fabs(acosf(cosa));
        arcb = fabs(acosf(cosb));
        len = (arca + arcb) * ibpp_radius_ + ibpp_extradist_;
        if (len < dist || dist > ibpp_maxdist_) break;
        align_index++;
    }
    utils::Normalize2Dvect(&single_start_.direction);
    tp.push_back(single_start_);
    AD_LDEBUG(PATH_PLANNING)
        << "Add QuintSpline Points:" << single_start_.position << " "
        << single_start_.direction;

    double ref_line_length_ = 30;
    for (uint32_t i = align_index; i < lanepts_m.size(); i++) {
        TrajectoryPoint tpp;
        tpp.position = lanepts_m[i];
        tpp.direction = lanepts_m[i] - tp[tp.size() - 1].position;
        if (i == lanepts_m.size()) {
            tpp.direction = single_goal_.direction;
        }
        utils::Normalize2Dvect(&tpp.direction);
        float dist;
        tp.push_back(tpp);
        AD_LDEBUG(PATH_PLANNING) << "Add QuintSpline Points:" << tpp.position
                                 << " " << tpp.direction;
        utils::CalcNorm(tpp.position - single_start_.position, &dist);
        if (dist > ref_line_length_) break;
    }
    quintspline_smoother_.SetData(tp);
    quintspline_smoother_.Fit();
    tp = quintspline_smoother_.SamplePoints(ref_line_interval_);
    utils::SegmentTrajectory(tp, ref_line_interval_, &improved_base_path_);
    return AD_SUCCESS;
}

adStatus_t SceneParser::GenImprovedBPP(
    std::vector<TrajectoryPoint>* base_path) {
    *(base_path) = improved_base_path_;
    return AD_SUCCESS;
}

adStatus_t SceneParser::SetRoutingRefline(const Trajectory& routing_refline) {
    routing_refline_.clear();
    utils::SegmentTrajectory(routing_refline, ref_line_interval_,
                             &routing_refline_);
    AD_LINFO(PATH_PLANNING) << "routing base path" << routing_refline_.size();
    return AD_SUCCESS;
}

adStatus_t SceneParser::GetRoutingRefline(Trajectory* routing_refline) {
    *routing_refline = this->routing_refline_;
    return AD_SUCCESS;
}

adStatus_t SceneParser::ShouldOverrideVPS(bool* should_override_vp_s) {
    *should_override_vp_s = dm_target_->type == DMTarget::Type::NONE ||
                            (dm_target_->type != DMTarget::Type::STOPPED &&
                             dm_target_->target_point_index == 0);
    return AD_SUCCESS;
}
void SceneParser::LogOutTime() {
    std::stringstream ss_info;
    ss_info << "SP_time \t";
    for (uint32_t i = 0; i < titles.size(); i++) {
        ss_info << titles[i] << "\t" << function_called_nums[i] << "\t"
                << std::chrono::duration<float>(durations[i]).count() << "\t";
    }
    AD_LINFO(PATH_PLANNING) << ss_info.str();
}

adStatus_t SceneParser::ManuallySetMaps(
    const std::string grid_filename,
    const std::vector<std::vector<int>> pred_vect) {
    this->map.LoadMapFromFile(grid_filename);
    this->predict_map_.BuildMapFromVector(pred_vect);
    return AD_SUCCESS;
}

adStatus_t SceneParser::SelectGoalDistance(const float& max_curvature,
                                           const float& lateral_deviation,
                                           float* goal_distance) {
    *goal_distance = min_change_lane_distance_;
    *goal_distance = 1.0 / ((1.0 / (bezier_fitting_coeff1_ * lateral_deviation +
                                    bezier_fitting_coeff2_)) *
                                max_curvature +
                            bezier_fitting_coeff3_ * lateral_deviation +
                            bezier_fitting_coeff4_);
    return AD_SUCCESS;
}

void SceneParser::SelectCollidedPoint(const int& first_collided_index,
                                      const int& last_collieded_index,
                                      TrajectoryPoint* goal) {
    float probe_step = probe_step_;
    if (dm_target_->intention == DMTarget::Intention::NONEINTENTION) {
        AD_LINFO(PATH_PLANNING) << "overtake or pull over but no intension ";
        // detect intension according relative position of ego car and refline
        cv::Point2f ref_line_direction = ref_line_.front().direction;
        cv::Point2f ref_to_car_direction =
            cv::Point2f(g_vehicle_state.x - ref_line_.front().position.x,
                        g_vehicle_state.y - ref_line_.front().position.y);
        if (cv::norm(ref_to_car_direction) < 0.00001) {
            AD_LERROR(PATH_PLANNING) << "must give intension!!";
        } else {
            ref_to_car_direction =
                ref_to_car_direction * (1.0 / cv::norm(ref_to_car_direction));
            if (ref_to_car_direction.cross(ref_line_direction) < 0.0) {
                // ego car in right side of ref line
                probe_step = -probe_step_;
            }
        }
    } else {
        if (dm_target_->intention == DMTarget::Intention::RIGHTCHANGELANE) {
            AD_LINFO(PATH_PLANNING) << "overtake or park intended to go right";
            probe_step = -probe_step_;
        }
    }
    int consecutive_free = 0;
    float offset_probed = probe_step;
    int32_t collided_last_index =
        last_collieded_index + overtake_extend_verify_;
    if (collided_last_index + 1 > static_cast<int32_t>(ref_line_.size())) {
        collided_last_index = ref_line_.size() - 1;
    }
    std::vector<cv::Point2f> probe_vecs;
    for (int ii = first_collided_index; ii <= collided_last_index; ii++) {
        auto waypoint_direction = ref_line_[ii].direction;
        if (cv::norm(waypoint_direction) > 0.0001) {
            waypoint_direction =
                waypoint_direction * (1.0 / cv::norm(waypoint_direction));
        } else {
            // using vehicle heading as default direction
            waypoint_direction = cv::Point2f(std::cos(g_vehicle_state.heading),
                                             std::sin(g_vehicle_state.heading));
        }
        cv::Point2f probe_vec;
        probe_vec.x = -waypoint_direction.y;
        probe_vec.y = waypoint_direction.x;
        probe_vecs.push_back(probe_vec);
    }
    AD_LINFO(PATH_PLANNING) << "prob_step " << probe_step << "\tclearence "
                            << clearance_threshold_;
    int max_consecutive_free = 0;
    float max_offset = 0;
    while (std::abs(offset_probed) < probe_range_) {
        bool in_free;
        char risk_dist;
        for (int ii = first_collided_index; ii <= collided_last_index; ii++) {
            // auto waypoint_pos = ref_line_[ii].position;
            auto tjp = ref_line_[ii];
            auto probe_vec = probe_vecs[ii - first_collided_index];
            tjp.position = tjp.position + probe_vec * offset_probed;
            its_risk(tjp.position + probe_vec * offset_probed, &risk_dist);
            if (static_cast<int>(risk_dist) > 1) {
                in_free = true;
            } else {
                in_free = false;
            }
            if (in_free) {
                is_free_with_time(
                    tjp, static_cast<float>(ref_line_[ii].time_difference),
                    &in_free);
            }
            if (!in_free) {
                break;
            }
        }
        if (in_free) {
            consecutive_free += 1;
            if (consecutive_free > max_consecutive_free) {
                max_consecutive_free = consecutive_free;
                max_offset = offset_probed;
            }
        } else {
            consecutive_free = 0;
        }
        if (consecutive_free * std::abs(probe_step) >=
            clearance_threshold_ + g_vehicle_param.width) {
            break;
        }
        offset_probed += probe_step;

        AD_LINFO(PATH_PLANNING) << "offset " << offset_probed
                                << "\tconsecutive_free " << consecutive_free;
    }
    AD_LINFO(PATH_PLANNING) << "final offset " << offset_probed
                            << "\tconsecutive_free " << consecutive_free;
    if (consecutive_free * std::abs(probe_step) >=
        clearance_threshold_ + g_vehicle_param.width) {
        auto waypoint_pos = ref_line_[first_collided_index].position;
        auto probe_vec = probe_vecs[0];
        auto waypoint_direction = ref_line_[first_collided_index].direction;
        if (cv::norm(waypoint_direction) > 0.0001) {
            waypoint_direction =
                waypoint_direction * (1.0 / cv::norm(waypoint_direction));
        } else {
            waypoint_direction = cv::Point2f(std::cos(g_vehicle_state.heading),
                                             std::sin(g_vehicle_state.heading));
        }
        goal->position =
            waypoint_pos +
            probe_vec * (offset_probed > 0
                             ? (offset_probed - 0.5 * g_vehicle_param.width)
                             : (offset_probed + 0.5 * g_vehicle_param.width));
        goal->direction = waypoint_direction;

        AD_LINFO(PATH_PLANNING) << "waypoint_pos " << waypoint_pos
                                << " offset_probed " << offset_probed
                                << " probe_vec " << probe_vec
                                << " refline goal: if  " << goal->position;
    } else {
        auto waypoint_pos = ref_line_[first_collided_index].position;
        auto probe_vec = probe_vecs[0];
        auto waypoint_direction = ref_line_[first_collided_index].direction;
        if (cv::norm(waypoint_direction) > 0.0001) {
            waypoint_direction =
                waypoint_direction * (1.0 / cv::norm(waypoint_direction));
        } else {
            // using vehicle heading as default direction
            waypoint_direction = cv::Point2f(std::cos(g_vehicle_state.heading),
                                             std::sin(g_vehicle_state.heading));
        }
        goal->position =
            waypoint_pos +
            probe_vec * (max_offset > 0
                             ? (max_offset - 0.5 * g_vehicle_param.width)
                             : (max_offset + 0.5 * g_vehicle_param.width));
        goal->direction = waypoint_direction;

        AD_LINFO(PATH_PLANNING) << "waypoint_pos " << waypoint_pos
                                << " offset_probed " << offset_probed
                                << " probe_vec " << probe_vec
                                << " refline goal: else " << goal->position;
    }
}

void SceneParser::SelectPointByDistance(const float& max_lat_acc,
                                        const float& min_distance,
                                        const float& max_distance,
                                        const DMTarget::Intention& intention,
                                        const float& offset_distance,
                                        TrajectoryPoint* goal) {
    float max_curvature = std::fabs(
        max_lat_acc /
        (g_vehicle_state.velocity * g_vehicle_state.velocity + 1.0e-5));
    float basepath_goal_distance = min_distance;
    curr_basepath_offset_ = offset_distance;
    SelectGoalDistance(max_curvature, offset_distance, &basepath_goal_distance);
    basepath_goal_distance =
        std::min(max_distance, std::max(basepath_goal_distance, min_distance));
    AD_LINFO(GOAL) << max_lat_acc << " goal distance "
                   << basepath_goal_distance;
    int32_t goal_index = basepath_goal_distance / ref_line_interval_;
    if (goal_index >= static_cast<int32_t>(ref_line_.size())) {
        goal_index = ref_line_.size() - 1;
    }
    auto waypoint_pos = ref_line_[goal_index].position;
    auto waypoint_direction = ref_line_[goal_index].direction;
    cv::Point2f cross_dir;
    cross_dir.x = -waypoint_direction.y;
    cross_dir.y = waypoint_direction.x;
    if (cv::norm(waypoint_direction) > 0.0001) {
        waypoint_direction =
            waypoint_direction * (1.0 / cv::norm(waypoint_direction));
    } else {
        waypoint_direction = cv::Point2f(std::cos(g_vehicle_state.heading),
                                         std::sin(g_vehicle_state.heading));
    }
    if (intention == DMTarget::Intention::LEFTCHANGELANE) {
        goal->position = waypoint_pos + offset_distance * cross_dir;
    } else {
        goal->position = waypoint_pos - offset_distance * cross_dir;
    }
    goal->direction = waypoint_direction;
}

adStatus_t SceneParser::SetCachedBasePath(
    const std::vector<TrajectoryPoint>& cached_base_path) {
    cached_base_path_ = cached_base_path;
    return AD_SUCCESS;
}

adStatus_t SceneParser::GenBasePathFromCached() {
    if (cached_base_path_.empty()) {
        return AD_INVALID_PARAM;
    }
    base_path_ = cached_base_path_;
    float32_t insert_distance_ = 0.2;
    utils::PathElongation(&base_path_, ref_line_, insert_distance_);
    auto trajpoint_path = base_path_;
    base_path_.clear();
    utils::SegmentTrajectory(trajpoint_path, insert_distance_, &base_path_);
    for (size_t i = 0; i < base_path_.size(); i++) {
        base_path_[i].velocity = dm_target_->dm_velocity;
    }
    AD_LINFO(PATH_PLANNING)
        << "Generated basepath from cached base path, size: "
        << base_path_.size();
    return AD_SUCCESS;
}

}  // namespace pp
}  // namespace senseAD
