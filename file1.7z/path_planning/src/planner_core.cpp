/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 */

#include "path_planning/planner_core.hpp"
#include "path_planning/lattice_core.hpp"
#include "path_planning/refline_core.hpp"
#include "path_planning/rrt_core.hpp"
#include "ini.h"  // NOLINT
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "common/log.hpp"

namespace senseAD {
namespace pp {

std::shared_ptr<PlannerCore> PlannerCore::CreatePlanner(
    const std::string& pp_type) {
    std::shared_ptr<PlannerCore> pc_ptr;
    if (pp_type == "LatticeCore") {
        pc_ptr.reset(new LatticeCore());
        return pc_ptr;
    } else if (pp_type == "RRTCore") {
        pc_ptr.reset(new RRTCore());
        return pc_ptr;
    } else if (pp_type == "ReflineCore") {
        pc_ptr.reset(new ReflineCore());
        return pc_ptr;
    } else {
        AD_LERROR(PATH_PLANNING) << " No valid pp type is specified.";
    }
    return nullptr;
}

}  // namespace pp
}  // namespace senseAD
