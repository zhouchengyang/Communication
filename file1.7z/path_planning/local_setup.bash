#!/bin/bash

declare _this_path=$(builtin cd "`dirname "${BASH_SOURCE[0]}"`" && pwd)
declare _module_name=path_planning
export ${_module_name}_PKG_PATH=${_this_path}
