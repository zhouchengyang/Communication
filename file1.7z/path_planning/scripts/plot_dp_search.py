#
#Copyright(C) 2019 by SenseTime Group Limited.All rights reserved.
#Shengfa Zhu < zhushengfa @sensetime.com >
#
'''
plot dynamic programming search process, including st-graph and dp search result
'''

import argparse
import json
import matplotlib.pyplot as plt
import numpy as np
import re
import os

def ParseJson(json_path):
    with open(json_path, 'r') as f:
        data = json.loads(f.read())
    return data

def findMatchDataFile(dir, data_file_name):
    '''
    find data file name match given data name (first)
    '''
#dir is file not a directory
    if os.path.isfile(dir):
        return match_file
    for file_name in os.listdir(dir):
        if data_file_name in file_name:
            return file_name

def plotRectange(axes, vertice):
    axes.plot([vertice[0, 0], vertice[1, 0]], [vertice[0, 1], vertice[1, 1]])
    axes.plot([vertice[1, 0], vertice[2, 0]], [vertice[1, 1], vertice[2, 1]])
    axes.plot([vertice[2, 0], vertice[3, 0]], [vertice[2, 1], vertice[3, 1]])
    axes.plot([vertice[3, 0], vertice[0, 0]], [vertice[3, 1], vertice[0, 1]])

def plotGraph(axes, st_graph, search_result = None):
    t_resolution = 0.2
    for i in range(len(st_graph['value0'])):
        t = float(i) * t_resolution
        for st_bound in st_graph['value0'][i]:
            vertice = np.array([[t - t_resolution / 2.0, st_bound['s_min']],
                [t + t_resolution / 2.0, st_bound['s_min']],
                [t + t_resolution / 2.0, st_bound['s_max']],
                [t - t_resolution / 2.0, st_bound['s_max']]])
            plotRectange(axes, vertice)
    if search_result is not None and 'value0' in search_result:
        longi_result = np.array([search_result['value0']])
        t = np.array([float(i) * t_resolution \
                for i in range(longi_result.shape[1]) ])
        axes.plot(t, longi_result[0, :], 'k')

def plot_longi_search(axes, s_interval_file, longi_result_file):
    if (os.path.isfile(s_interval_file) is False):
        print("s_interval_file is not existed")
        return
    if (os.path.isfile(longi_result_file) is False):
        print("longi result is not existed")
    st_graph = ParseJson(s_interval_file)
    search_result = ParseJson(longi_result_file)
    plotGraph(axes, st_graph, search_result)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(\
            description = "plot st-graph and search result")
    parser.add_argument('--directory', '-d', required = False, \
            default = '/tmp/', help = 'data directory')
    parser.add_argument('--stgraph', '-st', required = True, type = str, \
            help = 'data timestamp, ex 2019-12-03-10-20-50-926s_intervals.json')
    parser.add_argument('--searchResult', '-sr', required = True, type = str, \
            help = 'data timestamp, ex 2019-12-03-10-20-50-926longi_dp.json')
    args = parser.parse_args()
    stgraph_dir = findMatchDataFile(args.directory, args.stgraph)
    print(stgraph_dir)
    search_result_dir = findMatchDataFile(args.directory, args.searchResult)
    st_graph = ParseJson(args.directory + stgraph_dir)
    search_result = ParseJson(args.directory + search_result_dir)
    fig = plt.figure("st-graph search result")
    axes = fig.add_axes([0.1, 0.1, 0.8, 0.8])
    plotGraph(axes, st_graph, search_result)
    plt.show()
