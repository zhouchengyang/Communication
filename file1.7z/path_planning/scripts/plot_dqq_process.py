#
#Copyright(C) 2019 by SenseTime Group Limited.All rights reserved.
#Shengfa Zhu < zhushengfa @sensetime.com >
#
'''
1. plot predict result form prediction module
2. plot dynamic programming search process,
including st-graph and dp search result
3. plot longitudinal optimization
4. plot lateral optimization
'''

import argparse
import json
import matplotlib.pyplot as plt
import numpy as np
import re
import os
import random
from functools import cmp_to_key
from plot_dp_search import plot_longi_search
from plot_qp_result import plot_qp_optimize

def cmp_file(x, y):
    min_len = min(len(x), len(y))
    for i in range(min_len):
        if x[i] < y[i]:
            return -1
        elif x[i] > y[i]:
            return 1
    return 0

def parse_json(json_path):
    with open(json_path, 'r') as f:
        data = json.loads(f.read())
    return data

def find_match_datafile(dir, data_file_name, \
        predict_result_keyword = "predict_result", \
        longi_dp_keyword = "longi_dp", s_interval_keyword = "s_intervals", \
        qp_keyword = "qp_optimization"):
    '''
    find data file name match given time stamp
    '''
    file_name_dict = {}
    file_name_dict["predict_result"] = ""
    file_name_dict["s_intervals"] = ""
    file_name_dict["longi_dp"] = ""
    file_name_dict["longi_qp"] = ""
    file_name_dict["lateral_qp"] = ""

    file_list = os.listdir(dir)
    file_list.sort(key = cmp_to_key(cmp_file))
    count = 0
    for i in range(len(file_list)):
        if data_file_name in file_list[i]:
            j = i
            while count < 5 and (j - i) < 100 and \
                    (data_file_name in file_list[j]):
                if (predict_result_keyword in file_list[j] and \
                        len(file_name_dict["predict_result"]) < 1):
                    file_name_dict["predict_result"] = \
                            os.path.join(dir, file_list[j])
                    count = count + 1
                elif (longi_dp_keyword in file_list[j] and \
                        len(file_name_dict["longi_dp"]) < 1):
                    file_name_dict["longi_dp"] = os.path.join(dir, file_list[j])
                    count = count + 1
                elif (s_interval_keyword in file_list[j] and \
                        len(file_name_dict["s_intervals"]) < 1):
                    file_name_dict["s_intervals"] = os.path.join(dir, file_list[j])
                    count = count + 1
                elif (qp_keyword in file_list[j] and \
                        len(file_name_dict["longi_qp"]) < 1):
                    file_name_dict["longi_qp"] = os.path.join(dir, file_list[j])
                    count = count + 1
                elif (qp_keyword in file_list[j] and \
                        len(file_name_dict["longi_qp"]) > 0 and \
                        len(file_name_dict["lateral_qp"]) < 1):
                    file_name_dict["lateral_qp"] = os.path.join(dir, file_list[j])
                    count = count + 1
                j = j + 1
            break

    if (count < 5):
        print("cannot find all data file for some reasons")
    for k, v in file_name_dict.items():
        print(k, ",", v)
    return file_name_dict

def plot_single_trajectory(axes, trajectory, color):
    '''
    plot single predict trajectory
    '''
    for polygon in trajectory:
        if polygon.shape[0] < 1:
            continue
        for i in range(polygon.shape[0] - 1):
            axes.plot([polygon[i][0], polygon[i + 1][0]], \
                    [polygon[i][1], polygon[i + 1][1]], color)
        axes.plot([polygon[-1][0], polygon[0][0]], \
                [polygon[-1][1], polygon[0][1]], c = color)

def plot_predict_result(axes, predict_result_file):
    '''
    plot predcit result from given file
    '''
    if (os.path.isfile(predict_result_file) is False):
        print("predict result file is not existed")
        return

    predict_data = parse_json(predict_result_file);
    for object in predict_data['value0']['prediction_object_array']:
#for each object
        for traj in object['trajectory_array']:
#for each trajecotory with prob
            trajectory = []
            for point in traj['trajectory_point_array']:
                polygon  = []
                for vertice in point['polygon_contour']:
                    polygon.append([vertice['x'], vertice['y']])
                trajectory.append(np.array(polygon))
            color = "#"+''.join([random.choice('0123456789ABCDEF') \
                    for k in range(6)])
            plot_single_trajectory(axes, trajectory, color)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(\
            description = "plot longi-lateral planning process, " \
            + "including predict result, longitudinal search, " \
            + "longitudinal optimization and lateral optimization")
    parser.add_argument('--directory', '-d', required = False, \
            default = '/tmp/', help = 'data directory')
    parser.add_argument('--time', '-t', required = True, type = str, \
            help = 'data timestamp, ex 2019-12-03-10-20-50-9')
    args = parser.parse_args()
    file_name_dict = find_match_datafile(args.directory, args.time)

    fig, axes = plt.subplots(3, 2)
    plot_predict_result(axes[0, 0], file_name_dict["predict_result"])
    axes[0, 0].set_title("predict result")
    plot_longi_search(axes[0, 1], file_name_dict["s_intervals"],\
            file_name_dict["longi_dp"])
    axes[0, 1].set_title("longitudinal search")
    plot_qp_optimize(axes[1, 0], axes[2, 0], file_name_dict["longi_qp"])
    axes[1, 0].set_title("longitudinal optimization")
    plot_qp_optimize(axes[1, 1], axes[2, 1], file_name_dict["lateral_qp"])
    axes[1, 1].set_title("lateral optimization")
    plt.show()
