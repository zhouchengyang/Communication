"""
Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
Shengfa Zhu <zhushengfa@sensetime.com>

plot qp optimization bounds and solution

"""

import numpy as np
import os
import argparse
import matplotlib.pyplot as plt
import re
import mmap

def readDataBlock(data_str, pattern_block, pattern_split = re.compile(r",?\n")):
    '''
    read string into numpy array with two demension
    '''
    numerial_number = r"(-?[0-9]+(.[0-9]*)?([eE]-?[0-9]+)?)"
    match_obj = re.search(pattern_block, data_str)
    index = match_obj.span()
    vec_str = re.split(pattern_split, data_str[index[0] : index[1]])
    data = []
    for vec in vec_str:
        num_str = re.split(re.compile(r","), vec)
        curr_row = []
        for s in num_str:
            if re.fullmatch(re.compile(numerial_number), s):
                curr_row.append(float(s))
        if (len(curr_row) > 0):
            data.append(np.array(curr_row))
    return np.array(data)

def verifyH(data_file_dir):
    '''
    read matrix H
    '''
    # 1. extract data into H (numpy array)
    with open(data_file_dir, "r") as f:
        content = f.read()
        pat_H = re.compile(r"H\n(((\S+),( )?)+\n)*")
        H = readDataBlock(content, pat_H)
        print(H)

    # 2. calculate numerical result
    s = np.zeros((H.shape[0], 1))
    for i in range(s.shape[0]):
        t = i * 0.2
        a = 2.0
        s[i, 0] = 0.5 * a * t * t
    a_sum_numerical = 0.0
    for i in range(2, s.shape[0]):
        curr_a = (s[i, 0] - 2.0 * s[i - 1, 0] + s[i - 2, 0]) / (0.2 * 0.2)
        a_sum_numerical = a_sum_numerical + curr_a * curr_a

    # 3. calculate sum a with matrix H
    a_sum_H = np.matmul(np.matmul(s.transpose(), H), s)

    # 4. compare numerical result and H result
    print("numerial result: ", a_sum_numerical)
    print("H result : ", a_sum_H)

def readData(data_file_dir):
    '''
    read data from data file
    '''
    # 0. extract data into string from file
    with open(data_file_dir, "r") as f:
        content = f.read()
        # 1. read lb
        pat_lb = re.compile(r"lb\n(((\S+),( )?)+\n)*")
        lb = readDataBlock(content, pat_lb)
        # 2. read ub
        pat_ub = re.compile(r"ub\n(((\S+),( )?)+\n)*")
        ub = readDataBlock(content, pat_ub)
        # 3. read lb
        pat_lbA = re.compile(r"lbA\n(((\S+),( )?)+\n)*")
        lbA = readDataBlock(content, pat_lbA)
        # 4. read ub
        pat_ubA = re.compile(r"ubA\n(((\S+),( )?)+\n)*")
        ubA = readDataBlock(content, pat_ubA)
        # 5. read ub
        pat_last = re.compile(r"last\n(((\S+),( )?)+\n)*")
        last = readDataBlock(content, pat_last)
        # 6. read ub
        pat_ref = re.compile(r"ref\n(((\S+),( )?)+\n)*")
        ref = readDataBlock(content, pat_ref)
        # 7. read solution
        pat_solution = re.compile(r"qp_solution\n(((\S+),( )?)+\n)*")
        solution = readDataBlock(content, pat_solution)
        return lb, ub, lbA, ubA, last, ref, solution

def plotQPBounds(axes, lb, ub, lbA, ubA, last, ref):
    '''
    plot lower and upper bound
    '''
    if lb.shape[1] > 0 and ub.shape[1] > 0:
        t = np.array([0.2 * i for i in range(lb.shape[0])])
        l1, = axes.plot(t, lb[:, 0], 'r')
        l2, = axes.plot(t, ub[:, 0], 'b')
    if lbA is not None and lbA.shape[1] > 0 and ubA.shape[1] > 0:
        t = np.array([0.2 * i for i in range(lbA.shape[0])])
        l3, = axes.plot(t, lbA[:, 0], 'm')
        l4, = axes.plot(t, ubA[:, 0], 'y')
    if (len(last) > 2) and ref.shape[1] > 0:
            t = np.array([0.2 * i for i in range(last.shape[0])])
            l5, = axes.plot(t, last[:, 0], 'm')
    t = np.array([0.2 * i for i in range(ref.shape[0])])
    l6, = axes.plot(t, ref[:, 0], 'y')
    if lbA is not None and (len(last) > 2) and ref.shape[1] > 0:
        axes.legend(handles = [l1, l2, l3, l4, l5, l6], labels = ["lower bound", \
            "upper bound", "lower rate bound", "upper rate bound", "last", "ref"])
    elif lbA is None and (len(last) > 2) and ref.shape[1] > 0:
        axes.legend(handles = [l1, l2, l5, l6], labels = ["lower bound", \
            "upper bound",  "last", "ref"])

def plotQPSolution(axes, solution):
    '''
    plot qp solution
    '''
    t = np.array([0.2 * i for i in range(solution.shape[0])])
    l5, =  axes.plot(t, solution[:, 0], 'k')
    axes.legend(handles = [l5], labels = ["solution"])

def plotQPDerivative(axes, solution):
    '''
    plot qp derivative
    '''
    t = np.array([0.2 * i for i in range(solution.shape[0])])
    first_derivative = np.zeros(solution.shape[0])
    second_derivative = np.zeros(solution.shape[0])
    third_derivative = np.zeros(solution.shape[0])
    for i in range(solution.shape[0]):
        if i + 1 < solution.shape[0]:
            first_derivative[i] = (solution[i + 1, 0] - solution[i, 0]) / 0.2
        if i + 2 < solution.shape[0]:
            second_derivative[i] = (solution[i+2, 0] - 2.0 * solution[i + 1, 0]\
                    + solution[i, 0]) / (0.2 * 0.2)
        if i + 3 < solution.shape[0]:
            third_derivative[i] = (solution[i + 3, 0] \
                    - 3.0 * solution[i + 2, 0] + 3.0 * solution[i + 1, 0] \
                    - solution[i, 0]) / (0.2 * 0.2 * 0.2)
    l6, =  axes.plot(t[0 : -1], first_derivative[0 : -1])
    l7, =  axes.plot(t[0 : -2], second_derivative[0 : -2])
    l8, =  axes.plot(t[0 : -3], third_derivative[0 : -3])
    axes.legend(handles = [l6, l7, l8], labels = ["first_derivative", \
            "second_derivative", "third_derivative"])

def findMatchDataFile(dir, data_file_name):
    '''
    find data file name match given time
    '''
    match_file = []
    # dir is file not a directory
    if os.path.isfile(dir):
        return match_file
    for file_name in os.listdir(dir):
        if data_file_name in file_name:
            print(file_name)
            match_file.append(file_name)
    return match_file

def plot_qp_optimize(axes1, axes2,  data_file_name, plot_rate_bound = False):
    if os.path.isfile(data_file_name) is False:
        print(data_file_name + "is not a file")
        return
    lb, ub, lbA, ubA, last, ref, solution = readData(data_file_name)
    plotQPBounds(axes1, lb, ub, None, None, last, ref)
    if len(solution) > 0:
        print("solution ploted")
        plotQPSolution(axes1, solution)
        print("derivative ploted")
        plotQPDerivative(axes2, solution)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(\
            description = "plot qp bounds and solution")
    parser.add_argument('--directory', '-d', required = False, \
            default = '/tmp/', help = 'data directory')
    parser.add_argument('--time', '-t', required = True, type = str, \
            help = 'data timestamp, ex 2019-11-28-12-00-00.0')
    args = parser.parse_args()
    match_file = findMatchDataFile(args.directory, args.time)
    fig = plt.figure()
    axes = fig.add_axes([0.1, 0.1, 0.8, 0.8])
    if (len(match_file) > 0):
        for file in match_file:
            lb, ub, lbA, ubA, last, ref, solution = readData(args.directory + file)
            plotQPBounds(axes, lb, ub, lbA, ubA, last, ref)
            if len(solution) > 0:
                print("solution ploted")
                plotQPSolution(axes, solution)
            plt.show()
    else:
        print("no file match directory and time, please check it")
    '''
    # evaluate H
    for file in match_file:
        verifyH(args.directory + file)
    '''
