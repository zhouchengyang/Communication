# path_planning (Basic Path Planning)

This is a Sensedrive SDK project for path planning (path planning with RRT star).

| Features              | Use case                                          | Input     | Parameters                     | Output                                                                        |
| --------------------- | --------------------                              | --------- | ------------------------------ | ----------------------------------------                                      |
| RRT star Path Planner   | Crossroad                                    | output of RD result | interp_points | Sets of points representing the path planning result |
| Quadratic Bezier Planner   | Crossroad                                    | output of RD result | interp_points | Sets of points representing the path planning result |

