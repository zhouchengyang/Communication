/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 * Liang Yu <liangyu@sensetime.com>
 */

#pragma once

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <opencv2/opencv.hpp>

#include "common/error.hpp"
#include "common/data_type/car_trajectory.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/vehicle_info.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/ppconfig.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API CachePoint {
 public:
    /**
     * @brief Initialize the PP_Tracker
     **/
     CachePoint();
    /**
     * @brief Destruct the PP_Tracker
     **/
    ~CachePoint();

    adStatus_t Init();

    typedef std::function<adStatus_t(cv::Point2f *point)> fun_warp_point_t;

    /**
     * @brief register coordinate conversion plug
     * @param fun_warp_point[in] coordinate conversion function
     **/
    void RegisterWarpPointPlug(fun_warp_point_t fun_warp_point) {
        WarpPoint_ = fun_warp_point;
    }

    adStatus_t WarpPoint(TrajectoryPoint* traj_pt);
    /**
     * @brief advance with one timestamp, should be call only once
     *      warp update all cache infomation base on given timestamp
     *
     *      should be called before calling cache/query
     */
    adStatus_t Update(const int64_t& timestamp);
    /**
     * @brief Set car trajectory point to allow query of read-only can data
     */

    // Manual version of Caching
    // timestamp at called
    adStatus_t CacheTrajectoryPoint(const int& id,
                                    const TrajectoryPoint& tj_point);
    // Auto version of caching
    // TODO(congq): Not implemented implement it
    adStatus_t CacheTrajectoryPoint(const TrajectoryPoint& tj_point,
                                    int* match_id);
    adStatus_t ClearPointByID(const int& id);

    adStatus_t QueryTrajectoryPoint(const int& id, TrajectoryPoint* tj_point);

    adStatus_t CachePath(const std::vector<TrajectoryPoint>& trajectory);
    adStatus_t CachePathWithSmooth(
            const std::vector<TrajectoryPoint>& trajectory);

    adStatus_t QueryPath(std::vector<TrajectoryPoint>* result_path);

    adStatus_t TrackPath(const int& id,
                         const std::vector<TrajectoryPoint>& trajectory);

    adStatus_t QueryPath(const int& id,
                         std::vector<TrajectoryPoint>* trajectory);

    adStatus_t SetParameters(const int& max_pool_size,
                             const int& max_tj_pool_size);

    adStatus_t TryTrajectoryPoint(const int& id, TrajectoryPoint* tj_point);
    /*
     * @brief Anchor at a point, track the accumulated distance.
     */
    adStatus_t RegisterTravelPoint(const std::string& name);

    /*
     * @brief Query traveled distance from the registered point by its name
     */
    adStatus_t QueryTraveledDistance(const std::string& name, float* distance);

 private:
    adStatus_t WarpPoint(cv::Point2f *point);

 private:
    std::shared_ptr<Car_Trajectory> ct;
    int64_t last_timestamp_ = 0;

    std::map<int, std::vector<TrajectoryPoint> > history_trajectroy_pool_;
    std::map<int, int> pool_tail_;
    std::map<int, int64_t> last_access_time_;

    int max_pool_size_ = 10;

    bool should_replan_ = false;

    float off_track_tolerance_ = 1.0;
    float length_discrepance_tolerance_ = 1.1;
    float max_tjp_diff_tolerance_ = 0.7;
    float avg_tjp_diff_tolerance_ = 0.3;

    std::vector<TrajectoryPoint> cached_trajectory_;
    std::map<int, std::vector<TrajectoryPoint> > trajectory_pool_;
    std::map<int, int> tj_pool_tail_;
    int max_tj_pool_size_ = 2;

    int64_t timeout_ = 2e9;
    fun_warp_point_t WarpPoint_ = nullptr;
};
}  // namespace pp
}  // namespace senseAD
