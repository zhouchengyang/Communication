/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <iostream>
#include <string>
#include <map>
#include "common/log.hpp"
#include "common/error.hpp"
#include "ini.h"  // NOLINT

namespace senseAD {
namespace pp {
/*
 * DO NOT CHANGE THE ORDER OF THESE FOLLOWING LINES UNLESS YOU UNDERSTAND IT
 * IMPROPER MODIFICATION WOULD RESULT IN COMPILE ERROR
 */
typedef std::string ppstring;
#define PPCONFIG_SUPPORT_TYPES \
    LOGICS(float) LOGICS(double) LOGICS(int) LOGICS(ppstring)

class PPConfig;
class PPConfigSection;
class ReturnTypeProxy {
 public:
    ReturnTypeProxy(PPConfig *ppconfig, std::string idx) {
        this->index = idx;
        this->conf = ppconfig;
    }
#define LOGICS(type) operator type();
    PPCONFIG_SUPPORT_TYPES
#undef LOGICS
 private:
    std::string index;
    PPConfig *conf;
};
class PPConfig {
    friend ReturnTypeProxy;
    friend PPConfigSection;

#define LOGICS(type) std::map<std::string, type> type##_configs;
    PPCONFIG_SUPPORT_TYPES
#undef LOGICS

 public:
    ReturnTypeProxy operator[](std::string idx) {
        return ReturnTypeProxy(this, idx);
    }
};

#define LOGICS(type)                                                          \
    inline ReturnTypeProxy::operator type() {                                 \
        if (this->conf->type##_configs.find(this->index) ==                   \
            this->conf->type##_configs.end()) {                               \
            AD_LERROR(PATH_PLANNING) << "key: " << this->index                \
                                     << " not found at " << #type             \
                                     << " configs, may return random values"; \
        }                                                                     \
        return this->conf->type##_configs[this->index];                       \
    }
PPCONFIG_SUPPORT_TYPES
#undef LOGICS

class PPConfigSection {
 public:
    PPConfigSection() {}
    PPConfig operator[](std::string idx) { return this->configs[idx]; }
    adStatus_t Init(std::string file_path);

 private:
    std::map<std::string, PPConfig> configs;
    int config_read_state;
    INI::Level inisection;
};

extern PPConfigSection g_pp_conf;

}  // namespace pp
}  // namespace senseAD

