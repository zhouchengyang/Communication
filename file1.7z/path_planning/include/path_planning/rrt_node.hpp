/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <set>
#include <opencv2/opencv.hpp>
#include "common/data_type/trajectory_point.hpp"

namespace senseAD {
namespace pp {

struct RRTNode : public TrajectoryPoint {
    int id;
    float cost;
    float base_path_cost;
    cv::Point2f default_direction;
    int parent_id;
    float sumcost;
    std::set<int> children_id;
    float sum_dist = 0.0f;
    float sum_time = 0.0f;
    float frenet_s = 0.0f;
    float frenet_d = 0.0f;
    int bpp_index = 0;
};

}  // namespace pp
}  // namespace senseAD

