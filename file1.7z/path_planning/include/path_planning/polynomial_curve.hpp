/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 */

#pragma once

#include <vector>
#include <iostream>
#include <string>
class PolynomialCurve {
 public:
    PolynomialCurve();
    /**
     * @brief create a 1d bezier curve
     * @param n degree
     **/
    explicit PolynomialCurve(int n);
    /*
     * @brief differential of the curve
     * @return another curve
     */
    PolynomialCurve Differential();
    /*
     * @brief NOT IMPLEMENTED
     */
    PolynomialCurve Integral();
    /*
     * @brief Set the reference value
     * @param ref_v a vector of p0, p1...pn-1
     */
    void SetReferenceValue(std::vector<float> ref_v);

    /*
     * @brief get the value of given t
     */
    float Value(float t);
    float Findt(float value);
    std::vector<std::vector<float>> polynomials_;
    std::vector<float> reference_value_;
    float min_error = 0.0001;
    void Display();
    std::string to_str();
    /*
     * @brief for monotonic curve, find t for a given value, in binary search
     * style
     * @param begin search between t [begin, begin+ range]
     * @param allrange the whole range
     * @param range search between t [begin, begin + range]
     * @param target the target value
     * @param error when to end the recurrsion
     */
    float SpecialFindtForMonotonic(
        float begin, float allrange, float range, float target, float error);
};

