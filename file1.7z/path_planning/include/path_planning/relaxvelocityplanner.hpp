/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cstdlib>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/velocityplanner.hpp"

namespace senseAD {
namespace pp {

class RelaxVelocityPlanner : public VelocityPlanner {
 public:
    adStatus_t PlanVelocity(
        std::vector<TrajectoryPoint> *path_to_plan);
    adStatus_t Init() {
        VelocityPlanner::Init();
        auto conf = g_pp_conf["rrt_setting"];
        speed_eps_ = conf["rvp_speed_eps"];
        accel_jerk_ = conf["rvp_accel_jerk"];
        accel_max_ = conf["rvp_accel_max"];
        thres_keep_distance_ = conf["rvp_thres_keep_distance"];
        return AD_SUCCESS;
    }
 protected:
    float speed_eps_ = 0.27f;
    float accel_jerk_ = 0.9f;
    float accel_max_ = 2.0f;
    float thres_keep_distance_ = 2.0f;
};

}  // namespace pp
}  // namespace senseAD

