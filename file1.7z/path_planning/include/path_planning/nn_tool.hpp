/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 */

#pragma once

#include <vector>
#include <iostream>
#include <string>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/data_type/trajectory_point.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API KDTreeNode {
 public:
    int data;
    KDTreeNode* left_child_;
    KDTreeNode* right_child_;
};

class SENSEAD_API NNTool {
 public:
    NNTool();
    ~NNTool();
    adStatus_t Init();
    adStatus_t UpdateData(const std::vector<TrajectoryPoint>& tj_pts);
    int NearestNeighbor(const TrajectoryPoint& tjp) const;

    void SetNNToolMode(int mode) { nn_tool_mode_ = mode; }
    void SetDownSampleRate(int rate) { nn_down_sample_rate_ = rate; }

 private:
    int nn_tool_mode_ = 1;
    int nn_down_sample_rate_ = 5;
    KDTreeNode* kd_tree_ = NULL;

    KDTreeNode* build_tree_(std::vector<int>* tjps,
                            uint32_t begin,
                            uint32_t end,
                            uint32_t depth);

    void delete_tree_(KDTreeNode* tree);

    int nn(KDTreeNode* root, cv::Point2f point, int depth) const;

    int closer_one(const cv::Point2f& point, const int& a, const int& b) const;
    std::vector<cv::Point2f> pts_;
    std::vector<int> ids_;
};

extern NNTool g_nn_tool;

}  // namespace pp
}  // namespace senseAD

