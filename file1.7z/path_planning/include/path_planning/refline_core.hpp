/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong<qiucong@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cstdlib>
#include <chrono>  // NOLINT
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/schneidersmooth.hpp"
#include "path_planning/parampolyqpsmooth.hpp"
#include "path_planning/quinticsplinesmooth.hpp"
#include "path_planning/rrt_node.hpp"
#include "path_planning/planner_core.hpp"
#include "path_planning/scene_parser.hpp"
#include "path_planning/relaxvelocityplanner.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API ReflineCore : public PlannerCore {
 public:
    ReflineCore() {}
    virtual ~ReflineCore();
    adStatus_t Init();
    adStatus_t Plan(std::vector<TrajectoryPoint> *out_path);
 private:
};

}  // namespace pp
}  // namespace senseAD

