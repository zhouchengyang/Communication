/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <algorithm>
#include <cstdlib>
#include <chrono>  // NOLINT
#include <iomanip>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/schneidersmooth.hpp"
#include "path_planning/parampolyqpsmooth.hpp"
#include "path_planning/quinticsplinesmooth.hpp"
#include "path_planning/rrt_node.hpp"
#include "path_planning/planner_core.hpp"
#include "path_planning/scene_parser.hpp"
#include "path_planning/relaxvelocityplanner.hpp"
#include "path_planning/qpvelocityplanner.hpp"

namespace senseAD {
namespace pp {

typedef std::chrono::time_point<std::chrono::high_resolution_clock,
                                std::chrono::microseconds>
    MicroClock;

class SENSEAD_API RRTCore : public PlannerCore {
 public:
    RRTCore() {}
    virtual ~RRTCore();
    adStatus_t Init();
    adStatus_t Plan(std::vector<TrajectoryPoint> *out_path);

    // adStatus_t BindFunctionFromClass(SceneParser *sp);
    // Here define all interface function RRT needed
    /*
    typedef std::function<adStatus_t(
         const cv::Point2f &position,
         bool *pass_check)> func_bool_collisioncheck_static_t;
    typedef std::function<adStatus_t(
         const cv::Point2f &position,
         char *pass_check)> func_char_collisioncheck_static_t;A
    */
    typedef std::function<adStatus_t(float s,
                                     float d,
                                     float heading,
                                     float t,
                                     float longi_safe_dist_,
                                     float lat_safe_dist_,
                                     bool *pass_check)>
        func_bool_frenet_collisioncheck_predict_t;

    typedef std::function<adStatus_t(float s,
                                     float d,
                                     float heading,
                                     float t,
                                     float longi_safe_dist_,
                                     float lat_safe_dist_,
                                     int *pass_check)>
        func_int_frenet_risk_t;

    typedef std::function<adStatus_t(TrajectoryPoint *point)>
        func_warp_trajpoint_frame_t;
    /*
    func_bool_collisioncheck_static_t func_bool_collisioncheck_static;
    func_char_collisioncheck_static_t func_char_collisioncheck_static;
    */
    /**
     * @brief register collision check plug
     * @param fun_collision[in] collosion check function
     **/
    void RegisterFrenetCollisionPlug(
        func_bool_frenet_collisioncheck_predict_t fun_collision) {
        func_bool_frenet_collisioncheck_predict = fun_collision;
    }

    void RegisterFrenetRiskPlug(func_int_frenet_risk_t fun_risk) {
        func_int_frenet_risk = fun_risk;
    }
    /**
     * @brief for rrt build tree test
     * @param points[in] random point
     **/
    void SetRandomPointsForTest(const std::vector<cv::Point2f> &points,
                                bool if_sort = false);

    inline void SetBuildTreeTestMode(bool is_on) {
        this->buildtree_test_mode_ = is_on;
    }

 private:
    /**
     * @brief sample point and put to re_calc_samples for "all_rewire == 1" mode
     * @param points[in] random point
     **/
    void SamplesPointSet();

    /**
     * @brief set timestamp on trajectory point
     * @param points[out] planning trajectory
     **/
    void SetTimestamp(std::vector<TrajectoryPoint> *out_path);

    /**
     * @brief plan path
     * @param out_path[out] planning trajectory
     **/
    adStatus_t PlanPath(std::vector<TrajectoryPoint> *out_path);

    /**
     * @brief plan velocity on path
     * @param out_path[out] planning trajectory
     **/
    adStatus_t PlanVelocity(std::vector<TrajectoryPoint> *out_path) const;

    /**
     * @brief truncate path as origin point and clear velocity of trajectory
     * @param out_path[out] planning trajectory with zero velocity
     **/
    adStatus_t TruncatePath(std::vector<TrajectoryPoint> *out_path);

 protected:
    func_bool_frenet_collisioncheck_predict_t
        func_bool_frenet_collisioncheck_predict;
    func_int_frenet_risk_t func_int_frenet_risk;

    // ----These variable is for unit test----
    // [WARN] Do not modify this, if it is true, we never do collision check.
    int32_t buildtree_test_i = 0;
    std::vector<RRTNode> buildtree_test_random_points_;
    cv::Point2f buildtree_test_enterdir;
    std::vector<int> *buildtree_test_path_res = nullptr;
    // ---------------------------------------
    float expand_distance_ = 1.0;
    float insert_distance_ = 0.2;
    int max_iteration_ = 500;
    int max_cap_iteration_ = 500;

    float sample_rate_ = 0.1;
    bool if_cutpath_ = false;
    int bpp_sample_interval_ = 2;
    int rrtgoal_by_mincost_ = 1;
    float rrtgoal_bymincost_dist_ = 1.0f;
    int avg_sum_cost_ = 0;

    float boundary_offset = 0;
    int pp_point_frame = 10;
    int pp_traj_frame = 5;

    float accel_quick = 2;
    float accel_slow = 2;
    float approaching_velocity = 2;
    float goal_not_reachable_thres_ = 2.0f;
    float steer_far_scale_ = 0.2f;
    int vp_mode = 0;
    int bpp_preplan_ = 0;
    int bpp_sample_ = 0;
    int pure_bp_ = 1;
    int pure_ref_line_ = 1;
    int bpp_improved_ = 0;
    float w_bpp_cost_ = 10.0;
    float w_risk_cost_ = 1.0;
    float w_parent_cost_ = 1.0;
    float w_curvature_ = 100.0;
    float w_yaw_from_parent_ = 1.0;
    float w_dist_ = 1.0;
    float w_direction_ = 100.0;
    float w_alignment_ = 1.0;
    float w_curvature_change_ = 100.0;
    float extra_hop_cost_ = 1.0;
    int all_rewire_ = 1;
    int sumcost_optimize_ = 1;
    int traj_smoothing_ = 1;
    // smooth type: 0 default smoother
    //              1 schneider smoother
    //              2 paramatic polynormal qp smoother
    int use_smoother_ = 1;
    int32_t max_inter_ = max_iteration_;
    int32_t num_ctl_nearidx_ = 1;
    bool newnode_chooseparent_ = false;
    int32_t density_ctl_x_ = 30;
    int32_t density_ctl_y_ = 30;
    int32_t density_per_grid_ = 50;
    int32_t *denstiy_map_ = NULL;
    float y_standard_deviation_ = 2.0;
    // `expand_distance_` is used for controlling maxiumal distance of two
    // connected RRT Nodes
    // Now if the manhattan distance of goal is smaller than
    // `adjust_expand_dist_thres_`
    // we set `expand_distance_` to the same value of `expand_dist_ordinate_`
    // `expand_dist_ordinate_` saves the `expand_distance` value from config
    // initially
    // because `expand_dist` should be coordinate with density check
    // the `denstiy_per_grid` would be modify as well.
    float adjust_expand_dist_thres_ = 16.0f;
    float adjust_expand_dist_ = 1.0f;
    float expand_dist_ordinate_ = 2.0f;
    int density_per_grid_ordinate_ = 50;
    int density_per_grid_adjust_ = 50;

    int32_t use_base_path_goal_ = 1;

    float current_curvature_ = 0;

    int neglect_all_freespace_ = 0;
    int neglect_intersection_freespace_ = 0;
    int using_dot_cost_ = 0;
    float stopline_starting_offset_ = 0;
    float stopline_starting_adjustment_ = 0;
    float stopline_stop_offset_ = 0;

    // X offset of the whole rrt path
    float whole_path_x_offset_ = 10;
    // path offset adjustment
    float whole_path_x_adjustment_ = whole_path_x_offset_;

    int replan_mode_on_ = 1;
    int replan_mode_on_laneline_ = 1;
    float replan_per_second_ = 1.0;
    float node_frequency_ = 10.0;

    float rrt_goal_near_threshold_ = 2.0f;

    int key_extra_points_ = 100;
    int goal_safety_back_ = -1;
    int allow_stop_when_fail_ = 0;
    int failed_reach_goal_ = 0;
    int bp_assume_free_index_ = 0;

    float sample_same_bpp_ = 0.6f;

    Smoother *smoother_ = nullptr;
    VelocityPlanner *vplanner_ = nullptr;

    int output_by_time_ = 0;
    int output_planning_log_ = 1;

    std::vector<int> collied_bpp_index;
    std::vector<TrajectoryPoint> ref_line_;
    std::vector<int> sampled_flags_;
    std::vector<TrajectoryPoint> *out_path;

    VPPurpose single_purpose_ = KEEP_UP_NON_ZERO_VELOCITY;

    std::vector<TrajectoryPoint> goals_;
    std::vector<int> purpose_;
    std::vector<cv::Point2f> path;
    std::vector<RRTNode> re_calc_samples;

    std::string pp_core = "rrt";

    int32_t *newnear_idx = NULL;
    int32_t ao;

    float ref_line_interval_ = 1.0;

    float ref_line_length_ = 30.0;

    int use_ref_line_ = 0;

    int32_t switch_steering_input_direction_ = 0;

    bool should_replan_ = false;

    // set the first sample as goal
    bool sample_the_goal_ = true;

    int test_old_can_data;

    float default_velocity_ = 0;

    bool if_rand_engine_init = false;

    int max_goal_index_ = 200;
    int min_goal_index_ = 50;
    // time to select rrt goal, unit : s
    float select_rrt_goal_time_ = 3.5;

    bool if_skip_the_point_ = false;

    std::default_random_engine x_random_engine;
    std::default_random_engine y_random_engine;
    std::default_random_engine p_random_engine;

    int road_id_mode_ = 0;

    int extra_root_sample_ = 0;

    // >0 left <0 right
    float current_shift_ = 0;
    float shift_remain_ = 0;
    float honda_ped_shift_ = 0;
    float honda_vec_shift_ = 0;
    float honda_ped_start_shift_ = 0;
    float honda_vec_start_shift_ = 0;
    float honda_shift_remain_dist_ = 0;
    float shift_start_x_ = 1000.0f;
    float honda_close_y_threshold_ = 2.0f;
    float goal_forward_range_ = 10.0f;
    std::vector<RRTNode> nodes_;
    bool buildtree_test_mode_ = false;
    std::vector<int> bpp_key_index_;
    std::vector<bool> bpp_collision_check_;
    std::vector<int> collied_bp_index_;
    int bpp_first_usable_index_;
    int bpp_last_usable_index_;
    int key_point_around_collision_ = 10;
    int sample_same_bpp_maxtime_ = 1;
    int retry_count_collision_ = 5;
    int rrt_gridmap_as_free_ = 12;
    int rrt_predmap_as_free_ = 0;
    float rrt_longi_safe_dist_ = 0.0f;
    float rrt_lat_safe_dist_ = 0.0f;
    int predmap_as_free_ = 10;
    float speed_eps_ = 0.27f;
    float frenet_d_continue_ = 1.0f;
    int goal_index_threshold_ = 10;
    int goal_index_ = -1;
    cv::Point2f origin_point_ = cv::Point2f(0, 0);

    inline void InitSampledFlag() {
        sampled_flags_ =
            std::vector<int>(std::max(0,
                                      static_cast<int>(base_path_.size() - 1) /
                                              bpp_sample_interval_ +
                                          1),
                             0);
    }

    /**
     * @brief density check
     * @param a a 2d point
     * @return true if there number of points in current
     *        density_ctl_x_ * density_ctl_y_ grid is less than
     *        density_per_grid_,
     *         false otherwise
     **/
    inline bool density_check(const cv::Point2f &a) {
        cv::Point2f goal = goal_.position;
        // Only check forward.
        if (a.x < 0 || a.x >= density_ctl_x_ ||
            fabs(goal.y) >= density_ctl_y_) {
            return true;
        }
        int32_t x, y, t;
        x = (int32_t)a.x;
        y = (int32_t)(a.y + density_ctl_y_);
        t = x * density_ctl_y_ * 2 + y;
        if (denstiy_map_[t] < density_per_grid_) {
            denstiy_map_[t] = denstiy_map_[t] + 1;
            return true;
        } else {
            return false;
        }
    }

    adStatus_t WarpTree();
    void SimplilyAddWrappedNode();
    adStatus_t PurgeBranch();
    adStatus_t OriginCheckExpandValidFrom(const RRTNode &node,
                                          const RRTNode &trj_pt,
                                          bool *pass_check);

    adStatus_t IsFreeWithTime(float s,
                              float d,
                              float heading,
                              bool *pass_check);
    adStatus_t IsFreeWithTime(const TrajectoryPoint &tp, bool *pass_check);

    adStatus_t ItsRiskWithTime(float s,
                               float d,
                               float heading,
                               int *pass_check);
    adStatus_t ItsRiskWithTime(const TrajectoryPoint &tp, int *pass_check);

    inline void CostBetweenNode(const RRTNode &node_pre,
                                const RRTNode &node_add,
                                float *dist,
                                float *extra_yaw,
                                float *curvature,
                                float *maintain_direction,
                                float *curvature_change,
                                int32_t *legal_type) {
        const float small_eps = 1e-2;
        // where to put the extra yaw, curvature
        cv::Point2f d_pos = node_add.position - node_pre.position;
        *dist = utils::cvnorm(d_pos);
        cv::Point2f parent_parent = cv::Point2f(0, 0);
        cv::Point2f parent_parent_parent = cv::Point2f(0, 0);
        if (node_pre.id == 0) {
            parent_parent = start_.direction * (-1.0) * (*dist) + origin_point_;
        } else {
            parent_parent = nodes_[node_pre.parent_id].position;
            if (nodes_[node_pre.parent_id].id == 0) {
                parent_parent_parent =
                    start_.direction * (-1.0) * (*dist) + origin_point_;
            } else {
                parent_parent_parent =
                    nodes_[nodes_[node_pre.parent_id].parent_id].position;
            }
        }
        AD_LTRACE(PATH_PLANNING) << "vec_parent_parent: " << parent_parent;
        // Vector of parent's parent to parent
        auto vec_pp_p = node_pre.position - parent_parent;
        // Vector of parent's parent's parent to parent's parent
        auto vec_ppp_pp = cv::Point2f(0, 0);
        if (node_pre.id != 0) {
            vec_ppp_pp = parent_parent - parent_parent_parent;
        }
        // Vector of parent to newnode
        auto vec_p_n = node_add.position - node_pre.position;
        AD_LTRACE(PATH_PLANNING) << "vec_pp_p: " << vec_pp_p;
        AD_LTRACE(PATH_PLANNING) << "vec_p_n: " << vec_p_n;

        // direction constrains
        float minx, miny, maxx, maxy;
        minx = maxx = start_.position.x;
        miny = maxy = start_.position.y;
        if (minx < goal_.position.x) {
            minx = goal_.position.x;
        }
        if (miny < goal_.position.y) {
            miny = goal_.position.y;
        }
        if (maxx > goal_.position.x) {
            maxx = goal_.position.x;
        }
        if (maxy > goal_.position.y) {
            maxy = goal_.position.y;
        }
        float cos_alpha =
            (vec_pp_p.x * vec_p_n.x + vec_pp_p.y * vec_p_n.y) /
            sqrtf((vec_pp_p.x * vec_pp_p.x + vec_pp_p.y * vec_pp_p.y) *
                  (vec_p_n.x * vec_p_n.x + vec_p_n.y * vec_p_n.y));

        float cos_alpha2 = 1;
        if (node_pre.id != 0) {
            cos_alpha2 =
                (vec_ppp_pp.x * vec_pp_p.x + vec_ppp_pp.y * vec_pp_p.y) /
                sqrtf((vec_ppp_pp.x * vec_ppp_pp.x +
                       vec_ppp_pp.y * vec_ppp_pp.y) *
                      (vec_pp_p.x * vec_pp_p.x + vec_pp_p.y * vec_pp_p.y));
        }

        // TODO(congq): NO MORE HARDCODED VALUE
        if (fabs(cos_alpha - 1) < 0.0001) {
            *extra_yaw = 0.0;
            *curvature = 0.0;

            AD_LTRACE(PATH_PLANNING) << "Radius fine: "
                                     << "Infinity";
            *legal_type = 1;

        } else {
            *extra_yaw = acosf(cos_alpha);
            float c = utils::cvnorm(vec_p_n) / 2 / cos_alpha;
            float b = utils::cvnorm(vec_pp_p) / 2;
            float d = (c + b) / (sqrtf(1 - cos_alpha * cos_alpha) / cos_alpha);
            float R = sqrtf(b * b + d * d);
            if (fabs(cos_alpha) < 1e-4) {
                b = utils::cvnorm(vec_pp_p);
                c = utils::cvnorm(vec_p_n);
                R = sqrtf(b * b + c * c) / 2;
            }
            *curvature = w_curvature_ / R;
            // legal_type:
            // 1 legal
            // 0 what? do you run through this function?
            // -1 cosine too small illegal
            // -2 radius too small illigal
            if (cos_alpha < 0.2 + small_eps ||
                (cos_alpha < 0.5 + small_eps && cos_alpha2 < 0.5 + small_eps)) {
                AD_LTRACE(PATH_PLANNING)
                    << "Cos_alpha too smalll: " << cos_alpha;
                *legal_type = -1;
            } else {
                AD_LTRACE(PATH_PLANNING) << "Cos_alpha fine: " << cos_alpha;
                // TODO(Congq): adaptive R constrain with velocity
                if (R < 2 + small_eps) {
                    AD_LTRACE(PATH_PLANNING) << "Radius too smalll:" << R;
                    *legal_type = -2;
                } else {
                    AD_LTRACE(PATH_PLANNING) << "Radius fine:" << R;
                    *legal_type = 1;
                }
            }
        }
        if (*legal_type == 1) {
            if (node_pre.id == 0) {
                *curvature_change =
                    fabs(*curvature / w_curvature_ - current_curvature_);
            } else {
                if (fabs(cos_alpha2 - 1) < 0.0001) {
                    *curvature_change = fabs(*curvature / w_curvature_);
                } else {
                    float c = utils::cvnorm(vec_pp_p) / 2 / cos_alpha2;
                    float b = utils::cvnorm(vec_ppp_pp) / 2;
                    float d = (c + b) /
                              (sqrtf(1 - cos_alpha2 * cos_alpha2) / cos_alpha2);
                    float R = sqrtf(b * b + d * d);
                    if (fabs(cos_alpha2) < 1e-4) {
                        b = utils::cvnorm(vec_ppp_pp);
                        c = utils::cvnorm(vec_pp_p);
                        R = sqrtf(b * b + c * c) / 2;
                    }

                    float p_curvature = 0;
                    if (fabs(R - 0.001) > 0.001) {
                        p_curvature = 1.0 / R;
                    }

                    *curvature_change =
                        fabs(*curvature / w_curvature_ - p_curvature);
                }
            }
            cv::Point2f vec_direct;
            // if goes wrong, set expected direction to the final.
            if (node_add.position.x > maxx || node_add.position.y > maxy ||
                node_add.position.x < minx || node_add.position.x < miny) {
                vec_direct = goal_.direction;
            } else {
                // use area rate to set the cost direction
                float area_all =
                    std::fabs(goal_.position.x) * std::fabs(goal_.position.x);
                float this_node = std::fabs(node_add.position.x) *
                                  std::fabs(node_add.position.y);
                float rate = this_node / (area_all + 1e-4);
                vec_direct = goal_.direction - start_.direction;
                vec_direct = vec_direct * rate;
                vec_direct = vec_direct + start_.direction;
            }
            float cos_direction =
                (vec_direct.x * vec_p_n.x + vec_direct.y * vec_p_n.y) /
                sqrtf((vec_direct.x * vec_direct.x +
                       vec_direct.y * vec_direct.y) *
                      (vec_p_n.x * vec_p_n.x + vec_p_n.y * vec_p_n.y));
            *maintain_direction = std::fabs(acosf(cos_direction));
        }
    }
    // private member function
    inline float NodeCost(const RRTNode &parent,
                          const RRTNode &leaf,
                          int32_t *legal_type) {
        // yaw value of from the its parent, in radian, cap at some limitatin
        //  return max if it exceed limitaion
        float yaw_from_parent = 0;
        // distance from its parent, in meter
        float dist;
        // curvature of the circumscribe circle of leaf/parent/parent'parent
        // m^-1
        float curvature = 0;
        // cost of parent

        // float parent_cost = parent.cost;
        // distance from its bpp original
        float bpp_cost = leaf.base_path_cost;
        // closest distance to last trajectory
        float alignment_cost = 0.0;
        if (cached_path_.empty() == false) {
            int closest_index = nn_tool_cached_path_.NearestNeighbor(leaf);
            if (closest_index >= 0 &&
                closest_index < static_cast<int>(cached_path_.size())) {
                alignment_cost = utils::cvnorm(
                    cached_path_.at(closest_index).position - leaf.position);
            }
        }
        // distance from closest barrieage
        float risk_cost = 0;
        float maintain_direction = 0;
        float curvature_change = 0;
        CostBetweenNode(parent, leaf, &dist, &yaw_from_parent, &curvature,
                        &maintain_direction, &curvature_change, legal_type);
        if (*(legal_type) != 1) {
            return 99999.999f;
        }
        char its_risk = 0;
        CheckRisk(leaf.position, &its_risk);

        risk_cost = static_cast<float>(std::max(0, 38 - its_risk)) / 38.0;

        // int32_t flag_old = FLAGS_v;
        // FLAGS_v = 5;
        if (parent.id == 0) {
            AD_LDEBUG(PATH_PLANNING) << "Got dist: " << dist;
            AD_LDEBUG(PATH_PLANNING)
                << "Got yaw_from_parent: " << yaw_from_parent;
            AD_LDEBUG(PATH_PLANNING) << "Got curvature: " << curvature;
            AD_LDEBUG(PATH_PLANNING)
                << "Got maintain_direction: " << maintain_direction;
            AD_LDEBUG(PATH_PLANNING)
                << "Got curvature_change: " << curvature_change;
            AD_LDEBUG(PATH_PLANNING)
                << "Got extra_hop_cost_: " << extra_hop_cost_;
            AD_LDEBUG(PATH_PLANNING) << "Got legal_type: " << (*legal_type);
        }

        float cost_final = 0;
        if (using_dot_cost_ > 0) {
            cost_final = curvature * curvature_change * maintain_direction;
            // w_yaw_from_parent_ * yaw_from_parent;
            // w_dist_ * dist;
        } else {
            cost_final = w_bpp_cost_ * bpp_cost + w_risk_cost_ * risk_cost +
                         curvature + w_yaw_from_parent_ * yaw_from_parent +
                         w_dist_ * dist + w_direction_ * maintain_direction +
                         w_curvature_change_ * curvature_change +
                         extra_hop_cost_ + w_alignment_ * alignment_cost;
        }
        if (parent.id == 0) {
            AD_LDEBUG(PATH_PLANNING) << "Got cost: " << cost_final;
        }
        // FLAGS_v = flag_old;
        return cost_final;
    }

    inline float AccumlateCost(const RRTNode &parent,
                               const RRTNode &leaf,
                               int32_t *legal_type) {
        float cost_all = 0;
        if (sumcost_optimize_ == 0) {
            std::vector<int32_t> ids;
            int32_t pid = parent.parent_id;
            while (pid != -1) {
                ids.push_back(pid);
                pid = nodes_[pid].parent_id;
            }
            if (ids.size() > 0) {
                for (int32_t ii = ids.size() - 1; ii >= 0; ii--) {
                    cost_all = w_parent_cost_ * cost_all + nodes_[ids[ii]].cost;
                }
            }
            cost_all = w_parent_cost_ * cost_all + parent.cost;
        } else {
            cost_all = parent.sumcost;
        }
        cost_all =
            w_parent_cost_ * cost_all + NodeCost(parent, leaf, legal_type);
        return cost_all;
    }

    inline float AccumlateCost(const RRTNode &parent,
                               const RRTNode &leaf,
                               int32_t *legal_type,
                               float *nodecost) {
        float cost_all = 0;
        if (sumcost_optimize_ == 0) {
            std::vector<int32_t> ids;
            int32_t pid = parent.parent_id;
            while (pid != -1) {
                ids.push_back(pid);
                pid = nodes_[pid].parent_id;
            }
            if (ids.size() > 0) {
                for (int32_t ii = ids.size() - 1; ii >= 0; ii--) {
                    cost_all = w_parent_cost_ * cost_all + nodes_[ids[ii]].cost;
                }
            }
            cost_all = w_parent_cost_ * cost_all + parent.cost;
            *nodecost = NodeCost(parent, leaf, legal_type);
            cost_all = w_parent_cost_ * cost_all + (*nodecost);
        } else {
            cost_all = parent.sumcost;
            *nodecost = NodeCost(parent, leaf, legal_type);
            cost_all = w_parent_cost_ * cost_all + (*nodecost);
        }
        return cost_all;
    }

    inline float AccumlateCost(const RRTNode &leaf) {
        float cost_all = 0;
        if (sumcost_optimize_ == 0) {
            std::vector<int32_t> ids;
            int32_t pid = leaf.parent_id;
            while (pid != -1) {
                ids.push_back(pid);
                pid = nodes_[pid].parent_id;
            }
            if (ids.size() > 0) {
                for (int32_t ii = ids.size() - 1; ii >= 0; ii--) {
                    cost_all = w_parent_cost_ * cost_all + nodes_[ids[ii]].cost;
                }
            }
            cost_all = w_parent_cost_ * cost_all + leaf.cost;
        } else {
            cost_all = leaf.sumcost;
        }
        return cost_all;
    }

    inline void ForwardAccCost(const RRTNode &node) {
        std::set<int> ids;
        int32_t legal_type = 0;
        float nodecost;
        ids.insert(node.children_id.begin(), node.children_id.end());
        for (auto id : ids) {
            nodes_[id].sumcost =
                AccumlateCost(nodes_[nodes_[id].parent_id], nodes_[id],
                              &legal_type, &nodecost);
            nodes_[id].sum_dist =
                nodes_[nodes_[id].parent_id].sum_dist +
                cv::norm(nodes_[id].position -
                         nodes_[nodes_[id].parent_id].position);
            nodes_[id].cost = nodecost;
            ids.insert(nodes_[id].children_id.begin(),
                       nodes_[id].children_id.end());
        }
    }
    adStatus_t SampleSameBPPTrajPoint(RRTNode *sample_traj_point,
                                      float *base_path_point_distance);
    adStatus_t SampleTrajPoint(RRTNode *sample_traj_point,
                               float *base_path_point_distance);
    adStatus_t Steer(const TrajectoryPoint &traj_pt,
                     TrajectoryPoint *steer_traj_point);
    adStatus_t OriginChooseParent(const RRTNode &traj_pt, RRTNode *new_node);
    adStatus_t AroundRootSample(TrajectoryPoint *sample_traj_point);
    adStatus_t SampleKeyTrajPoint(RRTNode *sample_traj_point,
                                  float *base_path_point_distance);
    adStatus_t Rewire(RRTNode *new_node);
    adStatus_t GenTrajPath(const TrajectoryPoint &goal,
                           std::vector<TrajectoryPoint> *trajpoint_path);
    adStatus_t BPPPathCollisionCheck();

    inline adStatus_t RRTCheckCollision(const cv::Point2f &position,
                                        bool *in_free_space) {
        char is_free_value = 0;
        if (ItsRisk_ == nullptr) {
            AD_LERROR(PATH_PLANNING) << "RRTCore no register collision plug()";
            return AD_NULL_PTR;
        }
        ItsRisk_(position, &is_free_value);
        if (neglect_all_freespace_ || is_free_value >= rrt_gridmap_as_free_) {
            *in_free_space = true;
        } else {
            *in_free_space = false;
        }
        return AD_SUCCESS;
    }
    std::vector<int> function_called_nums_;
    std::vector<std::chrono::nanoseconds> durations_;
    void CheckCollision(const cv::Point2f &pt, bool *result);

    void CheckRisk(const cv::Point2f &pt, char *result);
};

}  // namespace pp
}  // namespace senseAD

