/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include <utility>
#include <fstream>
#include <sstream>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/object_recovery.hpp"
#include "common/data_type/prediction_result.hpp"
#include "common/utils/configuration_reader.hpp"
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/obstacle_screen.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/frenet_coordinate_system.hpp"

namespace senseAD {
namespace pp {

template <typename T>
class Cell3d {
 public:
    void Init(const uint32_t size) {
        cell_size_ = size;
        data_ = new T[cell_size_];
        std::memset(data_, 0, cell_size_ * sizeof(T));
    }

    ~Cell3d() {
        if (data_ != nullptr) {
            delete[] data_;
        }
    }

    void SetCell(const uint32_t index, const int id) {
        if (index >= cell_size_) {
            return;
        }
        data_[index] = data_[index] | Encode(id);
    }

    void GetCell(const uint32_t index, std::vector<int>* ids) const {
        if (nullptr == ids) {
            return;
        }
        ids->clear();
        if (index >= cell_size_) {
            AD_LERROR(PREDICT_MAP) << "invalid index";
            return;
        }
        Decode(data_[index], ids);
    }

    T GetCell(const uint32_t index) const {
        if (index < cell_size_) {
            return data_[index];
        } else {
            return T(0);
        }
    }

    bool IsOccupied(const uint32_t index) const {
        if (index >= cell_size_) {
            // out of range
            return false;
        }
        if (data_[index] == T(0)) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @brief Refresh data and map
     */
    void Refresh() {
        encode_count_ = 0;
        std::memset(data_, 0, cell_size_ * sizeof(T));
        obj_to_id_.clear();
        id_to_obj_.clear();
    }

    /**
     * @brief decode obj into ids of obstacle
     * @param ids[out] vector of obstacle id
     * @return status
     **/
    inline void Decode(const T& obj, std::vector<int>* ids) const {
        if (nullptr == ids) {
            return;
        }
        ids->clear();
        T mask = 1;
        for (uint32_t i = 0; i < 8 * sizeof(T); ++i) {
            if ((mask & obj) != 0 &&
                (obj_to_id_.find(mask) != obj_to_id_.end())) {
                ids->emplace_back(obj_to_id_.at(mask));
            }
            mask = mask << 1;
        }
    }

    /**
     * @brief encode obstacle id into integer and set up maps
     * @return obj_id
     **/
    inline T Encode(const int id) {
        T num = 1;
        if (id_to_obj_.find(id) == id_to_obj_.end()) {
            if (encode_count_ >= (8 * sizeof(T))) {
                AD_LERROR(PREDICT_MAP) << "number of different obstacle "
                                          "exceeds max range of integer";
                return AD_INVALID_PARAM;
            }
            id_to_obj_[id] = (num << encode_count_);
            obj_to_id_[(num << encode_count_)] = id;
            encode_count_++;
        }
        return id_to_obj_[id];
    }

    inline void PrintDecodeInfo() {
        for (auto& item : id_to_obj_) {
            AD_LINFO(PREDICT_MAP) << "obs id " << item.first << "===>"
                                  << item.second;
        }
        for (auto& item : obj_to_id_) {
            AD_LINFO(PREDICT_MAP) << "obj id  " << item.first << "===>"
                                  << item.second;
        }
    }

 private:
    uint32_t cell_size_;
    uint32_t encode_count_ = 0;
    std::map<T, int> obj_to_id_;
    std::map<int, T> id_to_obj_;
    T* data_ = nullptr;
};

class SENSEAD_API PredictMap {
 public:
    PredictMap();

    virtual ~PredictMap();

    adStatus_t Init();

    adStatus_t Update(
        ObjectTrajectory* object_trajectory,
        PredictionResult* prediction_result,
        const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
        const bool lane_change_activated = false);

    adStatus_t Update(
        const PredictionObjectArray& poa,
        const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
        const bool lane_change_activated = false);

    adStatus_t SetParam(float pedestrain_extrasafe_dist,
                        float vehicle_extrasafe_dist);

    adStatus_t Refresh();

    inline adStatus_t GetVehicleRegion(
        const float& s,
        const float& d,
        const float& heading,
        const float& longi_safe_dist,
        const float& lat_safe_dist,
        std::vector<std::pair<uint32_t, uint32_t>>* sd_indice) const {
        // 1. calculate polygon in frenet coords
        sd_indice->clear();
        std::vector<cv::Point2f> polygon;
        polygon.reserve(5);
        float length = g_vehicle_param.length + 2.0 * longi_safe_dist;
        float width = g_vehicle_param.width + 2.0 * lat_safe_dist;
        float heading_bpp = frenet_system_->GetHeadingAtS(s);
        float angle = heading - heading_bpp;
        // should be counter-clockwise
        // 0 - 4 - 3
        // |   ^   |
        // 1   ^   2
        // |   ^   |
        // * - - - *
        polygon.emplace_back(cv::Point2f(length / 2.0, width / 2.0));
        polygon.emplace_back(cv::Point2f(0.0, width / 2.0));
        polygon.emplace_back(cv::Point2f(0.0, -width / 2.0));
        polygon.emplace_back(cv::Point2f(length / 2.0, -width / 2.0));
        polygon.emplace_back(cv::Point2f(length / 2.0, 0.0));
        for (auto& vertice : polygon) {
            float ss =
                s + vertice.x * std::cos(angle) + vertice.y * std::sin(angle);
            float dd =
                d - vertice.x * std::sin(angle) + vertice.y * std::cos(angle);
            uint32_t s_index = static_cast<uint32_t>(ss / s_per_front_grid_);
            uint32_t d_index =
                static_cast<uint32_t>(dd / d_per_grid_ + (num_d_grid_ * 0.5f));
            if (s_index < num_s_front_grid_ && d_index < num_d_grid_) {
                sd_indice->emplace_back(std::make_pair(s_index, d_index));
            }
        }
        return AD_SUCCESS;
    }

    inline adStatus_t is_free(const TrajectoryPoint& pt,
                              const float& after_time,
                              const float& longi_safe_dist,
                              const float& lat_safe_dist,
                              bool* in_free_space) const {
        uint32_t t_index =
            static_cast<uint32_t>(after_time / time_layer_width_);
        if (t_index >= num_time_layers_) {
            *in_free_space = true;
            return AD_SUCCESS;
        }
        *in_free_space = true;
        auto frenet_point = frenet_system_->Cartesian2Frenet(pt.position);
        float s = frenet_point.x, d = frenet_point.y;
        std::vector<std::pair<uint32_t, uint32_t>> sd_indice;
        GetVehicleRegion(s, d, pt.theta, longi_safe_dist, lat_safe_dist,
                         &sd_indice);
        for (const auto& sd_index : sd_indice) {
            uint32_t index = t_index * slice_size_ +
                             sd_index.first * num_d_grid_ + sd_index.second;
            if (cells_3d_.IsOccupied(index) == true) {
                *in_free_space = false;
                return AD_SUCCESS;
            }
        }
        return AD_SUCCESS;
    }

    inline adStatus_t is_free(const float& s,
                              const float& d,
                              const float& heading,
                              const float& after_time,
                              const float& longi_safe_dist,
                              const float& lat_safe_dist,
                              bool* in_free_space) {
        uint32_t t_index =
            static_cast<uint32_t>(after_time / time_layer_width_);
        if (t_index >= num_time_layers_) {
            *in_free_space = true;
            return AD_SUCCESS;
        }
        *in_free_space = true;
        std::vector<std::pair<uint32_t, uint32_t>> sd_indice;
        GetVehicleRegion(s, d, heading, longi_safe_dist, lat_safe_dist,
                         &sd_indice);
        for (const auto& sd_index : sd_indice) {
            uint32_t index = t_index * slice_size_ +
                             sd_index.first * num_d_grid_ + sd_index.second;
            if (cells_3d_.IsOccupied(index) == true) {
                *in_free_space = false;
                return AD_SUCCESS;
            }
        }
        return AD_SUCCESS;
    }

    inline adStatus_t its_risk(const TrajectoryPoint& pt,
                               const float& after_time,
                               const float& longi_safe_dist,
                               const float& lat_safe_dist,
                               int* in_free_space) {
        uint32_t t_index =
            static_cast<uint32_t>(after_time / time_layer_width_);
        if (t_index >= num_time_layers_) {
            *in_free_space = 0;
            return AD_SUCCESS;
        }
        *in_free_space = 0;
        auto frenet_point = frenet_system_->Cartesian2Frenet(pt.position);
        float s = frenet_point.x, d = frenet_point.y;
        std::vector<std::pair<uint32_t, uint32_t>> sd_indice;
        GetVehicleRegion(s, d, pt.theta, longi_safe_dist, lat_safe_dist,
                         &sd_indice);
        for (const auto& sd_index : sd_indice) {
            uint32_t index = t_index * slice_size_ +
                             sd_index.first * num_d_grid_ + sd_index.second;
            if (cells_3d_.IsOccupied(index) == true) {
                *in_free_space += risk_occupied_;
            }
        }
        return AD_SUCCESS;
    }

    inline adStatus_t its_risk(const float& s,
                               const float& d,
                               const float& heading,
                               const float& longi_safe_dist,
                               const float& lat_safe_dist,
                               const float& after_time,
                               int* in_free_space) {
        uint32_t t_index =
            static_cast<uint32_t>(after_time / time_layer_width_);
        if (t_index >= num_time_layers_) {
            *in_free_space = 0;
            return AD_SUCCESS;
        }
        *in_free_space = 0;
        std::vector<std::pair<uint32_t, uint32_t>> sd_indice;
        GetVehicleRegion(s, d, heading, longi_safe_dist, lat_safe_dist,
                         &sd_indice);
        for (const auto& sd_index : sd_indice) {
            uint32_t index = t_index * slice_size_ +
                             sd_index.first * num_d_grid_ + sd_index.second;
            if (cells_3d_.IsOccupied(index) == true) {
                *in_free_space += risk_occupied_;
            }
        }
        return AD_SUCCESS;
    }

    adStatus_t BuildMapFromVector(const std::vector<std::vector<int>>& vectors);

 protected:
    int debug_print_ = 1;
    uint32_t num_time_layers_ = 41;
    float32_t time_layer_width_ = 0.2;
    // TODO(congq): variable width

    uint32_t num_d_grid_ = 31;
    float32_t d_per_grid_ = 0.3;
    // TODO(congq): variable width

    uint32_t num_s_front_grid_ = 81;
    float s_per_front_grid_ = 1.0;

    int slice_size_ = 0;
    int cell_size_ = 0;

    int risk_occupied_ = 10;
    int predmap_as_free_ = 10;
    int predmap_using_ellipse_ = 0;
    int extend_pred_res_to_end_ = 0;
    ObjectTrajectory object_trajectory_;
    PredictionResult prediction_result_;
    PredictionObjectArray poa_;
    ObstacleScreen obs_screen;

    uint64_t obj_type_ = 1;
    Cell3d<decltype(obj_type_)> cells_3d_;

    std::map<int, uint32_t> id_to_index_;
    // flag of lane changing, including BPP lane changing
    bool lane_change_activated_ = false;
    std::shared_ptr<FrenetCoordinateSystem> frenet_system_;

 protected:
    /**
     * @brief convert time_index, s_index and d_index to index of 1-d array
     * @param time_index[in] index of time
     * @param s_index[in] index of s
     * @param d_index[in] index of d
     * @return index of 1-d array
     **/
    uint32_t TripleToOne(const uint32_t time_index,
                         const uint32_t s_index,
                         const uint32_t d_index) const;

    /**
     * @brief convert index of 1-d array to time_index, s_index and d_index
     * @param indx[in] index of 1-d array
     * @param time_index[out] index of time
     * @param s_index[out] index of s
     * @param d_index[out] index of d
     * @return status of conversion
     **/
    bool OneToTriple(const uint32_t index,
                     uint32_t* time_index,
                     uint32_t* s_index,
                     uint32_t* d_index) const;

    /**
     * @brief claculate coordinates of polygon after move
     * @param polygon[in] cart coords of polygon
     * @param move_vec[in] vector of moving
     * @param rotate_angle[in] angle of rotation
     * @param polygon_new[out] coordinates of polygon after move
     * @return status of conversion
     **/
    bool MovePolygon(const std::vector<cv::Point2f>& polygon,
                     const cv::Point2f& move_vec,
                     const float rotate_angle,
                     std::vector<cv::Point2f>* polygon_new);

    /**
     * @brief claculate Frenet coords
     * @param polygon[in] cart coords of polygon
     * @param center[in] center coords of polygon
     * @param polygon_new[out] coordinates in frenet
     * @return status of conversion
     **/
    bool CalculateFrenet(const std::vector<cv::Point2f>& polygon,
                         const cv::Point2f& center,
                         std::vector<cv::Point2f>* polygon_new);

    /**
     * @brief determine the obstacle is static
     * @param tjp_array[in] prediction trajectory array of obstacle
     * @return true if the obstacle is static
     **/
    bool IsStatic(const std::vector<PredictionTrajectoryPoint>& tjp_array);

    /**
     * @brief find SD region of given polygon with frenet coords
     * @param sd_indice[out] corresponding sd region
     * @return status
     **/
    adStatus_t FindSDRegion(const std::vector<cv::Point2f>& polygon_sd,
                            std::set<std::pair<uint32_t, uint32_t>>* sd_indice);

    /**
     * @brief determine if an obstacle trajectory can be ignored
     *
     * @param tjp_array is predict trajectory of an obstacle
     *
     * @return true if this obstacle can be ignored
     */
    bool IsIgnore(
        const std::vector<PredictionTrajectoryPoint>& tjp_array) const;
};

}  // namespace pp
}  // namespace senseAD

