/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * QiuCong <qiucong@sensetime.com>
 * ZhuYuzhang <zhuyuzhang@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cstdlib>
#include <limits>
#include <cmath>
#include <chrono>    // NOLINT
#include "cvaux.h"   // NOLINT
#include "cxcore.h"  // NOLINT
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/planner_core.hpp"
#include "path_planning/baseplanner.hpp"

namespace senseAD {
namespace pp {

enum Behavior { FOLLOW, MERGE, STOP, KEEP_SPEED };

enum LonCase { LOWSPEED, CRUISE };

typedef struct StructFrenetPath {
    bool Stop;
    int free = 0;
    float32_t cost = 0.0f;
    float32_t T;

    Behavior behavior;
    LonCase lon_case;

    std::vector<cv::Point2f> points;
    std::vector<float32_t> velocity;
    std::vector<float32_t> acceleration;
    std::vector<float32_t> yaw;  // theta
    std::vector<float32_t> curvature;

    int32_t lat_id;
    int32_t lon_id;

} FrenetPath;

adStatus_t CalculateCurvature(const cv::Point2f& pt1,
                              const cv::Point2f& pt2,
                              const cv::Point2f& pt3,
                              float32_t* curvature);

adStatus_t CalculateYaw(const cv::Point2f& pt1,
                        const cv::Point2f& pt2,
                        float* yaw);

adStatus_t ThreePointAvg(const cv::Point2f& pt1,
                         cv::Point2f* pt2,
                         const cv::Point2f& pt3);

///  @brief Solves quintic polynomial
///  @param cur_position        f(0)
///  @param curr_velocity       f'(0)
///  @param curr_accleration    f''(0)
///  @param target_position     f(T)
///  @param target_velocity     f'(T)
///  @param target_accleration  f''(T)
///  @param T                   T
///  @param a(0~5)              coefficients
void SolveQuinticPoly(float32_t cur_position,
                      float32_t cur_velocity,
                      float32_t cur_acceleration,
                      float32_t target_position,
                      float32_t target_velocity,
                      float32_t target_acceleration,
                      float32_t T,
                      float32_t* a0,
                      float32_t* a1,
                      float32_t* a2,
                      float32_t* a3,
                      float32_t* a4,
                      float32_t* a5);

///  @brief Solves quartic polynomial
///  @param cur_position        f(0)
///  @param curr_velocity       f'(0)
///  @param curr_accleration    f''(0)
///  @param target_velocity     f'(T)
///  @param target_accleration  f''(T)
///  @param T                   T
///  @param a(0~4)              coefficients

void SolveQuarticPoly(float32_t cur_position,
                      float32_t cur_velocity,
                      float32_t cur_acceleration,
                      float32_t target_velocity,
                      float32_t target_acceleration,
                      float32_t T,
                      float32_t* a0,
                      float32_t* a1,
                      float32_t* a2,
                      float32_t* a3,
                      float32_t* a4);

class SENSEAD_API LatticeCore : public PlannerCore {
 public:
    LatticeCore();
    ~LatticeCore();
    adStatus_t Plan(std::vector<TrajectoryPoint>* out_path);
    adStatus_t Init();
    typedef std::function<adStatus_t(float s,
                                     float d,
                                     float heading,
                                     float t,
                                     float longi_safe_dist,
                                     float lat_safe_dist,
                                     bool* pass_check)>
        func_bool_frenet_collisioncheck_predict_t;

    typedef std::function<adStatus_t(float s,
                                     float d,
                                     float heading,
                                     float t,
                                     float longi_safe_dist,
                                     float lat_safe_dist,
                                     int* pass_check)>
        func_int_frenet_risk_t;
    typedef std::function<adStatus_t(TrajectoryPoint* point)>
        func_warp_trajpoint_frame_t;

    void RegisterFrenetCollisionPlug(
        func_bool_frenet_collisioncheck_predict_t fun_collision) {
        func_bool_frenet_collisioncheck_predict = fun_collision;
    }

    void RegisterFrenetRiskPlug(func_int_frenet_risk_t fun_risk) {
        func_int_frenet_risk = fun_risk;
    }

    // for agentmode only;
    void SetAgentState(VehicleState vs_) { active_vehicle_state_ = vs_; }

    void SetAgentModeOn() { agent_mode_ = 1; }
    adStatus_t FrenetToCartesian(const float& s,
                                 const float& ds,
                                 const float& dds,
                                 const float& d,
                                 const float& dd,
                                 const float& ddd,
                                 const std::vector<TrajectoryPoint>& ref_path,
                                 TrajectoryPoint* result_pt);

    adStatus_t CartesianToFrenet(const TrajectoryPoint& pt,
                                 const std::vector<TrajectoryPoint>& ref_path,
                                 float* s,
                                 float* ds,
                                 float* dds,
                                 float* d,
                                 float* dd,
                                 float* ddd);
    adStatus_t SetNNToolData(const Trajectory& data) {
        nn_tool_.UpdateData(data);
        return AD_SUCCESS;
    }

 private:
    func_bool_frenet_collisioncheck_predict_t
        func_bool_frenet_collisioncheck_predict;
    func_int_frenet_risk_t func_int_frenet_risk;

    Trajectory out_path_;

    std::vector<polynomial<double>> lat_paths;
    std::vector<polynomial<double>> lon_paths;

    std::vector<float32_t> lat_j_cost;
    std::vector<float32_t> lon_j_cost;
    std::vector<float32_t> lat_T_cost;
    std::vector<float32_t> lon_T_cost;
    std::vector<float32_t> lat_d_cost;
    std::vector<float32_t> lon_s_cost;
    std::vector<float32_t> lon_s_prime_cost;

    float32_t curr_lon_speed;
    float32_t curr_lat_speed;
    float32_t curr_lat_acce;
    float32_t curr_lon_acce;
    float32_t curr_lon_position;
    float32_t curr_lat_position;

    float32_t goal_s, goal_ds, goal_dds, goal_d, goal_dd, goal_ddd;
    // setting
    float32_t SAMPLE_DISTANCE = 0.2;  // less zero means sampling based on time
    float32_t extend_len_ = 30.0;
    int longitude_acc_on_ = 1;
    int lateral_acc_on_ = 0;
    int lateral_velocity_on_ = 1;
    int search_velocity_ = 0;
    int use_prediction_ = 0;
    int predmap_as_free_ = 0;
    int warp_time_ = 1;

    int output_by_time_ = 0;

    Behavior curr_behavior = Behavior::STOP;
    LonCase curr_lon_case = LonCase::LOWSPEED;

    float32_t insert_distance_ = 0.2;

    // if agent mode == 1, use the external vehicle state, and custom collision
    // check
    int32_t agent_mode_ = 0;

    VehicleState active_vehicle_state_;

    // param
    float32_t MIN_STEERING_RADIUS_ = 6.0;  // [m]
    float32_t CarWeight_ = 1800;           // kg
    float32_t MaxPower_ = 88000;           // w
    float32_t PLAN_T_INTERVAL_ = 0.2;      // time tick [s]
    float32_t SAMPLE_T_INTERVAL_ = 0.2;    // [s]
    float32_t MAX_TIME_ = 8.0;             // max prediction time [m]
    float32_t MIN_TIME_ = 3.0;             // min prediction time [m]
    float32_t SAMPLE_ROAD_INTERVAL_ = 1;   // road width sampling length [m]
    float32_t MAX_ROAD_WIDTH_ = 5;         // maximum road width [m]
    // cost weights
    float32_t K_OFFSET = 1.0;
    float32_t K_LAT_JERK = 0.1;
    float32_t K_LON_JERK = 0.5;
    float32_t K_ACCE = 1.5;
    float32_t K_TARGET = 1.0;
    float32_t K_DISTANCE = 10;
    float32_t K_SPEED = 5.0;

    float32_t k_lat = 1.0;
    float32_t k_lon = 10.0;

    float32_t k_j_lat = 1.0;
    float32_t k_j_lon = 1.0;
    float32_t k_T_lat = 1.0;
    float32_t k_T_lon = 10.0;
    float32_t k_d2_lat = 1.0;
    float32_t k_s2_lon = 10.0;
    float32_t k_s_prime_lon = 10.0;

    // tamed by dm
    int32_t tamed_ = 1;
    // drive like you stole the car
    int32_t unleashed_ = 0;

    float32_t low_speed_threshold_ = 3;

    float32_t t_search_range_up_ = 0.0;
    float32_t t_search_range_low_ = 0.0;
    float32_t t_search_range_step_ = 0.0;
    float32_t width_search_range_up_ = 0.0;
    float32_t width_search_range_low_ = 0.0;
    float32_t width_search_range_step_ = 0.0;
    float32_t v_search_range_up_ = 0.0;
    float32_t v_search_range_low_ = 0.0;
    float32_t v_search_range_step_ = 0.0;
    float32_t s_search_range_up_ = 0.0;
    float32_t s_search_range_low_ = 0.0;
    float32_t s_search_range_step_ = 0.0;

    std::vector<FrenetPath> frenet_paths_;
    float32_t low_target_v_;

    float32_t ref_line_interval_ = 1.0;
    int32_t curr_index_ = 0;
    adStatus_t MatchPoint(cv::Point2f pt, int32_t* curr_index);

    adStatus_t ConfigureMode();
    adStatus_t MatchCurrentFrenetStatus();
    adStatus_t CalculateFrenetPaths(float32_t curr_speed,
                                    float32_t curr_lat_position,
                                    float32_t curr_lat_speed,
                                    float32_t curr_lat_acce,
                                    float32_t curr_course_position,
                                    float32_t curr_course_acce);

    adStatus_t CheckPath();

    adStatus_t SampleByTime();
    adStatus_t SampleByDistance();
    adStatus_t FillTimeStamp(Trajectory* path);

    float32_t AnticipateVelocity(Trajectory& path);

    NNTool nn_tool_;
};

}  // namespace pp
}  // namespace senseAD

