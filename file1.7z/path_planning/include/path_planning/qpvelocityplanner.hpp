/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cstdlib>
#include <opencv2/opencv.hpp>
#include "qpOASES.hpp"
#include "eigen3/Eigen/Core"
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/velocityplanner.hpp"
#include "path_planning/util.hpp"

namespace senseAD {
namespace pp {

class QPVelocityPlanner : public VelocityPlanner {
 public:
    adStatus_t PlanVelocity(std::vector<TrajectoryPoint> *path_to_plan);
    adStatus_t Init() {
        VelocityPlanner::Init();
        auto conf = g_pp_conf["rrt_setting"];
        speed_eps_ = conf["rvp_speed_eps"];
        accel_jerk_ = conf["rvp_accel_jerk"];
        accel_max_ = conf["rvp_accel_max"];
        thres_keep_distance_ = conf["rvp_thres_keep_distance"];
        num_seg_ = conf["qpp_num_seg"];
        t_sample_ = conf["qpp_t_sample"];
        t_larger_eps_ = conf["qpp_t_larger_eps"];
        cont_weight_ = conf["qpp_cont_weight"];
        ineq_weight_ = conf["qpp_ineq_weight"];
        img_threshold_ = conf["qpp_img_threshold"];
        regularize_eps_ = conf["qpp_regularize_eps"];
        minacc_est_ = conf["qpp_minest_acc"];
        dist_minus_eps_ = conf["qpp_dist_minus_eps"];

        lower_leeway_ = conf["lower_leeway"];
        upper_leeway_ = conf["upper_leeway"];
        acc_up_leeway_ = conf["acc_up_leeway"];

        acc_decay_v_thres_ = conf["acc_decay_v_thres"];
        acc_decay_v_diff_thres_ = conf["acc_decay_v_diff_thres"];
        acc_decay_v_diff_end_ = conf["acc_decay_v_diff_end"];
        acc_decay_min_ = conf["acc_deacy_min"];
        return AD_SUCCESS;
    }

 protected:
    float speed_eps_ = 0.27f;
    float accel_jerk_ = 0.9f;
    float accel_max_ = 2.0f;
    float thres_keep_distance_ = 2.0f;
    float t_larger_eps_ = 0.1f;
    float cont_weight_ = 30.0f;
    float ineq_weight_ = 30.0f;
    float img_threshold_ = 0.001f;
    int num_seg_ = 5;
    int t_sample_ = 20;
    float regularize_eps_ = 0.01f;
    float minacc_est_ = 1.0f;
    float dist_minus_eps_ = 0.1f;
    // degree is not changeable
    const int degree_ = 5;

    float32_t acc_decay_v_thres_ = 4.0f;
    float32_t acc_decay_v_diff_thres_ = 3.0f;
    float32_t acc_decay_v_diff_end_ = 0.3f;
    float32_t acc_decay_min_ = 0.1;

    float32_t upper_leeway_ = 0.1;
    float32_t lower_leeway_ = -0.1;
    float32_t acc_up_leeway_ = 0.01;

    uint32_t creep_to_target_first_ = 1;
    float32_t creep_velocity_threshold_ = 2.0;
    float32_t creep_distance_ = 0.0;

    // return time parameters
    inline Eigen::RowVectorXd ti(double t) {
        Eigen::RowVectorXd vec(degree_);
        vec << 0, t, t * t, pow(t, 3), pow(t, 4);
        return vec;
    }

    inline Eigen::RowVectorXd dti(double t) {
        Eigen::RowVectorXd vec(degree_);
        vec << 0, 1, 2 * t, 3 * t * t, 4 * pow(t, 3);
        return vec;
    }

    inline Eigen::RowVectorXd ddti(double t) {
        Eigen::RowVectorXd vec(degree_);
        vec << 0, 0, 2, 6 * t, 12 * t * t;
        return vec;
    }

    inline Eigen::RowVectorXd dddti(double t) {
        Eigen::RowVectorXd vec(degree_);
        vec << 0, 0, 0, 6, 24 * t;
        return vec;
    }

    // solve equation a+b*t+c*t^2+d*t^3+e*t^4 = s
    // return the real value that is closest to t_est
    inline double solveT(double a,
                         double b,
                         double c,
                         double d,
                         double e,
                         double s,
                         double t_est) {
        std::complex<double> result[4];
        double ans = -1.5;
        if (std::abs(e) > 1e-4) {
            utils::solve_quartic(result, d / e, c / e, b / e, (a - s) / e);
            {
                std::stringstream ss;
                for (int i = 0; i < 4; i++) {
                    if (i != 0) {
                        ss << ",";
                    }
                    ss << (result[i]);
                }
                AD_LDEBUG(PATH_PLANNING) << "[" << d / e << ", " << c / e
                                         << ", " << b / e << ", " << (a - s) / e
                                         << "], Got Solutions " << ss.str();
            }
            for (int i = 0; i < 4; i++) {
                if (std::abs(result[i].imag()) < img_threshold_ &&
                    (result[i].real() >= t_est - t_larger_eps_ &&
                     (ans < -1 ||
                      std::abs(result[i] - t_est) < std::abs(ans - t_est)))) {
                    ans = result[i].real();
                }
            }
        } else {
            AD_LDEBUG(PATH_PLANNING) << "e is zero, use SolveCubic instead";
            // e is zero
            std::vector<float> result_cubic;
            utils::SolveCubic(d, c, b, a - s, &result_cubic);
            if (result_cubic.size() == 0) {
                return -1;
            }
            for (size_t i = 0; i < result_cubic.size(); i++) {
                if (result_cubic[i] >= t_est - t_larger_eps_ &&
                    (ans < -1 ||
                     std::abs(result_cubic[i] - t_est) <
                         std::abs(ans - t_est))) {
                    ans = result_cubic[i];
                }
            }
        }
        return ans;
    }

    Eigen::MatrixXd generateH(double t_int);
    std::vector<Eigen::MatrixXd> generateEq(double s_tgt,
                                            double v_0,
                                            double a_0,
                                            double v_tgt,
                                            double a_tgt,
                                            double t_est);
    std::vector<Eigen::MatrixXd> generateUEq(double v_0,
                                             double v_tgt,
                                             double t_int);
    void CalulateCoefficients(double s_tgt,
                              double v_0,
                              double a_0,
                              double v_tgt,
                              double a_tgt,
                              std::vector<double> *coeffs,
                              double *t_est_out);
    void FallBackVelocityProfile(std::vector<TrajectoryPoint> *path_to_plan);
    void ApplyQPVelocityProfile(std::vector<TrajectoryPoint> *path_to_plan,
                                const std::vector<double> &coeffs,
                                double t_est,
                                float32_t creep_distance);
    bool PassFinalCheck(const Trajectory &path_planned) const;
};

}  // namespace pp
}  // namespace senseAD

