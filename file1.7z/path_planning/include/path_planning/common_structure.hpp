/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <vector>
#include <algorithm>
#include <limits>
#include <cereal/archives/json.hpp>
#include "common/data_type/vehicle_param.hpp"
#include "common/utils/configuration_reader.hpp"

namespace senseAD {
namespace pp {

typedef enum {
    INVALID_PURPOSE = -1,
    KEEP_UP_NON_ZERO_VELOCITY = 0,
    STOP_AT_GIVEN_POINT = 1,
    EMERGE_STOP = 2,
    REMAIN_TILL_CACHE_GOAL = 3,
    FOLLOW_AT_GIVEN_POINT = 4,
    STOP_AT_STOPLINE = 5,
    USE_DM_S = 6
} VPPurpose;

typedef enum {
    RECYCLE = 0,
    PATH_SPEED_REPLAN = 1,
    SPEED_REPLAN = 2,
    PATH_REPLAN = 3
} ReplanFlag;

typedef enum { LANE_KEEPING = 0, LANE_CHANGE = 1 } PlanningScenario;

typedef enum { IGNORE = 0, YEILD = 1, SURPASS = 2 } Tag;

typedef enum {
    NO_CHANGE = 0,
    CHANGE_LEFT = 1,
    CHANGE_RIGHT = 2
} ChangeDirection;

class VehicleState {
 public:
    double velocity;           // m/s
    double acceleration;       // m/s^2
    double front_wheel_angle;  // m
    double x;                  // m
    double y;                  // m
    double heading;            // radian
    double yaw_rate;           // radian/s
    double curvature;          //
    double last_pos_x;
    double last_pos_y;
    double delta_s;
};

extern VehicleState g_vehicle_state;

extern VehicleParam g_vehicle_param;

struct BVPStage {
    // --type--
    // 0.
    // 1. const acc
    // 2. acc up
    // 3. acc down
    int type;
    // s_v: start velocity
    float s_v;
    // e_v: end velocity
    float e_v;
    // s_a: start acceleration
    float s_a;
    // e_a: end acceleration
    float e_a;
    // d_f_s: stage start distance from start point
    float d_f_s;
    // jerk;
    float j;
    bool operator<(const BVPStage& t) const {
        if (d_f_s < t.d_f_s) return true;
        return false;
    }
};

template <class T>
class polynomial {
 public:
    typedef typename std::vector<T>::value_type value_type;
    typedef typename std::vector<T>::size_type size_type;

    // Default constructor
    polynomial() {}
    // Construct from list of coefficents

    polynomial(std::initializer_list<T> l) : data_(l) {}
    explicit polynomial(std::vector<T> l) : data_(l) {}

    size_type degree() const { return data_.size(); }
    value_type& operator[](size_type i) { return data_[i]; }
    const value_type& operator[](size_type i) const;
    std::vector<T>& data() { return data_; }

    polynomial(const polynomial<T>& poly) : data_(poly.data_) {}

    template <class U>
    U operator()(const U& value) {
        auto tmp_pow = U(1);
        U result = U(0);
        for (size_t i = 0; i < data_.size(); i++) {
            result += tmp_pow * U(data_[i]);
            tmp_pow = tmp_pow * value;
        }
        return result;
    }

    polynomial<T>& operator=(const polynomial<T>& poly) {
        this->data_ = poly.data_;
        return *this;
    }

    std::vector<T> const& data() const { return data_; }

    polynomial differential() {
        std::vector<T> data2_;
        if (data_.size() > 1) {
            for (size_t i = 1; i < data_.size(); i++) {
                data2_.push_back(data_[i] * T(i));
            }
        } else {
            data2_.push_back(T(0));
        }
        auto result = polynomial(data2_);
        return result;
    }
    polynomial integral(const T& constant) {
        std::vector<T> data2_;
        data2_.push_back(constant);
        for (size_t i = 0; i < data_.size(); i++) {
            data2_.push_back(data_[i] / (T(i) + T(1.0)));
        }
        auto result = polynomial(data2_);
        return result;
    }

 private:
    // index of
    std::vector<T> data_;
};

template <class T>
polynomial<T> operator+(const polynomial<T>& a, const polynomial<T>& b) {
    auto data_size = std::max(a.data().size(), b.data().size());
    std::vector<T> data_plus_(data_size, T(0));
    for (auto i = 0; i < data_size; i++) {
        data_plus_[i] = (i < a.data().size() ? a.data()[i] : T(0)) +
                        (i < b.data().size() ? b.data()[i] : T(0));
    }
    // TODO(congq): Find 0.0001 somewhere
    while (data_plus_.size() > 0 && std::abs(data_plus_.back()) < 0.000001) {
        data_plus_.pop_back();
    }

    if (data_plus_.size() == 0) {
        data_plus_.push_back(T(0));
    }

    auto result = polynomial<T>(data_plus_);
    return result;
}

template <class T>
polynomial<T> operator-(const polynomial<T>& a, const polynomial<T>& b) {
    auto data_size = std::max(a.data().size(), b.data().size());
    std::vector<T> data_plus_(data_size, T(0));
    for (auto i = 0; i < data_size; i++) {
        data_plus_[i] = (i < a.data().size() ? a.data()[i] : T(0)) -
                        (i < b.data().size() ? b.data()[i] : T(0));
    }
    // TODO(congq): Find 0.0001 somewhere
    while (data_plus_.size() > 0 && std::abs(data_plus_.back()) < 0.000001) {
        data_plus_.pop_back();
    }

    if (data_plus_.size() == 0) {
        data_plus_.push_back(T(0));
    }

    auto result = polynomial<T>(data_plus_);
    return result;
}

template <class T>
polynomial<T> operator*(const polynomial<T>& a, const polynomial<T>& b) {
    auto data_size = a.data().size() - 1 + b.data().size() - 1 + 1;
    std::vector<T> data_mul_(data_size, T(0));

    for (size_t i = 0; i < a.data().size(); i++) {
        for (size_t j = 0; j < b.data().size(); j++) {
            data_mul_[i + j] += a.data()[i] * b.data()[j];
        }
    }

    while (data_mul_.size() > 0 && std::abs(data_mul_.back()) < 0.000001) {
        data_mul_.pop_back();
    }

    if (data_mul_.size() == 0) {
        data_mul_.push_back(T(0));
    }
    auto result = polynomial<T>(data_mul_);
    return result;
}

template <class charT, class traits, class T>
std::basic_ostream<charT, traits>& operator<<(
    std::basic_ostream<charT, traits>& os, const polynomial<T>& poly) {
    for (typename polynomial<T>::size_type i = 0; i < poly.data().size() - 1;
         i++) {
        auto j = poly.data().size() - i - 1;
        os << poly.data()[j] << " * x^" << j << " + ";
    }
    if (poly.data().size() > 0) {
        os << poly.data().front();
    }
    return os;
}

class STPoint {
 public:
    STPoint(const double s, const double t) : s_(s), t_(t) {}

    STPoint() {}

    void SetPrePoint(const STPoint& st_point) { pre_point_ = &st_point; }

    void SetCost(const double cost) { cost_ = cost; }

    const STPoint* pre_point() const { return pre_point_; }

    void SetS(const double s) { s_ = s; }

    void SetT(const double t) { t_ = t; }

    const double s() const { return s_; }

    const double t() const { return t_; }

    const double cost() const { return cost_; }

    // serialization
    template <class Archive>
    void serialize(Archive& archive) const {  // NOLINT
        archive(
            cereal::make_nvp("s", s_), cereal::make_nvp("t", t_),
            cereal::make_nvp("cost", cost_),
            cereal::make_nvp("pre_s",
                             pre_point_ != nullptr ? pre_point_->s() : -1000.0),
            cereal::make_nvp(
                "pre_t", pre_point_ != nullptr ? pre_point_->t() : -1000.0));
    }

 private:
    double s_ = 0.0;
    double t_ = 0.0;
    double cost_ = std::numeric_limits<double>::infinity();
    const STPoint* pre_point_ = nullptr;
};

constexpr double kMax = std::numeric_limits<double>::max();
constexpr double kMin = -1 * kMax;

template <typename T>
class SBound {
 public:
    const double s_min() const { return s_min_; }

    const double s_max() const { return s_max_; }

    const double v_min() const { return v_min_; }

    const double v_max() const { return v_max_; }

    void SetSMin(const double s_min) { s_min_ = s_min; }

    void SetSMax(const double s_max) { s_max_ = s_max; }

    void SetVMin(const double v_min) { v_min_ = v_min; }

    void SetVMax(const double v_max) { v_max_ = v_max; }

    void SetObjID(const T& obj_id) { obj_id_ = obj_id_ | obj_id; }

    const T GetObjID() const { return obj_id_; }

    void SetTag(const Tag tag) { tag_ = tag; }

    const Tag GetTag() const { return tag_; }

    // serialization
    template <class Archive>
    void serialize(Archive& archive) const {  // NOLINT
        archive(cereal::make_nvp("s_min", s_min_),
                cereal::make_nvp("s_max", s_max_),
                cereal::make_nvp("v_min", v_min_),
                cereal::make_nvp("v_max", v_max_),
                cereal::make_nvp("obj_id", obj_id_));
    }

 private:
    double s_min_ = kMax;
    double s_max_ = kMin;
    double v_min_ = kMax;
    double v_max_ = kMin;
    T obj_id_ = 0;
    Tag tag_ = Tag::IGNORE;
};

class QPConfig {
 public:
    QPConfig() {}

    QPConfig(const double lower_limit,
             const double upper_limit,
             const double lower_first_deriv_limit,
             const double upper_first_deriv_limit,
             const double lower_second_deriv_limit,
             const double upper_second_deriv_limit,
             const double lower_third_deriv_limit,
             const double upper_third_deriv_limit,
             const double w_ref,
             const double w_first_order,
             const double w_second_order,
             const double w_third_order,
             const double w_start,
             const double decay_rate)
        : lower_limit_(lower_limit),
          upper_limit_(upper_limit),
          lower_first_deriv_limit_(lower_first_deriv_limit),
          upper_first_deriv_limit_(upper_first_deriv_limit),
          lower_second_deriv_limit_(lower_second_deriv_limit),
          upper_second_deriv_limit_(upper_second_deriv_limit),
          lower_third_deriv_limit_(lower_third_deriv_limit),
          upper_third_deriv_limit_(upper_third_deriv_limit),
          w_ref_(w_ref),
          w_first_order_(w_first_order),
          w_second_order_(w_second_order),
          w_third_order_(w_third_order),
          w_start_(w_start),
          decay_rate_(decay_rate) {}

    QPConfig& operator=(const QPConfig& rhs) {
        if (this != &rhs) {
            lower_limit_ = rhs.lower_limit();
            upper_limit_ = rhs.upper_limit();
            lower_first_deriv_limit_ = rhs.lower_first_deriv_limit();
            upper_first_deriv_limit_ = rhs.upper_first_deriv_limit();
            lower_second_deriv_limit_ = rhs.lower_second_deriv_limit();
            upper_second_deriv_limit_ = rhs.upper_second_deriv_limit();
            lower_third_deriv_limit_ = rhs.lower_third_deriv_limit();
            upper_third_deriv_limit_ = rhs.upper_third_deriv_limit();
            w_ref_ = rhs.w_ref();
            w_first_order_ = rhs.w_first_order();
            w_second_order_ = rhs.w_second_order();
            w_third_order_ = rhs.w_third_order();
            w_start_ = rhs.w_start();
            decay_rate_ = rhs.decay_rate();
        }
        return *this;
    }

    const double lower_limit() const { return lower_limit_; }

    const double upper_limit() const { return upper_limit_; }

    const double lower_first_deriv_limit() const {
        return lower_first_deriv_limit_;
    }

    const double upper_first_deriv_limit() const {
        return upper_first_deriv_limit_;
    }

    const double lower_second_deriv_limit() const {
        return lower_second_deriv_limit_;
    }

    const double upper_second_deriv_limit() const {
        return upper_second_deriv_limit_;
    }

    const double lower_third_deriv_limit() const {
        return lower_third_deriv_limit_;
    }

    const double upper_third_deriv_limit() const {
        return upper_third_deriv_limit_;
    }

    const double w_ref() const { return w_ref_; }

    const double w_first_order() const { return w_first_order_; }

    const double w_second_order() const { return w_second_order_; }

    const double w_third_order() const { return w_third_order_; }

    const double w_start() const { return w_start_; }

    const double decay_rate() const { return decay_rate_; }

 private:
    double lower_limit_ = 0.0;
    double upper_limit_ = 0.0;
    double lower_first_deriv_limit_ = 0.0;
    double upper_first_deriv_limit_ = 0.0;
    double lower_second_deriv_limit_ = 0.0;
    double upper_second_deriv_limit_ = 0.0;
    double lower_third_deriv_limit_ = 0.0;
    double upper_third_deriv_limit_ = 0.0;
    double w_ref_ = 0.0;
    double w_first_order_ = 0.0;
    double w_second_order_ = 0.0;
    double w_third_order_ = 0.0;
    double w_start_ = 0.0;
    double decay_rate_ = 0.0;
};

}  // namespace pp
}  // namespace senseAD
