/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * zhuhaibo <zhuhaibo@sensetime.com>
 */

#pragma once

#include <string>
#include <vector>
#include <memory>
#include <limits>
#include "common/error.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/dm_target.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/vehicle_param.hpp"
#include "common/data_type/vehicle_info.hpp"
#include "common/data_type/road_structure.hpp"
#include "common/data_type/object_recovery.hpp"

namespace senseAD {
namespace pp {

struct PPEvaluationResult {
    std::string results_save_file_path;
    int32_t total_frames = 0;

    float32_t max_time_cost = 0.0;
    float32_t min_time_cost = std::numeric_limits<float32_t>::max();
    float32_t max_centripetal_acc = 0.0;
    float32_t min_min_dist_ped = 0.0;
    float32_t min_min_dist_veh_lon = 0.0;
    float32_t min_min_dist_veh_lat = 0.0;

    int32_t total_F1 = 0;
    int32_t total_F2 = 0;
    int32_t total_F3 = 0;
    int32_t total_C1 = 0;
    int32_t total_C2 = 0;
    int32_t total_C3 = 0;
};

class SENSEAD_API PPEvaluation {
 public:
    PPEvaluation() {}
    ~PPEvaluation() {}
    adStatus_t Init(const std::string &estimator_config_file,
                    const std::string &results_save_directory,
                    const std::string &results_save_pattern_name,
                    const std::string &testcase_id);
    adStatus_t Process(const std::vector<senseAD::TrajectoryPoint> &trajectory,
                       const senseAD::SingleFrameObjRecovery &sr_result,
                       const float64_t &stamp);

 private:
    int32_t total_frames_ = 0;
    int32_t total_F1_ = 0;
    int32_t total_F2_ = 0;
    int32_t total_F3_ = 0;
    int32_t total_C1_ = 0;
    int32_t total_C2_ = 0;
    int32_t total_C3_ = 0;
    // the unit of time is second [s]
    float32_t max_time_cost_ = 0.0;
    float32_t min_time_cost_ = std::numeric_limits<float32_t>::max();
    float32_t max_centripetal_acc_ = 0.0;
    float32_t min_min_dist_ped_ = std::numeric_limits<float32_t>::max();
    float32_t min_min_dist_veh_lon_ = std::numeric_limits<float32_t>::max();
    float32_t min_min_dist_veh_lat_ = std::numeric_limits<float32_t>::max();

    float32_t kCarWeight;       // kg
    float32_t kMaxPower;        // W
    float32_t kLincolnLength;   // mm
    float32_t kLincolnWidth;    // mm
    float32_t kAngleThreshold;  // radius, is calculated
    float32_t kBrakeDistance;   // m
    float32_t kMinRadius;       // m
    int32_t kUsefulSize;

    // the meanings of indexs below can be found in the slides
    // http://jira.sensetime.com/browse/SENSEFORCE-6
    // default value
    float32_t t_f1_ = 1 / 6.0;
    float32_t t_f3_ = 1.0 * 100 * 100 / (2 * 38 * 3.6 * 3.6);
    float32_t t_c1_ = 2;
    float32_t t_c2_ = 0.9;
    float32_t t_c3_ = 1;

    std::string output_file_path_;
};

}  // namespace pp
}  // namespace senseAD

