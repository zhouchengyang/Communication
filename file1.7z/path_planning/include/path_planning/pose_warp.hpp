/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Liang Yu <liangyu@sensetime.com>
 */

#pragma once

#include <memory>
#include <map>
#include <string>

#include <opencv2/opencv.hpp>

#include "eigen3/Eigen/Core"
#include "eigen3/Eigen/Geometry"

#include "common/error.hpp"
#include "common/data_type/car_trajectory.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/vehicle_info.hpp"
#include "common/data_type/localization_info.hpp"
#include "path_planning/common_structure.hpp"

namespace senseAD {
namespace pp {

class PoseWarp {
 public:
    PoseWarp() {}

    ~PoseWarp() {}

    adStatus_t SetVehicleInfo(const VehicleInfo& vehicle_info);

    adStatus_t WarpPoint(cv::Point2f* point);

 private:
    int64_t last_timestamp_ = 0;
    double delta_x_m_ = 0.0;
    double delta_y_m_ = 0.0;
    double delta_heading_ = 0.0;

    float warped_delta_x_m_ = 0.0;
    float warped_delta_y_m_ = 0.0;

    float curr_acc_m_per_s2_ = 0;
    float curr_velocity_m_per_s_ = 0;
    float curr_yaw_rate_rad_per_s_ = 0;
    float last_valid_velocity_m_per_s_ = 0;
    float last_valid_acc_m_per_s2 = 0;
    float last_valid_curvature_ = 0;

    VehicleInfo vehicle_info_;
    std::map<std::string, float> distance_tracker_m_;

    Eigen::Matrix3d matrix_ = Eigen::Matrix3d::Identity();
    senseAD::CarPose last_car_pose_;
    VehicleState vehicle_state_;
};

}  // namespace pp
}  // namespace senseAD
