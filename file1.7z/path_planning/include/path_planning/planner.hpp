/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cstdlib>
#include <chrono>  // NOLINT
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/baseplanner.hpp"
#include "path_planning/rrt_node.hpp"
#include "path_planning/planner_core.hpp"

using senseAD::Boundary;
using senseAD::IntersectionCenter;
using senseAD::LaneLine;

namespace senseAD {
namespace pp {

class SENSEAD_API Planner : public BasePathPlanner {
    // Coordinate system obey the body standard of ROS:
    // (x forward, y left, z up)
    // See this link: http://www.ros.org/reps/rep-0103.html
 public:
    Planner();
    ~Planner();
    adStatus_t Init(const std::string& config);

    /**
     * @brief The outer plan procedure
     * @param out_path to output the result
     * @notes 1. Update scene and can info, let pp_tracker_ update what was
     *tracked
     *              and scene_parser_ parse the latest Decision and Scene
     *        2. scene_parser_ and pp_tracker_ decide whether should replan a
     *new path or not
     *        3. if should replan, call PlanInternal() to replan
     *        4. if should not replan, use the path stored in pp_tracker
     *        5. trajectory_planner_ plan velocity on the path.
     **/
    adStatus_t Plan(std::vector<TrajectoryPoint>* out_path);

 private:
    int traj_smoothing_ = 0;
    float node_frequency_ = 10;
    float replan_per_second_ = 1;
    int recycle_mode_on_laneline_ = 1;
    int recycle_mode_on_ = 1;
    float goal_drift_threshold_ = 1;
    float off_track_tolerance_ = 10;
    float length_discrepance_tolerance_ = 10;
    float max_tjp_diff_tolerance_ = 10;
    float avg_tjp_diff_tolerance_ = 10;
    float insert_distance_ = 0.2;
    int test_old_can_data = 1;
    int bpp_improved_ = 0;
    int use_ref_line_ = 1;
    int switch_steering_input_direction_ = 1;
    float min_path_length_ = 20;
    int replan_timer_ = 0;
    int reclying_flag_ = 0;
    int use_routing_refline_ = 0;
    // track time error threshold, uint : s
    float replan_track_time_threshold_ = 0.5;
    float replan_track_time_threshold_stop_ = 3.0;
    // replan threshold for position error
    float replan_position_threshold_ = 3.0;
    float target_point_replan_threshold_ = 5.0;
    float velocity_plan_distance_ = 0.0;
    VPPurpose vp_purpose_ = VPPurpose::KEEP_UP_NON_ZERO_VELOCITY;

    DMTarget last_dm_target_;
    DMTarget curr_dm_target_;
    cv::Point2f last_target_point_ = cv::Point2f(0.0, 0.0);
    cv::Point2f last_velocity_target_point_ = cv::Point2f(0.0, 0.0);

    TrajectoryPoint single_start_;
    TrajectoryPoint single_goal_;
    TrajectoryPoint closest_point_;

    float cached_path_offset_threshold_ = 0.4;
    int recycle_at_terminal_ = 1;
    int cached_path_check_index_ = 150;

    std::vector<TrajectoryPoint> cached_path_;
    std::vector<TrajectoryPoint> cached_base_path_;
    std::vector<TrajectoryPoint> ref_line_;
    std::vector<TrajectoryPoint> base_path_;

    senseAD::OdometryInfo current_odometry_;
    senseAD::CarPose current_car_pose_;
    uint64_t current_timestamp_ns_;
    int correct_path_ = 0;

    std::shared_ptr<senseAD::pp::PlannerCore> planner_core_ = nullptr;
    /*
     * @brief Gether result from scene_parser_ and pp_tracker_ to check if
     *should replan this time
     * @return flag of replan
     **/
    ReplanFlag ShouldRecycle();

    /*
     * @brief check if path should replan at this time
     * @return false if path need to be replan
     **/
    bool ShouldPathRecycle();

    /*
     * @brief check if speed should replan at this time
     * @return false if speed need to be replan
     **/
    bool ShouldSpeedRecycle() const;

    /*
     * See if the path differed significantly enough the be cached
     */
    void CheckPathRecyclability(const std::vector<TrajectoryPoint>& path);

    adStatus_t UpdateSceneAndTracker();

    adStatus_t TmpUpdateCachedPath();

    /*
     * @brief update cached basepath to current position
     **/
    adStatus_t UpdateCachedBasePath();

    std::vector<std::string> titles;
    std::vector<int> function_called_nums;
    std::vector<std::chrono::nanoseconds> durations;
};

}  // namespace pp
}  // namespace senseAD

