/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Dengke Wan <wandengke@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include <utility>
#include <fstream>
#include <sstream>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/prediction_result.hpp"
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/frenet_coordinate_system.hpp"


namespace senseAD {
namespace pp {

enum class ScreenType{
    IGNORE_OBS,
    IGNORE_TRAJ_POINT,
    NOT_IGNORE
};

class SENSEAD_API ObstacleScreen{
 public:
    /**
     * @brief construct funtion
     **/
    ObstacleScreen();

    /**
     * @brief update state which is needed by ObstacleScreen
     **/
    void Update(const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
      const bool lane_change_activated, const VehicleState & ego_state);

    /**
     * @brief check obstacle PredictionTrajectoryPoint
     **/
    void  SetObstacleState(const PredictionObject &obs_predition);

    /**
     * @brief check obstacle PredictionTrajectoryPoint
     **/
    ScreenType IsIgnore(const PredictionTrajectoryPoint &obs_traj) const;
    
 private:
    /**
    * @brief limit theta (-pi,pi)
    **/
    void limit_theta(double &theta) const;

    std::shared_ptr<FrenetCoordinateSystem> frenet_system_;
    const double consider_range_ = 80.0;
    const double d_consdie_range_ = 40.0;
    const double angle_check_default_ = M_PI / 4.0;
    const double angle_check_lane_change_ = M_PI / 5.0;
    const double vehicle_max_consider_s_ = 60.0 * 8.0 / 3.6;

    bool lane_change_activated_ = false;
    double obs_initial_speed_ = 0.0;
    double obs_length_ = 10.0;
    double obs_width_ = 10.0;
    int obs_id_ = 0;
    double lane_width_ = 3.4;
    VehicleState ego_car_state_;
};
}  // namespace pp
}  // namespace senseAD
