/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/dm_target.hpp"
#include "common/data_type/object_recovery.hpp"
#include "common/data_type/prediction_result.hpp"
#include "common/data_type/vehicle_info.hpp"
#include "common/data_type/road_structure.hpp"
#include "path_planning/gridmap.hpp"
#include "path_planning/predict_map.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/rrt_node.hpp"
#include "path_planning/quinticsplinesmooth.hpp"
#include "path_planning/frenet_coordinate_system.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API SceneParser {
    // Coordinate system obey the body standard of ROS:
    // (x forward, y left, z up)
    // See this link: http://www.ros.org/reps/rep-0103.html
 public:
    SceneParser();
    ~SceneParser();
    adStatus_t Init();

    /**
     * @brief update the source of roadblocks and target
     **/
    adStatus_t Update(senseAD::roadStructure::RoadStructure<cv::Point2f>* rs,
                      ObjectTrajectory* object_trajectory,
                      PredictionResult* prediction_result,
                      std::shared_ptr<FrenetCoordinateSystem> frenet_system,
                      DMTarget* dm_target);

    adStatus_t Update(senseAD::roadStructure::RoadStructure<cv::Point2f>* rs,
                      const PredictionObjectArray& poa,
                      std::shared_ptr<FrenetCoordinateSystem> frenet_system,
                      DMTarget* dm_target);

    adStatus_t SetQSSParam(float rdp_threshold,
                           int cur_sample,
                           float weight_cur_change,
                           float weight_cur,
                           float lr,
                           int iters,
                           int special_init_for_one,
                           float pts_weight,
                           float penalty_weight,
                           float penalty_distance) {
        quintspline_smoother_.SetParam(
            rdp_threshold, cur_sample, weight_cur_change, weight_cur, lr, iters,
            special_init_for_one, pts_weight, penalty_weight, penalty_distance);
        return AD_SUCCESS;
    }

    bool notCollided(const std::vector<TrajectoryPoint>& to_test_path);
    /**
     * @brief Parse the scene for a TrajectoryPoint Goal, update the
     *          current basepath
     **/
    adStatus_t Parse();

    /**
     * @brief Get the goal
     * @param[out] goal a TrajectoryPoint consist of position, direction and
     *velocity
     **/
    adStatus_t GetTrajPointGoal(TrajectoryPoint* goal);

    /**
     * @brief Get Velocity planning purpose
     * @param[out] vp_purpose the purpose
     **/
    adStatus_t GetVPPurpose(VPPurpose* vp_purpose);

    /**
     * @brief Set the cached goal incase sceneparser needs it
     **/
    adStatus_t SetCachedGoal(const TrajectoryPoint& cached_goal);

    adStatus_t SetRoutingRefline(const Trajectory& routing_refline);
    adStatus_t GetRoutingRefline(Trajectory* routing_refline);

    adStatus_t SelectGoalFromRefline(TrajectoryPoint* goal);
    /**
     * @brief Select Goal according to Scene and Target
     * @param[out] goal a TrajectoryPoint
     * @param[out] purpose A velocity planning purpose VPPurpose
     * @param[out] target_velocity mostly dm_velocity, could be zero in
     *emergency
     * @param[out] ifusecachegoal tells planner to use the cached goal as goal
     **/
    adStatus_t SelectGoalPurposeVelocity(TrajectoryPoint* goal,
                                         VPPurpose* purpose,
                                         float* target_velocity,
                                         bool* ifusecachegoal);

    adStatus_t SetRefLineInterval(const float& interval,
                                  const float& ref_line_adding_dist);

    adStatus_t SetRefLineLength(const float& length);

    adStatus_t SetMapParameter(int32_t map_ww,
                               int32_t map_hh,
                               int32_t fix_bonnet_xx,
                               int32_t fix_bonnet_yy,
                               int32_t fix_bonnet_hh,
                               int32_t fix_bonnet_ww,
                               bool if_fix_bonnet,
                               float32_t per_grid_meter,
                               int32_t min_value_as_free,
                               bool if_optimize,
                               float32_t out_as_free,
                               bool if_applybonnetfix_final,
                               float pedestrain_extrasafe_dist,
                               float vehicle_extrasafe_dist);

    adStatus_t is_free(const cv::Point2f& pt, bool* in_free_space);

    adStatus_t is_free_with_time(const TrajectoryPoint& pt,
                                 const float& after_time,
                                 bool* in_free_space);

    adStatus_t sdt_is_free(float s,
                           float d,
                           float heading,
                           float t,
                           float longi_safe_dist,
                           float lat_safe_dist,
                           bool* pass_check);

    adStatus_t sdt_its_risk(float s,
                            float d,
                            float heading,
                            float t,
                            float longi_safe_dist,
                            float lat_safe_dist,
                            int* risk);

    adStatus_t its_risk(const cv::Point2f& pt, char* in_free_space);

    adStatus_t GetBasePath(std::vector<TrajectoryPoint>* base_path);

    adStatus_t GetBPPCollisionIndex(int* first_unusable_bp_index,
                                    int* last_usable_bp_index);

    adStatus_t GenBasePathNEvaluate();
    adStatus_t GenBasePath();

    adStatus_t GetReferenceLine(std::vector<TrajectoryPoint>* ref_line);

    adStatus_t GenImprovedBPP(std::vector<TrajectoryPoint>* base_path);

    adStatus_t GenImprovedBPP();

    /**
     * @brief Select Start Point accordin to cached path
     * @param[in] cached_path trajectory of last planning
     * @param[in&out] singles_start updated start point
     **/
    adStatus_t SetStartPoint(const std::vector<TrajectoryPoint>& cached_path,
                             bool entering_autodriving,
                             TrajectoryPoint* single_start,
                             TrajectoryPoint* closest_point);

    adStatus_t SetVPEnd(const float& vp_length);

    adStatus_t ShouldOverrideVPS(bool* should_override_vp_s);

    std::vector<int> GetKeyBPPIndex();

    void LogOutTime();

    adStatus_t ManuallySetMaps(const std::string grid_filename,
                               const std::vector<std::vector<int>> pred_vect);

    /**
     * @brief Set cached base path
     **/
    adStatus_t SetCachedBasePath(
        const std::vector<TrajectoryPoint>& cached_base_path);

 private:
    GridMap map;
    PredictMap predict_map_;
    roadStructure::RoadStructure<cv::Point2f> rs_;
    std::shared_ptr<FrenetCoordinateSystem> frenet_system_;

    DMTarget* dm_target_ = nullptr;

    ObjectTrajectory* object_trajectory_ = nullptr;
    PredictionResult* prediction_result_ = nullptr;
    PredictionTrajectory pred_traj_;

    DMTarget curr_dm_target_;
    DMTarget last_dm_target_;

    int neglect_all_freespace_ = 0;
    int neglect_intersection_freespace_ = 0;

    float max_change_lane_distance_ = 50;
    float min_change_lane_distance_ = 20;
    float default_change_lane_distance_ = 40;
    float default_change_lane_velocity_ = 5.0;
    float default_change_lane_offset_ = 4.0;

    float goal_drift_threshold_ = 0.0f;

    // if use quadratic bezier for BPP
    int quadratic_bezier_turning_ = 0;

    float ibpp_radius_ = 5.0f;
    float ibpp_extradist_ = 1.0f;
    float ibpp_maxdist_ = 15.0f;

    float ref_line_adding_dist_ = 1.0f;

    int key_point_around_collision_ = 10;
    float cross_to_lane_cosine_ = 0.5f;
    float cross_to_lane_dist_ = 5.0f;

    float delta_s_;
    TrajectoryPoint single_start_;
    TrajectoryPoint single_goal_;

    float vp_length_;
    float emerge_stop_acc_ = 2.0;

    int in_cross_to_lane = 0;

    TrajectoryPoint lane_mid_pts;

    float probe_step_ = 0.1;           // meters
    float probe_range_ = 5.0;          // meters
    float clearance_threshold_ = 1.0;  // meters
    int collision_check_range_ = 150;  // index
    float goal_forward_range_ = 5.0f;  // meters

    std::vector<std::vector<char>> mask_map =
        std::vector<std::vector<char>>(450, std::vector<char>(800, -1));

    bool point_in_rect(const cv::Point2f& pt,
                       const cv::Point2f& pt0,
                       const cv::Point2f& pt1,
                       const cv::Point2f& pt2,
                       const cv::Point2f& pt3);
    void buildmap();

    std::vector<TrajectoryPoint> base_path_;
    std::vector<TrajectoryPoint> cached_base_path_;
    std::vector<TrajectoryPoint> final_base_path_;
    std::vector<TrajectoryPoint> improved_base_path_;
    std::vector<TrajectoryPoint> ref_line_;
    std::vector<TrajectoryPoint> routing_refline_;
    QuintSplineSGDSmoother quintspline_smoother_;

    TrajectoryPoint cached_goal_;

    TrajectoryPoint goal_;
    VPPurpose vp_purpose_;
    float target_velocity_;
    bool use_cached_goal_;
    float current_velocity_;
    float ref_line_interval_ = 1.0;
    int jp_lane_map_ = 0;
    int goal_safety_back_ = -1;

    int gen_ref_line_mode_ = 0;

    int bpp_improved_ = 0;

    int use_routing_refline_ = true;
    TrajectoryPoint cached_lane_end_;

    std::string last_tgt_road_id_ = "";
    int32_t last_tgt_lane_id_ = -1;

    int suppress_predmap_refresh_ = 0;
    int fixed_goal_index_ = 200;

    int overtake_extend_verify_ = 20;

    // bias for max_curvature and goal distance
    float max_curvature_bias_ = -0.0175;
    // slope for max_curvature and goal distance
    float max_curvature_slope_ = 1.25;
    // max lateral acc during lane change
    float max_lateral_acc_ = 2.0;
    // fitting coffeficence for bezier curve
    // goal_distance = 1.0 / ((1.0 / (coeff1 * width + coeff2) *
    // max_curvature4) + coeff3 * width + coeff4)
    float bezier_fitting_coeff1_ = 0.0;
    float bezier_fitting_coeff2_ = 0.0;
    float bezier_fitting_coeff3_ = 0.0;
    float bezier_fitting_coeff4_ = 0.0;
    // alignment debug
    int alignment_ = 1;
    // alignmnet flag
    bool alignment_activated_ = false;
    // min basepath distance in uturn
    float min_basepath_distance_uturn_ = 1.0;
    // offset of basepath in pull over
    float pull_over_offset_ = 3.5;
    // offset of basepath due to DM deviation
    float nudge_offset_ = 0.7;
    // distance of basepath offset
    float last_basepath_offset_ = 0.0;
    float curr_basepath_offset_ = 0.0;

    // record the dm overtake intention
    senseAD::DMTarget::Intention last_dm_intention_ =
        senseAD::DMTarget::Intention::NONEINTENTION;
    // threshold for update origin postio and direction
    float update_origin_position_threshold_ = 0.5;    // m
    float update_origin_direction_threshold_ = 0.05;  // rad
    int extract_lane_pt(const std::string& road_id,
                        const int32_t& lane_id,
                        std::vector<TrajectoryPoint>* lane_pts);
    int lane_direction(const std::vector<TrajectoryPoint>& lane_pt,
                       cv::Point2f* begin_direction,
                       cv::Point2f* end_direction);

    int stitch_traj_path(const std::vector<TrajectoryPoint>& part_a,
                         const std::vector<TrajectoryPoint>& part_b,
                         std::vector<TrajectoryPoint>* result);

    int trim_ref_line(const float& length_back,
                      const float& length_front,
                      std::vector<TrajectoryPoint>* line);

    int notCollided(const std::vector<TrajectoryPoint>& to_test_path,
                    int range_,
                    bool if_gridmap_pure = false);

    void notCollided(const std::vector<TrajectoryPoint>& to_test_path,
                     int range_,
                     int* continued_first_index,
                     int* continued_last_index);

    std::vector<std::string> titles;
    std::vector<int> function_called_nums;
    std::vector<std::chrono::nanoseconds> durations;

    /**
     * @brief Select Goal distance based on max curvature
     * @param[in] max curvature of bezier curve
     * @param[in] lateral deviation in lane change
     * @param[out] longitudinal goal distance
     **/
    adStatus_t SelectGoalDistance(const float& max_curvature,
                                  const float& lateral_deviation,
                                  float* goal_distance);

    /**
     * @brief Select offset point by collided point for overtake and parking
     * @param[in] first_collided_index first collided index in ref line
     * @param[in] last_colliided_index last collided index in ref line
     * @param[out] goal offseted of ref_line point in overtake or parking
     **/
    void SelectCollidedPoint(const int& first_collided_index,
                             const int& last_collieded_index,
                             TrajectoryPoint* goal);

    /**
     * @brief Select offset point by distance for overtake and parking
     * @param[in] max_lat_acc maximum lateral acc to calcalte max curvature
     * @param[in] min_distance minimum distance for selecting point
     * @param[in] intersion right or left
     * @param[in] offset_distance lateral distance for offset
     * @param[out] goal set goal position and direction
     **/
    void SelectPointByDistance(const float& max_lat_acc,
                               const float& min_distance,
                               const float& max_distance,
                               const DMTarget::Intention& intension,
                               const float& offset_distance,
                               TrajectoryPoint* goal);

    /**
     * @brief Generate base path according to cached base path, elongation and
     **/
    adStatus_t GenBasePathFromCached();
};
}  // namespace pp
}  // namespace senseAD
