/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once
#include <glog/logging.h>
#include <math.h>
#include <cmath>
#include <string>
#include <functional>
#include <vector>
#include <utility>
#include "path_planning/smoother.hpp"
#include "qpOASES.hpp"

namespace senseAD {
namespace pp {
/*
   OVERVIEW:
   1. RDP determine number of segment and points for each segment
   2. LearnableQuintSpline gives the fitting result and has init value
   3. PTSLOSS and CURVATURELOSS constraints the param
   4. SGD/ADAM optimize all learnable param
*/
struct LearnableVariable {
    float v;
    float d;
    bool require_grad = true;
    bool grad_fixed_direction = false;
};

struct LearnablePoints {
    cv::Point2f v;
    cv::Point2f d;
    bool require_grad = true;
    bool grad_fixed_direction = false;
};

class LearnableQuintSpline {
 public:
    LearnableQuintSpline();
    void SetInput(const std::vector<float> t_for_points,
                  const std::vector<float> t_for_curvature);
    void SetOutput(std::vector<LearnablePoints> *points,
                   std::vector<LearnableVariable> *curvature);
    void Initialize(const std::vector<LearnablePoints> in_param,
                    const std::vector<int> numofeachsegs);
    void Forward();
    void Backward();
    void Step();
    void ADAM_Step();
    std::vector<LearnablePoints> ExportResult();
    // Learning Rate
    float lr = 0.1f;

 private:
    // segments
    int ss;
    // Parameter
    // Order:
    // P_0 t_s a_s P_5 t_e a_e
    // for adjecent, the previous `P_5 t_e a_e` is the next `P_0 t_s a_s`
    // So the number of param should be 3 * (ss + 1)
    std::vector<LearnablePoints> param;
    // target `t` for points output
    std::vector<float> t_pts;
    // target `t` for curvature output
    std::vector<float> t_cur;
    // number of points that each segments should provide
    // numofeachsegs.size() == ss;
    std::vector<int> numofeachsegs;
    // ptr output
    std::vector<LearnablePoints> *ptr_outpts;
    // for curvature, output size = t_cur.size() * (ss)
    std::vector<LearnableVariable> *ptr_outcur;
    // for convenient
    const float fac[6] = {1, 5, 10, 10, 5, 1};
    const float dmatrix[6][6] = {
        {-1, 5, -10, 10, -5, 1},  {5, -20, 30, -20, 5, 0},
        {-10, 30, -30, 10, 0, 0}, {10, -20, 10, 0, 0, 0},
        {-5, 5, 0, 0, 0, 0},      {1, 0, 0, 0, 0, 0}};
    // Intermediate params for ADAM solver
    float adam_eps = 1e-6;
    float adam_b1 = 0.9;
    float adam_b2 = 0.999;
    // here, we use v to store g and d store g^2
    std::vector<LearnablePoints> mm_g;
    // for bias correction (to remove the affects of initial zeros)
    float b1_c = 1.0f;
    float b2_c = 1.0f;
    float step = 0;
    void init_adam_params();
    // constraints some grad update
    void grad_direction_warp(const cv::Point2f &src, cv::Point2f *grad);
};

class PTSLOSS {
 public:
    PTSLOSS();
    void SetInput(const std::vector<TrajectoryPoint> target_points,
                  std::vector<LearnablePoints> *points);
    void SetOutput(LearnableVariable *loss);
    void Forward();
    void Backward();

    // weight;
    float pts_weight = 4.0f;

    // extra penalty weight
    float penalty_weight = 6.0f;
    // distance threshold for extra penalty
    float penalty_distance = 0.5f;

 private:
    // Input: [Standard] target points
    std::vector<TrajectoryPoint> target_points;
    // Input: points caculated by previous module
    std::vector<LearnablePoints> *in_points;
    // Output: point euclidean loss
    LearnableVariable *out_loss;
};

class CurvatureLoss {
 public:
    CurvatureLoss();
    void SetInput(std::vector<LearnableVariable> *in_curs);
    void SetOutput(LearnableVariable *loss);
    void Forward();
    void Backward();

    // weight
    float cur_change = 10.0f;
    // wholescale
    float wholescale = 1.0f;

 private:
    // Input: caculated curvature by previous module
    std::vector<LearnableVariable> *in_curs;
    // Output: curvature loss
    LearnableVariable *out_loss;
    // index of max curvature for BP
    int max_cur_idx = -1;
};

class QuintSplineSGDSmoother : public Smoother {
 public:
    QuintSplineSGDSmoother();
    void SetParam(float rdp_threshold,
                  int cur_sample,
                  float weight_cur_change,
                  float weight_cur,
                  float lr,
                  int iters,
                  int special_init_for_one,
                  float pts_weight,
                  float penalty_weight,
                  float penalty_distance);
    void SetData(const std::vector<TrajectoryPoint> &tps);
    LearnableQuintSpline GetFinalResult();
    std::vector<TrajectoryPoint> SamplePoints(float insert_distance);
    void Init();
    void Fit();
    void LogCurrentResult(std::string prefix = "");

 private:
    // CurvatureLoss
    CurvatureLoss m_curloss;
    // PTSLOSS
    PTSLOSS m_ptsloss;
    // LearnableQuintSpline
    LearnableQuintSpline m_lqs;
    // RDP method for simplesegment
    void simplesegment();
    // build init path
    void initpath();
    // build t for optimization
    void buildt();
    // RDP distance threshold
    float rdp_threshold = 1.414f;
    // trajectory points for smooth
    std::vector<TrajectoryPoint> trp;
    // t values for point caculation
    std::vector<float> seg_t;
    // t values for curvature caculation
    std::vector<float> cur_t;
    // segment index: start point index of each segment
    std::vector<int> segindexs;
    // number of covered points at each segments
    std::vector<int> numofeachsegs;
    // total amount of segments
    int num_segments;
    // total amount of t for curvature sampling at each segment
    int cur_sample = 10;
    // Optimize loss;
    LearnableVariable pts_loss;
    LearnableVariable cur_loss;
    // Parameters for LearnableQuintSpline
    std::vector<LearnablePoints> param;
    // S for each segments
    std::vector<float> s_seg;
    // Iterations
    int times = 100;
    // weight for curvature change loss
    float weight_cur_change = 10.0f;
    // weight for curvature loss
    float weight_cur = 1.0f;
    // weight for distance loss
    float pts_weight = 1.0f;
    // extra penalty weight for distance loss
    float penalty_weight = 6.0f;
    // distance threshold for extra penalty
    float penalty_distance = 0.5f;
    // learning rate
    float lr = 0.1f;
    // enable special init for one segment cases
    int special_init_for_one = 1;
    // enable second mid point method
    int second_mid_point = 1;
    // for convenient
    const float fac[6] = {1, 5, 10, 10, 5, 1};
    const float dmatrix[6][6] = {
        {-1, 5, -10, 10, -5, 1},  {5, -20, 30, -20, 5, 0},
        {-10, 30, -30, 10, 0, 0}, {10, -20, 10, 0, 0, 0},
        {-5, 5, 0, 0, 0, 0},      {1, 0, 0, 0, 0, 0}};
};

}  // namespace pp
}  // namespace senseAD
