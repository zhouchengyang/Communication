/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Liang Yu <liangyu@sensetime.com>
 */

#pragma once

#include <vector>
#include <functional>
#include <string>
#include <memory>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/nn_tool.hpp"
#include "path_planning/baseplanner.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API PlannerCore {
 public:
    typedef std::function<adStatus_t(const cv::Point2f& position,
                                     bool* pass_check)>
        fun_collision_t;

    typedef std::function<adStatus_t(const cv::Point2f& position, char* risk)>
        func_risk_t;

    typedef std::function<adStatus_t(cv::Point2f* point)> fun_warp_point_t;

    PlannerCore() {}
    virtual ~PlannerCore() {}

    /**
     * @brief register collision check plug
     * @param fun_collision[in] collosion check function
     **/
    void RegisterCheckCollisionPlug(fun_collision_t fun_collision) {
        IsFree_ = fun_collision;
    }

    void RegisterCheckSceneRiskPlug(func_risk_t func_risk) {
        ItsRisk_ = func_risk;
    }

    /**
     * @brief register coordinate conversion plug
     * @param fun_warp_point[in] coordinate conversion function
     **/
    void RegisterWarpPointPlug(fun_warp_point_t fun_warp_point) {
        WarpPoint_ = fun_warp_point;
    }

    /**
     * @brief create a planner base on string
     * @param type[in] "LatticeCore" / "RRTCore"
     * @return return null if fail
     **/
    static std::shared_ptr<PlannerCore> CreatePlanner(const std::string& type);

    /**
     * @brief Init
     * @return flag to specify if succeed or fail
     **/
    virtual adStatus_t Init() = 0;

    /**
     * @brief update data
     * @param base_path[in] base path
     * @param goal[in] goal point
     * @return flag to specify if succeed or fail
     **/
    adStatus_t Update(const std::vector<TrajectoryPoint>& base_path,
                      const TrajectoryPoint& start,
                      const TrajectoryPoint& goal,
                      const VPPurpose& vppurpose,
                      const float& vp_s,
                      const std::vector<TrajectoryPoint>& cached_path,
                      const ReplanFlag& replan_flag) {
        base_path_ = base_path;
        start_ = start;
        goal_ = goal;
        vppurpose_ = vppurpose;
        vp_s_ = vp_s;
        cached_path_ = cached_path;
        replan_flag_ = replan_flag;
        return AD_SUCCESS;
    }

    /**
     * @brief planning
     * @param out_path[out] plan path
     * @return flag to specify if succeed or fail
     **/
    virtual adStatus_t Plan(std::vector<TrajectoryPoint>* out_path) = 0;

    /**
     * @brief get planninglog
     * @param planning_log[out] plannning debug [s,v,a,jerk]
     * @return flag to specify if succeed or fail
     **/
    adStatus_t GetPLanningLog(PlannningLog* planning_log) const {
        *planning_log = core_planning_log_;
        return AD_SUCCESS;
    }

 protected:
    /**
     * @brief collosion check plug
     * @param position[in] will check position
     * @param in_free_space[out] collosion check result
     * @return flag to specify if succeed or fail
     * @node must be using RegisterCheckCollisionPlug() to get plug
     **/
    adStatus_t CheckCollision(const cv::Point2f& position,
                              bool* in_free_space) {
        if (IsFree_ == nullptr) {
            AD_LERROR(PATH_PLANNING) << "Planner no register collision plug()";
            return AD_NULL_PTR;
        }
        return IsFree_(position, in_free_space);
    }

    adStatus_t CheckRisk(const cv::Point2f& position, char* risk) {
        if (IsFree_ == nullptr) {
            AD_LERROR(PATH_PLANNING) << "Planner no register collision plug()";
            return AD_NULL_PTR;
        }
        return ItsRisk_(position, risk);
    }

    /**
     * @brief coordinate conversion
     * @param point[in/out] point coordinate conversion
     * @return flag to specify if succeed or fail
     * @node must be using RegisterWarpPointPlug() to get plug
     **/
    adStatus_t WarpTrajectoryPoint(TrajectoryPoint* traj_pt) {
        if (WarpPoint_ == nullptr) {
            AD_LERROR(PATH_PLANNING) << "Planner no register wrap point plug()";
            return AD_NULL_PTR;
        }
        auto new_position = traj_pt->position;
        auto new_direction = traj_pt->direction;
        auto new_position_with_direction = new_position + new_direction;
        SD_CHECK_SUCCESS(WarpPoint_(&new_position));
        SD_CHECK_SUCCESS(WarpPoint_(&new_position_with_direction));
        traj_pt->position = new_position;
        traj_pt->direction = new_position_with_direction - new_position;
        return AD_SUCCESS;
    }

 protected:
    TrajectoryPoint goal_;
    TrajectoryPoint start_;
    std::vector<TrajectoryPoint> base_path_;
    PlannningLog core_planning_log_;
    VPPurpose vppurpose_;
    float vp_s_ = 0;
    // TODO(congq) refline info
    // TODO(congq) vp purpose
    fun_collision_t IsFree_ = nullptr;
    func_risk_t ItsRisk_ = nullptr;
    fun_warp_point_t WarpPoint_ = nullptr;
    // nn tool for cached_path
    NNTool nn_tool_cached_path_;
    // last planning trajectory
    std::vector<TrajectoryPoint> cached_path_;
    // replan flag
    ReplanFlag replan_flag_;
};

}  // namespace pp
}  // namespace senseAD

