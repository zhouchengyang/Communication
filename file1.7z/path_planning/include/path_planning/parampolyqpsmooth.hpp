/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once
#include <glog/logging.h>
#include <math.h>
#include <cmath>
#include <string>
#include <functional>
#include <vector>
#include <utility>
#include "path_planning/smoother.hpp"
#include "qpOASES.hpp"

namespace senseAD {
namespace pp {

// Formular:
// x(t) = xt_param[0] + xt_param[1] * t + xt_param[2] * t * t + ...
// y(t) = yt_param[0] + yt_param[1] * t + yt_param[2] * t * t + ...
// x(t) has the same order as y(t) defined by `order`
struct ParamPolyCurve {
    std::vector<float> xt_param;
    std::vector<float> yt_param;
    int order;
};

class ParamPolyQPSmoother : public Smoother {
 public:
    explicit ParamPolyQPSmoother(int order = 3);
    void SetData(const std::vector<TrajectoryPoint> &tps);
    ParamPolyCurve GetFinalResult();
    std::vector<TrajectoryPoint> SamplePoints(float insert_distance);
    void Init() {}
    void Fit();
    int order_ = 3;
    float scale_ = 15.0;

 private:
    ParamPolyCurve curve;
    std::vector<TrajectoryPoint> data;
    bool is_result_available_;
    float max_dist_estimate_;
};

}  // namespace pp
}  // namespace senseAD
