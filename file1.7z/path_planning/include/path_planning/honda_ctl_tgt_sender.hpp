/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#pragma once

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/honda_ctl_input.hpp"
#include "common/data_type/vehicle_info.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API HondaCtlTgtSender {
 public:
    HondaCtlTgtSender();
    ~HondaCtlTgtSender();

    adStatus_t set_ip_addr(const std::string ip_addr);

    adStatus_t SendHCIPacket();
    adStatus_t SetHCI(const HondaCtlInput& hci);

 private:
    HondaCtlInput hci_;

    const uint pt_PORT = 5001;
    const int DECIMAL_GAIN = 65536;

    int pt_sock;

    struct sockaddr_in pt_addr;
};

}  // namespace pp
}  // namespace senseAD

