/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Qiu Cong <qiucong@sensetime.com>
 */

#pragma once

#include <memory>
#include <string>
#include <vector>
#include <memory>
#include <unordered_map>
#include "common/error.hpp"
#include "common/data_type/dm_target.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/road_structure.hpp"
#include "common/data_type/routing_base.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/vehicle_info.hpp"
#include "common/data_type/vehicle_param.hpp"
#include "common/error.hpp"

#include "path_planning/cache_point.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/pose_warp.hpp"
#include "path_planning/scene_parser.hpp"

#include "path_planning/honda_ctl_can_sender.hpp"
#include "path_planning/honda_ctl_input_converter.hpp"
#include "path_planning/honda_ctl_sig_sender.hpp"
#include "path_planning/honda_ctl_tgt_sender.hpp"

namespace senseAD {

namespace pp {

struct PlannningLog {
    int num;
    float64_t time_interval;
    std::vector<float64_t> x;
    std::vector<float64_t> y;
    std::vector<float64_t> s;
    std::vector<float64_t> v;
    std::vector<float64_t> a;
    std::vector<float64_t> jerk;
    float64_t lateral_d;
    float64_t lateral_v;
    float64_t lateral_a;
    float64_t lateral_jerk;
    std::unordered_map<int, Tag> obstacle_tag;

    PlannningLog()
        : num(0),
          time_interval(0.2f),
          lateral_d(0.0f),
          lateral_v(0.0f),
          lateral_a(0.0f),
          lateral_jerk(0.0f) {}
};

class SENSEAD_API BasePathPlanner {
    // Coordinate system obey the body standard of ROS:
    // (x forward, y left, z up)
    // See this link: http://www.ros.org/reps/rep-0103.html
 public:
    /**
     * @brief Initialize the BasePathPlanner()
     **/

    BasePathPlanner();
    /**
     * @brief Destruct the BasePathPlanner
     **/
    virtual ~BasePathPlanner();

    /**
     * @brief Create a pathplanner based on config file
     * @param config_path path to config file
     * @param bpp_ptr a pointer to store path planner's instance
     * @return flag to specify if succeed or fail
     * @notes there should another path pointing to another config file for each
     *path planner
     **/
    static adStatus_t CreatePlanner(const std::string &config_path,
                                    std::shared_ptr<BasePathPlanner> *bpp_ptr);

    /**
     * @brief Initialize pathplanner with file
     * @param config
     * @return flag to specify if succeed or fail
     **/
    virtual adStatus_t Init(const std::string &config) = 0;
    /**
     * @brief Update input
     * @param rbs
     * @param object_trajecory po result
     * @param prediction_result
     * @param dm_target DMTarget
     * @param car_trajectory localization
     * @param vehicle_info CAN info
     * @return flag to specify if succeed or fail
     **/
    // TODO(origin): To use the desinated odometry?
    virtual adStatus_t Update(
        senseAD::roadStructure::RoadStructure<cv::Point2f> *rs,
        ObjectTrajectory *object_trajectory,
        PredictionResult *prediction_result,
        DMTarget *dm_target,
        std::shared_ptr<Car_Trajectory> car_trajectory,
        VehicleInfo *vehicle_info,
        routing::BasePath *base_path,
        VehicleStat *vehicle_status);
    /**
     * @brief Update input
     * @param rbs
     * @param object_trajecory po result
     * @param prediction_result
     * @param dm_target DMTarget
     * @param car_trajectory localization
     * @param vehicle_info CAN info
     * @return flag to specify if succeed or fail
     **/
    // TODO(origin): To use the desinated odometry?
    virtual adStatus_t Update(
        senseAD::roadStructure::RoadStructure<cv::Point2f> *rs,
        const PredictionObjectArray &poa,
        DMTarget *dm_target,
        std::shared_ptr<Car_Trajectory> car_trajectory,
        VehicleInfo *vehicle_info,
        routing::BasePath *base_path,
        VehicleStat *vehicle_status);
    /**
     * @brief Plan paths to all goals and store them in out_path
     * @param out_path vector of TrajectoryPoint
     * @return flag to specify if succeed or fail
     **/
    virtual adStatus_t Plan(std::vector<TrajectoryPoint> *out_path) = 0;

    adStatus_t GetPlanningLog(PlannningLog *planning_log) const;

    adStatus_t SetHondaConverter(const bool flag, const std::string ip_addr);

 protected:
    /**
     * @brief Build Frenet Coordinate System started behind of ego car
     *
     * @return status of building. If the basepath is so short, it won't return
     * success
     */
    adStatus_t BuildFrenetCoordSystem();

 protected:
    // common tools
    SceneParser scene_parser_;
    PoseWarp pose_warp_;
    CachePoint cache_point_;
    std::shared_ptr<FrenetCoordinateSystem> frenet_system_;
    // deviation of frenet coordinate
    cv::Point2f frenet_origin_move_vec_ = std::move(cv::Point2f(0.0f, 0.0f));

    // For Honda Control Interface
    HondaCtlInputConverter honda_converter_;
    HondaCtlCanSender honda_can_sender_;
    HondaCtlSigSender honda_sig_sender_;
    HondaCtlTgtSender honda_tgt_sender_;

    // inputs for every plan
    // TODO(congq): replace CarTrajectory with OdomExt
    std::shared_ptr<Car_Trajectory> car_trajectory_;
    ObjectTrajectory object_trajectory_;
    PredictionResult prediction_result_;
    PredictionObjectArray poa_;
    roadStructure::RoadStructure<cv::Point2f> rs_;
    DMTarget dm_target_;
    VehicleInfo vehicle_info_;
    // vehicle status from canbus
    VehicleStat vehicle_status_;
    bool last_autodriving_status_on_ = false;
    routing::BasePath base_path_;

    // Input from launch file
    bool interface_to_autobox_ = false;
    std::string autobox_ip_addr_;

    // current state
    VehicleState curr_vehicle_state_;

    VehicleParam vehicle_setting_;
    int64_t current_timestamp_;
    PlannningLog planning_log_;
};
}  // namespace pp
}  // namespace senseAD
