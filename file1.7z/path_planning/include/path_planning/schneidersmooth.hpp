/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once
#include <glog/logging.h>
#include <math.h>
#include <cmath>
#include <string>
#include <functional>
#include <vector>
#include <utility>
#include "path_planning/polynomial_curve.hpp"
#include "path_planning/smoother.hpp"

namespace senseAD {
namespace pp {

struct CubicBezierCurve {
    PolynomialCurve xt = PolynomialCurve(3);
    PolynomialCurve yt = PolynomialCurve(3);
    std::vector<float> keypoint_t;
    float norm;
};

class SchneiderSmoother : public Smoother {
 public:
    SchneiderSmoother();
    void SetData(const std::vector<TrajectoryPoint> &tps);
    std::vector<CubicBezierCurve> GetFinalResult();
    std::vector<TrajectoryPoint> SamplePoints(float insert_distance);
    void Fit();
    void Init();

 private:
    std::vector<CubicBezierCurve> internal_fit(int32_t b_idx, int32_t e_idx);
    // const reference will fail the functoin called at PolynormalCurve,
    // so we leave it.
    std::pair<float, int32_t> maxinternal_error(CubicBezierCurve &func,
                                                int32_t b_idx,
                                                int32_t e_idx);
    bool internal_reparam(CubicBezierCurve &func,
                          int32_t b_idx,
                          int32_t e_idx,
                          std::vector<float> *tt);
    float update_t(CubicBezierCurve &func, int32_t idx, float t);
    CubicBezierCurve gen_cubic_bezier(int32_t b_idx,
                                      int32_t e_idx,
                                      const std::vector<float> &tt);
    std::vector<TrajectoryPoint> data;
    std::vector<CubicBezierCurve> final_result;
    int32_t state_smoother;
    float error_;
    float escale_;
};

}  // namespace pp
}  // namespace senseAD
