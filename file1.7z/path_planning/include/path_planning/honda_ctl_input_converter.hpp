/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Cong Qiu <qiucong@sensetime.com>
 */

#pragma once

#include <vector>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/honda_ctl_input.hpp"
#include "common/data_type/vehicle_info.hpp"

namespace senseAD {
namespace pp {

class SENSEAD_API HondaCtlInputConverter {
 public:
    HondaCtlInputConverter();
    ~HondaCtlInputConverter();
    static int fake_run_timef;
    adStatus_t SetDefaultVelocity(const float& vel);
    adStatus_t ToHondaCtl(const float& run_timef,
                          const float& insert_interval,
                          const std::vector<TrajectoryPoint>& input_traj_pts,
                          HondaCtlInput* honda_ctl_input);

 private:
    HondaCtlInput hci_;
    float default_velocity = 5;
    const int DECIMAL_GAIN = 65536;
};

}  // namespace pp
}  // namespace senseAD

