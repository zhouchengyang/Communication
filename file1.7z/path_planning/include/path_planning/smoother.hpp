/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once
#include <string>
#include <vector>
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/ppconfig.hpp"

namespace senseAD {
namespace pp {

class Smoother {
 public:
    Smoother() {}
    virtual ~Smoother() {}
    virtual void SetData(const std::vector<TrajectoryPoint> &tps) = 0;
    virtual std::vector<TrajectoryPoint>
            SamplePoints(float insert_distance) = 0;
    virtual void Fit() = 0;
    virtual void Init() = 0;
};

}  // namespace pp
}  // namespace senseAD
