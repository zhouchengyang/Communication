/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <cstdlib>
#include <chrono>  // NOLINT
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/util.hpp"
#include "path_planning/ppconfig.hpp"

namespace senseAD {
namespace pp {

class VelocityPlanner {
 public:
    VelocityPlanner() {}
    virtual ~VelocityPlanner() {}
    virtual adStatus_t PlanVelocity(
        std::vector<TrajectoryPoint> *path_to_plan) = 0;
    virtual adStatus_t Init() {
        auto conf = g_pp_conf["rrt_setting"];
        extra_dacc_stop_ = conf["extra_dacc_stop"];
        AD_LINFO(PATH_PLANNING) << "extra_dacc_stop: " << extra_dacc_stop_;
        return AD_SUCCESS;
    }
    adStatus_t Update(const VPPurpose &vppurpose,
                      int to_index,
                      float target_speed) {
        this->vppurpose_ = vppurpose;
        this->target_speed_ = target_speed;
        this->to_index_ = to_index;
        return AD_SUCCESS;
    }

 protected:
    VPPurpose vppurpose_;
    int to_index_ = -1;
    float target_speed_;
    std::vector<BVPStage> bvs_;
    float extra_dacc_stop_ = -0.0f;
    void applybvpstage(std::vector<TrajectoryPoint> *traj_path) {
        int32_t early_stage = 0;
        int32_t current_stage = -1;
        float tn = 0;
        AD_LINFO(PATH_PLANNING) << "bvs_.size =" << bvs_.size();
        for (uint32_t i = 0; i < bvs_.size(); i++) {
            AD_LINFO(PATH_PLANNING)
                << "(" << i << ")" << bvs_[i].type << " " << bvs_[i].s_v << " "
                << bvs_[i].e_v << " " << bvs_[i].s_a << " " << bvs_[i].e_a
                << " " << bvs_[i].j << " " << bvs_[i].d_f_s;
        }
        float accumulate_sum_distance = 0;
        for (uint32_t i = 0; i < traj_path->size(); i++) {
            float norm_now;
            if (i == 0) {
                // utils::CalcNorm(traj_path->at(i).position, &norm_now);
                norm_now = 0.0f;
                traj_path->at(i).time_difference = 0.0;
            } else {
                utils::CalcNorm(
                    traj_path->at(i).position - traj_path->at(i - 1).position,
                    &norm_now);
            }
            float d = accumulate_sum_distance + norm_now;
            accumulate_sum_distance += norm_now;
            while (current_stage == -1 ||
                   (current_stage < static_cast<int>(bvs_.size()) &&
                    d > bvs_[current_stage].d_f_s)) {
                early_stage = current_stage;
                current_stage = current_stage + 1;
                tn = 0;
            }
            bool use_goal_directly = false;
            if (current_stage < static_cast<int32_t>(bvs_.size()) &&
                d > bvs_[current_stage].d_f_s) {
                AD_LDEBUG(PATH_PLANNING) << "Reach the end point: " << d;
                use_goal_directly = true;
            }
            if (early_stage >= 0) {
                d = d - bvs_[early_stage].d_f_s;
            }
            if (current_stage >= 0 &&
                current_stage < static_cast<int>(bvs_.size()) &&
                !use_goal_directly) {
                float a, b, c;
                // jerk, acc, v0, v1;
                switch (bvs_[current_stage].type) {
                    case 1:
                        // v=v0+at
                        a = 0;
                        b = bvs_[current_stage].s_a / 2.0f;
                        c = bvs_[current_stage].s_v;
                        break;
                    case 2:
                    case 3:
                        a = bvs_[current_stage].j / 6.0f;
                        b = bvs_[current_stage].s_a / 2.0f;
                        c = bvs_[current_stage].s_v;
                        break;
                    default:
                        a = 0;
                        b = 0;
                        c = 0;
                        break;
                }
                std::vector<float> cand_t;
                utils::SolveCubic(a, b, c, -d, &cand_t);
                float tmp_nowt = -1;
                for (uint32_t j = 0; j < cand_t.size(); j++) {
                    if (cand_t[j] >= 0 &&
                        (cand_t[j] - tn >= 0 || fabs(cand_t[j] - tn) < 1e-5) &&
                        (tmp_nowt < 0 || tmp_nowt - tn > cand_t[j] - tn))
                        tmp_nowt = cand_t[j];
                }
                if (tmp_nowt >= 0) {
                    traj_path->at(i).velocity = a * 3.0f * tmp_nowt * tmp_nowt +
                                                b * 2 * tmp_nowt +
                                                bvs_[current_stage].s_v;
                    traj_path->at(i).acceleration = a * 6 * tmp_nowt + b * 2;
                    traj_path->at(i).time_difference = tmp_nowt;
                    AD_LDEBUG(PATH_PLANNING)
                        << "utils::SolveCubic ok: " << a << " " << b << " " << c
                        << " " << -d;
                    AD_LDEBUG(PATH_PLANNING)
                        << "current_stage = " << current_stage
                        << ", tn = " << tn << ", tmp_nowt = " << tmp_nowt;
                    tn = tmp_nowt;
                } else {
                    LOG(INFO) << "Error, utils::SolveCubic failed: " << a << " "
                              << b << " " << c << " " << -d;
                    AD_LDEBUG(PATH_PLANNING)
                        << "cand_t.size() = " << cand_t.size();
                    for (uint32_t i = 0; i < cand_t.size(); i++) {
                        AD_LDEBUG(PATH_PLANNING)
                            << "[" << i << "]" << cand_t[i];
                    }
                    AD_LDEBUG(PATH_PLANNING)
                        << "tn = " << tn << ", tmp_nowt = " << tmp_nowt;
                    if (i > 0) {
                        traj_path->at(i).velocity =
                            traj_path->at(i - 1).velocity;
                        traj_path->at(i).acceleration = 0;
                        if (traj_path->at(i).velocity > 0.001) {
                            traj_path->at(i).time_difference =
                                traj_path->at(i - 1).time_difference +
                                cv::norm(traj_path->at(i).position -
                                         traj_path->at(i - 1).position) /
                                    traj_path->at(i).velocity;
                        } else {
                            traj_path->at(i).time_difference =
                                traj_path->at(i - 1).time_difference + 1000.0;
                        }

                    } else {
                        traj_path->at(i).velocity = bvs_[current_stage].s_v;
                        traj_path->at(i).acceleration = bvs_[current_stage].s_a;
                        traj_path->at(i).time_difference = 0;
                    }
                }
            } else {
                traj_path->at(i).velocity = bvs_[early_stage].e_v;
                traj_path->at(i).acceleration = bvs_[early_stage].e_a;
                auto conf = g_pp_conf["rrt_setting"];
                float speed_eps_ = conf["rvp_speed_eps"];
                if (vppurpose_ == STOP_AT_GIVEN_POINT ||
                    vppurpose_ == EMERGE_STOP ||
                    vppurpose_ == REMAIN_TILL_CACHE_GOAL ||
                    fabs(target_speed_) < speed_eps_) {
                    traj_path->at(i).acceleration = extra_dacc_stop_;
                }
            }
        }
    }
};

}  // namespace pp
}  // namespace senseAD

