/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <math.h>
#include <vector>
#include <string>
#include <memory>
#include <map>
#include <complex>
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/road_base.hpp"
#include "path_planning/common_structure.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "eigen3/Eigen/Core"
#include "eigen3/unsupported/Eigen/Splines"

namespace senseAD {
namespace pp {
namespace utils {
adStatus_t SampleLanelinepts(const senseAD::LaneLine &laneline,
                             float from,
                             float to,
                             float delta,
                             int num,
                             int farfirst,
                             std::vector<cv::Point2f> *out);
adStatus_t Normalize2Dvect(cv::Point2f *a);

inline float cvnorm(const cv::Point2f &a) {
    float dist;
    dist = a.x * a.x + a.y * a.y;
    dist = sqrtf(dist);
    return dist;
}

adStatus_t FrenetToCartesian(const float &s,
                             const float &ds,
                             const float &dds,
                             const float &d,
                             const float &dd,
                             const float &ddd,
                             const std::vector<TrajectoryPoint> &ref_path,
                             TrajectoryPoint *result_pt);

adStatus_t CartesianToFrenet(const TrajectoryPoint &pt,
                             const std::vector<TrajectoryPoint> &ref_path,
                             float *s,
                             float *ds,
                             float *dds,
                             float *d,
                             float *dd,
                             float *ddd);

adStatus_t GetHeadingAtS(const std::vector<TrajectoryPoint> &ref_path,
                         const float s,
                         float *heading);

adStatus_t GetHeadingAtS(const std::vector<TrajectoryPoint> &ref_path,
                         const float s,
                         cv::Point2f *heading);

cv::RotatedRect GetErrorEllipse(double chisquare_val,
                                cv::Point2f mean,
                                cv::Mat covmat);

adStatus_t Cosine2Dvect(const cv::Point2f &a,
                        const cv::Point2f &b,
                        float *cosine);
adStatus_t PointsToLine(const std::vector<cv::Point2f> &ce,
                        float *a,
                        float *b,
                        float *c);
adStatus_t IntersectionPoint(float a1,
                             float b1,
                             float c1,
                             float a2,
                             float b2,
                             float c2,
                             cv::Point2f *pts);
adStatus_t CalcbyPoint(const cv::Point2f &pts, float a, float b, float *c);
adStatus_t SortidoflanesByFaraway(
    const std::vector<senseAD::LaneLine> &lanelines, std::vector<int> *id);
adStatus_t isptsafarawayfromb(const cv::Point2f &pta,
                              const cv::Point2f &ptb,
                              int *isfar);
adStatus_t CalcNorm(const cv::Point2f &pts, float *norm);
adStatus_t SmoothDirection(std::vector<cv::Point2f> *directions,
                           cv::Point2f *newdirection,
                           int num);
adStatus_t UpdateSmooth(std::vector<cv::Point2f> *directions,
                        cv::Point2f *newdirection,
                        int num);
// solve ax^3+bx^2+cx+d=0;
adStatus_t SolveCubic(
    float a, float b, float c, float d, std::vector<float> *res);

inline cv::Point2f ep(const cv::Point2f &a, const cv::Point2f &b) {
    cv::Point2f p;
    p.x = a.x * b.x;
    p.y = a.y * b.y;
    return p;
}
adStatus_t CubicBezierSmoothing(const std::vector<cv::Point2f> &path,
                                const cv::Point2f &entering_direction,
                                const cv::Point2f &exiting_direction,
                                std::vector<TrajectoryPoint> *smooth_path,
                                bool if_quadratic_bezier_first = false);

adStatus_t SegmentTrajectory(const std::vector<TrajectoryPoint> &trajectory,
                             const float &interval_dist,
                             std::vector<TrajectoryPoint> *result_trajectory);

/** @brief Segment the path by time using the time_difference, if the path's
 * time spand is less than 15 m(in case of dacc to 0), the path will be extend
 * to 15m with the min interval;
 *  @param trajectory
 *  @param interval_dist (by second)
 *  @param result_trajectory the outpt
 */
adStatus_t SegmentTrajectoryByTime(
    const std::vector<TrajectoryPoint> &trajectory,
    const float &interval_dist,
    std::vector<TrajectoryPoint> *result_trajectory);
adStatus_t SegmentTrajectoryV2(const std::vector<TrajectoryPoint> &trajectory,
                               const float &interval_dist,
                               std::vector<TrajectoryPoint> *result_trajectory);

// Aproximating the time of each trajpoint in a path, by deviding difference of
// "sum_distance" by average velocity,
// if average velocity was 0, which happens, the time will be 1000 more than the
// previous trajpoint.
adStatus_t EstimatePathTime(std::vector<TrajectoryPoint> *traj_path);

std::vector<TrajectoryPoint> CombineTrajectory(
    const std::vector<TrajectoryPoint> &traj_a,
    const std::vector<TrajectoryPoint> &traj_b);
void PathElongation(Trajectory *path,
                    const Trajectory &ref_line_,
                    const float &insert_distance_);

Trajectory TrimProperBasePath(const Trajectory &path,
                              const TrajectoryPoint &goal);
void solve_quartic(
    std::complex<double> *retval, double a, double b, double c, double d);

adStatus_t cos_pt2f(const cv::Point2f &pt_a,
                    const cv::Point2f &pt_b,
                    float *result);

int MatchClosestPoint(const Trajectory &trajectory,
                      int start_index,
                      const cv::Point2f &pos,
                      double range);

void UpdateSumDistance(Trajectory *trajectory, const cv::Point2f &pt);

void UpdateCurvatureYawrate(Trajectory *trajectory, int step = 10);

/** @brief Denote control points of cubic bezier curve as [p0, p1, p2, p3]
* If p0 and p1 are located in line p2p3 both side, the bezier curve will be
* snakelike. Thus, move p1 to intersection of line p0p1 and line p2p3.
*   @param p0 first control point
*   @param p1 second control point
*   @param p2 third control point
*   @param p3 fourth control point
*/
adStatus_t BezierCurveAmend(const cv::Point2f &p0,
                            cv::Point2f *p1,
                            cv::Point2f *p2,
                            const cv::Point2f &p3);

void CalcPerpendicularFoot(const cv::Point2f &point,
                           const std::vector<cv::Point2f> &line,
                           cv::Point2f *foot);

void SetTimestamp(std::vector<TrajectoryPoint> *out_path,
                  const float insert_distance);

const std::string GetTimestampString();

template <typename ScalarType>
void FitPolynomial(const std::vector<ScalarType> &x,
                   const std::vector<ScalarType> &y,
                   const int order,
                   polynomial<ScalarType> *poly) {
    if (poly == nullptr) {
        AD_LERROR(PATH_PLANNING) << "poly pointer is nullptr";
        return;
    }
    typedef Eigen::Matrix<ScalarType, Eigen::Dynamic, Eigen::Dynamic> Matrix;
    typedef Eigen::Matrix<ScalarType, Eigen::Dynamic, 1> Vector;
    typedef typename std::vector<ScalarType>::size_type size_type;
    // set matrix of linear equal
    Matrix A(x.size(), order + 1);
    Vector y_fitted = Vector::Map(&y.front(), y.size());
    for (size_type i = 0; i < x.size(); ++i) {
        for (int j = 0; j < order + 1; ++j) {
            A(i, j) = std::pow(x.at(i), j);
        }
    }
    // solve the linear equation by QR decomposition
    Vector result = A.householderQr().solve(y_fitted);
    std::vector<ScalarType> coeff(order + 1, 0);
    for (size_type i = 0; i < coeff.size(); ++i) {
        coeff.at(i) = result[i];
    }
    // constuct polynomial
    *poly = polynomial<ScalarType>(coeff);
}

/**
 * @brief FitPolynomialDerivs with given derivs at zero point
 *
 * @tparam ScalarType
 * @param x
 * @param y
 * @param derivs
 * @param order
 * @param poly
 */
template <typename ScalarType>
void FitPolynomialDerivs(const std::vector<ScalarType> &x,
                         const std::vector<ScalarType> &y,
                         const std::vector<ScalarType> &derivs,
                         const int order,
                         polynomial<ScalarType> *poly) {
    if (poly == nullptr) {
        AD_LERROR(PATH_PLANNING) << "poly pointer is nullptr";
        return;
    }
    typedef Eigen::Matrix<ScalarType, Eigen::Dynamic, Eigen::Dynamic> Matrix;
    typedef Eigen::Matrix<ScalarType, Eigen::Dynamic, 1> Vector;
    typedef typename std::vector<ScalarType>::size_type size_type;
    std::vector<ScalarType> coeff(order + 1, 0), tmp_coeff(derivs.size(), 0.0);
    // set coeffience by given derivs
    ScalarType factorial = 1;
    for (size_type i = 0; i < derivs.size(); ++i) {
        if (i > 0) {
            factorial = factorial * i;
        }
        coeff.at(i) = derivs.at(i) / factorial;
        tmp_coeff.at(i) = coeff.at(i);
    }

    // set matrix of linear equal
    Matrix A(x.size(), order + 1 - static_cast<int>(derivs.size()));
    for (size_type i = 0; i < x.size(); ++i) {
        for (int j = derivs.size(); j < order + 1; ++j) {
            A(i, j - derivs.size()) = std::pow(x.at(i), j);
        }
    }
    Vector y_fitted = Vector::Map(&y.front(), y.size());
    polynomial<ScalarType> tmp_poly(tmp_coeff);
    for (int i = 0; i < y_fitted.rows(); ++i) {
        y_fitted[i] = y_fitted[i] - tmp_poly(x.at(i));
    }

    // solve the linear equation by QR decomposition
    Vector result = A.householderQr().solve(y_fitted);
    for (size_type i = derivs.size(); i < coeff.size(); ++i) {
        coeff.at(i) = result[i - derivs.size()];
    }
    // constuct polynomial
    *poly = polynomial<ScalarType>(coeff);
    // evaluate fitting error
    const bool evaluate_on = true;
    if (evaluate_on == true) {
        ScalarType max_error = 0.0, mean_error = 0.0;
        size_type index_max_error = 0;
        for (size_type i = 0; i < x.size(); ++i) {
            ScalarType error = std::fabs((*poly)(x.at(i)) - y.at(i));
            mean_error = mean_error + error;
            if (error > max_error) {
                max_error = error;
                index_max_error = i;
            }
        }
        AD_LINFO(UTILS) << "max fitting error is " << max_error << ", at "
                        << index_max_error << ", mean fitting error is "
                        << (mean_error / x.size());
    }
}

template <typename ScalarType>
class SplineFunction {
 public:
    typedef Eigen::Matrix<ScalarType, Eigen::Dynamic, 1> Vector;
    typedef Eigen::Matrix<ScalarType, 1, Eigen::Dynamic> RowVector;

    SplineFunction() {}

    SplineFunction(const std::vector<ScalarType> &x,
                   const std::vector<ScalarType> &y) {
        Interpolate(x, y);
    }

    void Update(const std::vector<ScalarType> &x,
                const std::vector<ScalarType> &y) {
        Interpolate(x, y);
    }

    const ScalarType operator()(ScalarType x) const {
        // x values need to be scaled down in extraction as well.
        return spline_(scaled_value(x))(0);
    }

    const ScalarType CalcDerivative(ScalarType x, int order = 1) const {
        return spline_.derivatives(scaled_value(x), order)(order) /
               std::pow(x_max_ - x_min_, order);
    }

    const bool IsValid(ScalarType x) const {
        if (x_min_ >= x_max_) {
            return false;
        }
        if (x >= x_min_ && x <= x_max_) {
            return true;
        } else {
            return false;
        }
    }

 private:
    ScalarType x_min_ = static_cast<ScalarType>(0.0);
    ScalarType x_max_ = static_cast<ScalarType>(0.0);
    // Spline of one-dimensional "points."
    Eigen::Spline<ScalarType, 1> spline_;

    void Interpolate(const std::vector<ScalarType> &x,
                     const std::vector<ScalarType> &y) {
        Vector x_vec(x.size()), y_vec(y.size());
        for (uint32_t i = 0; i < static_cast<uint32_t>(x.size()); ++i) {
            x_vec(i) = x.at(i);
            y_vec(i) = y.at(i);
        }
        x_min_ = x_vec.minCoeff();
        x_max_ = x_vec.maxCoeff();
        // Spline fitting here. X values are scaled down to [0, 1] for this.
        spline_ =
            Eigen::SplineFitting<Eigen::Spline<ScalarType, 1>>::Interpolate(
                y_vec.transpose(),
                // No more than cubic spline, but accept short vectors.
                std::min<int>(x_vec.rows() - 1, 2), scaled_values(x_vec));
    }

    // Helpers to scale X values down to [0, 1]
    ScalarType scaled_value(ScalarType x) const {
        return (x - x_min_) / (x_max_ - x_min_ + 0.0001);
    }

    RowVector scaled_values(Vector const &x_vec) const {
        return x_vec.unaryExpr([this](ScalarType x) { return scaled_value(x); })
            .transpose();
    }
};
}  // namespace utils
}  // namespace pp
}  // namespace senseAD

