/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#pragma once

#include <opencv2/opencv.hpp>
#include <vector>
#include "common/data_type/prediction_result.hpp"
#include "common/data_type/road_structure.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/error.hpp"
#include "common/timing_logger.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/longi_lat_planner/object_map.hpp"
#include "path_planning/frenet_coordinate_system.hpp"
#include "path_planning/nn_tool.hpp"

namespace senseAD {
namespace pp {

class Parser {
 public:
    Parser() {}

    /**
     * @brief Destruct the parser
     **/
    ~Parser() {}

    /**
     * @brief Init parser
     *
     * @param s_horizon is horizon of frenet coord s, start from zero
     * @param s_resolution is resolution of s
     * @param t_horizon is horizon of frenet coord t, start from zero
     * @param t_resolution is resolution of t
     *
     * @return status of initialization
     */
    adStatus_t Init();

    /**
     * @brief update roadstructure, prediction result and ref line
     *
     * @return status of update
     **/
    adStatus_t Update(
        const senseAD::roadStructure::RoadStructure<cv::Point2f>& rs,
        const PredictionObjectArray& poa,
        const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
        const PlanningScenario planning_scenario,
        const bool lane_change_activated = false);

    /**
     * @brief parse scenario for planner
     * 1. setting frenet frame i.e. basepath
     * 2. refresh preditct map
     * 2. generate interface for longitudinal search
     * 3. generate interface for longitudinal optimize
     * 4. generate interface for lateral optimize
     * 5. cached path collied checker for replan
     *
     * @return status of parse
     **/
    adStatus_t Parse();

    /**
     * @brief check if to_test_path is collided with predict_map
     *
     * return true if not collied
     **/
    bool NotCollided(const std::vector<TrajectoryPoint>& to_test_path) const;

    /**
     * @brief Get obstacle cost for longitudinal search
     *
     * @param s is frenet coord
     * @param t is enquiried time
     * @param safe_distance is safe distance between ego car and obstacle
     * @param follow_time defines the follow distance to front car. Follow
     * distance is follow_time times two seconds
     * @param w_follow_to_near is weight of distance is lass than follow
     * distance
     * @param w_follow_to_far is weight of distance if more than follow distance
     *
     * @return obstacle cost at enquired (s, t)
     */
    double GetObstacleCost(const double s,
                           const double t,
                           const double w_follow_to_near,
                           const double w_follow_to_far) const;

    /**
     * @brief Get longitudinal bound and ref
     *
     * @param t_seq is enquried time sequence
     * @param safe_distance is safe distance between ego car and obstacle
     * @param follow_time defines the follow distance to front car. Follow
     * distance is follow_time times two seconds
     * @param upper_bound[out] is longitudinal upper bound
     * @param lower_bound[out] is longitudinal lower bound
     * @param ref[out] is longitudinal ref
     *
     * @return status
     */
    adStatus_t GetLongiBoundAndRef(const std::vector<double>& t_seq,
                                   const double curr_s,
                                   const double curr_speed,
                                   const double curr_acc,
                                   const double target_s,
                                   const double target_speed,
                                   std::vector<double>* lower_bound,
                                   std::vector<double>* upper_bound,
                                   std::vector<double>* ref);

    /**
     * @brief Get lateral bounds and ref
     *
     * @param t_seq is enquried time sequence
     * @param s_seq is enquried s sequence
     * @param safe_distance is lateral safe distance
     * @param lower_bound[out] is lateral lower bound
     * @param upper_bound[out] is lateral upper bound
     * @param ref[out] is lateral ref
     *
     * @return statue of get lateral bounds
     */
    adStatus_t GetLateralBoundAndRef(const std::vector<double>& t_seq,
                                     const std::vector<double>& s_seq,
                                     std::vector<double>* lower_bound,
                                     std::vector<double>* upper_bound,
                                     std::vector<double>* ref);

    /**
     * @brief Set search result to set tag for optimization
     *
     * @param longi_search_result is a rough longitudinal planning result
     *
     * @return status of setting
     */
    const std::unordered_map<int, Tag>& GetObstacleTag(
        const std::vector<double>& longi_search_result);

    /**
     * @brief Check Collision of test path in check range
     *
     * @param traj_to_test[in] is trajectory to be test
     * @param check_range[in] is index range of checking
     * @param collided_index[out] is collided index
     */
    const void CheckCollision(const std::vector<TrajectoryPoint>& traj_to_test,
                              const uint32_t check_range,
                              uint32_t* collided_index) const;

 private:
    PlanningScenario scenario_ = PlanningScenario::LANE_KEEPING;
    senseAD::roadStructure::RoadStructure<cv::Point2f> rs_;
    PredictionObjectArray poa_;
    std::shared_ptr<FrenetCoordinateSystem> frenet_system_;
    ObjectMap object_map_;
    double refline_invertal_ = 0.2;

    int debug_print_ = 1;
    double s_horizon_ = 80.0;
    double s_resolution_ = 2.0;
    double t_horizon_ = 8.0;
    double t_resolution_ = 0.2;

    double frenet_frame_extend_ = 20.0;
    double nbo_speed_ = 120.0 / 3.6;
    double nbo_distance_ = 200.0;
};
}  // namespace pp
}  // namespace senseAD
