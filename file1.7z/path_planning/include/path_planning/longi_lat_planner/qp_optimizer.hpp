/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#pragma once

#include <string>
#include <vector>
#include "common/error.hpp"
#include "eigen3/Eigen/Core"
#include "qpOASES.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/util.hpp"
#include "path_planning/common_structure.hpp"

namespace senseAD {
namespace pp {

typedef Eigen::VectorXd Vector;
typedef Eigen::MatrixXd Matrix;

class QPOptimizer {
 public:
    /**
     * @brief Initialize the QPOptimizer
     **/
    QPOptimizer();

    /**
     * @brief Destruct the QPOptimizer
     **/
    virtual ~QPOptimizer();

    /**
     * @brief Update last optimize result
     *
     * @param last_path is last optimize result
     * @param ref_seq is sequence of reference
     * @param qp_config is config parameters for solve qp optimization
     *
     * @return update state
     */
    adStatus_t Update(const std::vector<double>& last_seq,
                      const std::vector<double>& ref_seq,
                      const std::vector<double>& lower_bound,
                      const std::vector<double>& upper_bound,
                      const int num_look_back,
                      const QPConfig& qp_config,
                      const QPConfig& relax_qp_config);

    /**
     * @brief Plan paths to all goals and store them in out_path
     *
     * @param out_path vector of TrajectoryPoint
     *
     * @return flag to specify if succeed or fail
     **/
    adStatus_t Solve(std::vector<double>* out_path);

    /**
     * @brief set qp optimization config
     *
     * @param qp_config is qp optimization config
     */
    void SetConfig(const QPConfig& qp_config);

 private:
    /**
     * @brief Generate first derivative matrix using forward differential
     * method
     */
    void GenFirstDerivative();

    /**
     * @brief generate second derivative matrix using forward differential
     * method
     */
    void GenSecondDerivative();

    /**
     * @brief generate second derivative matrix using forward differential
     * method
     */
    void GenThirdDerivative();

    /**
     * @brief Generate sum matrix of first derivative using forward differential
     * method
     */
    void GenSumFirstDerivative();

    /**
     * @brief Generate sum matrix of second derivative using forward
     * differential method
     */
    void GenSumSecondDerivative();

    /**
     * @brief Generate sum matrix of third derivative using forward
     * differential method
     */
    void GenSumThirdDerivative();

    /**
     * @brief Setup matrix of qp optimization
     *
     * @return status of setup
     */
    adStatus_t SetupMatrix();

    /**
     * @brief Check constraints, lb <= ub, lbA <= ubA, and consitency
     * set up t_dim_
     *
     */
    void CheckConstraints();

    /**
     * @brief Print QP matrix to debug
     */
    void PrintQP() const;

    /**
     * @brief Print debug info including constraints and costs
     */
    void PrintDebugInfo() const;

    /**
     * @brief Relax constraints when qp solve failed
     */
    void RelaxConstraints();

    /**
     * @brief Solve core qp problem
     *
     * @param out_path is optimization result
     *
     * @return success if qp is succussfully return
     */
    adStatus_t SolveCore(std::vector<double>* out_path);

 private:
    int debug_print_ = 1;
    const double t_resolution_ = 0.2;

    QPConfig qp_config_;
    QPConfig relax_qp_config_;

    uint32_t t_dim_ = 41;
    uint32_t A_dim_ = 41;
    uint32_t s_dim_ = 41;

    uint32_t num_look_back_ = 0;
    // qp vectors and matrix
    double* lb_ = nullptr;
    double* ub_ = nullptr;
    double* lbA_ = nullptr;
    double* ubA_ = nullptr;
    double* g_ = nullptr;
    double* H_ = nullptr;
    double* A_ = nullptr;
    std::vector<double> last_seq_;
    std::vector<double> ref_;
    std::vector<double> lower_bound_;
    std::vector<double> upper_bound_;

    // qp helper matrix
    // TODO(Shengfa) try to use sparse matrix in eigen
    // TODO(Shengfa) try to make these matrix into static matrix
    Matrix first_derivative_;
    Matrix second_derivative_;
    Matrix third_derivative_;
    Matrix sum_first_derivative_;
    Matrix sum_second_derivative_;
    Matrix sum_third_derivative_;
    Matrix lbA_failed_;
    Matrix ubA_failed_;

    // qp solution, just for debug
    std::vector<double> solution_;
};

}  // namespace pp
}  // namespace senseAD
