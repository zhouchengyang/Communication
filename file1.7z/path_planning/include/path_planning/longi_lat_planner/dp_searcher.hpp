/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */
#pragma once

#include <vector>
#include "path_planning/common_structure.hpp"
#include "path_planning/util.hpp"
#include "path_planning/longi_lat_planner/st_graph_searcher.hpp"
#include "path_planning/ppconfig.hpp"

namespace senseAD {
namespace pp {

class DPSearcher : public STGraphSearcher {
 public:
    DPSearcher() {}

    typedef std::function<double(const double s,
                                 const double t,
                                 const double w_follow_to_near,
                                 const double w_follow_to_far)>
        func_get_obs_cost;
    /**
     * @brief Initialize the dp_searcher
     **/
    DPSearcher(const double s_horizon,
               const double s_resolution,
               const double t_horizon,
               const double t_resolution,
               func_get_obs_cost func_get_obs_cost)
        : s_horizon_(s_horizon),
          s_resolution_(s_resolution),
          t_horizon_(t_horizon),
          t_resolution_(t_resolution),
          GetObstacleCost(func_get_obs_cost) {
        auto core_conf = g_pp_conf["longi_lat_core"];
        auto dqq_setting = g_pp_conf["dqq_setting"];
        debug_print_ = dqq_setting["debug_print"];
        num_s_ = static_cast<uint32_t>(s_horizon_ / s_resolution_ + 1);
        num_t_ = static_cast<uint32_t>(t_horizon_ / t_resolution_ + 1);
        // setup cost table
        cost_table_ = std::vector<std::vector<STPoint>>(
            num_t_, std::vector<STPoint>(num_s_, STPoint()));
    }

    /**
     * @brief Destruct the dp_searcher
     **/
    virtual ~DPSearcher() {}

    /**
     * @brief Update vehicle speed and acc along with frenet frame
     *
     * @param vehicle_speed is speed along with frenet frame
     * @param vehicle_acc is accelaration along with frenet frame
     *
     * @return update status
     */
    adStatus_t Update(const double& longi_speed,
                      const double& longi_acc,
                      const double& speed_limit) override;

    /**
     * @brief Search on st graph to find (t, s) sequence
     * @param out_path is longitudinal result (t, s)
     * @return search status
     */
    adStatus_t Search(std::vector<double>* out_path) override;

 private:
    const double s_horizon_ = 80.0;
    const double s_resolution_ = 2.0;
    const double t_horizon_ = 8.0;
    const double t_resolution_ = 0.2;
    uint32_t num_s_;
    uint32_t num_t_;
    int debug_print_ = 1;
    // configs to be placed somewhere in the future
    // configs for lane keeping
    double speed_limit_ = 12.0;
    double w_acc_ = 0.1;
    double w_jerk_ = 0.05;
    double max_acc_ = 5.0;
    double max_deacc_ = -10.0;
    double max_jerk_ = 25.0;
    double safe_distance_ = 5.0;
    double w_exceed_speed_ = 20.0;
    double w_low_speed_ = 1.0;
    double follow_time_ = 2.0;
    double w_follow_to_far_ = 10.0;
    double w_follow_to_near_ = 100.0;
    double w_ahead_ = 1.0;
    // vehicle state along frenet frame
    double vehicle_speed_ = 0.0;
    double vehicle_acc_ = 0.0;

    func_get_obs_cost GetObstacleCost;

    // initialize with reserve
    std::vector<std::vector<STPoint>> cost_table_;
    double reacheable_time_ = 0.0;

 private:
    /**
     * @brief Get Vel Cost
     * @param first_point is pre st-point
     * @param second_point is current st-point
     * @param speed_limit is max speed, used to normalization
     * @return cost of velocity
     */
    double GetVelCost(const STPoint& first_point,
                      const STPoint& second_point,
                      const double speed_limit) const;

    /**
     * @brief Get acc cost
     * @param acc is acceleration
     * @return cost
     */
    double GetAccCost(const double acc) const;

    /**
     * @brief Get Acc Cost
     * @param pre_point is previous st-point
     * @param curr_point is current st-point
     * @param speed is initial speed of vehicle
     * @return cost of acceleration
     */
    double GetAccCost(const STPoint& pre_point,
                      STPoint curr_point,
                      const double speed) const;

    double GetAccCost(const STPoint& first_point,
                      const STPoint& second_point,
                      const STPoint& third_point) const;

    double GetJerkCost(const double jerk) const;

    double GetJerkCost(const double first_speed,
                       const double first_acc,
                       const STPoint& first_point,
                       const STPoint& second_point) const;

    double GetJerkCost(const double first_speed,
                       const STPoint& first_point,
                       const STPoint& second_point,
                       const STPoint& third_point) const;

    double GetJerkCost(const STPoint& first_point,
                       const STPoint& second_point,
                       const STPoint& third_point,
                       const STPoint& fourth_point) const;

    bool CalculateCostAt(const STPoint& st_point);

    double CalculateCostForSecondCol(const STPoint& curr_point) const;

    double CalculateCostForThirdCol(const STPoint& curr_point,
                                    const uint32_t s_pre_index) const;

    double CalculateEdgeCost(const STPoint& curr_point,
                             const uint32_t& s_pre_index) const;

    void CalcNextAvailabelSIndex(const uint32_t t_index,
                                 uint32_t* s_index_low,
                                 uint32_t* s_index_upp);

    adStatus_t ConstructCostTable();

    adStatus_t GenerateSpeedProfile(std::vector<double>* out_path);
};

}  // namespace pp
}  // namespace senseAD
