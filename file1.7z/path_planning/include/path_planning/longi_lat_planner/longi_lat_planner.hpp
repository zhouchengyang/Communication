/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#pragma once

#include <cassert>
#include <memory>
#include <string>
#include <vector>
#include "common/error.hpp"
#include "common/timing_logger.hpp"
#include "eigen3/Eigen/Core"
#include "eigen3/unsupported/Eigen/Splines"
#include "path_planning/baseplanner.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/longi_lat_planner/dp_searcher.hpp"
#include "path_planning/longi_lat_planner/parser.hpp"
#include "path_planning/longi_lat_planner/qp_optimizer.hpp"
#include "path_planning/longi_lat_planner/st_graph_searcher.hpp"
#include "path_planning/util.hpp"
#include "path_planning/frenet_coordinate_system.hpp"

namespace senseAD {
namespace pp {

struct PlanningState {
    // frenet coordinate s
    double s;
    // ds / dt, i.e. longitudinal speed
    double ds;
    // dds / (dt)^2, i.e. longitudinal acceleration
    double dds;
    // frenet coordinate d
    double d;
    // dd / dt, i.e. lateral speed
    double dd;
    // ddd / (dt)^2, i.e. lateral acceleration
    double ddd;

    const double velocity() const { return std::sqrt(ds * ds + dd * dd); }

    const double acceleration() const {
        return std::sqrt(dds * dds + ddd * ddd);
    }

    friend std::ostream& operator<<(std::ostream& out,
                                    const PlanningState& src) {
        out << "(" << src.s << ", " << src.d << ")"
            << ", (" << src.ds << ", " << src.dd << ")"
            << ", (" << src.dds << ", " << src.ddd << ")";
        return out;
    }
};

class SENSEAD_API LongiLatPlanner : public BasePathPlanner {
 public:
    /**
     * @brief Initialize the longitudinal and lateral planner
     **/
    LongiLatPlanner() {}

    /**
     * @brief Destruct the longitudinal and lateral planner
     **/
    virtual ~LongiLatPlanner() {}

    /**
     * @brief Initialize pathplanner with file
     *
     * @param config
     *
     * @return flag to specify if succeed or fail
     **/
    adStatus_t Init(const std::string& config) override;

    /**
     * @brief Plan paths to all goals and store them in out_path
     * @param out_path vector of TrajectoryPoint
     * @return flag to specify if succeed or fail
     **/
    adStatus_t Plan(std::vector<TrajectoryPoint>* out_path) override;

 private:
    /**
     * @brief Should cached path recycled right now
     *
     * @return ture if cached path is suitable for keep
     */
    bool ShouldRecycle();

    /**
     * @brief Update cachedpath due to vehicle state
     *
     * @return status of update
     */
    adStatus_t UpdateCachedPath();

    /**
     * @brief Update inital state of planning
     *
     * @return status of update
     */
    adStatus_t UpdateInitalState();

    /**
     * @brief Update interface
     *
     * 1. update routing line i.e. ref line
     * 2. update qp_config for longitudinal and lateral qp optimization, if
     * needed
     *
     * @return status
     */
    adStatus_t UpdateInterface();

    /**
     * @brief fillup trajectory with longitudinal and lateral result
     *
     * @param longi_result is longitudinal optimization result
     * @param lateral_result is lateral optimization result
     * @param out_path[out] is planning trajectory
     *
     * @return
     */
    adStatus_t FillupTrajectory(const std::vector<double>& longi_result,
                                const std::vector<double>& lateral_result,
                                std::vector<TrajectoryPoint>* out_path);

    /**
     * @brief Aplly emergency brake, when search or optimization failed
     *
     * @param out_path[int&out] planning trajectory
     *
     * @return statue of calculate emergency brack trajectory
     */
    adStatus_t ApplyEmergencyBrake(std::vector<double>* longi_s,
                                   std::vector<double>* lateral_d,
                                   std::vector<TrajectoryPoint>* out_path);

    /**
     * @brief Longitudinal search with dp search
     *
     * @param longi_result[out] is longitudianl planning result frenet-s
     * responding to time sequence
     *
     * @return status of longitudinal search
     */
    adStatus_t LongitudinalSearch(std::vector<double>* longi_result);

    /**
     * @brief Longitudinal plan with qp optimization
     *
     * @param longi_result[out] is longitudianl planning result frenet-s
     * responding to time sequence
     *
     * @return status of longitudinal planning
     */
    adStatus_t LongitudinalOptimize(
        const std::vector<double>& longi_search_result,
        std::vector<double>* longi_result);

    /**
     * @brief Lateral plan with qp optimization
     *
     * @param lateral_result[out] is lateral planning result frenet-d responding
     * to time sequence
     *
     * @return status of longitudinal planning
     */
    adStatus_t LateralOptimize(const std::vector<double>& longi_result,
                               std::vector<double>* lateral_result);

    /**
     * @brief Apply fall back, if something goes wrong, check collision of
     * cachedpath.
     * if there is no collision of cached path, apply it and count continuous
     * times of calculation fails.
     * if there is collision of cached path, have no choice but to emergency
     * brake
     *
     * @return success
    */
    adStatus_t ApplyFallback(std::vector<double>* longi_s,
                             std::vector<double>* lateral_d,
                             std::vector<TrajectoryPoint>* out_path);

    // this function will be removed once control is ready...
    // so I just skip the comments
    void PathElongation(std::vector<TrajectoryPoint>* path,
                        const float insert_distance) const;

 private:
    std::shared_ptr<STGraphSearcher> searcher_;
    std::shared_ptr<QPOptimizer> longi_optimizer_;
    std::shared_ptr<QPOptimizer> lat_optimizer_;
    Parser scene_interface_;
    std::vector<TrajectoryPoint> cached_path_;
    std::vector<double> last_longi_path_;
    // polynomial
    int poly_order_ = 7;
    polynomial<double> longi_poly_;
    polynomial<double> lateral_poly_;
    std::vector<double> last_lateral_path_;
    double last_planning_horizon_ = 0.0;
    PlanningState origin_point_;
    bool last_autodriving_status_on_ = false;
    int continous_solve_fail_ = 0;
    int continous_solve_fail_threshold_ = 5;
    bool use_cashed_path_flag_ = false;
    uint64_t last_timestamp_ = 0;

    std::vector<std::chrono::nanoseconds> durations_;
    bool is_last_brake_ = false;
    double stop_distance_ = 1000.0;

    double frent_resolution_ = 0.2;
    double routing_interval_ = 0.2;
    // planning begin at num_look_back * t_resolution
    uint32_t num_look_back_ = 3;
    double max_brake_acc_ = 7.0;
    double max_brake_jerk_ = -10.0;
    // origin vehicle state
    double longi_s_ = 0.0;
    double lateral_d_ = 0.0;
    double longi_speed_ = 0.0;
    double lateral_speed_ = 0.0;
    double longi_acc_ = 0.0;
    double lateral_acc_ = 0.0;

    double s_horizon_ = 80.0;
    double s_resolution_ = 2.0;
    double t_horizon_ = 8.0;
    double t_resolution_ = 0.2;

    double speed_limit_ = 11.11;
    double speed_ref_ = 11.11;
    double curr_speed_limit_ = 11.11;
    double curr_speed_ref_ = 11.11;
    double curr_s_ref_ = 200.0;
    double longi_safe_distance_ = 5.0;    // unit, m
    double stop_line_buffer_ = 2.0;       // unit, m
    double lateral_safe_distance_ = 0.3;  // unit, m
    double follow_time_ = 3.0;            // uint, s
    double nbo_reponse_range_ = 40.0;     // unit, m

    // TODO(Shengfa) set qp config based on scenario
    // just in case initial longitudinal s is negative
    double longi_lower_limit_ = -100.0;
    double longi_upper_limit_ = speed_limit_ * s_horizon_;
    double longi_lower_rate_limit_ = 0.0;
    // a little exceed speed is allowed
    double overspeed_percentage_ = 1.1;
    double longi_upper_rate_limit_ = speed_limit_ * overspeed_percentage_;
    double longi_lower_second_deriv_limit_ = -10.0;
    double longi_upper_second_deriv_limit_ = 5.0;
    double longi_lower_third_deriv_limit_ = -10.0;
    double longi_upper_third_deriv_limit_ = 5.0;
    // weight of longitudinal optimization
    double longi_w_ref_ = 1.0;
    double longi_w_first_order_ = 0.0;
    double longi_w_second_order_ = 20.0;
    double longi_w_third_order_ = 1.0;
    double longi_w_start_ = 0.0;
    double longi_decay_rate_ = 0.2;
    // speed of leading front car, used to determine recycle
    double leading_speed_ = speed_limit_;
    double replan_leading_speed_threshold_ = 1.0;

    double lateral_lower_limit_ = -100.0;
    double lateral_upper_limit_ = 100.0;
    double lateral_lower_rate_limit_ = -2.0;
    double lateral_upper_rate_limit_ = 2.0;
    double lateral_lower_second_deriv_limit_ = -10.0;
    double lateral_upper_second_deriv_limit_ = 3.0;
    double lateral_lower_third_deriv_limit_ = -10.0;
    double lateral_upper_third_deriv_limit_ = 10.0;
    double lateral_w_ref_ = 1.0;
    double lateral_w_first_order_ = 3.0;
    double lateral_w_second_order_ = 0.0;
    double lateral_w_third_order_ = 0.0;
    double lateral_w_start_ = 0.0;
    double lateral_decay_rate_ = 0.1;
};

}  // namespace pp
}  // namespace senseAD
