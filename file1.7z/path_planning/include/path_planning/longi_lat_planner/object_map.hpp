/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */
#pragma once

#include <algorithm>
#include <unordered_map>
#include <vector>
#include <map>
#include <memory>
#include "path_planning/common_structure.hpp"
#include "path_planning/predict_map.hpp"
#include "path_planning/frenet_coordinate_system.hpp"

namespace senseAD {
namespace pp {

class ObjectMap : public PredictMap {
 public:
    ObjectMap() {}

    adStatus_t Init();

    adStatus_t Update(
        const PredictionObjectArray& poa,
        const std::shared_ptr<FrenetCoordinateSystem>& frenet_system,
        const double change_start_time,
        const double change_end_time,
        const ChangeDirection change_direction,
        const bool lane_change_activated = false);

    /**
     * @brief calculate obstacle cost
     **/
    double GetObstacleCost(const double s,
                           const double t,
                           const double w_follow_to_near,
                           const double w_follow_to_far) const;

    const std::unordered_map<int, Tag>& GetObstacleTag(
        const std::vector<double>& longi_search_result);

    adStatus_t GetLongiBoundAndRef(const std::vector<double>& t_seq,
                                   const double curr_s,
                                   const double curr_peed,
                                   const double curr_acc,
                                   const double target_s,
                                   const double target_speed,
                                   std::vector<double>* lower_bound,
                                   std::vector<double>* upper_bound,
                                   std::vector<double>* ref_seq);

    adStatus_t GetLateralBoundAndRef(const std::vector<double>& t_seq,
                                     const std::vector<double>& s_seq,
                                     std::vector<double>* lower_bound,
                                     std::vector<double>* upper_bound,
                                     std::vector<double>* ref_seq);

    adStatus_t ConstructSIntervals();

    /**
     * @brief Find NBO(non-blocking obstacle) and get nbo speed as longi
     * planning reference
     *
     */
    void FindNBO();

 private:
    /**
     * @brief Choose leader car to determine leader speed and distance
     *
     * @param v_limit[in] is speed limit of road
     * @param v_leader[out] is speed of leader car
     * @param s_leader[out] is distance of leader car
     */
    void ChooseLeaderCar(const double v_limit,
                         double* v_leader,
                         double* s_leader) const;

    /**
     * @brief Choose target speed of s_ref based on leader car
     *
     * @param v_limit is speed limit of road
     *
     * @return target speed of s_ref
     */
    const double ChooseTargetSpeed(const double v_limit);

    adStatus_t GetSpeed(const int obj_id,
                        const double t,
                        const cv::Point2f& heading_bpp,
                        double* min_speed,
                        double* max_speed) const;

    void GetSDBound(const std::vector<cv::Point2f>& sd_seq,
                    double* s_min,
                    double* s_max,
                    double* d_min,
                    double* d_max) const;

    void CalculateLateralRef(const std::vector<double>& t_seq,
                             std::vector<double>* ref_seq) const;

    /**
     * @brief calculate object id (one-hot) with union bit-operation between
     * given index_start and index_end
     *
     * @param index_start is lateral start index
     * @param index_end is lateral end indexx
     *
     * @return obj_id in given region
     */
    decltype(obj_type_) CalculateObjId(const int index_start,
                                       const int index_end) const {
        uint32_t d_index_start =
            std::min(std::max(static_cast<int>(0), index_start),
                     static_cast<int>(num_d_grid_ - 1));
        uint32_t d_index_end =
            std::min(std::max(static_cast<int>(0), index_end),
                     static_cast<int>(num_d_grid_ - 1));
        decltype(obj_type_) obj_id = 0;
        for (uint32_t d_index = d_index_start; d_index <= d_index_end;
             ++d_index) {
            for (uint32_t t_index = 0;
                 t_index < static_cast<uint32_t>(num_time_layers_); ++t_index) {
                for (uint32_t s_index = 0;
                     s_index < static_cast<uint32_t>(num_s_front_grid_);
                     ++s_index) {
                    uint32_t index = TripleToOne(t_index, s_index, d_index);
                    obj_id = obj_id | cells_3d_.GetCell(index);
                }
            }
        }
        return obj_id;
    }

    /**
     * @brief calculate obj_id and vector of object id compressed in d direction
     *
     * @param index_start is lateral start index
     * @param index_end is lateral end indexx
     * @param obj_vec[out] is vector of object id compressed in d direction
     */
    decltype(obj_type_) CalculateObjId(
        const int index_start,
        const int index_end,
        std::vector<std::vector<decltype(obj_type_)>>* obj_vec) const {
        if (obj_vec == nullptr) {
            AD_LERROR(ObjectMap) << "obj_vec is nullptr";
            return decltype(obj_type_)(0);
        }
        uint32_t d_index_start =
            std::min(std::max(static_cast<int>(0), index_start),
                     static_cast<int>(num_d_grid_ - 1));
        uint32_t d_index_end =
            std::min(std::max(static_cast<int>(0), index_end),
                     static_cast<int>(num_d_grid_ - 1));
        decltype(obj_type_) obj_id = 0;
        obj_vec->clear();
        *obj_vec = std::vector<std::vector<decltype(obj_type_)>>(
            num_time_layers_,
            std::vector<decltype(obj_type_)>(num_s_front_grid_, 0));
        for (uint32_t t_index = 0;
             t_index < static_cast<uint32_t>(num_time_layers_); ++t_index) {
            for (uint32_t s_index = 0;
                 s_index < static_cast<uint32_t>(num_s_front_grid_);
                 ++s_index) {
                decltype(obj_type_) curr_obj_id = 0;
                for (uint32_t d_index = d_index_start; d_index <= d_index_end;
                     ++d_index) {
                    uint32_t index = TripleToOne(t_index, s_index, d_index);
                    curr_obj_id = curr_obj_id | cells_3d_.GetCell(index);
                }
                obj_id = obj_id | curr_obj_id;
                obj_vec->at(t_index).at(s_index) = curr_obj_id;
            }
        }
        return obj_id;
    }

    /**
     * @brief Set the longitudinal reference based kinetic arguements
     *
     * @param t_seq is sequence of time
     * @param init_s is current frenet coordinate s
     * @param init_speed is current longitudinal speed
     * @param init_acc is current longitudinal acceleration
     * @param target_s is target frenet coordinate s
     * @param target_speed is target speed at given target_s
     * @param speed_lower_limit is lower limit value of speed
     * @param speed_upper_limit is upper limit value of speed
     * @param acc_lower_limit is lower limit value of acceleration
     * @param acc_upper_limit is upper limit value of acceleration
     * @param result_seq is calulation result with given parameters
     */
    void SetLongiRef(const std::vector<double>& t_seq,
                     const double init_s,
                     const double init_speed,
                     const double init_acc,
                     const double target_s,
                     const double target_speed,
                     const double speed_lower_limit,
                     const double speed_upper_limit,
                     const double acc_lower_limit,
                     const double acc_upper_limit,
                     std::vector<double>* result_seq) const;

    /**
     * @brief Calc follow distance between ego car and front car
     *
     * @param front_v is speed of front car
     * @param ego_v is speed of ego car
     *
     * @return follow distance btween ego car and front car
     */
    const double CalcFollowDistance(const double front_v,
                                    const double ego_v) const;

    /**
     * @brief Calculate speed and distance of NBO
     *
     * @param nbo_speed[out] is speed of nearest NBO
     * @param nbo_distance[out] is distance of nearest NBO
     */
    void CalcNBOSpeedAndDistance(const std::vector<decltype(obj_type_)>& st_seq,
                                 double* nbo_speed,
                                 double* nbo_distance) const;

 private:
    double s_horizon_ = 80.0;
    double t_horizon_ = 8.0;
    double s_resolution_ = 2.0;
    double t_resolution_ = 0.2;
    double change_start_time_ = 8.0;
    double change_end_time_ = 8.0;
    ChangeDirection change_direction_ = ChangeDirection::NO_CHANGE;
    uint32_t num_t_ = 0;
    uint32_t num_s_ = 0;
    int debug_print_ = 1;
    double longi_overlap_threshold_ = 7.5;
    int nbo_counter_threshold_ = 3;
    int bo_counter_threshold_ = 3;
    double lane_width_ = 3.5;
    double ref_acc_ = 0.8f;
    double ref_deacc_ = -0.8f;
    double ref_jerk_ = 0.4f;
    double change_period_ = 6.0;
    double follow_time_ = 3.0;
    double longi_safe_distance_ = 5.0;
    double longi_dp_safe_distance_rear_ratio_ = 2.0;
    double longi_dp_safe_distance_ = 3.0;
    double longi_stop_distance_ = 8.0;
    double time_to_collision_ = 1.8;
    double max_deacc_vehicle_ = 9.8;
    double lateral_safe_distance_ = 0.3;

    std::map<int, int> nbo_counter;
    std::map<int, int> bo_counter_;
    // replace by map api in the future
    decltype(obj_type_) NBO_obj_ = 0;
    // map from id of obstacle to its tag(SURPASS or YEILD)
    std::unordered_map<int, Tag> obs_tag_;
    std::vector<std::vector<SBound<decltype(obj_type_)>>> s_intervals_;

    // nbo_speed
    double nbo_speed_ = 120.0 / 3.6;         // unit, m
    double nbo_distance_ = kMax;             // unit, m
    double target_speed_old_ = 120.0 / 3.6;  // unit, m
};

}  // namespace pp
}  // namespace senseAD
