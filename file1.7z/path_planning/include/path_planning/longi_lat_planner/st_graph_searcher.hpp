/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#pragma once

#include <string>
#include <vector>
#include "common/error.hpp"
#include "common/data_type/trajectory_point.hpp"

namespace senseAD {
namespace pp {

class STGraphSearcher {
 public:
    STGraphSearcher() {}

    /**
     * @brief Destruct the st_graph search
     **/
    virtual ~STGraphSearcher() {}

    /**
     * @brief Update longitudianl speed and acceralatin
     *
     * @param longi_speed is *longitudinal speed*
     * @param longi_acc is longitudinal acceralation
     *
     * @return status of update
     */
    virtual adStatus_t Update(const double& longi_speed,
                              const double& longi_acc,
                              const double& speed_limit) = 0;

    /**
     * @brief search on ST graph
     * @return rough trajectory
     **/
    virtual adStatus_t Search(std::vector<double>* out_path) = 0;
};

}  // namespace pp
}  // namespace senseAD
