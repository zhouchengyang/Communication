/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#pragma once

#include <vector>
#include <string>
#include <memory>
#include <map>
#include <set>
#include <chrono>  // NOLINT
#include <opencv2/opencv.hpp>
#include "common/error.hpp"
#include "common/sensead_api_attribute.hpp"
#include "common/timing_logger.hpp"
#include "common/data_type/road_base.hpp"
#include "common/data_type/road_structure.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/data_type/object_recovery.hpp"

namespace senseAD {
namespace pp {
class SENSEAD_API GridMap {
    // Coordinate system obey the body standard of ROS:
    // (x forward, y left, z up)
    // See this link: http://www.ros.org/reps/rep-0103.html
 public:
    GridMap();
    ~GridMap();
    adStatus_t Init();

    adStatus_t Update(roadStructure::RoadStructure<cv::Point2f> *rs,
                      ObjectTrajectory *object_trajectory);

    adStatus_t Update(roadStructure::RoadStructure<cv::Point2f> *rs);

    // type:
    // 0: normal laneline cut the freespace
    // 1: no laneline cut, use physical freespace
    // 2: add laneline cut after some meter
    adStatus_t Refresh(int32_t type,
                       std::string road_id,
                       std::string l_lanelineid = "",
                       std::string r_lanelineid = "");

    inline adStatus_t is_free(const cv::Point2f &pt, char *in_free_space) {
        AD_LTRACE(PATH_PLANNING) << "GridMap checking Risk " << pt;
        int32_t x, y;
        if (in_free_space == nullptr) {
            SD_CHECK_ERROR(AD_NULL_PTR);
        }
        cv::Point2f pt_cvt = convert_to_gridmap_coordinate(pt);
        x = int32_t(-pt_cvt.y / this->per_grid_meter + this->map_ww / 2);
        y = int32_t(-pt_cvt.x / this->per_grid_meter + this->map_hh / 2);
        if (x < 0 || y < 0 || x >= this->map_ww || y >= this->map_hh) {
            // if out of gridmap region, consider as valid
            // if need fix bonnet,
            // we consider all pixel that might be fixed as valid.
            *in_free_space =
                static_cast<char>(this->as_free_measure_length + 1);
            return AD_SUCCESS;
        }
        char *data = reinterpret_cast<char *>(map.data);
        *in_free_space = data[y * this->map_ww + x];
        AD_LTRACE(PATH_PLANNING) << "GridMap Got Risk "
                                 << static_cast<int>(*in_free_space);
        return AD_SUCCESS;
    }

    inline adStatus_t is_free(const cv::Point2f &pt, bool *in_free_space) {
        AD_LTRACE(PATH_PLANNING) << "GridMap checking Collision " << pt;
        if (in_free_space == nullptr) {
            SD_CHECK_ERROR(AD_NULL_PTR);
        }
        char x;
        x = 0;
        this->is_free(pt, &x);
        if (x >= this->min_value_as_free) {
            *in_free_space = true;
        } else {
            *in_free_space = false;
        }
        AD_LTRACE(PATH_PLANNING) << "GridMap got collision check "
                                 << *in_free_space;
        return AD_SUCCESS;
    }
    adStatus_t Reconf();
    adStatus_t LoadMapFromFile(std::string filename);

    int32_t map_hh, map_ww;
    char dot_default_scalar;
    char init_draw_color;
    float32_t map_maxrealh, map_maxrealw;
    float32_t per_grid_meter;
    float32_t out_as_free;
    int32_t fix_bonnet_xx, fix_bonnet_yy, fix_bonnet_ww, fix_bonnet_hh;
    int32_t min_value_as_free;
    int32_t as_free_measure_length;
    bool if_fix_bonnet;
    bool if_optimize;
    bool if_applybonnetfix_final;
    cv::Point2f centerenu;

 private:
    cv::Mat map, dot_map;
    std::vector<int32_t> xx;
    std::vector<int32_t> yy;
    std::vector<bool> ifvisit;
    std::vector<int32_t> qx;
    std::vector<int32_t> qy;

    roadStructure::RoadStructure<cv::Point2f> *rs_ = nullptr;
    ObjectTrajectory *object_trajectory_ = nullptr;
    void draw_sr_freespacemap();
    void draw_cone_freespacemap();
    void draw_laneline_dotmap(roadStructure::LaneLine<cv::Point2f> lanel,
                              roadStructure::LaneLine<cv::Point2f> laner);
    void crop_out_illegal_lanes_in_a_road(std::string road_id);
    void crop_out_illegal_lane(roadStructure::LaneLine<cv::Point2f> lanel,
                               roadStructure::LaneLine<cv::Point2f> laner);
    void rewrite_freespacemap();
    inline cv::Point2f convert_to_gridmap_coordinate(cv::Point2f enu_pts) {
        return enu_pts - centerenu;
    }
};

}  // namespace pp
}  // namespace senseAD

