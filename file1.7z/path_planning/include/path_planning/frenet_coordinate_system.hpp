/*
 * Copyright (C) 2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#pragma once

#include <vector>
#include <opencv2/opencv.hpp>

#include "common/data_type/base.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/nn_tool.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/util.hpp"

namespace senseAD {
namespace pp {
class FrenetCoordinateSystem {
 public:
    /**
     * @brief FrenetCoordinateSystem is default constructor function
     */
    FrenetCoordinateSystem() {}

    /**
     * @brief Init the parameters of frenet coordinate system
     */
    void Init();

    /**
     * @brief Update the frenet coordinate system
     *
     * @param points represent s-axis of frenet coordinate system
     * @param origin_index is indicates the index of points, which is the origin
     * of frenet coordinate system
     *
     * @return true if input parameters are valid, else return false:
     */
    bool Update(const std::vector<TrajectoryPoint>& points,
                const uint32_t origin_index = 0);

    /**
     * @brief Update the frenet coordinate system
     *
     * @param points represent s-axis of frenet coordinate system
     * @param origin_point indicats the origin of frenet coordinate system, that
     * is the nearest point to origin_point in points
     *
     * @return true if input parameters are valid, else return false:
     */
    bool Update(const std::vector<TrajectoryPoint>& points,
                const cv::Point2f& origin_point);

    /**
     * @brief ~FrenetCoordinateSystem is default deconstructor function
     */
    ~FrenetCoordinateSystem() {}

    /**
     * @brief Frenet2Cartesian converts coordinate from frenet to cartesian
     *
     * @param s is s-coordinate of frenet system
     * @param d is d-coordinate of frenet system
     *
     * @return cartesian coordinates
     */
    cv::Point2f Frenet2Cartesian(const float s, const float d) const;

    /**
     * @brief Cartesian2Frenet converts coordinate from cartesian to frenet
     *
     * @param cartesian_point is coordiantes of cartesian system
     *
     * @return frenet coordinates
     */
    cv::Point2f Cartesian2Frenet(const cv::Point2f& cartesian_point) const;

    /**
     * @brief GetHeadingAtS calculate heading of frenet s-axis at given s
     *
     * @param s is s-coordinate
     *
     * @return heading angle
     */
    float GetHeadingAtS(const float s) const;

    /**
     * @brief IsValid indicate whether the frenet coordinate system is valid or
     * not
     *
     * @return status of frenet coordinate system
     */
    const bool IsValid() const;

 private:
    /**
     * @brief UpdateReflineAndOrigin update reference line and origin of frenet
     * coordinate system
     *
     * @param points is vector of refline
     * @param origin_point defines the origin point of frenet coordinate system
     *
     * @return true if refline is valid, else return false
     */
    bool UpdateReflineAndOrigin(const std::vector<TrajectoryPoint>& points,
                                const cv::Point2f& origin_point);

    /**
     * @brief CalcSDFromFront calculates frenet coordinates from the front of
     * refline
     *
     * @param cart_point is cartesina point
     *
     * @return frenet coordinates from the front of refline
     */
    const cv::Point2f CalcSDFromFront(const cv::Point2f& cart_point) const;

 private:
    NNTool nn_tool_;
    // sum distance from origin_point to first point of s-axis
    float start_sum_distance_ = 0.0f;  // unit, m
    // insert distance of s-axis
    const float frenet_resolution_ = 0.2f;  // unit, m
    // refline
    std::vector<TrajectoryPoint> ref_line_;
    // flag of valid or not
    bool is_valid_ = false;
};

}  // namespace pp
}  // namespace senseAD

