/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include <fstream>
#include <chrono>  // NOLINT
#include "gtest/gtest.h"
#include "common/log.hpp"
#include "common/serialization/serialization.hpp"
#include "path_planning/util.hpp"
#include "path_planning/nn_tool.hpp"
#include "common/utils/configuration_reader.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/predict_map.hpp"
#include "path_planning/longi_lat_planner/object_map.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/longi_lat_planner/qp_optimizer.hpp"
#include "path_planning/frenet_coordinate_system.hpp"

// #define API_SHOW_
// #define DETECTOR_SHOW

#ifndef GFLAGS_GFLAGS_H_
namespace gflags = google;
#endif  // GFLAGS_GFLAGS_H_

int main(int argc, char *argv[]) {
    google::InitGoogleLogging(argv[0]);
    google::InstallFailureSignalHandler();
    testing::InitGoogleTest(&argc, argv);
    gflags::ParseCommandLineFlags(&argc, &argv, true);
    return RUN_ALL_TESTS();
}

TEST(PredictMap, Refresh) {
    // 0. setup environmnet
    std::string data_dir = "./path_planning_test_data/";
    std::vector<senseAD::TrajectoryPoint> base_path;
    EXPECT_EQ(senseAD::pp::g_pp_conf.Init("./config/pp_config.ini"),
              senseAD::AD_SUCCESS);

    senseAD::pp::PredictMap predict_map;
    predict_map.Init();

    senseAD::common::utils::ConfigurationReader::LoadJSON(
        data_dir + "basepath.json", &base_path);

    std::shared_ptr<senseAD::pp::FrenetCoordinateSystem> frenet_system;
    frenet_system.reset(new senseAD::pp::FrenetCoordinateSystem());
    frenet_system->Init();
    frenet_system->Update(base_path);
    senseAD::PredictionObjectArray poa;
    senseAD::common::utils::ConfigurationReader::LoadJSON(
        data_dir + "PredictionResult.json", &poa);
    predict_map.Update(poa, frenet_system);
    // 1. test
    EXPECT_EQ(predict_map.Refresh(), senseAD::AD_SUCCESS);
}
