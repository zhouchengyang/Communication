/*
 * Copyright (C) 2019-2020 by SenseTime Group Limited. All rights reserved.
 * Shengfa Zhu <zhushengfa@sensetime.com>
 */

#include <fstream>
#include <chrono>  // NOLINT
#include "gtest/gtest.h"
#include "common/log.hpp"
#include "common/serialization/serialization.hpp"
#include "path_planning/util.hpp"
#include "common/utils/configuration_reader.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "path_planning/common_structure.hpp"
#include "path_planning/ppconfig.hpp"
#include "path_planning/frenet_coordinate_system.hpp"

// #define API_SHOW_
// #define DETECTOR_SHOW

#ifndef GFLAGS_GFLAGS_H_
namespace gflags = google;
#endif  // GFLAGS_GFLAGS_H_

int main(int argc, char* argv[]) {
    google::InitGoogleLogging(argv[0]);
    google::InstallFailureSignalHandler();
    testing::InitGoogleTest(&argc, argv);
    gflags::ParseCommandLineFlags(&argc, &argv, true);
    return RUN_ALL_TESTS();
}

TEST(FrenetCoordinateSystem, Frenet2Cartesian) {
    // 0. setup environmnet
    std::string data_dir = "./path_planning_test_data/";
    std::vector<senseAD::TrajectoryPoint> base_path;
    senseAD::common::utils::ConfigurationReader::LoadJSON(
        data_dir + "basepath.json", &base_path);
    senseAD::pp::g_pp_conf.Init("./config/pp_config.ini");

    // test
    senseAD::pp::FrenetCoordinateSystem frenet_system;
    frenet_system.Init();

    uint32_t origin_index = 50;
    EXPECT_EQ(
        frenet_system.Update(base_path, base_path.at(origin_index).position),
        true);

    float s = 150.0f, d = 0.0f;
    cv::Point2f cartesian_point = frenet_system.Frenet2Cartesian(s, d);
    std::cout << cv::norm(cartesian_point - base_path.back().position)
              << std::endl;
}

TEST(FrenetCoordinateSystem, Cartesian2Frenet) {
    // 0. setup environmnet
    std::string data_dir = "./path_planning_test_data/";
    std::vector<senseAD::TrajectoryPoint> base_path;
    senseAD::common::utils::ConfigurationReader::LoadJSON(
        data_dir + "basepath.json", &base_path);
    senseAD::pp::g_pp_conf.Init("./config/pp_config.ini");

    // test
    senseAD::pp::FrenetCoordinateSystem frenet_system;
    frenet_system.Init();

    uint32_t origin_index = 50;
    EXPECT_EQ(frenet_system.Update(base_path, origin_index), true);

    float s = 50.6f, d = -10.0f;
    uint32_t index = static_cast<uint32_t>(s / 0.2) + origin_index;
    cv::Point2f direction = base_path.at(index).direction;
    cv::Point2f vertical = cv::Point2f(-1.0 * direction.y, direction.x);
    cv::Point2f cartesian_point = base_path.at(index).position + d * vertical;
    cv::Point2f frenet_point = frenet_system.Cartesian2Frenet(cartesian_point);
    std::cout << frenet_point << std::endl;
}

TEST(FrenetCoordinateSystem, GetHeadingAtS) {
    // 0. setup environmnet
    std::string data_dir = "./path_planning_test_data/";
    std::vector<senseAD::TrajectoryPoint> base_path;
    senseAD::common::utils::ConfigurationReader::LoadJSON(
        data_dir + "basepath.json", &base_path);
    senseAD::pp::g_pp_conf.Init("./config/pp_config.ini");

    // test
    senseAD::pp::FrenetCoordinateSystem frenet_system;
    frenet_system.Init();

    uint32_t origin_index = 50;
    EXPECT_EQ(frenet_system.Update(base_path, origin_index), true);

    float s = 50.6f;
    uint32_t index = static_cast<uint32_t>(s / 0.2) + origin_index;
    cv::Point2f direction = base_path.at(index).direction;
    float heading = frenet_system.GetHeadingAtS(s);
    std::cout << std::atan2(direction.y, direction.x) << std::endl
              << heading << std::endl;
}
