/*
 * Copyright (C) 2018-2020 by SenseTime Group Limited. All rights reserved.
 * Guo Yingdi <guoyingdi@sensetime.com>
 */

#include <fstream>
#include "gtest/gtest.h"
#include "common/log.hpp"
//#include "gflags/gflags.h"
#include "common/serialization/serialization.hpp"
#include "path_planning/rrt_node.hpp"
#include "path_planning/rrt_core.hpp"
#include "path_planning/baseplanner.hpp"
#include "path_planning/quinticsplinesmooth.hpp"
#include "path_planning/util.hpp"
#include "path_planning/planner_core.hpp"
#include "path_planning/nn_tool.hpp"
#include "common/data_type/trajectory_point.hpp"
#include "common/utils/configuration_reader.hpp"
#include <chrono>  // NOLINT
// #define API_SHOW_
// #define DETECTOR_SHOW

#ifndef GFLAGS_GFLAGS_H_
namespace gflags = google;
#endif  // GFLAGS_GFLAGS_H_

int main(int argc, char *argv[]) {
    google::InitGoogleLogging(argv[0]);
    google::InstallFailureSignalHandler();
    testing::InitGoogleTest(&argc, argv);
    gflags::ParseCommandLineFlags(&argc, &argv, true);
    return RUN_ALL_TESTS();
}

TEST(PlannCore, plann_core_test) {
    EXPECT_EQ(senseAD::pp::g_pp_conf.Init("./config/pp_config.ini"),
              senseAD::AD_SUCCESS);
    auto core_conf = senseAD::pp::g_pp_conf["pp_core"];
    std::string pp_type = core_conf["pp_core"];

    auto planner_core = senseAD::pp::PlannerCore::CreatePlanner(pp_type);
    EXPECT_NE(planner_core, nullptr);
    planner_core->RegisterCheckCollisionPlug(
        [](const cv::Point2f &position, bool *pass_check) {
            *pass_check = true;
            return senseAD::AD_SUCCESS;
        });
    planner_core->RegisterCheckSceneRiskPlug(
        [](const cv::Point2f &position, char *risk) {
            // risk is char type, should be make risk > 0
            *risk = 127;
            return senseAD::AD_SUCCESS;
        });

    planner_core->RegisterWarpPointPlug(
        [](cv::Point2f *point) { return senseAD::AD_SUCCESS; });

    if (pp_type == "RRTCore") {
        std::dynamic_pointer_cast<senseAD::pp::RRTCore>(planner_core)
            ->RegisterFrenetCollisionPlug([](
                float s, float d, float heading, float t, float longi_safe_dist,
                float lat_safe_dist, bool *pass_check) {
                *pass_check = true;
                return senseAD::AD_SUCCESS;
            });
        std::dynamic_pointer_cast<senseAD::pp::RRTCore>(planner_core)
            ->RegisterFrenetRiskPlug([](float s, float d, float heading,
                                        float t, float longi_safe_dist,
                                        float lat_safe_dist, int *risk) {
                *risk = 0;
                return senseAD::AD_SUCCESS;
            });
    }
    EXPECT_EQ(planner_core->Init(), senseAD::AD_SUCCESS);

    std::string pp_test_data_dir = "./path_planning_test_data/";
    // load test case
    std::ifstream fin(pp_test_data_dir + "rrttreetest1.txt", std::ios::in);

    int n;
    std::vector<senseAD::pp::RRTNode> nodes;
    std::vector<cv::Point2f> init_points;
    std::vector<int> path_res;
    cv::Point2f endir, goal, direction;
    fin >> n >> endir.x >> endir.y >> goal.x >> goal.y >> direction.x >>
        direction.y;

    std::vector<senseAD::TrajectoryPoint> base_path, output, cached_path;
    senseAD::TrajectoryPoint single_start, single_goal;
    single_start.position.x = single_start.position.y = 0;
    single_start.direction = endir;
    single_goal.position = goal;
    single_goal.direction = direction;
    single_goal.velocity = single_start.velocity = 0.0;
    single_goal.theta = single_start.theta = 0.0f;
    single_goal.curvature = single_start.curvature = 0.0f;
    single_goal.sum_distance = single_start.sum_distance = 0.0;
    single_goal.time_difference = single_start.time_difference = 0.0;
    single_goal.yaw_rate = single_start.yaw_rate = 0.0;
    single_goal.acceleration = single_start.acceleration = 0.0;
    single_goal.timestamp = single_start.timestamp = 0;
    single_goal.gear = single_start.gear =
        senseAD::ControlCommand::GEAR::GEAR_NONE;
    single_goal.turn_signal = single_start.turn_signal =
        senseAD::ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;
    for (int i = 0; i < n; i++) {
        senseAD::TrajectoryPoint p;
        fin >> p.position.x >> p.position.y;
        p.direction.x = 1;
        p.position.y = 0;
        base_path.push_back(p);
    }

    EXPECT_EQ(planner_core->Update(
                  base_path, single_start, single_goal,
                  senseAD::pp::VPPurpose::KEEP_UP_NON_ZERO_VELOCITY, 40,
                  cached_path, senseAD::pp::ReplanFlag::PATH_SPEED_REPLAN),
              senseAD::AD_SUCCESS);
    if (pp_type == "RRTCore") {
        std::vector<cv::Point2f> random_points;
        for (int32_t i = 0; i < 100; i++) {
            random_points.emplace_back(static_cast<float>(random() % 30),
                                       static_cast<float>(random() % 10));
        }
        std::dynamic_pointer_cast<senseAD::pp::RRTCore>(planner_core)
            ->SetRandomPointsForTest(random_points);
    }

    EXPECT_EQ(planner_core->Plan(&output), senseAD::AD_SUCCESS);
}
/*
TEST(PoseWarp, pose_warp_test) {
    senseAD::pp::PoseWarp pose_warp;
    senseAD::VehicleInfo veh_info;
    std::shared_ptr<senseAD::Car_Trajectory> car_trajectory;
    car_trajectory.reset(new senseAD::Car_Trajectory());
    EXPECT_EQ(pose_warp.SetVehicleInfo(veh_info), senseAD::AD_SUCCESS);
    for (uint32_t i = 0; i < 10; i++) {
        cv::Point2f point(0, 0);
        senseAD::pp::VehicleState veh_state;
        uint64_t time;
        // EXPECT_NE(pose_warp.Advance(&time), senseAD::AD_SUCCESS);
        EXPECT_EQ(pose_warp.WarpPoint(&point), senseAD::AD_SUCCESS);
        EXPECT_EQ(point, cv::Point2f(0, 0));
    }
}
*/
TEST(VelocityPlanner, velocityplannertest) {
    std::string pp_test_data_dir = "./path_planning_test_data/";
    // load test case
    std::ifstream fin(pp_test_data_dir + "rrttreetest1.txt", std::ios::in);

    int n;
    std::vector<senseAD::pp::RRTNode> nodes;
    std::vector<cv::Point2f> init_points;
    std::vector<int> path_res;
    cv::Point2f endir, goal, direction;
    fin >> n >> endir.x >> endir.y >> goal.x >> goal.y >> direction.x >>
        direction.y;

    std::vector<senseAD::TrajectoryPoint> base_path, output;
    senseAD::TrajectoryPoint single_start, single_goal;
    single_start.position.x = single_start.position.y = 0;
    single_start.direction = endir;
    single_goal.position = goal;
    single_goal.direction = direction;
    single_goal.velocity = single_start.velocity = 0.0;
    single_goal.theta = single_start.theta = 0.0f;
    single_goal.curvature = single_start.curvature = 0.0f;
    single_goal.sum_distance = single_start.sum_distance = 0.0;
    single_goal.time_difference = single_start.time_difference = 0.0;
    single_goal.yaw_rate = single_start.yaw_rate = 0.0;
    single_goal.acceleration = single_start.acceleration = 0.0;
    single_goal.timestamp = single_start.timestamp = 0;
    single_goal.gear = single_start.gear =
        senseAD::ControlCommand::GEAR::GEAR_NONE;
    single_goal.turn_signal = single_start.turn_signal =
        senseAD::ControlCommand::TURN_SIGNAL::TURN_SIGNAL_NONE;

    for (int i = 0; i < n; i++) {
        senseAD::TrajectoryPoint p;
        fin >> p.position.x >> p.position.y;
        p.direction.x = 1;
        p.position.y = 0;
        base_path.push_back(p);
    }
    EXPECT_EQ(senseAD::pp::g_pp_conf.Init("./config/pp_config.ini"),
              senseAD::AD_SUCCESS);
    auto core_conf = senseAD::pp::g_pp_conf["pp_core"];
    std::string pp_type = core_conf["pp_core"];

    senseAD::pp::RelaxVelocityPlanner vplanner;
    EXPECT_EQ(vplanner.Init(), senseAD::AD_SUCCESS);

    float target_speed = 5.1;
    memset(&senseAD::pp::g_vehicle_state, 0,
           sizeof(senseAD::pp::g_vehicle_state));

    vplanner.Update(senseAD::pp::VPPurpose::INVALID_PURPOSE,
                    base_path.size() - 1, target_speed);
    EXPECT_EQ(vplanner.PlanVelocity(&base_path), senseAD::AD_SUCCESS);

    vplanner.Update(senseAD::pp::VPPurpose::KEEP_UP_NON_ZERO_VELOCITY,
                    base_path.size() - 1, target_speed);
    EXPECT_EQ(vplanner.PlanVelocity(&base_path), senseAD::AD_SUCCESS);

    vplanner.Update(senseAD::pp::VPPurpose::EMERGE_STOP, base_path.size() - 1,
                    target_speed);
    EXPECT_EQ(vplanner.PlanVelocity(&base_path), senseAD::AD_SUCCESS);

    vplanner.Update(senseAD::pp::VPPurpose::REMAIN_TILL_CACHE_GOAL,
                    base_path.size() - 1, target_speed);
    EXPECT_EQ(vplanner.PlanVelocity(&base_path), senseAD::AD_SUCCESS);
}

TEST(RRTPlanner, SGDSmoother) {
    EXPECT_EQ(senseAD::pp::g_pp_conf.Init("./config/pp_config.ini"),
              senseAD::AD_SUCCESS);
    std::vector<senseAD::TrajectoryPoint> tmptp;
    std::vector<senseAD::TrajectoryPoint> fn;
    std::string pp_test_data_dir = "./path_planning_test_data/";
    // load test case
    std::ifstream fin(pp_test_data_dir + "sgdsmoother1.txt", std::ios::in);
    int n;
    cv::Point2f endir, goal, direction;
    fin >> n >> endir.x >> endir.y >> goal.x >> goal.y >> direction.x >>
        direction.y;
    std::vector<cv::Point2f> path;
    path.resize(n);
    for (int32_t ii = 0; ii < n; ii++) {
        cv::Point2f pt;
        fin >> pt.x >> pt.y;
        path[n - 1 - ii] = pt;
    }
    for (size_t ii = 0; ii < path.size(); ii++) {
        senseAD::TrajectoryPoint tp;
        tp.position = path[ii];
        if (ii == path.size() - 1) {
            tp.direction = direction;
            senseAD::pp::utils::Normalize2Dvect(&tp.direction);
        } else if (ii == 0) {
            tp.direction = endir;
            senseAD::pp::utils::Normalize2Dvect(&tp.direction);
        } else {
            tp.direction =
                0.5f * ((path[ii + 1] - path[ii]) + (path[ii] - path[ii - 1]));
            senseAD::pp::utils::Normalize2Dvect(&tp.direction);
        }
        tmptp.push_back(tp);
        AD_LDEBUG(PATH_PLANNING)
            << "Schneidersmooth/QP Point " << ii << " Postion: " << tp.position
            << " Direction: " << tp.direction;
    }
    senseAD::pp::QuintSplineSGDSmoother quintspline_smoother_;
    quintspline_smoother_.SetData(tmptp);
    quintspline_smoother_.Fit();
    fn = quintspline_smoother_.SamplePoints(0.2);
    // Intentionally use std::cout for easy parse
    for (size_t i = 0; i < fn.size(); i++) {
        std::cout << "Result " << i << " " << fn[i].position << " "
                  << fn[i].direction << " " << fn[i].velocity << " "
                  << fn[i].theta << " " << fn[i].curvature << " "
                  << fn[i].sum_distance << std::endl;
    }
}

TEST(RRTPlanner, SGDSmootherWithDirection) {
    EXPECT_EQ(senseAD::pp::g_pp_conf.Init("./config/pp_config.ini"),
              senseAD::AD_SUCCESS);
    std::vector<senseAD::TrajectoryPoint> tmptp;
    std::vector<senseAD::TrajectoryPoint> fn;
    std::string pp_test_data_dir = "./path_planning_test_data/";
    // load test case
    std::ifstream fin(pp_test_data_dir + "sgdsmoother4.txt", std::ios::in);
    int n;
    fin >> n;
    for (int32_t ii = 0; ii < n; ii++) {
        senseAD::TrajectoryPoint tp;
        fin >> tp.position.x >> tp.position.y >> tp.direction.x >>
            tp.direction.y;
        tmptp.push_back(tp);
    }
    senseAD::pp::QuintSplineSGDSmoother quintspline_smoother_;
    quintspline_smoother_.Init();
    quintspline_smoother_.SetData(tmptp);
    quintspline_smoother_.Fit();
    fn = quintspline_smoother_.SamplePoints(0.2);
    // Intentionally use std::cout for easy parse
    for (size_t i = 0; i < fn.size(); i++) {
        std::cout << "Result " << i << " " << fn[i].position << " "
                  << fn[i].direction << " " << fn[i].velocity << " "
                  << fn[i].theta << " " << fn[i].curvature << " "
                  << fn[i].sum_distance << std::endl;
    }
}

TEST(RRTPlanner, solve_quartic) {
    double a = -15.3068;
    double b = -2.4613;
    double c = 3.67305e-34;
    double d = -0;
    std::complex<double> result[4];
    senseAD::pp::utils::solve_quartic(result, a, b, c, d);
    std::stringstream ss;
    for (int i = 0; i < 4; i++) {
        if (i != 0) {
            ss << ",";
        }
        ss << result[i];
    }
    std::cout << "[" << a << ", " << b << ", " << c << ", " << d
              << "], Got Solutions " << ss.str() << std::endl;
}

TEST(RRTPlanner, RRTFullTest) {
    EXPECT_EQ(senseAD::pp::g_pp_conf.Init("./config/pp_config.ini"),
              senseAD::AD_SUCCESS);
    auto core_conf = senseAD::pp::g_pp_conf["pp_core"];
    std::string pp_type = core_conf["pp_core"];
    if (pp_type != "RRTCore") {
        std::cout << "PP Type is not RRTCore, return directly" << std::endl;
        return;
    }
    auto planner_core = senseAD::pp::PlannerCore::CreatePlanner(pp_type);
    EXPECT_NE(planner_core, nullptr);
    planner_core->RegisterWarpPointPlug(
        [](cv::Point2f *point) { return senseAD::AD_SUCCESS; });
    EXPECT_EQ(planner_core->Init(), senseAD::AD_SUCCESS);
    std::string pp_test_data_dir = "./path_planning_test_data/";
    // load test case
    std::ifstream fin(pp_test_data_dir + "rrtfull1.txt", std::ios::in);
    cv::Point2f endir, goal, direction;
    float goal_velocity, vp_s;
    fin >> endir.x >> endir.y >> goal.x >> goal.y >> direction.x >> direction.y >> goal_velocity >> vp_s;
    std::vector<senseAD::TrajectoryPoint> base_path, fn, cached_path;
    std::vector<std::vector<int>> pred_vect;
    int n, m, p;
    fin >> n;
    for (int32_t ii = 0; ii < n; ii++) {
        senseAD::TrajectoryPoint tp;
        fin >> tp.position.x >> tp.position.y >> tp.direction.x >>
            tp.direction.y >> tp.theta >> tp.sum_distance;
        base_path.push_back(tp);
    }
    std::vector<cv::Point2f> randpts;
    fin >> m;
    for (int32_t ii = 0; ii < m; ii++) {
        cv::Point2f aa;
        fin >> aa.x >> aa.y;
        randpts.push_back(aa);
    }
    fin >> p;
    for (int32_t ii = 0; ii < p; ii++) {
        int q, k;
        std::vector<int> kk;
        fin >> q;
        for (int32_t jj = 0; jj < q; jj++) {
            fin >> k;
            kk.push_back(k);
        }
        pred_vect.push_back(kk);
    }
    std::string grid_filename;
    fin >> grid_filename;
    float veh_v, veh_y, veh_a;
    fin >> veh_v >> veh_y >> veh_a;
    senseAD::pp::g_vehicle_state.velocity = veh_v;
    senseAD::pp::g_vehicle_state.yaw_rate = veh_y;
    senseAD::pp::g_vehicle_state.acceleration = veh_a;
    senseAD::pp::SceneParser scene_parser_;
    scene_parser_.Init();
    scene_parser_.ManuallySetMaps(pp_test_data_dir + grid_filename, pred_vect);
    senseAD::pp::g_nn_tool.Init();
    senseAD::pp::g_nn_tool.UpdateData(base_path);
    auto func_is_free = std::bind(&senseAD::pp::SceneParser::is_free, &scene_parser_,
                                  std::placeholders::_1, std::placeholders::_2);
    planner_core->RegisterCheckCollisionPlug(func_is_free);
    auto func_its_risk =
        std::bind(&senseAD::pp::SceneParser::its_risk, &scene_parser_, std::placeholders::_1,
                  std::placeholders::_2);
    planner_core->RegisterCheckSceneRiskPlug(func_its_risk);
    auto rrt_core_ = std::dynamic_pointer_cast<senseAD::pp::RRTCore>(planner_core);
    auto func_frenet_collision = std::bind(
        &senseAD::pp::SceneParser::sdt_is_free, &scene_parser_,
        std::placeholders::_1, std::placeholders::_2, std::placeholders::_3,
        std::placeholders::_4, std::placeholders::_5, std::placeholders::_6,
        std::placeholders::_7);
    rrt_core_->RegisterFrenetCollisionPlug(func_frenet_collision);

    auto func_frenet_risk = std::bind(
        &senseAD::pp::SceneParser::sdt_its_risk, &scene_parser_,
        std::placeholders::_1, std::placeholders::_2, std::placeholders::_3,
        std::placeholders::_4, std::placeholders::_5, std::placeholders::_6,
        std::placeholders::_7);
    rrt_core_->RegisterFrenetRiskPlug(func_frenet_risk);

    senseAD::TrajectoryPoint single_start, single_goal;
    single_start.position.x = single_start.position.y = 0;
    single_start.direction = endir;
    single_goal.position = goal;
    single_goal.direction = direction;
    EXPECT_EQ(planner_core->Update(
                  base_path, single_start, single_goal,
                  senseAD::pp::VPPurpose::KEEP_UP_NON_ZERO_VELOCITY, vp_s,
                  cached_path, senseAD::pp::ReplanFlag::PATH_SPEED_REPLAN),
              senseAD::AD_SUCCESS);
    std::dynamic_pointer_cast<senseAD::pp::RRTCore>(planner_core)
        ->SetRandomPointsForTest(randpts, false);
    std::dynamic_pointer_cast<senseAD::pp::RRTCore>(planner_core)
        ->SetBuildTreeTestMode(true);
    EXPECT_EQ(planner_core->Plan(&fn), senseAD::AD_SUCCESS);
    for (size_t i = 0; i < fn.size(); i++) {
        std::cout << "RRT FULL Result " << i << " " << fn[i].position << " "
                  << fn[i].direction << " " << fn[i].velocity << " "
                  << fn[i].theta << " " << fn[i].curvature << " "
                  << fn[i].sum_distance << std::endl;
    }
}
